/** @type {import('next').NextConfig} */
const nextConfig = {
  poweredByHeader: false,
  // Owners upload small images (up to 1 MB each) through the dashboard.
  experimental: { serverActions: { bodySizeLimit: "3mb" } },
  // Development only: lets the .localtest.me / .localhost client addresses load Next.js development files without warnings.
  allowedDevOrigins: ["*.localtest.me", "*.localhost"],
  serverExternalPackages: ["pg"],
  async headers() {
    return [{
      source: "/(.*)",
      headers: [
        { key: "X-Content-Type-Options", value: "nosniff" },
        { key: "X-Frame-Options", value: "DENY" },
        { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      ],
    }, {
      // The owner's preview is shown inside the editor. Only this one page, and only by this same website (it needs an owner login anyway).
      source: "/dashboard/preview",
      headers: [
        { key: "X-Frame-Options", value: "SAMEORIGIN" },
        { key: "Content-Security-Policy", value: "frame-ancestors 'self'" },
      ],
    }];
  },
};
export default nextConfig;

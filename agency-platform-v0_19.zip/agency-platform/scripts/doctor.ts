import { existsSync } from "node:fs";
import { join } from "node:path";
import pg from "pg";
import { loadEnv } from "../src/config/env";
import { decryptSecret } from "../src/crypto/secrets";
import { CONTROL_MIGRATIONS_DIR, TENANT_MIGRATIONS_DIR } from "../src/db/paths";
import { listMigrationFiles, OBSOLETE_MIGRATIONS } from "../src/db/migrate";

/** Checks everything that stops websites from opening and says how to fix it. Run: npm run doctor */
let problems = 0;
const ok = (m: string) => console.log(`  OK       ${m}`);
const bad = (m: string, fix: string) => { problems++; console.log(`  PROBLEM  ${m}\n           Fix: ${fix}`); };
const files = listMigrationFiles;

console.log("\nChecking your installation...\n");
const major = Number(process.versions.node.split(".")[0]);
major >= 20 ? ok(`Node.js ${process.versions.node}`) : bad(`Node.js ${process.versions.node} is too old`, "install Node.js 20 or newer");

let env;
try { env = loadEnv(); ok("The settings in .env are valid"); }
catch (e) { bad(`The settings in .env are not valid: ${(e as Error).message}`, "copy .env.development.example to .env and fill in the values (npm run secrets:generate makes the key)"); process.exit(1); }

for (const f of OBSOLETE_MIGRATIONS) for (const dir of [TENANT_MIGRATIONS_DIR, CONTROL_MIGRATIONS_DIR]) {
  if (existsSync(join(dir, f))) console.log(`  NOTE     An old file is left over from a previous version: ${join(dir, f)}. It is ignored; you can delete it.`);
}

const control = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 1, connectionTimeoutMillis: 5000 });
try {
  const v = (await control.query("SHOW server_version")).rows[0].server_version;
  ok(`Connected to the main database (PostgreSQL ${v})`);
  const have = new Set((await control.query("SELECT name FROM schema_migrations").catch(() => ({ rows: [] as { name: string }[] }))).rows.map((r) => r.name));
  const missing = files(CONTROL_MIGRATIONS_DIR).filter((f) => !have.has(f));
  missing.length ? bad(`The main database is missing updates: ${missing.join(", ")}`, "restart the app (it updates itself) or run: npm run db:migrate") : ok("The main database is up to date");

  const tenants = (await control.query(`SELECT t.slug, t.status, d.conn_encrypted FROM tenants t LEFT JOIN tenant_databases d ON d.tenant_id = t.id WHERE t.status <> 'archived' ORDER BY t.slug`)).rows;
  if (tenants.length === 0) console.log("  NOTE     No clients yet. Create one in the admin (Clients > Add a new client).");
  for (const t of tenants) {
    if (!t.conn_encrypted) { bad(`Client "${t.slug}" has no database`, "open the client in the admin and press Retry setup"); continue; }
    const pool = new pg.Pool({ connectionString: decryptSecret(t.conn_encrypted, env.SECRETS_MASTER_KEY), max: 1, connectionTimeoutMillis: 5000 });
    try {
      const done = new Set((await pool.query("SELECT name FROM schema_migrations")).rows.map((r) => r.name));
      const miss = files(TENANT_MIGRATIONS_DIR).filter((f) => !done.has(f));
      miss.length ? bad(`Client "${t.slug}" database is missing updates: ${miss.join(", ")}`, "restart the app or run: npm run db:migrate") : ok(`Client "${t.slug}" database is up to date`);
      const old = (await pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ('products','orders','categories','campaigns','product_images','order_items','discount_codes','shop_settings') ORDER BY 1")).rows.map((r) => r.table_name);
      if (old.length) console.log(`  NOTE     Client "${t.slug}" also has older tables (${old.join(", ")}). They are left untouched and are not used; the shop uses its own tables starting with shop_.`);
    } catch (e) { bad(`Cannot open the database of client "${t.slug}": ${(e as Error).message.slice(0, 120)}`, "check that PostgreSQL is running and the SECRETS_MASTER_KEY in .env is the one used when the client was created"); }
    finally { await pool.end().catch(() => {}); }
  }
  const doms = (await control.query(`SELECT d.hostname, d.status, d.is_primary, t.slug FROM domains d JOIN tenants t ON t.id = d.tenant_id WHERE d.status <> 'removed' ORDER BY t.slug, d.hostname`)).rows;
  console.log("\nWeb addresses (open these in the browser):");
  const port = process.env.PORT ?? "3000";
  console.log(`  Platform home and admin:  http://localhost:${port}/   and   http://localhost:${port}/admin`);
  for (const d of doms) console.log(`  ${d.status === "verified" ? "OK     " : "WAITING"}  http://${d.hostname}:${port}/   (client ${d.slug}; owner login: /dashboard)${d.status === "verified" ? "" : "   <- not verified yet, so it shows 'Site not found'"}`);
  if (doms.some((d) => d.status === "verified" && d.hostname.endsWith(".localtest.me"))) console.log("  NOTE     *.localtest.me names need an internet connection. *.localhost names work offline.");
  if (doms.some((d) => d.status === "verified" && !d.hostname.endsWith(".localhost") && !d.hostname.endsWith(".localtest.me"))) console.log("  NOTE     A real domain name such as shop.com only opens on this computer if you add it to your hosts file (127.0.0.1 shop.com).");
} catch (e) {
  bad(`Cannot connect to the main database: ${(e as Error).message}`, "start PostgreSQL and check CONTROL_DATABASE_URL (host, port, user, password, database) in .env");
} finally { await control.end().catch(() => {}); }

console.log(problems ? `\n${problems} problem${problems > 1 ? "s" : ""} found. Fix them, then run npm run doctor again.\n` : "\nEverything looks fine.\n");
process.exit(problems ? 1 : 0);

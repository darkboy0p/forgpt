import pg from "pg";
import readline from "node:readline";
import { loadEnv } from "../src/config/env";
import { createPlatformAdmin, AdminError } from "../src/auth/admins";

/** Creates a platform administrator. The password is typed here (hidden) and never stored in any file. */
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: Boolean(process.stdin.isTTY) });
const queue: string[] = [];
let waiting: ((line: string) => void) | null = null;
let muted = false;
const rlInternal = rl as unknown as { _writeToOutput: (s: string) => void };
const echo = rlInternal._writeToOutput.bind(rl);
rlInternal._writeToOutput = (s) => { if (!muted) echo(s); else if (/[\r\n]/.test(s)) echo("\r\n"); };
rl.on("line", (line) => { if (waiting) { const w = waiting; waiting = null; w(line); } else queue.push(line); });
rl.on("close", () => { if (waiting) { const w = waiting; waiting = null; w(""); } });

function ask(question: string, hidden = false): Promise<string> {
  process.stdout.write(question);
  muted = hidden && Boolean(process.stdin.isTTY);
  return new Promise((resolve) => {
    const done = (line: string) => { muted = false; resolve(line); };
    const queued = queue.shift();
    if (queued !== undefined) done(queued); else waiting = done;
  });
}

const env = loadEnv();
const pool = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 1 });
try {
  const email = await ask("Admin email: ");
  const password = await ask("Password (at least 12 characters, hidden): ", true);
  const again = await ask("Type the password again: ", true);
  if (password !== again) throw new AdminError("The two passwords did not match.");
  const admin = await createPlatformAdmin(pool, email, password);
  console.log(`Created administrator ${admin.email}. You can now log in at /admin/login.`);
} catch (err) {
  if (err instanceof AdminError) { console.error(`Could not create admin: ${err.message}`); process.exitCode = 1; }
  else throw err;
} finally { rl.close(); await pool.end(); }

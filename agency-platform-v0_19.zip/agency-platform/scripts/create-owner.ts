import pg from "pg";
import { loadEnv } from "../src/config/env";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { createStaffOwner, StaffError } from "../src/store/auth";

/** Usage: npm run owner:create -- <client-short-name> <owner-email>
 *  Creates the client's own dashboard login and prints a one-time temporary password. */
const [slug, email] = process.argv.slice(2);
if (!slug || !email) { console.error("Usage: npm run owner:create -- <client-short-name> <owner-email>"); process.exit(1); }
const env = loadEnv();
const control = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 2 });
const mgr = new TenantConnectionManager(control, env.SECRETS_MASTER_KEY);
try {
  const t = (await control.query("SELECT id FROM tenants WHERE slug = $1 AND status IN ('active','suspended')", [slug])).rows[0];
  if (!t) throw new StaffError(`No ready client named "${slug}".`);
  const owner = await mgr.withAdminPool(t.id, (pool) => createStaffOwner(pool, email));
  await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ('command-line','owner.created',$1,$2)", [t.id, JSON.stringify({ email: owner.email })]);
  console.log(`Owner login created for ${owner.email}.\nTemporary password (shown once, copy it now): ${owner.tempPassword}\nThey must choose their own password at first sign-in.`);
} catch (err) {
  if (err instanceof StaffError) { console.error(`Could not create owner: ${err.message}`); process.exitCode = 1; } else throw err;
} finally { await mgr.closeAll(); await control.end(); }

import pg from "pg";
import { loadEnv } from "../src/config/env";
import { normalizeHostname } from "../src/tenancy/hostname";

/**
 * DEVELOPMENT ONLY shortcut: marks a domain as verified WITHOUT checking DNS.
 * Real DNS ownership verification is a later phase. Refuses to run outside development.
 */
const env = loadEnv();
if (env.APP_ENV !== "development") throw new Error("verify-domain is only allowed when APP_ENV=development.");
const host = normalizeHostname(process.argv[2] ?? "");
if (!host) throw new Error("Usage: npm run domain:verify-dev -- <hostname>");
const pool = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 1 });
try {
  const r = await pool.query("UPDATE domains SET status='verified', verified_at=now() WHERE hostname=$1 AND status<>'removed'", [host]);
  console.log(r.rowCount ? `Marked ${host} as verified (dev shortcut).` : `No registered domain named ${host}.`);
} finally { await pool.end(); }

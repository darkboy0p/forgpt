import pg from "pg";
import { loadEnv } from "../src/config/env";
import { createProvider } from "../src/provisioning/providers/index";
import { provisionTenant } from "../src/provisioning/provisionTenant";

const env = loadEnv();
if (env.APP_ENV === "production") throw new Error("Demo data must never be created in production.");
const control = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 2 });
try {
  const provider = createProvider(env);
  const r = await provisionTenant(control, provider, env.SECRETS_MASTER_KEY, {
    slug: "demo-starter", businessName: "Demo Starter Shop", packageTier: 1, templateKey: "starter", hostname: "demo-starter.localtest.me",
  });
  console.log("Provisioned:", r.databaseName, "| steps:", r.steps.join(" > "));
  console.log("Domain is PENDING until verified (verification arrives in a later phase).");
} finally { await control.end(); }

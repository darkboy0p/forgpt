import { generateMasterKey } from "../src/crypto/secrets";
console.log("Copy this line into your .env file (keep it private, never share it):\n");
console.log(`SECRETS_MASTER_KEY=${generateMasterKey()}`);

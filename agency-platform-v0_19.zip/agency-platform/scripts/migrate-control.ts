import pg from "pg";
import { fileURLToPath } from "node:url";
import { join, dirname } from "node:path";
import { loadEnv } from "../src/config/env";
import { runMigrations } from "../src/db/migrate";
import { migrateAllTenants } from "../src/provisioning/migrateTenants";

const env = loadEnv();
const pool = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 1 });
const dir = join(dirname(fileURLToPath(import.meta.url)), "../migrations/control");
try {
  const applied = await runMigrations(pool, dir);
  console.log(applied.length ? `Applied: ${applied.join(", ")}` : "Control database already up to date.");
  const reports = await migrateAllTenants(pool, env.SECRETS_MASTER_KEY);
  for (const r of reports) console.log(r.error ? `Client ${r.slug}: FAILED (${r.error})` : r.applied.length ? `Client ${r.slug}: applied ${r.applied.join(", ")}` : `Client ${r.slug}: up to date`);
  if (reports.some((r) => r.error)) process.exitCode = 1;
} finally { await pool.end(); }

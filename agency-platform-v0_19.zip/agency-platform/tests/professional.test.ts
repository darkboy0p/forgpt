import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { changePackage } from "../src/clients/packages";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { parseSiteConfig, DEFAULT_SITE_CONFIG } from "../src/config/siteConfig";
import { entitlementsFor, entitlementsFromValues, applyEntitlements } from "../src/config/entitlements";
import { defaultValues } from "../src/packages/features";
import { buildConfigFromForm, saveDraft, publishDraft, loadEditorState, type EditorInput } from "../src/store/siteEditor";
import { submitInquiry, listInquiries, markInquiry, countNewInquiries, INQUIRIES_PER_IP_PER_HOUR, INQUIRIES_PER_SITE_PER_DAY } from "../src/store/inquiries";

// A package with no design extras (an administrator can switch any feature off per package). Tier 1 itself now includes them.
const T1 = entitlementsFromValues({ ...defaultValues(1), branding_advanced: false, layout_options: false }), T2 = entitlementsFor(2);
const form = (over: Partial<EditorInput> = {}): EditorInput => ({
  primary: "#0a7d4b", heroTitle: "Hello", heroSubtitle: "", about: "About us", phone: "01700-000000", whatsapp: "", address: "",
  sectionOrder: { hero: "1", about: "2", services: "3", contact: "4" }, ...over,
});

describe("site config v2", () => {
  it("accepts the new fields and still accepts an old Starter-era config", () => {
    const r = parseSiteConfig({ theme: { primary: "#112233", accent: "#aabbcc", font: "serif", buttonStyle: "pill" }, layout: { heroStyle: "light" },
      sections: ["hero", "services", "testimonials", "inquiry", "contact"],
      content: { services: [{ name: "Cleaning", description: "Deep clean", price: "৳500" }], testimonials: [{ name: "Rahim", quote: "Great" }] }, analytics: { ga4: "G-ABC123XYZ" } });
    expect(r.valid).toBe(true);
    const old = parseSiteConfig({ theme: { primary: "#1f6feb" }, sections: ["hero", "about", "contact"], content: { heroTitle: "Hi" } });
    expect(old.valid).toBe(true);
    expect(old.config.content.services).toEqual([]);
    expect(old.config.theme.font).toBe("sans");
  });
  it("rejects unsafe or malformed new values", () => {
    for (const bad of [{ theme: { accent: "red" } }, { theme: { font: "Comic Sans" } }, { theme: { buttonStyle: "x" } }, { layout: { heroStyle: "wild" } },
      { analytics: { ga4: "UA-1; alert(1)" } }, { content: { services: [{ name: "" }] } }, { content: { testimonials: [{ name: "a" }] } },
      { content: { services: Array.from({ length: 13 }, (_, i) => ({ name: "s" + i })) } }, { sections: ["hero", "payments"] }])
      expect(parseSiteConfig(bad).valid).toBe(false);
  });
});

describe("package entitlements", () => {
  const rich = parseSiteConfig({ theme: { primary: "#112233", accent: "#aabbcc", font: "serif", buttonStyle: "pill" }, layout: { heroStyle: "light" },
    sections: ["hero", "testimonials", "inquiry", "services", "contact"],
    content: { services: Array.from({ length: 9 }, (_, i) => ({ name: "S" + i })), testimonials: [{ name: "A", quote: "Good" }] }, analytics: { ga4: "G-ABC123XYZ" } }).config;
  it("Tier 1 sees only what its package includes (nothing is deleted)", () => {
    const v = applyEntitlements(rich, T1);
    expect(v.sections).toEqual(["hero", "services", "contact"]);
    expect(v.content.services).toHaveLength(6);
    expect(v.content.testimonials).toEqual([]);
    expect(v.theme).toMatchObject({ primary: "#112233", accent: DEFAULT_SITE_CONFIG.theme.accent, font: "sans", buttonStyle: "rounded" });
    expect(v.layout.heroStyle).toBe("solid");
    expect(v.analytics.ga4).toBeUndefined();
    expect(rich.content.services).toHaveLength(9); // original untouched
  });
  it("Tier 2 and above see everything", () => {
    for (const tier of [2, 3, 4, 5]) expect(applyEntitlements(rich, entitlementsFor(tier))).toEqual(rich);
  });
  it("never leaves a site with no sections", () => {
    expect(applyEntitlements({ ...rich, sections: ["testimonials", "inquiry"] }, T1).sections.length).toBeGreaterThan(0);
  });
});

describe("editor enforcement on the server", () => {
  it("rejects anything a Tier 1 package does not include, even if the request is forged", () => {
    const err = (o: Partial<EditorInput>) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, T1); return r.ok ? "ok" : r.error; };
    expect(err({ sectionOrder: { hero: "1", testimonials: "2" } })).toBe("not_in_package");
    expect(err({ sectionOrder: { hero: "1", inquiry: "2" } })).toBe("not_in_package");
    expect(err({ accent: "#ff0000" })).toBe("not_in_package");
    expect(err({ font: "serif" })).toBe("not_in_package");
    expect(err({ heroStyle: "light" })).toBe("not_in_package");
    expect(err({ ga4: "G-ABC123XYZ" })).toBe("not_in_package");
    expect(err({ testimonials: [{ name: "A", quote: "Nice" }] })).toBe("not_in_package");
    expect(err({ services: Array.from({ length: 7 }, (_, i) => ({ name: "S" + i, description: "", price: "" })) })).toBe("not_in_package");
    expect(err({ services: [{ name: "One", description: "", price: "" }] })).toBe("ok");
    expect(err({ ga4: "" })).toBe("ok"); // an empty analytics field is not a feature request
  });
  it("accepts the same input for Tier 2 and validates choices", () => {
    const ok = buildConfigFromForm(form({ accent: "#ff8800", font: "rounded", buttonStyle: "square", heroStyle: "light", ga4: "g-abc123xyz",
      sectionOrder: { hero: "1", testimonials: "2", inquiry: "3", contact: "4" }, testimonials: [{ name: "A", quote: "Nice" }, { name: "", quote: "" }],
      services: [{ name: "Cut", description: "Hair", price: "৳300" }] }), DEFAULT_SITE_CONFIG, T2);
    expect(ok.ok).toBe(true);
    if (ok.ok) { expect(ok.config.analytics.ga4).toBe("G-ABC123XYZ"); expect(ok.config.content.testimonials).toHaveLength(1); expect(ok.config.theme.font).toBe("rounded"); }
    const e = (o: Partial<EditorInput>) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, T2); return r.ok ? "ok" : r.error; };
    expect(e({ accent: "red;}" })).toBe("invalid_color");
    expect(e({ font: "Comic Sans" })).toBe("invalid_choice");
    expect(e({ buttonStyle: "x" })).toBe("invalid_choice");
    expect(e({ heroStyle: "x" })).toBe("invalid_choice");
    expect(e({ ga4: "UA-12345" })).toBe("invalid_analytics");
    expect(e({ ga4: "G-1'); alert(1);//" })).toBe("invalid_analytics");
    expect(e({ services: [{ name: "", description: "orphan text", price: "" }] })).toBe("incomplete_row");
    expect(e({ testimonials: [{ name: "Only name", quote: "" }] })).toBe("incomplete_row");
    expect(e({ services: Array.from({ length: 13 }, (_, i) => ({ name: "S" + i, description: "", price: "" })) })).toBe("not_in_package");
  });
  it("keeps stored optional values when the form does not include them (downgrade-safe)", () => {
    const base = parseSiteConfig({ theme: { accent: "#aabbcc", font: "serif" }, content: { testimonials: [{ name: "A", quote: "Keep me" }] }, analytics: { ga4: "G-KEEP1234" } }).config;
    const r = buildConfigFromForm(form(), base, T1);
    expect(r.ok).toBe(true);
    if (r.ok) { expect(r.config.theme.accent).toBe("#aabbcc"); expect(r.config.content.testimonials).toHaveLength(1); expect(r.config.analytics.ga4).toBe("G-KEEP1234"); }
  });
  it("stores script-like text as plain text", () => {
    const r = buildConfigFromForm(form({ services: [{ name: "<img src=x onerror=alert(1)>", description: "", price: "" }] }), DEFAULT_SITE_CONFIG, T2);
    expect(r.ok && r.config.content.services[0]!.name).toBe("<img src=x onerror=alert(1)>");
  });
});

describe("inquiries, package changes and downgrades", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  let mgr: TenantConnectionManager;
  const actor = "owner@example.com";
  const poolOf = async (slug: string) => mgr.getPool((await w.control.query("SELECT id FROM tenants WHERE slug=$1", [slug])).rows[0].id);
  const good = { name: "Karim", phone: "01711-222333", email: "", message: "I need a quotation for 20 chairs", ip: "198.51.100.1" };
  beforeAll(async () => {
    w = await createTestWorld();
    mgr = new TenantConnectionManager(w.control, w.masterKey);
    await createClient(w.control, w.provider, w.masterKey, { businessName: "Acme", slug: "acme", packageTier: 1, templateKey: "starter", hostname: "acme.example.com" }, actor);
    await createClient(w.control, w.provider, w.masterKey, { businessName: "Beta", slug: "beta", packageTier: 1, templateKey: "starter", hostname: "beta.example.com" }, actor);
  }, 180_000);
  afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

  it("stores a valid inquiry only in that client's own database", async () => {
    const a = await poolOf("acme");
    expect(await submitInquiry(a, good)).toEqual({ ok: true });
    expect((await listInquiries(a))[0]).toMatchObject({ name: "Karim", phone: "01711-222333", email: null, status: "new" });
    expect((await listInquiries(await poolOf("beta"))).length).toBe(0);
    expect(await countNewInquiries(a)).toBe(1);
  });
  it("validates every field", async () => {
    const a = await poolOf("acme");
    const t = async (o: object) => { const r = await submitInquiry(a, { ...good, ip: "203.0.113." + Math.floor(Math.random() * 200), ...o }); return r.ok ? "ok" : r.error; };
    expect(await t({ name: "K" })).toBe("invalid_name");
    expect(await t({ phone: "", email: "" })).toBe("invalid_contact");
    expect(await t({ phone: "<b>1</b>" })).toBe("invalid_contact");
    expect(await t({ phone: "", email: "not-an-email" })).toBe("invalid_contact");
    expect(await t({ phone: "", email: "k@example.com" })).toBe("ok");
    expect(await t({ message: "hi" })).toBe("invalid_message");
    expect(await t({ message: "x".repeat(1001) })).toBe("invalid_message");
  });
  it("ignores bots that fill the hidden field, and rate-limits per visitor and per site", async () => {
    const b = await poolOf("beta");
    expect(await submitInquiry(b, { ...good, honeypot: "http://spam.example" })).toEqual({ ok: true });
    expect((await listInquiries(b)).length).toBe(0);
    const now = new Date();
    for (let i = 0; i < INQUIRIES_PER_IP_PER_HOUR; i++) expect((await submitInquiry(b, { ...good, ip: "192.0.2.50" }, now)).ok).toBe(true);
    expect(await submitInquiry(b, { ...good, ip: "192.0.2.50" }, now)).toEqual({ ok: false, error: "rate_limited" });
    expect((await submitInquiry(b, { ...good, ip: "192.0.2.51" }, now)).ok).toBe(true);
    expect((await submitInquiry(b, { ...good, ip: "192.0.2.50" }, new Date(now.getTime() + 3600_000 + 1000))).ok).toBe(true);
    await b.query("INSERT INTO inquiries (name, message, ip) SELECT 'x', 'filler message', 'ip' || g FROM generate_series(1, $1) g", [INQUIRIES_PER_SITE_PER_DAY]);
    expect(await submitInquiry(b, { ...good, ip: "192.0.2.99" })).toEqual({ ok: false, error: "unavailable" });
  });
  it("marks inquiries handled and refuses bad ids", async () => {
    const a = await poolOf("acme");
    const id = (await listInquiries(a))[0]!.id;
    expect(await markInquiry(a, id, "done")).toBe(true);
    expect((await listInquiries(a)).find((i) => i.id === id)!.status).toBe("done");
    expect(await markInquiry(a, "not-a-uuid", "done")).toBe(false);
    expect(await markInquiry(a, "00000000-0000-0000-0000-000000000000", "done")).toBe(false);
    expect(await markInquiry(a, id, "deleted" as never)).toBe(false);
  });

  it("changes packages with the right rules and an audit trail", async () => {
    const c = (tier: number, tpl: string, ok = false) => changePackage(w.control, "acme", tier, tpl, ok, actor);
    expect(await c(0, "starter")).toEqual({ ok: false, error: "invalid_tier" });
    expect(await c(2, "ecommerce")).toEqual({ ok: false, error: "template_tier_mismatch" }); // built, but needs Package 3
    expect(await c(2, "nope")).toEqual({ ok: false, error: "template_unavailable" });
    expect(await c(1, "professional")).toEqual({ ok: false, error: "template_tier_mismatch" });
    expect(await c(1, "starter")).toEqual({ ok: false, error: "unchanged" });
    expect(await changePackage(w.control, "ghost", 2, "professional", false, actor)).toEqual({ ok: false, error: "not_found" });
    expect(await c(2, "professional")).toMatchObject({ ok: true, downgrade: false });
    expect(await c(1, "starter")).toEqual({ ok: false, error: "downgrade_needs_confirmation" });
    expect((await w.control.query("SELECT package_tier, template_key FROM tenants WHERE slug='acme'")).rows[0]).toEqual({ package_tier: 2, template_key: "professional" });
    expect((await w.control.query("SELECT detail::text d FROM audit_log WHERE action='client.package.changed'")).rows.length).toBe(1);
  });

  it("a downgrade hides Tier 2 features but deletes nothing, and an upgrade restores them", async () => {
    const a = await poolOf("acme");
    const built = buildConfigFromForm(form({ accent: "#ff8800", sectionOrder: { hero: "1", testimonials: "2", inquiry: "3", contact: "4" }, testimonials: [{ name: "Rahim", quote: "Excellent" }] }), DEFAULT_SITE_CONFIG, T2);
    if (!built.ok) throw new Error("invalid");
    await saveDraft(a, built.config, actor);
    expect(await publishDraft(a, actor)).toEqual({ ok: true });
    const stored = (await loadEditorState(a)).live;
    expect(await changePackage(w.control, "acme", 1, "starter", true, actor)).toMatchObject({ ok: true, downgrade: true });
    const seen = applyEntitlements(stored, entitlementsFor(1));
    expect(seen.sections).toEqual(["hero", "contact"]);
    expect(seen.content.testimonials).toEqual([]);
    expect(seen.theme.accent).toBe("#ff8800"); // design choices are in every package now
    expect((await loadEditorState(a)).live.content.testimonials).toHaveLength(1); // still stored
    expect(await changePackage(w.control, "acme", 2, "professional", false, actor)).toMatchObject({ ok: true });
    expect(applyEntitlements((await loadEditorState(a)).live, entitlementsFor(2)).content.testimonials).toHaveLength(1);
  });
});

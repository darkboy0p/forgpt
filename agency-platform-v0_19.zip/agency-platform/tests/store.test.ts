import { listMigrationFiles } from "../src/db/migrate";
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { migrateAllTenants } from "../src/provisioning/migrateTenants";
import {
  createStaffOwner, resetStaffPassword, setStaffActive, attemptStoreLogin, getStaffSession, revokeStaffSession, changeStaffPassword,
  StaffError, STORE_MAX_FAILS_PER_EMAIL, STORE_WINDOW_MS,
} from "../src/store/auth";
import { buildConfigFromForm, loadEditorState, saveDraft, publishDraft, discardDraft, type EditorInput } from "../src/store/siteEditor";
import { SESSION_IDLE_MS } from "../src/auth/sessions";

const form = (over: Partial<EditorInput> = {}): EditorInput => ({
  primary: "#0a7d4b", heroTitle: "Fresh groceries", heroSubtitle: "Delivered daily", about: "Family shop since 2010", phone: "01700-000000", whatsapp: "+880 1700 000000", address: "Mirpur, Dhaka",
  sectionOrder: { contact: "1", hero: "2", about: "3", services: "" }, ...over,
});

describe("owner dashboard logic", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  let mgr: TenantConnectionManager;
  const poolOf = async (slug: string) => mgr.getPool((await w.control.query("SELECT id FROM tenants WHERE slug=$1", [slug])).rows[0].id);
  beforeAll(async () => {
    w = await createTestWorld();
    mgr = new TenantConnectionManager(w.control, w.masterKey);
    for (const [s, h] of [["acme", "acme.example.com"], ["beta", "beta.example.com"]] as const)
      await createClient(w.control, w.provider, w.masterKey, { businessName: s, slug: s, packageTier: 1, templateKey: "starter", hostname: h }, "admin@example.com");
  }, 180_000);
  afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

  it("migrateAllTenants is repeatable and reports per client", async () => {
    const first = await migrateAllTenants(w.control, w.masterKey);
    expect(first.map((r) => r.slug).sort()).toEqual(["acme", "beta"]);
    expect(first.every((r) => !r.error)).toBe(true);
    expect(first.every((r) => r.applied.length === 0)).toBe(true); // provisioning already applied everything
    // simulate an older client database that never received the dashboard migration
    const p = await poolOf("acme");
    await p.query("DROP TABLE staff_sessions, staff_login_attempts, staff_users, site_config_history");
    await p.query("ALTER TABLE site_config DROP COLUMN draft, DROP COLUMN draft_updated_at, DROP COLUMN draft_updated_by, DROP COLUMN published_at, DROP COLUMN published_by");
    await p.query("DELETE FROM schema_migrations WHERE name = '0002_dashboard.sql'");
    const second = await migrateAllTenants(w.control, w.masterKey);
    expect(second.find((r) => r.slug === "acme")!.applied).toEqual(["0002_dashboard.sql"]);
    expect(second.find((r) => r.slug === "beta")!.applied).toEqual([]);
    expect((await migrateAllTenants(w.control, w.masterKey)).every((r) => r.applied.length === 0)).toBe(true);
    expect((await w.control.query("SELECT schema_version FROM tenant_databases d JOIN tenants t ON t.id=d.tenant_id WHERE t.slug='acme'")).rows[0].schema_version).toBe(listMigrationFiles("migrations/tenant").length);
  });

  it("creates an owner with a one-time temporary password stored only as a hash", async () => {
    const p = await poolOf("acme");
    const o = await createStaffOwner(p, "  Owner@Acme.com ");
    expect(o.email).toBe("owner@acme.com");
    expect(o.tempPassword).toHaveLength(16);
    const row = (await p.query("SELECT password_hash, must_change_password FROM staff_users")).rows[0];
    expect(row.password_hash).not.toContain(o.tempPassword);
    expect(row.must_change_password).toBe(true);
    await expect(createStaffOwner(p, "owner@acme.com")).rejects.toThrow(StaffError);
    await expect(createStaffOwner(p, "nope")).rejects.toThrow(/valid email/);
  });

  it("forces a password change; the new password works and old sessions end", async () => {
    const p = await poolOf("acme");
    const o = await createStaffOwner(p, "second@acme.com");
    const l1 = await attemptStoreLogin(p, { email: "second@acme.com", password: o.tempPassword, ip: "198.51.100.1" });
    expect(l1.ok && l1.mustChangePassword).toBe(true);
    if (!l1.ok) return;
    expect(await changeStaffPassword(p, l1.staffId, "wrong", "A-brand-new-pass-1", l1.token)).toMatchObject({ ok: false, error: "wrong_password" });
    expect(await changeStaffPassword(p, l1.staffId, o.tempPassword, o.tempPassword, l1.token)).toMatchObject({ ok: false, error: "same_password" });
    expect(await changeStaffPassword(p, l1.staffId, o.tempPassword, "short", l1.token)).toMatchObject({ ok: false, error: "weak_password" });
    const other = await attemptStoreLogin(p, { email: "second@acme.com", password: o.tempPassword, ip: "198.51.100.2" });
    expect(await changeStaffPassword(p, l1.staffId, o.tempPassword, "A-brand-new-pass-1", l1.token)).toEqual({ ok: true });
    expect((await getStaffSession(p, l1.token))?.mustChangePassword).toBe(false);
    if (other.ok) expect(await getStaffSession(p, other.token)).toBeNull();
    expect((await attemptStoreLogin(p, { email: "second@acme.com", password: o.tempPassword, ip: "198.51.100.3" })).ok).toBe(false);
    expect((await attemptStoreLogin(p, { email: "second@acme.com", password: "A-brand-new-pass-1", ip: "198.51.100.4" })).ok).toBe(true);
  });

  it("gives one generic answer and locks after repeated failures", async () => {
    const p = await poolOf("acme");
    await createStaffOwner(p, "lock@acme.com");
    expect(await attemptStoreLogin(p, { email: "ghost@acme.com", password: "whatever-pass-123", ip: "203.0.113.1" })).toEqual({ ok: false, reason: "invalid" });
    const t0 = new Date();
    for (let i = 0; i < STORE_MAX_FAILS_PER_EMAIL; i++) await attemptStoreLogin(p, { email: "lock@acme.com", password: "bad-pass-" + i, ip: `192.0.2.${i}` }, t0);
    expect(await attemptStoreLogin(p, { email: "lock@acme.com", password: "bad", ip: "192.0.2.77" }, t0)).toEqual({ ok: false, reason: "rate_limited" });
    expect((await attemptStoreLogin(p, { email: "lock@acme.com", password: "bad", ip: "192.0.2.77" }, new Date(t0.getTime() + STORE_WINDOW_MS + 1000))).ok).toBe(false);
  });

  it("a login or session from one client can never work on another client", async () => {
    const a = await poolOf("acme"), b = await poolOf("beta");
    const o = await createStaffOwner(a, "shared@example.com");
    const la = await attemptStoreLogin(a, { email: "shared@example.com", password: o.tempPassword, ip: "198.51.100.9" });
    if (!la.ok) throw new Error("login failed");
    expect((await getStaffSession(a, la.token))?.email).toBe("shared@example.com");
    expect(await getStaffSession(b, la.token)).toBeNull();                                      // token unknown to beta
    expect(await attemptStoreLogin(b, { email: "shared@example.com", password: o.tempPassword, ip: "198.51.100.9" })).toEqual({ ok: false, reason: "invalid" }); // account unknown to beta
    expect((await b.query("SELECT count(*) AS c FROM staff_users")).rows[0].c).toBe(0);
  });

  it("sessions expire, logout revokes, reset and deactivation end sessions", async () => {
    const p = await poolOf("acme");
    const o = await createStaffOwner(p, "life@acme.com");
    const t0 = new Date();
    const s1 = await attemptStoreLogin(p, { email: "life@acme.com", password: o.tempPassword, ip: "198.51.100.20" }, t0);
    if (!s1.ok) throw new Error("login failed");
    expect(await getStaffSession(p, s1.token, new Date(t0.getTime() + SESSION_IDLE_MS + 1000))).toBeNull();
    const s2 = await attemptStoreLogin(p, { email: "life@acme.com", password: o.tempPassword, ip: "198.51.100.21" });
    if (!s2.ok) throw new Error("login failed");
    await revokeStaffSession(p, s2.token);
    expect(await getStaffSession(p, s2.token)).toBeNull();
    const s3 = await attemptStoreLogin(p, { email: "life@acme.com", password: o.tempPassword, ip: "198.51.100.22" });
    if (!s3.ok) throw new Error("login failed");
    const reset = await resetStaffPassword(p, "life@acme.com");
    expect(reset?.tempPassword).toHaveLength(16);
    expect(await getStaffSession(p, s3.token)).toBeNull();
    const s4 = await attemptStoreLogin(p, { email: "life@acme.com", password: reset!.tempPassword, ip: "198.51.100.23" });
    if (!s4.ok) throw new Error("login failed");
    expect(await setStaffActive(p, "life@acme.com", false)).toBe(true);
    expect(await getStaffSession(p, s4.token)).toBeNull();
    expect((await attemptStoreLogin(p, { email: "life@acme.com", password: reset!.tempPassword, ip: "198.51.100.24" })).ok).toBe(false);
    expect(await resetStaffPassword(p, "ghost@acme.com")).toBeNull();
  });

  it("validates editor input and rejects anything unsafe", () => {
    expect(buildConfigFromForm(form())).toMatchObject({ ok: true });
    const ok = buildConfigFromForm(form());
    if (ok.ok) { expect(ok.config.sections).toEqual(["contact", "hero", "about"]); expect(ok.config.content.whatsapp).toBe("8801700000000"); }
    for (const bad of ["red", "#12345", "#gggggg", "#000000; background:url(x)", "javascript:alert(1)", "</style><script>"])
      expect(buildConfigFromForm(form({ primary: bad }))).toEqual({ ok: false, error: "invalid_color" });
    expect(buildConfigFromForm(form({ sectionOrder: {} }))).toEqual({ ok: false, error: "no_sections" });
    expect(buildConfigFromForm(form({ sectionOrder: { hero: "1", evil: "2" } }))).toMatchObject({ ok: true }); // unknown keys are ignored, never stored
    expect(buildConfigFromForm(form({ phone: "<b>1</b>" }))).toEqual({ ok: false, error: "invalid_contact" });
    expect(buildConfigFromForm(form({ whatsapp: "wa.me/x" }))).toEqual({ ok: false, error: "invalid_contact" });
    expect(buildConfigFromForm(form({ about: "x".repeat(2001) }))).toEqual({ ok: false, error: "too_long" });
    const html = buildConfigFromForm(form({ heroTitle: "<script>alert(1)</script>" }));
    expect(html.ok && html.config.content.heroTitle).toBe("<script>alert(1)</script>"); // stored as plain text; the page escapes it when displayed
  });

  it("saves a draft without touching the live site, previews it, then publishes with history", async () => {
    const p = await poolOf("acme");
    const before = await loadEditorState(p);
    expect(before.hasUnpublishedChanges).toBe(false);
    const built = buildConfigFromForm(form());
    if (!built.ok) throw new Error("form invalid");
    await saveDraft(p, built.config, "owner@acme.com");
    const mid = await loadEditorState(p);
    expect(mid.hasUnpublishedChanges).toBe(true);
    expect(mid.draft?.theme.primary).toBe("#0a7d4b");
    expect(mid.live.theme.primary).toBe(before.live.theme.primary); // visitors still see the old site
    expect(await publishDraft(p, "owner@acme.com")).toEqual({ ok: true });
    const after = await loadEditorState(p);
    expect(after.live.theme.primary).toBe("#0a7d4b");
    expect(after.hasUnpublishedChanges).toBe(false);
    expect((await p.query("SELECT count(*) AS c FROM site_config_history")).rows[0].c).toBe(1);
    expect((await (await poolOf("beta")).query("SELECT config FROM site_config")).rows[0].config.theme.primary).toBe("#1f6feb"); // other client untouched
  });

  it("refuses to publish without a draft or with a corrupted draft, and can discard changes", async () => {
    const p = await poolOf("acme");
    await discardDraft(p);
    expect(await publishDraft(p, "owner@acme.com")).toEqual({ ok: false, error: "no_draft" });
    await p.query(`UPDATE site_config SET draft = '{"theme":{"primary":"bad;css"}}'::jsonb WHERE id = 1`);
    expect(await publishDraft(p, "owner@acme.com")).toEqual({ ok: false, error: "invalid_draft" });
    expect((await loadEditorState(p)).live.theme.primary).toBe("#0a7d4b");
    await discardDraft(p);
    expect((await loadEditorState(p)).draft).toBeNull();
  });

  it("keeps only the 20 most recent versions in history", async () => {
    const p = await poolOf("beta");
    for (let i = 0; i < 23; i++) {
      const c = buildConfigFromForm(form({ heroTitle: `Version ${i}` }));
      if (!c.ok) throw new Error("form invalid");
      await saveDraft(p, c.config, "o@b.com");
      await publishDraft(p, "o@b.com");
    }
    expect((await p.query("SELECT count(*) AS c FROM site_config_history")).rows[0].c).toBe(20);
  });
});

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { parseTaka, parseDate, addMonths, addDays, effectiveMonthlyFee, formatTaka } from "../src/billing/values";
import {
  setAgreement, getAgreement, createSetupInvoice, generateMonthlyInvoice, recordPayment, voidInvoice, billingSummary, nextMonthlyPeriod,
} from "../src/billing/service";

describe("money and date helpers", () => {
  it("parses taka strictly", () => {
    expect(parseTaka("12,500")).toBe(12500);
    expect(parseTaka(0)).toBe(0);
    for (const bad of ["", "-5", "1.5", "abc", "1e3", "100000001", "9999999999", null, undefined, {}]) expect(parseTaka(bad)).toBeNull();
  });
  it("parses only real calendar dates", () => {
    expect(parseDate("2026-02-28")).toBe("2026-02-28");
    for (const bad of ["2026-02-30", "2026-13-01", "26-01-01", "2026-1-1", "", "2026-01-01T00:00", null]) expect(parseDate(bad)).toBeNull();
  });
  it("adds months and days safely", () => {
    expect(addMonths("2026-01-28", 1)).toBe("2026-02-28");
    expect(addMonths("2026-12-05", 1)).toBe("2027-01-05");
    expect(addMonths("2026-11-10", 14)).toBe("2028-01-10");
    expect(addDays("2026-02-28", 1)).toBe("2026-03-01");
  });
  it("applies a discount only while it is valid", () => {
    const a = { monthlyFee: 1000, monthlyDiscount: 200, discountUntil: "2026-12-31" };
    expect(effectiveMonthlyFee(a, "2026-12-31")).toBe(800);
    expect(effectiveMonthlyFee(a, "2027-01-01")).toBe(1000);
    expect(effectiveMonthlyFee({ ...a, discountUntil: null }, "2030-01-01")).toBe(800);
    expect(formatTaka(1250000)).toBe("৳12,50,000");
  });
});

describe("billing service", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  const actor = "owner@example.com";
  beforeAll(async () => {
    w = await createTestWorld();
    for (const [slug, host] of [["acme", "acme.example.com"], ["beta", "beta.example.com"]] as const)
      await createClient(w.control, w.provider, w.masterKey, { businessName: slug.toUpperCase(), slug, packageTier: 1, templateKey: "starter", hostname: host }, actor);
  }, 180_000);
  afterAll(async () => { await w.cleanup(); }, 180_000);

  const agreement = (over: Record<string, unknown> = {}) => ({
    setupFee: "9,000", monthlyFee: "1000", monthlyDiscount: "200", discountUntil: "2026-12-31", serviceStart: "2026-11-05", graceDays: "7", notes: "negotiated on WhatsApp", ...over,
  });
  const tid = async (slug: string) => (await w.control.query("SELECT id FROM tenants WHERE slug=$1", [slug])).rows[0].id as string;

  it("seeds the standard packages as defaults", async () => {
    const r = await w.control.query("SELECT tier, monthly_bdt, setup_min_bdt, setup_max_bdt FROM packages ORDER BY tier");
    expect(r.rows.map((x) => x.monthly_bdt)).toEqual([1000, 1800, 2500, 3500, 5000]);
    expect(r.rows[0].setup_min_bdt).toBe(7000);
  });

  it("validates and saves a negotiated agreement (price can differ from the standard)", async () => {
    expect(await setAgreement(w.control, "ghost", agreement(), actor)).toEqual({ ok: false, error: "not_found" });
    expect(await setAgreement(w.control, "acme", agreement({ setupFee: "abc" }), actor)).toEqual({ ok: false, error: "invalid_amount" });
    expect(await setAgreement(w.control, "acme", agreement({ monthlyDiscount: "1500" }), actor)).toEqual({ ok: false, error: "discount_too_large" });
    expect(await setAgreement(w.control, "acme", agreement({ serviceStart: "2026-11-31" }), actor)).toEqual({ ok: false, error: "invalid_date" });
    expect(await setAgreement(w.control, "acme", agreement({ serviceStart: "2026-11-29" }), actor)).toEqual({ ok: false, error: "start_day_too_late" });
    expect(await setAgreement(w.control, "acme", agreement({ graceDays: "999" }), actor)).toEqual({ ok: false, error: "invalid_grace" });
    expect(await getAgreement(w.control, await tid("acme"))).toBeNull();
    expect(await setAgreement(w.control, "acme", agreement({ setupFee: "8,500" }), actor)).toEqual({ ok: true });
    const a = await getAgreement(w.control, await tid("acme"));
    expect(a).toMatchObject({ setupFee: 8500, monthlyFee: 1000, monthlyDiscount: 200, discountUntil: "2026-12-31", serviceStart: "2026-11-05", graceDays: 7 });
  });

  it("refuses invoices before an agreement exists", async () => {
    expect(await createSetupInvoice(w.control, "beta", "2026-11-10", actor)).toEqual({ ok: false, error: "no_agreement" });
    expect(await generateMonthlyInvoice(w.control, "beta", "2026-11-05", actor)).toEqual({ ok: false, error: "no_agreement" });
  });

  it("issues one setup invoice only, and allows a new one after voiding", async () => {
    const a = await createSetupInvoice(w.control, "acme", "2026-11-10", actor);
    expect(a.ok).toBe(true);
    expect(await createSetupInvoice(w.control, "acme", "2026-11-10", actor)).toEqual({ ok: false, error: "setup_invoice_exists" });
    if (!a.ok) return;
    expect(await voidInvoice(w.control, a.invoiceId, "", actor)).toEqual({ ok: false, error: "reason_required" });
    expect(await voidInvoice(w.control, a.invoiceId, "wrong amount", actor)).toEqual({ ok: true });
    expect(await voidInvoice(w.control, a.invoiceId, "again", actor)).toEqual({ ok: false, error: "invoice_void" });
    const b = await createSetupInvoice(w.control, "acme", "2026-11-10", actor);
    expect(b.ok).toBe(true);
    const nums = (await w.control.query("SELECT number FROM invoices ORDER BY issued_at")).rows.map((r) => r.number as string);
    expect(new Set(nums).size).toBe(nums.length);
    expect(nums[0]).toMatch(/^INV-\d{4}-\d{5}$/);
  });

  it("generates monthly invoices one period at a time, with discount only while valid, and never twice", async () => {
    const now = new Date("2026-11-10T00:00:00Z");
    const id = await tid("acme");
    const a = (await getAgreement(w.control, id))!;
    expect(await nextMonthlyPeriod(w.control, id, a)).toBe("2026-11-05");
    expect(await generateMonthlyInvoice(w.control, "acme", "2026-12-05", actor, now)).toEqual({ ok: false, error: "period_not_next" });
    const first = await generateMonthlyInvoice(w.control, "acme", "2026-11-05", actor, now);
    expect(first.ok).toBe(true);
    expect(await generateMonthlyInvoice(w.control, "acme", "2026-11-05", actor, now)).toEqual({ ok: false, error: "period_exists" });
    expect(await generateMonthlyInvoice(w.control, "acme", "2026-12-05", actor, now)).toMatchObject({ ok: true });
    expect(await generateMonthlyInvoice(w.control, "acme", "2027-01-05", actor, new Date("2026-12-20T00:00:00Z"))).toMatchObject({ ok: true });
    expect(await generateMonthlyInvoice(w.control, "acme", "2027-02-05", actor, now)).toEqual({ ok: false, error: "period_too_far" });
    const amounts = (await w.control.query("SELECT period_start, amount_bdt FROM invoices WHERE kind='monthly' ORDER BY period_start")).rows;
    expect(amounts.map((r) => r.amount_bdt)).toEqual([800, 800, 1000]); // discount ended 2026-12-31
    expect(amounts[0].period_start).toBe("2026-11-05"); // dates stay plain text, no time-zone shift
  });

  it("records partial then full payment, rejecting overpayment, duplicates and bad input", async () => {
    const inv = (await w.control.query("SELECT id FROM invoices WHERE kind='monthly' AND period_start='2026-11-05'")).rows[0].id as string;
    const pay = (over: Record<string, unknown> = {}) => recordPayment(w.control, inv, { amount: "300", method: "bkash", reference: "TX100", receivedOn: "2026-11-06", ...over }, actor);
    expect(await pay({ amount: "0" })).toEqual({ ok: false, error: "invalid_amount" });
    expect(await pay({ method: "bitcoin" })).toEqual({ ok: false, error: "invalid_method" });
    expect(await pay({ receivedOn: "yesterday" })).toEqual({ ok: false, error: "invalid_date" });
    expect(await pay()).toEqual({ ok: true, status: "partial" });
    expect(await pay()).toEqual({ ok: false, error: "duplicate_reference" });
    expect(await pay({ amount: "600", reference: "TX101" })).toEqual({ ok: false, error: "overpayment" });
    expect(await pay({ amount: "500", reference: "TX102", method: "cash" })).toEqual({ ok: true, status: "paid" });
    expect(await pay({ amount: "1", reference: "TX103" })).toEqual({ ok: false, error: "invoice_paid" });
    const row = (await w.control.query("SELECT status, paid_at FROM invoices WHERE id=$1", [inv])).rows[0];
    expect(row.status).toBe("paid");
    expect(row.paid_at).not.toBeNull();
    expect(await voidInvoice(w.control, inv, "oops", actor)).toEqual({ ok: false, error: "has_payments" });
    expect(await recordPayment(w.control, "00000000-0000-0000-0000-000000000000", { amount: "1", method: "cash", reference: "", receivedOn: "2026-11-06" }, actor)).toEqual({ ok: false, error: "invoice_not_found" });
  });

  it("cannot be tricked by two simultaneous payments for the same invoice", async () => {
    const inv = (await w.control.query("SELECT id FROM invoices WHERE kind='monthly' AND period_start='2026-12-05'")).rows[0].id as string;
    const results = await Promise.all([1, 2, 3, 4].map((n) =>
      recordPayment(w.control, inv, { amount: "800", method: "bank", reference: `RACE-${n}`, receivedOn: "2026-12-06" }, actor)));
    expect(results.filter((r) => r.ok).length).toBe(1);
    expect((await w.control.query("SELECT sum(amount_bdt) s FROM payments WHERE invoice_id=$1", [inv])).rows[0].s).toBe(800);
  });

  it("rejects payments on voided invoices", async () => {
    const v = (await w.control.query("SELECT id FROM invoices WHERE status='void' LIMIT 1")).rows[0].id as string;
    expect(await recordPayment(w.control, v, { amount: "1", method: "cash", reference: "", receivedOn: "2026-11-06" }, actor)).toEqual({ ok: false, error: "invoice_void" });
  });

  it("zero-amount invoices (fully discounted) start as paid", async () => {
    await setAgreement(w.control, "beta", agreement({ monthlyFee: "500", monthlyDiscount: "500", discountUntil: "", setupFee: "0" }), actor);
    const r = await generateMonthlyInvoice(w.control, "beta", "2026-11-05", actor, new Date("2026-11-01T00:00:00Z"));
    expect(r.ok).toBe(true);
    expect((await w.control.query("SELECT status FROM invoices WHERE tenant_id=$1", [await tid("beta")])).rows[0].status).toBe("paid");
  });

  it("summarises recurring revenue, outstanding and overdue (with grace days)", async () => {
    // Open now: acme setup 8500 (due 2026-11-10), acme 2027-01-05 invoice 1000. Paid: 2026-11-05, 2026-12-05 invoices.
    const s1 = await billingSummary(w.control, "2026-11-12"); // 2 days after setup due, within 7 grace days
    expect(s1.outstanding).toBe(9500);
    expect(s1.overdueCount).toBe(0);
    const s2 = await billingSummary(w.control, "2026-11-18"); // 8 days after due, grace over
    expect(s2.overdueCount).toBe(1);
    expect(s2.overdueAmount).toBe(8500);
    expect(s2.monthlyRecurring).toBe(800 + 0); // acme (800 discounted) + beta (500-500)
    expect((await billingSummary(w.control, "2027-03-01")).monthlyRecurring).toBe(1000);
  });

  it("writes audit entries for money actions", async () => {
    const actions = (await w.control.query("SELECT DISTINCT action FROM audit_log WHERE action LIKE 'billing.%' OR action LIKE 'invoice.%' OR action LIKE 'payment.%'")).rows.map((r) => r.action);
    for (const a of ["billing.agreement.set", "invoice.created", "invoice.voided", "payment.recorded"]) expect(actions).toContain(a);
  });
});

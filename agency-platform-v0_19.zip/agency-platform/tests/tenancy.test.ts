import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { provisionTenant } from "../src/provisioning/provisionTenant";
import { resolveTenantByHost } from "../src/tenancy/resolver";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { decryptSecret } from "../src/crypto/secrets";

let w: Awaited<ReturnType<typeof createTestWorld>>;
beforeAll(async () => { w = await createTestWorld(); }, 180_000);
afterAll(async () => { await w.cleanup(); }, 180_000);

const mk = (slug: string, hostname?: string) => ({
  slug, businessName: slug.toUpperCase(), packageTier: 3 as const, templateKey: "ecommerce", hostname,
});
const provision = (slug: string, hostname?: string) => provisionTenant(w.control, w.provider, w.masterKey, mk(slug, hostname));

describe("provisioning", () => {
  it("creates a genuinely separate database per tenant", async () => {
    const a = await provision("alpha", "alpha-shop.com");
    const b = await provision("bravo", "bravo-shop.com");
    expect(a.databaseName).not.toBe(b.databaseName);
    const dbs = (await w.control.query("SELECT datname FROM pg_database WHERE datname LIKE 'tenant_%'")).rows.map((r) => r.datname);
    expect(dbs).toContain(a.databaseName);
    expect(dbs).toContain(b.databaseName);
  });

  it("is idempotent: retrying creates no duplicates", async () => {
    const first = await provision("charlie", "charlie.com");
    const second = await provision("charlie", "charlie.com");
    expect(second.tenantId).toBe(first.tenantId);
    expect(second.databaseName).toBe(first.databaseName);
    expect((await w.control.query("SELECT 1 FROM tenants WHERE slug='charlie'")).rowCount).toBe(1);
    expect((await w.control.query("SELECT 1 FROM tenant_databases WHERE tenant_id=$1", [first.tenantId])).rowCount).toBe(1);
    expect((await w.control.query("SELECT 1 FROM domains WHERE tenant_id=$1", [first.tenantId])).rowCount).toBe(1);
    expect(second.steps).toContain("migrations-already-applied");
  });

  it("survives concurrent retries of the same tenant", async () => {
    const results = await Promise.allSettled([provision("delta"), provision("delta"), provision("delta")]);
    const ok = results.filter((r) => r.status === "fulfilled");
    expect(ok.length).toBeGreaterThanOrEqual(1);
    expect((await w.control.query("SELECT 1 FROM tenants WHERE slug='delta'")).rowCount).toBe(1);
    expect((await w.control.query("SELECT 1 FROM tenant_databases d JOIN tenants t ON t.id=d.tenant_id WHERE t.slug='delta'")).rowCount).toBe(1);
    const again = await provision("delta");
    expect(again.steps).toContain("tenant-active");
  });

  it("never stores the connection string in plain text", async () => {
    const r = await w.control.query("SELECT conn_encrypted FROM tenant_databases LIMIT 1");
    expect(r.rows[0].conn_encrypted).not.toMatch(/postgres:\/\//);
    expect(decryptSecret(r.rows[0].conn_encrypted, w.masterKey)).toMatch(/^postgres:\/\//);
  });

  it("refuses a hostname that already belongs to another tenant", async () => {
    await provision("echo", "echo-shop.com");
    await expect(provision("foxtrot", "echo-shop.com")).rejects.toThrow(/already belongs/);
    const t = await w.control.query("SELECT status FROM tenants WHERE slug='foxtrot'");
    expect(t.rows[0].status).toBe("failed");
    const jobs = await w.control.query("SELECT 1 FROM provisioning_jobs j JOIN tenants t ON t.id=j.tenant_id WHERE t.slug='foxtrot' AND j.status='failed'");
    expect(jobs.rowCount).toBeGreaterThan(0);
  });

  it("recovers a failed tenant when retried with valid input", async () => {
    const r = await provision("foxtrot", "foxtrot-shop.com");
    expect(r.steps).toContain("tenant-active");
  });
});

describe("domain -> tenant resolution", () => {
  it("does not resolve pending (unverified) domains", async () => {
    expect(await resolveTenantByHost(w.control, "alpha-shop.com")).toBeNull();
  });
  it("resolves verified domains regardless of case/port", async () => {
    await w.control.query("UPDATE domains SET status='verified', verified_at=now() WHERE hostname='alpha-shop.com'");
    const t = await resolveTenantByHost(w.control, "ALPHA-Shop.com:443");
    expect(t?.slug).toBe("alpha");
  });
  it("does not resolve unregistered or malformed hosts", async () => {
    for (const h of ["evil.com", "alpha-shop.com.evil.com", "alpha-shop.com/../x", "", "127.0.0.1"])
      expect(await resolveTenantByHost(w.control, h)).toBeNull();
  });
  it("does not resolve suspended tenants", async () => {
    await w.control.query("UPDATE tenants SET status='suspended' WHERE slug='alpha'");
    expect(await resolveTenantByHost(w.control, "alpha-shop.com")).toBeNull();
    await w.control.query("UPDATE tenants SET status='active' WHERE slug='alpha'");
  });
});

describe("tenant data isolation + connection manager", () => {
  it("keeps each tenant's data in its own database", async () => {
    const mgr = new TenantConnectionManager(w.control, w.masterKey, { maxTenants: 2, maxConnections: 2, idleMs: 60_000 });
    try {
      const a = (await w.control.query("SELECT id FROM tenants WHERE slug='alpha'")).rows[0].id;
      const b = (await w.control.query("SELECT id FROM tenants WHERE slug='bravo'")).rows[0].id;
      await (await mgr.getPool(a)).query("INSERT INTO store_settings (key, value) VALUES ('business_phone', '\"A-ONLY\"')");
      const bRows = await (await mgr.getPool(b)).query("SELECT * FROM store_settings");
      expect(bRows.rowCount).toBe(0);
      const aRows = await (await mgr.getPool(a)).query("SELECT value FROM store_settings WHERE key='business_phone'");
      expect(aRows.rows[0].value).toBe("A-ONLY");
      const dbA = (await (await mgr.getPool(a)).query("SELECT current_database() AS d")).rows[0].d;
      const dbB = (await (await mgr.getPool(b)).query("SELECT current_database() AS d")).rows[0].d;
      expect(dbA).not.toBe(dbB);
    } finally { await mgr.closeAll(); }
  });

  it("caps open pools (LRU) and still serves every tenant", async () => {
    const mgr = new TenantConnectionManager(w.control, w.masterKey, { maxTenants: 2, maxConnections: 1, idleMs: 60_000 });
    try {
      const ids = (await w.control.query("SELECT id FROM tenants WHERE slug IN ('alpha','bravo','charlie') ORDER BY slug")).rows.map((r) => r.id);
      for (const id of ids) await (await mgr.getPool(id)).query("SELECT 1");
      expect(mgr.openPoolCount).toBeLessThanOrEqual(2);
      await (await mgr.getPool(ids[0])).query("SELECT 1"); // evicted one reopens fine
    } finally { await mgr.closeAll(); }
  });

  it("closes idle pools", async () => {
    const mgr = new TenantConnectionManager(w.control, w.masterKey, { maxTenants: 5, maxConnections: 1, idleMs: 1000 });
    try {
      const id = (await w.control.query("SELECT id FROM tenants WHERE slug='alpha'")).rows[0].id;
      await (await mgr.getPool(id)).query("SELECT 1");
      expect(mgr.openPoolCount).toBe(1);
      await mgr.closeIdle(Date.now() + 5000);
      expect(mgr.openPoolCount).toBe(0);
    } finally { await mgr.closeAll(); }
  });

  it("refuses to open a pool for a suspended tenant", async () => {
    const id = (await w.control.query("SELECT id FROM tenants WHERE slug='bravo'")).rows[0].id;
    await w.control.query("UPDATE tenants SET status='suspended' WHERE id=$1", [id]);
    const mgr = new TenantConnectionManager(w.control, w.masterKey);
    try { await expect(mgr.getPool(id)).rejects.toThrow(/no active database/); }
    finally { await mgr.closeAll(); await w.control.query("UPDATE tenants SET status='active' WHERE id=$1", [id]); }
  });
});

import pg from "pg";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import { join, dirname } from "node:path";
import "../src/db/pgTypes";
import { runMigrations } from "../src/db/migrate";
import { generateMasterKey } from "../src/crypto/secrets";
import { LocalPostgresProvider } from "../src/provisioning/providers/localPostgres";

export const ADMIN_URL = process.env.TEST_ADMIN_URL ?? "postgres://postgres:devpassword@127.0.0.1:5432/postgres";
const CONTROL_DIR = join(dirname(fileURLToPath(import.meta.url)), "../migrations/control");

export async function createTestWorld() {
  const controlName = `agency_test_${randomBytes(4).toString("hex")}`;
  const admin = new pg.Client({ connectionString: ADMIN_URL });
  await admin.connect();
  await admin.query(`CREATE DATABASE "${controlName}"`);
  await admin.end();
  const u = new URL(ADMIN_URL); u.pathname = `/${controlName}`;
  const control = new pg.Pool({ connectionString: u.toString(), max: 4 });
  await runMigrations(control, CONTROL_DIR);
  const provider = new LocalPostgresProvider(ADMIN_URL);
  const masterKey = generateMasterKey();
  return {
    control, provider, masterKey,
    async cleanup() {
      const names = (await control.query("SELECT database_name FROM tenant_databases")).rows.map((r) => r.database_name as string);
      await control.end();
      for (const n of names) await provider.dropDatabase(n);
      const a = new pg.Client({ connectionString: ADMIN_URL });
      await a.connect();
      await a.query(`DROP DATABASE IF EXISTS "${controlName}" WITH (FORCE)`);
      await a.end();
    },
  };
}

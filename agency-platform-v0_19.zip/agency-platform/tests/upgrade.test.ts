import { describe, it, expect, beforeAll, afterAll } from "vitest";
import pg from "pg";
import type { Pool } from "pg";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { runMigrations } from "../src/db/migrate";
import { TENANT_MIGRATIONS_DIR } from "../src/db/paths";
import { runStartupMigrations } from "../src/web/bootstrap";
import { entitlementsFor } from "../src/config/entitlements";
import { buildShopView } from "../src/shop/view";
import { createProduct, listPublicProducts } from "../src/shop/products";
import { createOrder } from "../src/shop/orders";
import { orIfMissingSchema } from "../src/shop/safe";

let w: Awaited<ReturnType<typeof createTestWorld>>;
let mgr: TenantConnectionManager;
let tenantId = "", pool: Pool;
const T4 = entitlementsFor(4);
const quiet = { log: () => {}, warn: () => {}, error: () => {} };

/** Puts a client database back into the state of an older version, with unrelated tables that happen to share the new tables' common names. */
async function makeOld(p: Pool) {
  await p.query("DROP TABLE IF EXISTS shop_order_events, shop_order_items, shop_orders, shop_discount_codes, shop_config, shop_campaigns, shop_product_variants, shop_product_images, shop_products, shop_categories CASCADE");
  await p.query("DELETE FROM schema_migrations WHERE name IN ('0005_shop_tables.sql', '0006_shop_campaigns.sql')");
  await p.query("ALTER TABLE media DROP CONSTRAINT IF EXISTS media_kind_check");
  await p.query("ALTER TABLE media ADD CONSTRAINT media_kind_check CHECK (kind IN ('logo','hero','about','gallery'))");
  for (const t of ["products", "orders", "categories", "campaigns", "shop_settings", "product_images", "order_items", "discount_codes"]) await p.query(`DROP TABLE IF EXISTS ${t} CASCADE`);
  await p.query("CREATE TABLE products (id SERIAL PRIMARY KEY, name TEXT, price NUMERIC)");
  await p.query("CREATE TABLE orders (id SERIAL PRIMARY KEY, total NUMERIC, customer TEXT)");
  await p.query("CREATE TABLE categories (id SERIAL PRIMARY KEY, title TEXT)");
  await p.query("CREATE TABLE campaigns (id SERIAL PRIMARY KEY, label TEXT)");
  await p.query("CREATE TABLE shop_settings (key TEXT PRIMARY KEY, value TEXT)");
  await p.query("CREATE TABLE product_images (id SERIAL PRIMARY KEY, url TEXT)");
  await p.query("CREATE TABLE order_items (id SERIAL PRIMARY KEY, sku TEXT)");
  await p.query("CREATE TABLE discount_codes (id SERIAL PRIMARY KEY, code TEXT)");
  await p.query("INSERT INTO products (name, price) VALUES ('Old thing', 99.5)");
  await p.query("INSERT INTO orders (total, customer) VALUES (500, 'Old customer')");
  await p.query("INSERT INTO shop_settings VALUES ('currency', 'BDT')");
}

beforeAll(async () => {
  w = await createTestWorld();
  mgr = new TenantConnectionManager(w.control, w.masterKey);
  const c = await createClient(w.control, w.provider, w.masterKey, { businessName: "Legacy", slug: "legacy", packageTier: 4, templateKey: "professional" }, "t");
  if (!c.ok) throw new Error("setup");
  tenantId = c.tenantId; pool = await mgr.getPool(tenantId);
}, 180_000);
afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

describe("upgrading databases that already contain older tables", () => {
  it("adds the shop beside tables with the same common names, and leaves those tables and their data alone", async () => {
    await makeOld(pool);
    const applied = await runMigrations(pool, TENANT_MIGRATIONS_DIR);
    expect(applied).toEqual(["0005_shop_tables.sql", "0006_shop_campaigns.sql"]);
    expect((await pool.query("SELECT name, price::text AS price FROM products")).rows).toEqual([{ name: "Old thing", price: "99.5" }]);
    expect((await pool.query("SELECT customer FROM orders")).rows).toEqual([{ customer: "Old customer" }]);
    expect((await pool.query("SELECT value FROM shop_settings WHERE key = 'currency'")).rows[0].value).toBe("BDT");
    expect((await pool.query("SELECT to_regclass('shop_products') AS t")).rows[0].t).toBe("shop_products");
    expect((await pool.query("SELECT delivery_fee_bdt FROM shop_config WHERE id = 1")).rows[0].delivery_fee_bdt).toBe(0);
  });
  it("then the shop works", async () => {
    const r = await createProduct(pool, T4, { name: "New product", priceBdt: 700 });
    expect(r.ok).toBe(true);
    expect((await listPublicProducts(pool, T4, {})).items.map((i) => i.name)).toEqual(["New product"]);
    if (!r.ok) return;
    const o = await createOrder(pool, T4, { channel: "checkout", items: [{ productId: r.id, qty: 1 }], name: "Rahim", phone: "01710200935", address: "House 1, Dhaka", ip: "1.2.3.4" });
    expect(o.ok && !o.silent && o.total).toBe(700);
    expect((await pool.query("SELECT count(*)::int AS n FROM orders")).rows[0].n).toBe(1); // the old table did not get the new order
  });
  it("running it again changes nothing", async () => {
    expect(await runMigrations(pool, TENANT_MIGRATIONS_DIR)).toEqual([]);
  });
});

describe("old files left behind by copying a new version over an old folder", () => {
  it("are skipped, so the real migrations still run", async () => {
    const { mkdtempSync, copyFileSync, writeFileSync, readdirSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    const { join } = await import("node:path");
    const dir = mkdtempSync(join(tmpdir(), "mig-"));
    for (const f of readdirSync(TENANT_MIGRATIONS_DIR)) copyFileSync(join(TENANT_MIGRATIONS_DIR, f), join(dir, f));
    // the files that older versions shipped, which fail on a database that already has a "products" table
    writeFileSync(join(dir, "0005_shop.sql"), "CREATE TABLE IF NOT EXISTS products (id INT); CREATE INDEX IF NOT EXISTS products_list ON products(status);");
    writeFileSync(join(dir, "0006_campaigns.sql"), "SELECT no_such_column FROM no_such_table;");
    await makeOld(pool);
    expect(await runMigrations(pool, dir)).toEqual(["0005_shop_tables.sql", "0006_shop_campaigns.sql"]);
    expect((await pool.query("SELECT 1 FROM schema_migrations WHERE name IN ('0005_shop.sql','0006_campaigns.sql')")).rowCount).toBe(0);
  });
});

describe("a database that has not been upgraded never takes a website down", () => {
  it("builds no shop instead of failing when the shop tables are missing", async () => {
    const bare = new pg.Pool({ connectionString: process.env.TEST_ADMIN_URL ?? "postgres://postgres:devpassword@127.0.0.1:5432/postgres", max: 1 });
    try {
      expect(await buildShopView(bare, T4, { page: "home" })).toBeNull();
      expect(await orIfMissingSchema(async () => { await bare.query("SELECT 1 FROM shop_no_such_table"); return "x"; }, "fallback")).toBe("fallback");
      await expect(orIfMissingSchema(async () => { await bare.query("SELEKT 1"); return "x"; }, "fallback")).rejects.toThrow(); // other errors still surface
    } finally { await bare.end(); }
  });
});

describe("the automatic upgrade at startup", () => {
  it("brings an old main database and an old client database up to date, and is safe to repeat", async () => {
    await makeOld(pool);
    await w.control.query("DROP TABLE IF EXISTS purchase_requests");
    await w.control.query("ALTER TABLE domains DROP COLUMN IF EXISTS last_checked_at, DROP COLUMN IF EXISTS check_note");
    await w.control.query("DELETE FROM schema_migrations WHERE name = '0007_buy_and_domains.sql'");
    const r = await runStartupMigrations(w.control, w.masterKey, quiet);
    expect(r.control).toEqual(["0007_buy_and_domains.sql"]);
    const mine = r.clients.find((c) => c.slug === "legacy")!;
    expect(mine.error).toBeUndefined();
    expect(mine.applied).toEqual(["0005_shop_tables.sql", "0006_shop_campaigns.sql"]);
    expect((await w.control.query("SELECT to_regclass('purchase_requests') AS t")).rows[0].t).toBe("purchase_requests");
    expect((await w.control.query("SELECT count(*)::int AS n FROM information_schema.columns WHERE table_name = 'domains' AND column_name IN ('last_checked_at','check_note')")).rows[0].n).toBe(2);
    expect((await w.control.query("SELECT schema_version FROM tenant_databases WHERE tenant_id = $1", [tenantId])).rows[0].schema_version).toBe(6);
    const again = await runStartupMigrations(w.control, w.masterKey, quiet);
    expect(again.control).toEqual([]);
    expect(again.clients.every((c) => c.applied.length === 0 && !c.error)).toBe(true);
  });
});

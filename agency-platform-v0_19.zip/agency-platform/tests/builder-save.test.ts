import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { Pool } from "pg";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { entitlementsFor } from "../src/config/entitlements";
import { loadEditorState } from "../src/store/siteEditor";
import { saveMedia } from "../src/store/media";
import { saveBuilder } from "../src/builder/save";
import { newBlock } from "../src/builder/schema";
import { PRESETS } from "../src/builder/presets";

const PNG = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1]);
const T1 = entitlementsFor(1), T2 = entitlementsFor(2);
let w: Awaited<ReturnType<typeof createTestWorld>>, mgr: TenantConnectionManager, p1: Pool, p2: Pool;
beforeAll(async () => {
  w = await createTestWorld(); mgr = new TenantConnectionManager(w.control, w.masterKey);
  const a = await createClient(w.control, w.provider, w.masterKey, { businessName: "B1", slug: "b1", packageTier: 1, templateKey: "starter" }, "t");
  const b = await createClient(w.control, w.provider, w.masterKey, { businessName: "B2", slug: "b2", packageTier: 2, templateKey: "professional" }, "t");
  if (!a.ok || !b.ok) throw new Error("setup");
  p1 = await mgr.getPool(a.tenantId); p2 = await mgr.getPool(b.tenantId);
}, 180_000);
afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

describe("saving a page from the builder", () => {
  it("saves a draft without publishing, then publishes", async () => {
    const blocks = PRESETS[0]!.blocks("B2");
    expect(await saveBuilder(p2, T2, "o", { blocks, theme: { primary: "#112233" } }, false)).toEqual({ ok: true, published: false });
    let st = await loadEditorState(p2);
    expect(st.draft!.builder!.blocks).toHaveLength(blocks.length);
    expect(st.draft!.theme.primary).toBe("#112233");
    expect(st.live.builder).toBeUndefined(); // the live site did not change
    expect(await saveBuilder(p2, T2, "o", { blocks, theme: {} }, true)).toEqual({ ok: true, published: true });
    st = await loadEditorState(p2);
    expect(st.live.builder!.blocks).toHaveLength(blocks.length);
  });
  it("accepts only this website's own photos", async () => {
    const m = await saveMedia(p2, T2, { kind: "hero", filename: "a.png", alt: "x", bytes: PNG }, "o");
    if (!m.ok) throw new Error("media");
    const hero = { ...newBlock("hero"), props: { ...newBlock("hero").props, imageId: m.id } };
    expect((await saveBuilder(p2, T2, "o", { blocks: [hero] }, false)).ok).toBe(true);
    const ghost = { ...newBlock("hero"), props: { ...newBlock("hero").props, imageId: "11111111-1111-4111-8111-111111111111" } };
    expect(await saveBuilder(p2, T2, "o", { blocks: [ghost] }, false)).toEqual({ ok: false, error: "invalid_media" });
    const other = await saveMedia(p1, T1, { kind: "hero", filename: "b.png", alt: "x", bytes: PNG }, "o"); // a photo from ANOTHER client
    if (!other.ok) throw new Error("media");
    const stolen = { ...newBlock("hero"), props: { ...newBlock("hero").props, imageId: other.id } };
    expect(await saveBuilder(p2, T2, "o", { blocks: [stolen] }, false)).toEqual({ ok: false, error: "invalid_media" });
  });
  it("enforces the package on the server", async () => {
    const r = await saveBuilder(p1, T1, "o", { blocks: [newBlock("hero"), newBlock("faq")] }, false);
    expect(r).toMatchObject({ ok: false, error: "not_in_package", detail: "faq" });
    expect((await loadEditorState(p1)).draft).toBeNull(); // nothing was saved
  });
  it("refuses bad colours, unreadable pages and bad fonts; ignores brand changes the package lacks", async () => {
    const blocks = [newBlock("hero")];
    expect(await saveBuilder(p2, T2, "o", { blocks, theme: { primary: "red" } }, false)).toEqual({ ok: false, error: "invalid_color" });
    expect(await saveBuilder(p2, T2, "o", { blocks, theme: { background: "#222222", text: "#242424" } }, false)).toMatchObject({ ok: false, error: "low_contrast" });
    expect(await saveBuilder(p2, T2, "o", { blocks, theme: { font: "comic" } }, false)).toEqual({ ok: false, error: "invalid_choice" });
    const lock = { ...T1, branding: false };
    expect((await saveBuilder(p1, lock, "o", { blocks, theme: { primary: "#445566", background: "#000000" } }, false)).ok).toBe(true);
    const st = await loadEditorState(p1);
    expect(st.draft!.theme.primary).toBe("#445566");
    expect(st.draft!.theme.background).toBe("#ffffff"); // only the main colour was allowed
  });
  it("refuses malformed input", async () => {
    for (const bad of [null, "x", { blocks: "x" }, [{}], [{ type: "hero" }]]) expect((await saveBuilder(p2, T2, "o", { blocks: bad }, false)).ok).toBe(false);
  });
});

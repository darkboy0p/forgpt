import { describe, it, expect } from "vitest";
import { encryptSecret, decryptSecret, generateMasterKey } from "../src/crypto/secrets";
import { normalizeHostname } from "../src/tenancy/hostname";
import { loadEnv, ConfigError } from "../src/config/env";

const base = {
  APP_ENV: "development", CONTROL_DATABASE_URL: "postgres://u:p@localhost/db",
  TENANT_DB_PROVIDER: "local-postgres", PROVISIONER_ADMIN_URL: "postgres://u:p@localhost/postgres",
  SECRETS_MASTER_KEY: generateMasterKey(),
};

describe("secrets", () => {
  it("round-trips and uses a fresh IV each time", () => {
    const k = generateMasterKey();
    const a = encryptSecret("postgres://secret", k), b = encryptSecret("postgres://secret", k);
    expect(a).not.toEqual(b);
    expect(a).not.toContain("secret");
    expect(decryptSecret(a, k)).toBe("postgres://secret");
  });
  it("rejects tampering and wrong keys", () => {
    const k = generateMasterKey();
    const enc = encryptSecret("x", k);
    expect(() => decryptSecret(enc.slice(0, -2) + "AA", k)).toThrow();
    expect(() => decryptSecret(enc, generateMasterKey())).toThrow();
  });
});

describe("hostname normalization", () => {
  it("cleans valid hosts", () => {
    expect(normalizeHostname("ClientBrand.COM:443")).toBe("clientbrand.com");
    expect(normalizeHostname("shop.example.com.")).toBe("shop.example.com");
  });
  it("rejects junk", () => {
    for (const bad of ["", "localhost", "127.0.0.1", "a b.com", "-x.com", "x..com", "evil.com/../a", "<script>.com"])
      expect(normalizeHostname(bad)).toBeNull();
  });
});

describe("environment safety rules", () => {
  it("accepts a valid development config", () => { expect(loadEnv(base).APP_ENV).toBe("development"); });
  it("blocks the local provider in production", () => {
    expect(() => loadEnv({ ...base, APP_ENV: "production", CONTROL_DATABASE_URL: "postgres://u:p@db.example.com/x" })).toThrow(ConfigError);
  });
  it("blocks localhost control DB in production", () => {
    expect(() => loadEnv({ ...base, APP_ENV: "production", TENANT_DB_PROVIDER: "neon" })).toThrow(/localhost/);
  });
  it("blocks the production provider in demo", () => {
    expect(() => loadEnv({ ...base, APP_ENV: "demo", TENANT_DB_PROVIDER: "managed-postgres" })).toThrow(ConfigError);
  });
  it("rejects a weak master key", () => {
    expect(() => loadEnv({ ...base, SECRETS_MASTER_KEY: "short" })).toThrow(/32 random bytes/);
  });
});

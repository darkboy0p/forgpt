import { describe, it, expect } from "vitest";
import { parseSiteConfig, DEFAULT_SITE_CONFIG, LAYOUT_CHOICES } from "../src/config/siteConfig";
import { entitlementsFor, entitlementsFromValues, applyEntitlements } from "../src/config/entitlements";
import { defaultValues } from "../src/packages/features";
import { buildConfigFromForm, type EditorInput } from "../src/store/siteEditor";
import { LAYOUT_GROUPS, LAYOUT_PRESETS } from "../src/web/layoutFields";

// A package with no design extras (an administrator can switch any feature off per package). Tier 1 itself now includes them.
const T1 = entitlementsFromValues({ ...defaultValues(1), branding_advanced: false, layout_options: false }), T2 = entitlementsFor(2);
const form = (over: Partial<EditorInput> = {}): EditorInput => ({
  primary: "#0a7d4b", heroTitle: "Hi", heroSubtitle: "", about: "", phone: "", whatsapp: "", address: "",
  sectionOrder: { hero: "1", about: "2", contact: "3" }, ...over,
});
// A value for every layout choice that differs from the default.
const NON_DEFAULT: Record<string, string> = { heroStyle: "light", heroAlign: "center", heroHeight: "tall", headerStyle: "centered", headerBehavior: "stay", servicesView: "list", galleryPhotos: "large", reviewsView: "stacked", aboutLayout: "image-left", contactLayout: "side-by-side", cardStyle: "shadow", cardCorners: "round", sectionBackground: "tinted", headingAlign: "center", pageWidth: "wide", spacing: "airy", footerStyle: "detailed", whatsappButton: "left", logoSize: "large", heroOverlay: "strong", textSize: "large", headingSize: "xlarge", buttonSize: "large", heroEdge: "curve", heroFill: "gradient", heroAngle: "down-left", imageShape: "circle", productCards: "large" };

describe("customisable layout", () => {
  it("covers every layout choice in the table, the editor form and the presets", () => {
    const keys = Object.keys(LAYOUT_CHOICES).sort();
    expect(Object.keys(NON_DEFAULT).sort()).toEqual(keys);
    expect(LAYOUT_GROUPS.flatMap((g) => g.fields.map((f) => f.key)).sort()).toEqual(keys);
    for (const p of LAYOUT_PRESETS) expect(Object.keys(p.values).sort()).toEqual(keys);
    for (const g of LAYOUT_GROUPS) for (const f of g.fields) expect(f.options.map(([v]) => v).sort()).toEqual([...LAYOUT_CHOICES[f.key]].sort());
    for (const p of LAYOUT_PRESETS) for (const [k, v] of Object.entries(p.values)) expect(LAYOUT_CHOICES[k as keyof typeof LAYOUT_CHOICES] as readonly string[]).toContain(v);
  });
  it("old configs without the new fields still load with the previous look", () => {
    const r = parseSiteConfig({ theme: { primary: "#112233" }, layout: { heroStyle: "light" }, sections: ["hero", "contact"] });
    expect(r.valid).toBe(true);
    expect(r.config.layout).toMatchObject({ heroStyle: "light", heroAlign: "left", servicesView: "cards", galleryPhotos: "medium", pageWidth: "standard", spacing: "comfortable", cardCorners: "soft", whatsappButton: "right" });
    expect(r.config.content.faqs).toEqual([]);
    expect(r.config.promo.text).toBeUndefined();
  });
  it("rejects values outside the allowed lists", () => {
    for (const bad of [{ pageWidth: "100vw" }, { spacing: "0;color:red" }, { heroAlign: "right" }, { cardStyle: "neon" }, { whatsappButton: "top" }, { aboutLayout: "x" }])
      expect(parseSiteConfig({ layout: bad }).valid).toBe(false);
  });
  it("a Professional-package owner can save every layout option", () => {
    const r = buildConfigFromForm(form({ layout: NON_DEFAULT }), DEFAULT_SITE_CONFIG, T2);
    expect(r.ok && r.config.layout).toEqual(NON_DEFAULT);
  });
  it("a Starter owner cannot save any layout option, even with a forged request", () => {
    for (const [k, v] of Object.entries(NON_DEFAULT)) {
      const r = buildConfigFromForm(form({ layout: { [k]: v } }), DEFAULT_SITE_CONFIG, T1);
      expect(r.ok ? "ok" : r.error, k).toBe("not_in_package");
    }
  });
  it("rejects invalid choices and ignores unknown names; unsubmitted choices stay as stored", () => {
    const bad = buildConfigFromForm(form({ layout: { pageWidth: "100vw" } }), DEFAULT_SITE_CONFIG, T2);
    expect(bad.ok ? "ok" : bad.error).toBe("invalid_choice");
    const unknown = buildConfigFromForm(form({ layout: { evil: "x" } }), DEFAULT_SITE_CONFIG, T2);
    expect(unknown.ok && "evil" in unknown.config.layout).toBe(false);
    const base = parseSiteConfig({ layout: NON_DEFAULT }).config;
    const kept = buildConfigFromForm(form(), base, T2);
    expect(kept.ok && kept.config.layout).toEqual(NON_DEFAULT);
  });
  it("a downgraded site shows the default layout but keeps the saved choices", () => {
    const rich = parseSiteConfig({ layout: NON_DEFAULT }).config;
    expect(applyEntitlements(rich, T1).layout).toEqual(DEFAULT_SITE_CONFIG.layout);
    expect(applyEntitlements(rich, T2).layout).toEqual(NON_DEFAULT);
    expect(rich.layout.pageWidth).toBe("wide");
  });
});

describe("announcement banner, highlights and FAQ", () => {
  const sections = { hero: "1", highlights: "2", about: "3", faq: "4", contact: "5" };
  it("Professional can save all three and they are validated", () => {
    const r = buildConfigFromForm(form({ sectionOrder: sections,
      promo: { text: "Eid sale", linkLabel: "See offer", linkUrl: "/contact#inquiry", until: "2026-12-31", style: "dark" },
      highlights: [{ title: "Free delivery", text: "In Dhaka" }, { title: "", text: "" }],
      faqs: [{ question: "Do you deliver?", answer: "Yes." }, { question: "", answer: "" }] }), DEFAULT_SITE_CONFIG, T2);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.config.promo).toEqual({ text: "Eid sale", linkLabel: "See offer", linkUrl: "/contact#inquiry", until: "2026-12-31", style: "dark" });
      expect(r.config.content.highlights).toEqual([{ title: "Free delivery", text: "In Dhaka" }]);
      expect(r.config.content.faqs).toHaveLength(1);
      expect(r.config.sections).toEqual(["hero", "highlights", "about", "faq", "contact"]);
    }
  });
  it("rejects unsafe links and impossible dates", () => {
    const err = (promo: object) => { const r = buildConfigFromForm(form({ promo }), DEFAULT_SITE_CONFIG, T2); return r.ok ? "ok" : r.error; };
    for (const url of ["javascript:alert(1)", "//evil.example", "http://plain.example", "data:text/html,x", "https://a b.example", "/<script>"]) expect(err({ text: "x", linkUrl: url }), url).toBe("invalid_link");
    expect(err({ text: "x", until: "2026-02-31" })).toBe("invalid_date");
    expect(err({ text: "x", until: "tomorrow" })).toBe("invalid_date");
    expect(err({ text: "x", style: "rainbow" })).toBe("invalid_choice");
    expect(err({ text: "x".repeat(141) })).toBe("too_long");
    expect(err({ text: "ok", linkUrl: "https://example.com/offer" })).toBe("ok");
  });
  it("an empty message removes the banner", () => {
    const base = parseSiteConfig({ promo: { text: "Old", linkUrl: "/contact" } }).config;
    const r = buildConfigFromForm(form({ promo: { text: "", linkUrl: "/contact" } }), base, T2);
    expect(r.ok && r.config.promo.text).toBeUndefined();
    expect(r.ok && r.config.promo.linkUrl).toBeUndefined();
  });
  it("Starter owners are refused all three, even with a forged request", () => {
    const err = (o: Partial<EditorInput>) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, T1); return r.ok ? "ok" : r.error; };
    expect(err({ promo: { text: "Sale" } })).toBe("not_in_package");
    expect(err({ highlights: [{ title: "A", text: "" }] })).toBe("not_in_package");
    expect(err({ faqs: [{ question: "Q", answer: "A" }] })).toBe("not_in_package");
    expect(err({ sectionOrder: { hero: "1", faq: "2" } })).toBe("not_in_package");
    expect(err({ promo: { text: "" }, highlights: [{ title: "", text: "" }] })).toBe("ok"); // empty rows are fine
  });
  it("rows with half the data are refused", () => {
    const err = (o: Partial<EditorInput>) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, T2); return r.ok ? "ok" : r.error; };
    expect(err({ faqs: [{ question: "Q only", answer: "" }] })).toBe("incomplete_row");
    expect(err({ faqs: [{ question: "", answer: "A only" }] })).toBe("incomplete_row");
    expect(err({ highlights: [{ title: "", text: "text only" }] })).toBe("incomplete_row");
  });
  it("a downgraded site hides them but keeps the data", () => {
    const rich = parseSiteConfig({ sections: ["hero", "faq", "contact"], promo: { text: "Sale", style: "dark" }, content: { highlights: [{ title: "A", text: "" }], faqs: [{ question: "Q", answer: "A" }] } }).config;
    const v = applyEntitlements(rich, T1);
    expect(v.sections).not.toContain("faq");
    expect(v.content.faqs).toEqual([]);
    expect(v.content.highlights).toEqual([]);
    expect(v.promo.text).toBeUndefined();
    expect(rich.content.faqs).toHaveLength(1);
    expect(applyEntitlements(rich, T2)).toEqual(rich);
  });
});

describe("custom headings and the banner button", () => {
  const err = (o: Partial<EditorInput>, ent = T2) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, ent); return r.ok ? "ok" : r.error; };
  it("Professional can set headings and a button; blank headings fall back", () => {
    const r = buildConfigFromForm(form({ sectionTitles: { about: " Our story ", services: "What we do", contact: "" }, cta: { label: "Order now", url: "/contact#inquiry" } }), DEFAULT_SITE_CONFIG, T2);
    expect(r.ok && r.config.content.sectionTitles).toEqual({ about: "Our story", services: "What we do" });
    expect(r.ok && r.config.content.cta).toEqual({ label: "Order now", url: "/contact#inquiry" });
  });
  it("accepts https, tel and page links; rejects anything else", () => {
    for (const url of ["https://example.com/x", "tel:+8801700000000", "/services", "/"]) expect(err({ cta: { label: "Go", url } }), url).toBe("ok");
    for (const url of ["javascript:alert(1)", "//evil.example", "http://plain.example", "data:text/html,x", "tel:abc", "mailto:a@b.c", "/<x>"]) expect(err({ cta: { label: "Go", url } }), url).toBe("invalid_link");
  });
  it("needs both the text and the link, and limits lengths", () => {
    expect(err({ cta: { label: "Go", url: "" } })).toBe("incomplete_row");
    expect(err({ cta: { label: "", url: "/contact" } })).toBe("incomplete_row");
    expect(err({ cta: { label: "x".repeat(31), url: "/contact" } })).toBe("too_long");
    expect(err({ sectionTitles: { about: "x".repeat(41) } })).toBe("too_long");
    expect(err({ sectionTitles: { about: "<b>hi</b>" } })).toBe("invalid_choice");
  });
  it("ignores unknown heading names and clears with blanks", () => {
    const r = buildConfigFromForm(form({ sectionTitles: { evil: "x", about: "A" } }), DEFAULT_SITE_CONFIG, T2);
    expect(r.ok && r.config.content.sectionTitles).toEqual({ about: "A" });
    const base = parseSiteConfig({ content: { cta: { label: "Go", url: "/contact" }, sectionTitles: { about: "A" } } }).config;
    const c = buildConfigFromForm(form({ sectionTitles: {}, cta: { label: "", url: "" } }), base, T2);
    expect(c.ok && c.config.content.cta).toEqual({});
    expect(c.ok && c.config.content.sectionTitles).toEqual({});
  });
  it("Starter is refused (forged request), and a downgrade hides them but keeps them", () => {
    expect(err({ cta: { label: "Go", url: "/contact" } }, T1)).toBe("not_in_package");
    expect(err({ sectionTitles: { about: "A" } }, T1)).toBe("not_in_package");
    expect(err({ sectionTitles: { about: "" }, cta: { label: "", url: "" } }, T1)).toBe("ok");
    const rich = parseSiteConfig({ content: { cta: { label: "Go", url: "/contact" }, sectionTitles: { about: "A" } } }).config;
    expect(applyEntitlements(rich, T1).content.cta).toEqual({});
    expect(applyEntitlements(rich, T1).content.sectionTitles).toEqual({});
    expect(applyEntitlements(rich, T2).content.cta).toEqual({ label: "Go", url: "/contact" });
    expect(rich.content.cta.label).toBe("Go");
  });
});

describe("section designer (top package)", () => {
  const T4 = entitlementsFor(4), T5 = entitlementsFor(5);
  const run = (sectionStyles: EditorInput["sectionStyles"], ent = T5, base = DEFAULT_SITE_CONFIG) => buildConfigFromForm(form({ sectionStyles }), base, ent);
  const err = (s: EditorInput["sectionStyles"], ent = T5) => { const r = run(s, ent); return r.ok ? "ok" : r.error; };
  it("lets the top package style sections one by one", () => {
    const r = run({ about: { background: "#101820", text: "#f5f5f5", align: "center", spacing: "airy" }, services: { align: "left" }, contact: {} });
    expect(r.ok && r.config.sectionStyles).toEqual({ about: { background: "#101820", text: "#f5f5f5", align: "center", spacing: "airy" }, services: { align: "left" } });
  });
  it("refuses lower packages, even with a forged request", () => {
    expect(err({ about: { background: "#101820" } }, T4)).toBe("not_in_package");
    expect(err({ about: { align: "center" } }, T4)).toBe("not_in_package");
    expect(err({ about: { background: "", align: "" } }, T4)).toBe("ok"); // blanks mean "follow the site"
  });
  it("rejects bad colours, choices and unreadable combinations; ignores unknown or hero sections", () => {
    expect(err({ about: { background: "red" } })).toBe("invalid_color");
    expect(err({ about: { align: "right" } })).toBe("invalid_choice");
    expect(err({ about: { spacing: "huge" } })).toBe("invalid_choice");
    expect(err({ about: { background: "#202020", text: "#252525" } })).toBe("low_contrast");
    expect(err({ about: { background: "#000000" } })).toBe("low_contrast"); // the site's normal dark text on black
    const r = run({ evil: { align: "center" }, hero: { align: "center" }, about: { align: "center" } });
    expect(r.ok && Object.keys(r.config.sectionStyles)).toEqual(["about"]);
  });
  it("keeps styles when the form does not include them, and clears them when everything is blank", () => {
    const base = parseSiteConfig({ sectionStyles: { about: { align: "center" } } }).config;
    const kept = buildConfigFromForm(form(), base, T5);
    expect(kept.ok && kept.config.sectionStyles).toEqual({ about: { align: "center" } });
    const cleared = run({ about: { background: "", text: "", align: "", spacing: "" } }, T5, base);
    expect(cleared.ok && cleared.config.sectionStyles).toEqual({});
  });
  it("a downgraded site ignores them but keeps the saved choices", () => {
    const rich = parseSiteConfig({ sectionStyles: { about: { background: "#101820", text: "#ffffff", align: "center" } } }).config;
    expect(applyEntitlements(rich, T4).sectionStyles).toEqual({});
    expect(applyEntitlements(rich, T5).sectionStyles).toEqual(rich.sectionStyles);
    expect(rich.sectionStyles.about!.background).toBe("#101820");
    const colourOnly = entitlementsFromValues({ ...defaultValues(5), homepage_builder: false });
    expect(applyEntitlements(rich, colourOnly).sectionStyles).toEqual({ about: { background: "#101820", text: "#ffffff" } });
  });
});

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { createPurchaseRequest, listPurchaseRequests, setPurchaseStatus, linkPurchaseToClient, countNewPurchases, suggestSlug, getPurchaseRequest } from "../src/orders/service";
import { addDomain, checkDomain, setPrimaryDomain, removeDomain, listDomains, dnsInstructions, inspectRouting, checkRouting, listAllDomains, MAX_DOMAINS_PER_TENANT } from "../src/domains/service";
import { resolveHostState } from "../src/tenancy/resolver";
import { LocalPostgresProvider } from "../src/provisioning/providers/localPostgres";
import { createClient } from "../src/clients/createClient";

let w: Awaited<ReturnType<typeof createTestWorld>>;
let tenantA = "", tenantB = "";
const prodEnv = { APP_ENV: "production" as const, PLATFORM_HOSTS: "admin.agency.test-platform.com" };
const devEnv = { APP_ENV: "development" as const, PLATFORM_HOSTS: undefined };
const good = { packageTier: 2, businessName: "Rahim Traders", contactName: "Rahim", phone: "01710200935", whatsapp: "+880 1710-200935", email: "Rahim@Example.com", desiredHostname: "https://www.rahim.com/", message: "Please call", paymentMethod: "bkash" };

beforeAll(async () => {
  w = await createTestWorld();
  const provider = new LocalPostgresProvider(process.env.TEST_ADMIN_URL ?? "postgres://postgres:devpassword@127.0.0.1:5432/postgres");
  const a = await createClient(w.control, provider, w.masterKey, { businessName: "Shop A", slug: "shop-a", packageTier: 2, templateKey: "professional" }, "test");
  const b = await createClient(w.control, provider, w.masterKey, { businessName: "Shop B", slug: "shop-b", packageTier: 1, templateKey: "starter" }, "test");
  if (!a.ok || !b.ok) throw new Error("setup failed");
  tenantA = a.tenantId; tenantB = b.tenantId;
}, 180_000);
afterAll(async () => { await w.cleanup(); }, 120_000);

describe("buying a website (public purchase requests)", () => {
  it("stores a valid request with cleaned-up values", async () => {
    const r = await createPurchaseRequest(w.control, good);
    expect(r.ok && r.id).toBeTruthy();
    const row = (await listPurchaseRequests(w.control, "new"))[0]!;
    expect(row).toMatchObject({ package_tier: 2, business_name: "Rahim Traders", phone: "01710200935", whatsapp: "8801710200935", email: "rahim@example.com", desired_hostname: "www.rahim.com", payment_method: "bkash", status: "new" });
  });
  it("refuses bad input with a specific reason", async () => {
    const err = async (o: object) => { const r = await createPurchaseRequest(w.control, { ...good, phone: "01811111111", email: "", ...o }); return r.ok ? "ok" : r.error; };
    expect(await err({ packageTier: 9 })).toBe("invalid_package");
    expect(await err({ businessName: "<b>x</b>" })).toBe("invalid_business");
    expect(await err({ contactName: "" })).toBe("invalid_name");
    expect(await err({ phone: "abc" })).toBe("invalid_phone");
    expect(await err({ whatsapp: "12" })).toBe("invalid_whatsapp");
    expect(await err({ email: "not-an-email" })).toBe("invalid_email");
    expect(await err({ desiredHostname: "no spaces.com" })).toBe("invalid_domain");
    expect(await err({ message: "x".repeat(1001) })).toBe("invalid_message");
    expect(await err({ paymentMethod: "bitcoin" })).toBe("invalid_payment");
  });
  it("silently drops robot submissions (trap field) and stores nothing", async () => {
    const before = (await listPurchaseRequests(w.control)).length;
    const r = await createPurchaseRequest(w.control, { ...good, phone: "01999999999", website: "http://spam.example" });
    expect(r).toEqual({ ok: true, id: null });
    expect((await listPurchaseRequests(w.control)).length).toBe(before);
  });
  it("limits repeat requests from the same phone or email", async () => {
    const same = { ...good, phone: "01555000111", email: "limit@example.com" };
    for (let i = 0; i < 3; i++) expect((await createPurchaseRequest(w.control, same)).ok).toBe(true);
    const r = await createPurchaseRequest(w.control, { ...same, phone: "01555000222" }); // same email, new phone
    expect(r.ok ? "ok" : r.error).toBe("rate_limited");
  });
  it("admin can move a request along, and linking a client locks it", async () => {
    const row = (await listPurchaseRequests(w.control, "new"))[0]!;
    expect(await setPurchaseStatus(w.control, row.id, "contacted", "admin@x")).toBe(true);
    expect(await setPurchaseStatus(w.control, row.id, "nonsense", "admin@x")).toBe(false);
    expect(await setPurchaseStatus(w.control, row.id, "client_created", "admin@x")).toBe(false); // only linking can do this
    expect(await linkPurchaseToClient(w.control, row.id, tenantA, "admin@x")).toBe(true);
    expect(await setPurchaseStatus(w.control, row.id, "rejected", "admin@x")).toBe(false);
    expect((await getPurchaseRequest(w.control, row.id))!.tenant_id).toBe(tenantA);
    expect(await getPurchaseRequest(w.control, "not-a-uuid")).toBeNull();
    expect(await countNewPurchases(w.control)).toBeGreaterThanOrEqual(1);
  });
  it("suggests a safe short name", () => {
    expect(suggestSlug("Rahim Traders & Sons!")).toBe("rahim-traders-sons");
    expect(suggestSlug("রহিম")).toBe("");
    expect(suggestSlug("A".repeat(80)).length).toBeLessThanOrEqual(38);
  });
});

describe("owner adds and verifies a domain", () => {
  const found = (token: string) => async () => [[`agency-verify=${token}`]];
  it("adds a pending domain with a proof token and shows DNS instructions", async () => {
    const r = await addDomain(w.control, prodEnv, tenantA, "https://Shop-A.com/", "owner@a");
    expect(r).toEqual({ ok: true, hostname: "shop-a.com" });
    const [d] = await listDomains(w.control, tenantA);
    expect(d).toMatchObject({ hostname: "shop-a.com", status: "pending", is_primary: false });
    expect(d!.verify_token).toMatch(/^[0-9a-f]{48}$/);
    expect(dnsInstructions({ DOMAIN_CNAME_TARGET: "sites.agency.com" }, "shop-a.com", d!.verify_token)).toMatchObject({ txtName: "_agency-verify.shop-a.com", txtValue: `agency-verify=${d!.verify_token}`, cnameTarget: "sites.agency.com" });
  });
  it("a pending domain serves nothing", async () => {
    expect((await resolveHostState(w.control, "shop-a.com")).kind).toBe("none");
  });
  it("refuses platform hosts, reserved names and a name another client already has", async () => {
    const err = async (env: typeof prodEnv | typeof devEnv, host: string, t = tenantB) => { const r = await addDomain(w.control, env, t, host, "o"); return r.ok ? "ok" : r.error; };
    expect(await err(prodEnv, "admin.agency.test-platform.com")).toBe("reserved_host");
    expect(await err(prodEnv, "x.localhost")).toBe("reserved_host");
    expect(await err(prodEnv, "x.localtest.me")).toBe("reserved_host");
    expect(await err(prodEnv, "intranet.internal")).toBe("reserved_host");
    expect(await err(prodEnv, "singlelabel")).toBe("invalid_host");
    expect(await err(prodEnv, "1.2.3.4")).toBe("invalid_host");
    expect(await err(prodEnv, "shop-a.com")).toBe("host_taken");
    expect(await err(devEnv, "demo.localhost", tenantB)).toBe("ok"); // development allows local names
  });
  it("does not verify without the proof record, and reports why", async () => {
    expect(await checkDomain(w.control, tenantA, "shop-a.com", "o", async () => [["something-else"]])).toEqual({ ok: false, error: "not_found" });
    const e = Object.assign(new Error("x"), { code: "ENOTFOUND" });
    await w.control.query("UPDATE domains SET last_checked_at = NULL WHERE hostname = 'shop-a.com'");
    expect(await checkDomain(w.control, tenantA, "shop-a.com", "o", async () => { throw e; })).toEqual({ ok: false, error: "not_found" });
    await w.control.query("UPDATE domains SET last_checked_at = NULL WHERE hostname = 'shop-a.com'");
    expect(await checkDomain(w.control, tenantA, "shop-a.com", "o", async () => { throw new Error("boom"); })).toEqual({ ok: false, error: "dns_error" });
  });
  it("rate-limits repeated checks", async () => {
    expect(await checkDomain(w.control, tenantA, "shop-a.com", "o", async () => [])).toEqual({ ok: false, error: "too_soon" });
  });
  it("another client cannot verify or manage this domain", async () => {
    const [d] = await listDomains(w.control, tenantA);
    await w.control.query("UPDATE domains SET last_checked_at = NULL WHERE hostname = 'shop-a.com'");
    expect(await checkDomain(w.control, tenantB, "shop-a.com", "o", found(d!.verify_token))).toEqual({ ok: false, error: "unknown_domain" });
    expect(await removeDomain(w.control, tenantB, "shop-a.com", "o")).toEqual({ ok: false, error: "unknown_domain" });
    expect(await setPrimaryDomain(w.control, tenantB, "shop-a.com", "o")).toEqual({ ok: false, error: "unknown_domain" });
  });
  it("verifies with the right record; it becomes the main domain and starts serving", async () => {
    const [d] = await listDomains(w.control, tenantA);
    await w.control.query("UPDATE domains SET last_checked_at = NULL WHERE hostname = 'shop-a.com'");
    // the record may be split into several strings by the DNS server
    const split = async () => [[`agency-verify=${d!.verify_token.slice(0, 10)}`, d!.verify_token.slice(10)]];
    expect(await checkDomain(w.control, tenantA, "shop-a.com", "o", split)).toEqual({ ok: true });
    const [v] = await listDomains(w.control, tenantA);
    expect(v).toMatchObject({ status: "verified", is_primary: true });
    const state = await resolveHostState(w.control, "shop-a.com");
    expect(state.kind === "active" && state.tenant.slug).toBe("shop-a");
    expect(await checkDomain(w.control, tenantA, "shop-a.com", "o", async () => [])).toEqual({ ok: true, already: true });
  });
  it("www and the bare name are the same website; an exact match wins", async () => {
    const s = await resolveHostState(w.control, "www.shop-a.com");
    expect(s.kind === "active" && s.tenant.slug).toBe("shop-a");
    expect((await resolveHostState(w.control, "www.unknown-site.com")).kind).toBe("none");
  });
  it("a second verified domain does not steal the main spot; the owner can switch and remove", async () => {
    expect((await addDomain(w.control, prodEnv, tenantA, "second-a.com", "o")).ok).toBe(true);
    const second = (await listDomains(w.control, tenantA)).find((x) => x.hostname === "second-a.com")!;
    expect(await setPrimaryDomain(w.control, tenantA, "second-a.com", "o")).toEqual({ ok: false, error: "not_verified" });
    await w.control.query("UPDATE domains SET last_checked_at = NULL WHERE hostname = 'second-a.com'");
    expect((await checkDomain(w.control, tenantA, "second-a.com", "o", found(second.verify_token))).ok).toBe(true);
    expect((await listDomains(w.control, tenantA)).find((x) => x.hostname === "second-a.com")!.is_primary).toBe(false);
    expect(await removeDomain(w.control, tenantA, "shop-a.com", "o")).toEqual({ ok: false, error: "is_primary" });
    expect(await setPrimaryDomain(w.control, tenantA, "second-a.com", "o")).toEqual({ ok: true });
    expect((await listDomains(w.control, tenantA))[0]!.hostname).toBe("second-a.com");
    expect(await removeDomain(w.control, tenantA, "shop-a.com", "o")).toEqual({ ok: true });
    expect((await resolveHostState(w.control, "shop-a.com")).kind).toBe("none");
  });
  it("a released name can be claimed again by another client; the limit per client is enforced", async () => {
    expect((await addDomain(w.control, prodEnv, tenantB, "shop-a.com", "o")).ok).toBe(true);
    for (let i = 0; i < MAX_DOMAINS_PER_TENANT; i++) await addDomain(w.control, prodEnv, tenantB, `extra${i}-b.com`, "o");
    const r = await addDomain(w.control, prodEnv, tenantB, "one-too-many-b.com", "o");
    expect(r.ok ? "ok" : r.error).toBe("too_many_domains");
  });
});

describe("is the domain pointing at the platform?", () => {
  const env = { DOMAIN_CNAME_TARGET: "sites.myagency.com", DOMAIN_A_RECORD: "203.0.113.10" };
  const res = (cname: string[], a: string[], targetIps: string[] = ["203.0.113.10"]) => ({
    cname: async () => cname,
    a: async (n: string) => (n === "sites.myagency.com" ? targetIps : a),
  });
  it("says yes for a CNAME to the target, a fixed A record, or an address the target resolves to", async () => {
    expect((await inspectRouting(env, "www.x.com", res(["Sites.MyAgency.com."], []))).points).toBe("yes");
    expect((await inspectRouting(env, "x.com", res([], ["203.0.113.10"]))).points).toBe("yes");
    expect((await inspectRouting({ DOMAIN_CNAME_TARGET: "sites.myagency.com" }, "x.com", res([], ["198.51.100.7"], ["198.51.100.7"]))).points).toBe("yes");
  });
  it("says no when it points somewhere else or nowhere", async () => {
    expect((await inspectRouting(env, "x.com", res([], ["198.51.100.99"]))).points).toBe("no");
    expect((await inspectRouting(env, "x.com", res(["other.example."], []))).points).toBe("no");
    expect((await inspectRouting(env, "x.com", { cname: async () => { throw new Error("ENODATA"); }, a: async () => { throw new Error("ENOTFOUND"); } })).points).toBe("no");
  });
  it("says unknown when the agency has not configured a target", async () => {
    expect((await inspectRouting({}, "x.com", res([], ["1.2.3.4"]))).points).toBe("unknown");
  });
  it("stores the result for a verified domain, only for its own client, and not too often", async () => {
    await w.control.query("UPDATE domains SET last_checked_at = NULL WHERE hostname = 'second-a.com'");
    expect(await checkRouting(w.control, env, tenantB, "second-a.com", "o", res([], ["203.0.113.10"]))).toEqual({ ok: false, error: "unknown_domain" });
    const ok = await checkRouting(w.control, env, tenantA, "second-a.com", "o", res([], ["203.0.113.10"]));
    expect(ok.ok && ok.report.points).toBe("yes");
    expect((await listDomains(w.control, tenantA)).find((d) => d.hostname === "second-a.com")!.check_note).toBe("points_yes");
    expect(await checkRouting(w.control, env, tenantA, "second-a.com", "o", res([], []))).toEqual({ ok: false, error: "too_soon" });
    expect(await checkRouting(w.control, env, tenantB, "extra0-b.com", "o", res([], []))).toEqual({ ok: false, error: "not_verified" });
  });
  it("lists every domain with its client for the super panel", async () => {
    const all = await listAllDomains(w.control);
    expect(all.find((d) => d.hostname === "second-a.com")).toMatchObject({ slug: "shop-a", status: "verified" });
    expect(all.every((d) => d.status !== "removed")).toBe(true);
  });
});

describe("template looks", () => {
  it("gives a draft the template's sections and look without touching content, and only what the package allows", async () => {
    const mgr = new (await import("../src/tenancy/connectionManager")).TenantConnectionManager(w.control, w.masterKey);
    const { applyTemplateLookToClient } = await import("../src/clients/templateLook");
    const { loadEditorState } = await import("../src/store/siteEditor");
    await w.control.query("UPDATE tenants SET template_key = 'ecommerce' WHERE id = $1", [tenantA]); // tenant A is tier 2
    const r = await applyTemplateLookToClient(w.control, mgr, "shop-a", "admin");
    expect(r).toEqual({ ok: true });
    const st = await loadEditorState(await mgr.getPool(tenantA));
    expect(st.draft!.sections).toEqual(["hero", "products", "highlights", "about", "contact"]);
    expect(st.draft!.layout.heroAlign).toBe("center");
    expect(st.live.sections).not.toContain("products"); // nothing was published
    expect(await applyTemplateLookToClient(w.control, mgr, "no-such", "admin")).toEqual({ ok: false, error: "not_found" });
    await mgr.closeAll();
  });
});

import { describe, it, expect } from "vitest";
import { THEMES, applyTheme, currentThemeKey, themeByKey } from "../src/config/themes";
import { LAYOUT_CHOICES, parseSiteConfig, DEFAULT_SITE_CONFIG } from "../src/config/siteConfig";

describe("theme switching", () => {
  it("every theme uses only allowed values and has a unique key and colour", () => {
    expect(new Set(THEMES.map((t) => t.key)).size).toBe(THEMES.length);
    expect(new Set(THEMES.map((t) => t.primary)).size).toBe(THEMES.length);
    for (const t of THEMES) {
      expect(t.primary).toMatch(/^#[0-9a-f]{6}$/i); expect(t.accent).toMatch(/^#[0-9a-f]{6}$/i);
      for (const [k, v] of Object.entries(t.layout)) expect(LAYOUT_CHOICES[k as keyof typeof LAYOUT_CHOICES] as readonly string[], `${t.key}.${k}`).toContain(v);
      expect(() => applyTheme(DEFAULT_SITE_CONFIG, t, { branding: true, layout: true })).not.toThrow();
    }
  });
  it("a full package gets colours, font, buttons and layout", () => {
    const t = themeByKey("royal")!;
    const r = applyTheme(DEFAULT_SITE_CONFIG, t, { branding: true, layout: true });
    expect(r.theme).toMatchObject({ primary: t.primary, accent: t.accent, font: "serif", buttonStyle: "rounded" });
    expect(r.layout).toMatchObject({ heroStyle: "light", heroAlign: "center", cardCorners: "round", sectionBackground: "tinted" });
  });
  it("a Starter package only gets the main colour", () => {
    const t = themeByKey("sunset")!;
    const r = applyTheme(DEFAULT_SITE_CONFIG, t, { branding: false, layout: false });
    expect(r.theme).toEqual({ ...DEFAULT_SITE_CONFIG.theme, primary: t.primary });
    expect(r.layout).toEqual(DEFAULT_SITE_CONFIG.layout);
  });
  it("keeps the owner's content and unrelated choices, and does not change the input", () => {
    const base = parseSiteConfig({ content: { heroTitle: "Mine" }, layout: { pageWidth: "wide", footerStyle: "detailed" }, promo: { text: "Sale" } }).config;
    const before = JSON.stringify(base);
    const r = applyTheme(base, themeByKey("ocean")!, { branding: true, layout: true });
    expect(r.content.heroTitle).toBe("Mine");
    expect(r.promo.text).toBe("Sale");
    expect(r.layout).toMatchObject({ pageWidth: "wide", footerStyle: "detailed", heroAlign: "center" });
    expect(JSON.stringify(base)).toBe(before);
  });
  it("recognises the current theme, and rejects unknown keys", () => {
    expect(currentThemeKey(applyTheme(DEFAULT_SITE_CONFIG, themeByKey("slate")!, { branding: false, layout: false }))).toBe("slate");
    expect(currentThemeKey(DEFAULT_SITE_CONFIG)).toBeNull();
    expect(themeByKey("nope")).toBeUndefined();
    expect(themeByKey("__proto__")).toBeUndefined();
  });
});

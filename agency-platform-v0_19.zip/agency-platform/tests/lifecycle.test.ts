import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { suspendClient, reactivateClient } from "../src/clients/lifecycle";
import { exportClientData, MAX_EXPORT_ROWS } from "../src/clients/exportTenant";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { resolveHostState, resolveTenantByHost } from "../src/tenancy/resolver";
import { loadSiteForHost } from "../src/web/tenantSite";
import { setAgreement, createSetupInvoice } from "../src/billing/service";

describe("suspend, reactivate and export", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  let mgr: TenantConnectionManager;
  const actor = "owner@example.com";
  const id = async (slug: string) => (await w.control.query("SELECT id FROM tenants WHERE slug=$1", [slug])).rows[0].id as string;

  beforeAll(async () => {
    w = await createTestWorld();
    mgr = new TenantConnectionManager(w.control, w.masterKey);
    for (const [slug, host] of [["acme", "acme.example.com"], ["beta", "beta.example.com"]] as const) {
      await createClient(w.control, w.provider, w.masterKey, { businessName: slug.toUpperCase() + " Shop", slug, packageTier: 1, templateKey: "starter", hostname: host }, actor);
    }
    await w.control.query("UPDATE domains SET status='verified'");
    // private agency billing data that must never appear in a client export
    await setAgreement(w.control, "acme", { setupFee: "9999", monthlyFee: "1234", monthlyDiscount: "", discountUntil: "", serviceStart: "2026-11-05", graceDays: "7", notes: "SECRET NEGOTIATION NOTE" }, actor);
    await createSetupInvoice(w.control, "acme", "2026-11-10", actor);
    // client data
    await (await mgr.getPool(await id("acme"))).query(`INSERT INTO store_settings (key, value) VALUES ('phone', '"01700-ACME"')`);
    await (await mgr.getPool(await id("beta"))).query(`INSERT INTO store_settings (key, value) VALUES ('phone', '"01800-BETA"')`);
  }, 180_000);
  afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

  it("suspension needs a reason and only works on active clients", async () => {
    expect(await suspendClient(w.control, "acme", "  ", actor)).toEqual({ ok: false, error: "reason_required" });
    expect(await suspendClient(w.control, "ghost", "x", actor)).toEqual({ ok: false, error: "not_found" });
    expect(await reactivateClient(w.control, "acme", actor)).toEqual({ ok: false, error: "not_suspended" });
    expect((await w.control.query("SELECT status FROM tenants WHERE slug='acme'")).rows[0].status).toBe("active");
  });

  it("a suspended site stops being served, only for that client, and nothing is deleted", async () => {
    const acmeId = await id("acme");
    const r = await suspendClient(w.control, "acme", "Unpaid after grace period", actor);
    expect(r.ok).toBe(true);
    await mgr.closePool(acmeId);
    expect(await suspendClient(w.control, "acme", "again", actor)).toEqual({ ok: false, error: "not_active" });
    expect(await resolveHostState(w.control, "acme.example.com")).toEqual({ kind: "suspended" });
    expect(await resolveTenantByHost(w.control, "acme.example.com")).toBeNull();
    expect((await loadSiteForHost(w.control, mgr, "acme.example.com")).kind).toBe("suspended");
    await expect(mgr.getPool(acmeId)).rejects.toThrow(/no active database/);
    expect((await loadSiteForHost(w.control, mgr, "beta.example.com")).kind).toBe("site"); // other client unaffected
    const row = (await w.control.query("SELECT status, suspended_reason, suspended_at FROM tenants WHERE slug='acme'")).rows[0];
    expect(row.suspended_reason).toBe("Unpaid after grace period");
    expect(row.suspended_at).not.toBeNull();
    expect((await w.control.query("SELECT 1 FROM tenant_databases WHERE tenant_id=$1", [acmeId])).rowCount).toBe(1);
    expect((await w.control.query("SELECT 1 FROM domains WHERE tenant_id=$1", [acmeId])).rowCount).toBe(1);
  });

  it("a suspended client's data can still be exported by the admin, but the site cannot use that access", async () => {
    const ex = await exportClientData(w.control, mgr, "acme");
    expect(ex.ok).toBe(true);
    if (!ex.ok) return;
    expect(ex.filename).toMatch(/^acme-export-\d{4}-\d{2}-\d{2}\.json$/);
    const doc = JSON.parse(ex.json);
    expect(doc.client).toMatchObject({ name: "ACME Shop", slug: "acme", status: "suspended", package: "Tier 1: Starter" });
    expect(doc.tables.store_settings.rows.map((r: { key: string; value: string }) => r.value)).toContain("01700-ACME");
    expect(doc.tables.site_config.rows).toHaveLength(1);
    expect(doc.tables.schema_migrations).toBeUndefined();
    await expect(mgr.getPool(await id("acme"))).rejects.toThrow(/no active database/); // export did not leave a cached pool behind
  });

  it("an export holds only that client's data and none of the agency's private records", async () => {
    const ex = await exportClientData(w.control, mgr, "acme");
    if (!ex.ok) throw new Error("export failed");
    for (const forbidden of ["BETA", "01800-BETA", "SECRET NEGOTIATION NOTE", "9999", "1234", "INV-", "postgres://", "conn_encrypted", "v1."]) expect(ex.json).not.toContain(forbidden);
    const beta = await exportClientData(w.control, mgr, "beta");
    if (!beta.ok) throw new Error("export failed");
    expect(beta.json).toContain("01800-BETA");
    expect(beta.json).not.toContain("01700-ACME");
  });

  it("never exports password hashes, tokens or session tables", async () => {
    await mgr.withAdminPool(await id("beta"), async (p) => {
      await p.query("CREATE TABLE customers (id SERIAL PRIMARY KEY, email TEXT, password_hash TEXT, reset_token TEXT)");
      await p.query("INSERT INTO customers (email, password_hash, reset_token) VALUES ('a@b.com', 'scrypt$secret-hash', 'tok-123')");
      await p.query("CREATE TABLE sessions (id SERIAL PRIMARY KEY, token TEXT)");
      await p.query("INSERT INTO sessions (token) VALUES ('live-session-token')");
    });
    const ex = await exportClientData(w.control, mgr, "beta");
    if (!ex.ok) throw new Error("export failed");
    expect(ex.json).toContain("a@b.com");
    for (const secret of ["scrypt$secret-hash", "tok-123", "live-session-token"]) expect(ex.json).not.toContain(secret);
    expect(JSON.parse(ex.json).tables.customers.rows[0].password_hash).toBe("[not exported]");
    expect(JSON.parse(ex.json).tables.sessions).toBeUndefined();
  });

  it("refuses exports that are too large and unknown clients", async () => {
    expect(MAX_EXPORT_ROWS).toBe(100_000);
    expect(await exportClientData(w.control, mgr, "ghost")).toEqual({ ok: false, error: "not_found" });
    await mgr.withAdminPool(await id("beta"), (p) => p.query("INSERT INTO store_settings (key, value) SELECT 'k' || g, '1'::jsonb FROM generate_series(1, 100001) g"));
    expect(await exportClientData(w.control, mgr, "beta")).toEqual({ ok: false, error: "too_large" });
  });

  it("reactivation restores the site exactly as it was", async () => {
    const r = await reactivateClient(w.control, "acme", actor);
    expect(r.ok).toBe(true);
    expect(await reactivateClient(w.control, "acme", actor)).toEqual({ ok: false, error: "not_suspended" });
    const site = await loadSiteForHost(w.control, mgr, "acme.example.com");
    expect(site.kind === "site" && site.tenant.businessName).toBe("ACME Shop");
    const row = (await w.control.query("SELECT status, suspended_reason, suspended_at FROM tenants WHERE slug='acme'")).rows[0];
    expect(row).toMatchObject({ status: "active", suspended_reason: null, suspended_at: null });
    const phone = await (await mgr.getPool(await id("acme"))).query("SELECT value FROM store_settings WHERE key='phone'");
    expect(phone.rows[0].value).toBe("01700-ACME");
  });

  it("records audit entries for suspend, reactivate (with the reason) but never export contents", async () => {
    const rows = (await w.control.query("SELECT action, detail::text d FROM audit_log WHERE action LIKE 'client.%'")).rows;
    const actions = rows.map((r) => r.action);
    expect(actions).toContain("client.suspended");
    expect(actions).toContain("client.reactivated");
    expect(rows.find((r) => r.action === "client.suspended")!.d).toContain("Unpaid after grace period");
  });
});

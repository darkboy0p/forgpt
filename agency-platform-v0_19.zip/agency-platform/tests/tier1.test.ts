import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { parseSiteConfig, DEFAULT_SITE_CONFIG } from "../src/config/siteConfig";
import { entitlementsFor, applyEntitlements } from "../src/config/entitlements";
import { buildConfigFromForm, saveDraft, publishDraft, type EditorInput } from "../src/store/siteEditor";
import { detectImageType, safeFilename, saveMedia, listMedia, getMedia, deleteMedia, mediaUsage, KIND_LIMITS, MAX_MEDIA_COUNT } from "../src/store/media";

const T1 = entitlementsFor(1), T2 = entitlementsFor(2);
const png = (n = 200) => { const b = new Uint8Array(n); b.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]); return b; };
const jpg = (n = 200) => { const b = new Uint8Array(n); b.set([0xff, 0xd8, 0xff, 0xe0]); return b; };
const webp = (n = 200) => { const b = new Uint8Array(n); b.set([0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50]); return b; };
const form = (over: Partial<EditorInput> = {}): EditorInput => ({
  primary: "#0a7d4b", heroTitle: "Hi", heroSubtitle: "", about: "About", phone: "", whatsapp: "", address: "",
  sectionOrder: { hero: "1", about: "2", services: "3", contact: "4" }, ...over,
});

describe("business details in the site settings", () => {
  it("accepts hours, social links, email and SEO", () => {
    const r = parseSiteConfig({ hours: { mon: "9:00 AM - 6:00 PM", fri: "Closed" }, social: { facebook: "https://www.facebook.com/mypage", instagram: "https://instagram.com/mypage", youtube: "https://youtu.be/abc123" },
      seo: { title: "My Shop in Dhaka", description: "We sell things" }, content: { email: "hello@myshop.com" } });
    expect(r.valid).toBe(true);
  });
  it("rejects unsafe social links, bad email and oversized text", () => {
    const bad: object[] = [
      { social: { facebook: "javascript:alert(1)" } }, { social: { facebook: "http://facebook.com/x" } }, { social: { facebook: "https://facebook.com.evil.com/x" } },
      { social: { facebook: "https://evil.com/facebook.com/x" } }, { social: { instagram: "https://facebook.com/x" } }, { social: { facebook: "https://facebook.com/a b" } },
      { social: { facebook: 'https://facebook.com/x"onclick="y' } }, { social: { x: "https://x.com/" + "a".repeat(300) } },
      { content: { email: "not-an-email" } }, { content: { email: "<x@y.com>" } }, { hours: { mon: "x".repeat(41) } }, { seo: { title: "x".repeat(71) } }, { seo: { description: "x".repeat(171) } },
      { images: { logo: "not-a-uuid" } }, { images: { logo: "../../etc/passwd" } }, { images: { gallery: Array.from({ length: 13 }, () => "11111111-1111-1111-1111-111111111111") } },
    ];
    for (const b of bad) expect(parseSiteConfig(b).valid, JSON.stringify(b)).toBe(false);
  });
});

describe("image safety checks", () => {
  it("decides the type from the file's own bytes", () => {
    expect(detectImageType(png())).toBe("image/png");
    expect(detectImageType(jpg())).toBe("image/jpeg");
    expect(detectImageType(webp())).toBe("image/webp");
    expect(detectImageType(new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'))).toBeNull();
    expect(detectImageType(new TextEncoder().encode("<html><script>alert(1)</script></html>"))).toBeNull();
    expect(detectImageType(new TextEncoder().encode("GIF89a......."))).toBeNull();
    expect(detectImageType(new Uint8Array(0))).toBeNull();
  });
  it("cleans file names", () => {
    expect(safeFilename("../../etc/passwd")).toBe("passwd");
    expect(safeFilename("C:\\Users\\me\\logo.png")).toBe("logo.png");
    expect(safeFilename('a"<b>.png')).toBe("a__b_.png");
    expect(safeFilename("")).toBe("image");
    expect(safeFilename("x".repeat(200)).length).toBe(60);
  });
});

describe("uploads, drafts and Tier 1 rules", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  let mgr: TenantConnectionManager;
  const poolOf = async (slug: string) => mgr.getPool((await w.control.query("SELECT id FROM tenants WHERE slug=$1", [slug])).rows[0].id);
  beforeAll(async () => {
    w = await createTestWorld();
    mgr = new TenantConnectionManager(w.control, w.masterKey);
    for (const s of ["acme", "beta"]) await createClient(w.control, w.provider, w.masterKey, { businessName: s, slug: s, packageTier: 1, templateKey: "starter", hostname: `${s}.example.com` }, "admin@example.com");
  }, 180_000);
  afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

  it("stores a real image and serves its bytes back, only inside that client's database", async () => {
    const a = await poolOf("acme");
    const r = await saveMedia(a, T1, { kind: "logo", filename: "My Logo.png", alt: "", bytes: png(500) }, "o@a.com");
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const m = await getMedia(a, r.id);
    expect(m?.content_type).toBe("image/png");
    expect(m?.data.length).toBe(500);
    expect(await getMedia(await poolOf("beta"), r.id)).toBeNull();
    expect((await listMedia(a))[0]).toMatchObject({ kind: "logo", filename: "My Logo.png" });
    expect(await getMedia(a, "not-a-uuid")).toBeNull();
  });
  it("refuses unsafe or oversized uploads", async () => {
    const a = await poolOf("acme");
    const t = async (o: object) => { const r = await saveMedia(a, T1, { kind: "hero", filename: "x.png", alt: "", bytes: png(), ...o }, "o"); return r.ok ? "ok" : r.error; };
    expect(await t({ kind: "evil" })).toBe("invalid_kind");
    expect(await t({ bytes: new Uint8Array(0) })).toBe("empty");
    expect(await t({ bytes: new TextEncoder().encode('<svg><script>alert(1)</script></svg>') })).toBe("bad_type");
    expect(await t({ filename: "photo.png", bytes: new TextEncoder().encode("MZ fake exe renamed to .png") })).toBe("bad_type");
    expect(await t({ kind: "logo", bytes: png(KIND_LIMITS.logo + 1) })).toBe("too_large");
    expect(await t({ kind: "logo", bytes: png(KIND_LIMITS.logo) })).toBe("ok");
    expect(await t({ kind: "gallery", alt: "A photo" })).toBe("not_in_package"); // Tier 1 has no gallery
  });
  it("enforces the storage quota and the image count", async () => {
    const b = await poolOf("beta");
    const small = { ...entitlementsFor(1), maxMediaBytes: 1000 };
    expect((await saveMedia(b, small, { kind: "logo", filename: "a.png", alt: "", bytes: png(600) }, "o")).ok).toBe(true);
    expect(await saveMedia(b, small, { kind: "logo", filename: "b.png", alt: "", bytes: png(600) }, "o")).toEqual({ ok: false, error: "quota" });
    expect((await mediaUsage(b)).bytes).toBe(600);
    await b.query("INSERT INTO media (kind, filename, content_type, size_bytes, data, created_by) SELECT 'about','f.png','image/png',1,'\\x89'::bytea,'o' FROM generate_series(1, $1)", [MAX_MEDIA_COUNT]);
    expect(await saveMedia(b, T2, { kind: "about", filename: "c.png", alt: "", bytes: png() }, "o")).toEqual({ ok: false, error: "too_many" });
  });
  it("Tier 2 gallery photos need a description and other types work", async () => {
    const a = await poolOf("acme");
    expect(await saveMedia(a, T2, { kind: "gallery", filename: "g.jpg", alt: "  ", bytes: jpg() }, "o")).toEqual({ ok: false, error: "alt_required" });
    expect((await saveMedia(a, T2, { kind: "gallery", filename: "g.webp", alt: "Our shop front", bytes: webp() }, "o")).ok).toBe(true);
  });

  it("only lets the owner pick images that exist, and keeps Tier 1 out of the gallery", async () => {
    const a = await poolOf("acme");
    const ids = new Set((await listMedia(a)).map((m) => m.id));
    const logo = (await listMedia(a)).find((m) => m.kind === "logo")!.id;
    const ok = buildConfigFromForm(form({ images: { logo, hero: "", about: "", gallery: [] } }), DEFAULT_SITE_CONFIG, T1, { mediaIds: ids });
    expect(ok.ok && ok.config.images.logo).toBe(logo);
    const err = (o: Partial<EditorInput>, ent = T1) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, ent, { mediaIds: ids }); return r.ok ? "ok" : r.error; };
    expect(err({ images: { logo: "11111111-1111-1111-1111-111111111111" } })).toBe("invalid_media");
    expect(err({ images: { logo: "../../x" } })).toBe("invalid_media");
    expect(err({ images: { gallery: [logo] } })).toBe("not_in_package");
    expect(err({ images: { gallery: [logo] } }, T2)).toBe("ok");
    expect(err({ images: {} })).toBe("ok");
  });
  it("validates hours, social links, email and SEO from the form, and keeps stored values when absent", () => {
    const e = (o: Partial<EditorInput>) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, T1); return r.ok ? "ok" : r.error; };
    expect(e({ hours: { mon: "9-5", tue: "" } })).toBe("ok");
    expect(e({ hours: { mon: "x".repeat(41) } })).toBe("too_long");
    expect(e({ social: { facebook: "https://facebook.com/shop" } })).toBe("ok");
    expect(e({ social: { facebook: "javascript:alert(1)" } })).toBe("invalid_social");
    expect(e({ social: { instagram: "https://facebook.com/x" } })).toBe("invalid_social");
    expect(e({ email: "bad" })).toBe("invalid_contact");
    expect(e({ email: "Shop@Example.com" })).toBe("ok");
    expect(e({ seoTitle: "x".repeat(71) })).toBe("too_long");
    expect(e({ seoDescription: "x".repeat(171) })).toBe("too_long");
    const base = parseSiteConfig({ hours: { sat: "10-2" }, social: { tiktok: "https://tiktok.com/@shop" }, seo: { title: "Keep" }, content: { email: "k@shop.com" } }).config;
    const r = buildConfigFromForm(form(), base, T1);
    expect(r.ok && r.config.hours.sat).toBe("10-2");
    expect(r.ok && r.config.social.tiktok).toBe("https://tiktok.com/@shop");
    expect(r.ok && r.config.seo.title).toBe("Keep");
    expect(r.ok && r.config.content.email).toBe("k@shop.com");
    const cleared = buildConfigFromForm(form({ hours: { mon: "" }, social: {}, email: "" }), base, T1);
    expect(cleared.ok && cleared.config.hours.sat).toBeUndefined();
    expect(cleared.ok && cleared.config.social.tiktok).toBeUndefined();
    expect(cleared.ok && cleared.config.content.email).toBeUndefined();
  });

  it("will not delete an image the live site or the draft still uses", async () => {
    const a = await poolOf("acme");
    const logo = (await listMedia(a)).find((m) => m.kind === "logo")!.id;
    const built = buildConfigFromForm(form({ images: { logo } }), DEFAULT_SITE_CONFIG, T1, { mediaIds: new Set([logo]) });
    if (!built.ok) throw new Error("invalid");
    await saveDraft(a, built.config, "o@a.com");
    expect(await deleteMedia(a, logo)).toEqual({ ok: false, error: "in_use" });
    await publishDraft(a, "o@a.com");
    const cleared = buildConfigFromForm(form({ images: { logo: "" } }), built.config, T1);
    if (!cleared.ok) throw new Error("invalid");
    await saveDraft(a, cleared.config, "o@a.com");
    expect(await deleteMedia(a, logo)).toEqual({ ok: false, error: "in_use" }); // still on the LIVE site
    await publishDraft(a, "o@a.com");
    expect(await deleteMedia(a, logo)).toEqual({ ok: true });
    expect(await deleteMedia(a, logo)).toEqual({ ok: false, error: "not_found" });
    expect(await deleteMedia(a, "bad")).toEqual({ ok: false, error: "not_found" });
  });
  it("a downgrade hides the gallery but keeps the images", () => {
    const withGallery = parseSiteConfig({ images: { gallery: ["22222222-2222-2222-2222-222222222222"] }, sections: ["hero", "gallery", "contact"] }).config;
    const seen = applyEntitlements(withGallery, T1);
    expect(seen.images.gallery).toEqual([]);
    expect(seen.sections).toEqual(["hero", "contact"]);
    expect(withGallery.images.gallery).toHaveLength(1);
  });
});

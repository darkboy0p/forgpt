import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { setAgreement, createSetupInvoice, generateMonthlyInvoice } from "../src/billing/service";
import { COMPARISON_ROWS, FEATURES, defaultValues, effectiveValues } from "../src/packages/features";
import { entitlementsFor } from "../src/config/entitlements";
import { getEntitlements, getFeatureValues, hasFeature, clearPackageCache } from "../src/packages/resolve";
import { listPackages, updatePackage, type PackageInput } from "../src/packages/admin";
import { createClientRequest, markRequestDone, MAX_OPEN_REQUESTS, saveSettings, getSettings } from "../src/packages/requests";

const rowFor = (tier: number) => Object.fromEntries(COMPARISON_ROWS.map((r) => [r.label, r.show(defaultValues(tier))]));

describe("package feature catalogue (built-in defaults)", () => {
  it("matches the approved comparison table for all five packages", () => {
    const expected: Record<string, string[]> = {
      "Product management": ["YES", "YES", "YES", "YES", "YES"], "Product categories": ["YES", "YES", "YES", "YES", "YES"], "Product images": ["YES", "YES", "YES", "YES", "YES"],
      "Product variants": ["NO", "YES", "YES", "YES", "YES"], "Stock management": ["Basic", "Advanced", "YES", "Advanced", "Advanced"], "WhatsApp ordering": ["YES", "YES", "YES", "YES", "YES"],
      "Shopping cart": ["NO", "NO", "YES", "YES", "YES"], "Integrated checkout": ["NO", "NO", "YES", "YES", "YES"], "Customer accounts": ["NO", "NO", "YES", "YES", "YES"],
      "Order management": ["WhatsApp", "WhatsApp", "YES", "Advanced", "Advanced"], "Steadfast integration": ["NO", "NO", "YES", "YES", "YES"], "Discount codes": ["NO", "NO", "NO", "YES", "YES"],
      "Advanced analytics": ["NO", "NO", "Basic", "YES", "Advanced"], "Premium customization": ["NO", "NO", "NO", "NO", "YES"],
    };
    for (const [label, cells] of Object.entries(expected)) for (let t = 1; t <= 5; t++) expect(rowFor(t)[label], `${label} tier ${t}`).toBe(cells[t - 1]);
  });
  it("every higher package includes everything the lower one has", () => {
    for (let t = 2; t <= 5; t++) for (const f of FEATURES) {
      const lo = defaultValues(t - 1)[f.key]!, hi = defaultValues(t)[f.key]!;
      if (f.kind === "flag") expect(!lo || hi, `${f.key} tier ${t}`).toBeTruthy();
      else expect(hi as number, `${f.key} tier ${t}`).toBeGreaterThanOrEqual(lo as number);
    }
  });
  it("has unique keys and a sensible limit for every limit feature", () => {
    expect(new Set(FEATURES.map((f) => f.key)).size).toBe(FEATURES.length);
    for (const f of FEATURES.filter((x) => x.kind === "limit")) expect(f.unit).toBeTruthy();
  });
  it("turns defaults into the website rules used before (Tier 1 vs Tier 2+)", () => {
    const t1 = entitlementsFor(1), t2 = entitlementsFor(2), t5 = entitlementsFor(5);
    expect(t1).toMatchObject({ sections: ["hero", "about", "services", "contact", "products"], maxServices: 6, maxTestimonials: 0, inquiries: false, branding: true, layout: true, analytics: false, gallery: false, maxMediaBytes: 15 * 1048576 });
    expect(t2).toMatchObject({ maxServices: 12, maxTestimonials: 10, inquiries: true, branding: true, layout: true, analytics: true, gallery: true, multiPage: true, maxMediaBytes: 40 * 1048576 });
    expect(t2.sections).toEqual(["hero", "about", "services", "contact", "gallery", "testimonials", "inquiry", "highlights", "faq", "products"]);
    expect(t5.maxMediaBytes).toBe(300 * 1048576);
  });
});

describe("editable packages (database)", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  const actor = "owner@example.com";
  beforeAll(async () => { w = await createTestWorld(); }, 180_000);
  afterAll(async () => { await w.cleanup(); }, 180_000);
  beforeEach(() => clearPackageCache());

  const input = (over: Partial<PackageInput> = {}, p?: { description: string; setup: number; monthly: number }): PackageInput => ({
    description: p?.description ?? "", setupFee: p?.setup ?? 0, monthlyFee: p?.monthly ?? 0, flags: {}, limits: {}, ...over });
  const current = async (tier: number) => (await listPackages(w.control)).find((p) => p.tier === tier)!;
  const update = async (tier: number, over: Partial<PackageInput> = {}) => { const p = await current(tier); return updatePackage(w.control, tier, input(over, p), actor); };

  it("starts with the approved default prices", async () => {
    const p = await listPackages(w.control);
    expect(p.map((x) => x.setup)).toEqual([7000, 17000, 27000, 40000, 50000]);
    expect(p.map((x) => x.monthly)).toEqual([1000, 1800, 2500, 3500, 5000]);
    expect(p.map((x) => x.name)).toEqual(["Starter", "Business", "E-commerce", "Professional", "Premium"]);
    expect(p.every((x) => x.description.length > 10)).toBe(true);
    const range = (await w.control.query("SELECT bool_and(setup_min_bdt = setup_bdt AND setup_max_bdt = setup_bdt) AS same FROM packages")).rows[0].same;
    expect(range).toBe(true);
  });

  it("uses the built-in defaults when nothing was changed", async () => {
    expect(await getEntitlements(w.control, 2)).toEqual(entitlementsFor(2));
    expect(await hasFeature(w.control, 3, "cart_checkout")).toBe(true);
    expect(await hasFeature(w.control, 2, "cart_checkout")).toBe(false);
    expect(await hasFeature(w.control, 1, "cart_checkout")).toBe(false);
    expect(await hasFeature(w.control, 4, "discount_codes")).toBe(true);
    expect(await hasFeature(w.control, 3, "discount_codes")).toBe(false);
  });

  it("changes defaults, descriptions and prices with validation", async () => {
    expect(await update(0)).toEqual({ ok: false, error: "invalid_tier" });
    expect(await update(6)).toEqual({ ok: false, error: "invalid_tier" });
    expect(await update(1, { setupFee: "abc" })).toEqual({ ok: false, error: "invalid_price" });
    expect(await update(1, { monthlyFee: "-5" })).toEqual({ ok: false, error: "invalid_price" });
    expect(await update(1, { description: "x".repeat(301) })).toEqual({ ok: false, error: "description_too_long" });
    expect(await update(1, { flags: { made_up: true } })).toEqual({ ok: false, error: "unknown_feature" });
    expect(await update(1, { limits: { gallery: 3 } })).toEqual({ ok: false, error: "unknown_feature" });
    expect(await update(1, { limits: { max_services: "-1" } })).toEqual({ ok: false, error: "invalid_limit" });
    expect(await update(1, { limits: { max_services: "1.5" } })).toEqual({ ok: false, error: "invalid_limit" });
    expect(await update(1, { limits: { max_services: "99999999" } })).toEqual({ ok: false, error: "invalid_limit" });
    expect(await update(1)).toEqual({ ok: true, changes: 0 });
    const p = await current(1);
    expect(await updatePackage(w.control, 1, input({ description: "Entry package", setupFee: "7,500", monthlyFee: 1100 }, p), actor)).toEqual({ ok: true, changes: 2 });
    expect(await current(1)).toMatchObject({ description: "Entry package", setup: 7500, monthly: 1100 });
    await updatePackage(w.control, 1, input({ description: p.description, setupFee: p.setup, monthlyFee: p.monthly }, p), actor); // restore
  });

  it("enables and disables individual features and limits, and only the chosen package changes", async () => {
    expect(await update(2, { flags: { inquiry_forms: false }, limits: { max_services: "20" } })).toEqual({ ok: true, changes: 2 });
    let e2 = await getEntitlements(w.control, 2);
    expect(e2.inquiries).toBe(false);
    expect(e2.sections).not.toContain("inquiry");
    expect(e2.maxServices).toBe(20);
    expect((await getEntitlements(w.control, 3)).inquiries).toBe(true);
    expect((await getEntitlements(w.control, 1)).maxServices).toBe(6);
    expect((await w.control.query("SELECT count(*) AS n FROM package_features WHERE tier=2")).rows[0].n).toBe(2);
    // changing back to the default removes the stored difference
    expect(await update(2, { flags: { inquiry_forms: true }, limits: { max_services: 12 } })).toEqual({ ok: true, changes: 2 });
    expect((await w.control.query("SELECT count(*) AS n FROM package_features WHERE tier=2")).rows[0].n).toBe(0);
    e2 = await getEntitlements(w.control, 2);
    expect(e2).toEqual(entitlementsFor(2));
  });

  it("applies a change to the running site right away (cache is cleared by the update)", async () => {
    expect(await hasFeature(w.control, 4, "gallery")).toBe(true);
    await update(4, { flags: { gallery: false } });
    expect(await hasFeature(w.control, 4, "gallery")).toBe(false);
    expect((await getFeatureValues(w.control, 4)).gallery).toBe(false);
    await update(4, { flags: { gallery: true } });
    expect(await hasFeature(w.control, 4, "gallery")).toBe(true);
  });

  it("records every change in the audit log", async () => {
    const actions = (await w.control.query("SELECT DISTINCT action FROM audit_log WHERE action LIKE 'package.%'")).rows.map((r) => r.action);
    for (const a of ["package.price.changed", "package.description.changed", "package.features.changed"]) expect(actions).toContain(a);
    const feat = (await w.control.query("SELECT detail FROM audit_log WHERE action='package.features.changed' ORDER BY id LIMIT 1")).rows[0].detail;
    expect(feat.changed.length).toBeGreaterThan(0);
    expect(feat.changed[0]).toHaveProperty("from");
  });

  it("never changes an existing client's agreement or invoices when package defaults change", async () => {
    await createClient(w.control, w.provider, w.masterKey, { businessName: "Acme", slug: "acme", packageTier: 1, templateKey: "starter", hostname: "acme.example.com" }, actor);
    expect(await setAgreement(w.control, "acme", { setupFee: "6500", monthlyFee: "900", monthlyDiscount: "100", discountUntil: "", serviceStart: "2026-11-05", graceDays: "7", notes: "negotiated" }, actor)).toEqual({ ok: true });
    expect((await createSetupInvoice(w.control, "acme", "2026-11-10", actor)).ok).toBe(true);
    expect((await generateMonthlyInvoice(w.control, "acme", "2026-11-05", actor, new Date("2026-11-10T00:00:00Z"))).ok).toBe(true);
    const snap = async () => ({
      agreement: (await w.control.query("SELECT setup_fee_bdt, monthly_fee_bdt, monthly_discount_bdt, notes FROM tenant_billing")).rows,
      invoices: (await w.control.query("SELECT number, kind, amount_bdt, due_date, status FROM invoices ORDER BY number")).rows,
    });
    const before = await snap();
    expect(before.invoices.map((i) => i.amount_bdt).sort((a, b) => a - b)).toEqual([800, 6500]);
    const p = await current(1);
    expect(await updatePackage(w.control, 1, input({ description: p.description, setupFee: 9999, monthlyFee: 1999 }, p), actor)).toMatchObject({ ok: true });
    expect(await snap()).toEqual(before);
    expect(await current(1)).toMatchObject({ setup: 9999, monthly: 1999 });
    await updatePackage(w.control, 1, input({ description: p.description, setupFee: p.setup, monthlyFee: p.monthly }, p), actor);
  });
});

describe("owner requests and platform settings", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  let tid: string;
  beforeAll(async () => {
    w = await createTestWorld();
    await createClient(w.control, w.provider, w.masterKey, { businessName: "Acme", slug: "acme", packageTier: 1, templateKey: "starter", hostname: "acme.example.com" }, "o@x.com");
    tid = (await w.control.query("SELECT id FROM tenants WHERE slug='acme'")).rows[0].id;
  }, 180_000);
  afterAll(async () => { await w.cleanup(); }, 180_000);

  it("stores upgrade and support requests with validation", async () => {
    expect(await createClientRequest(w.control, tid, "upgrade", "hi", 2, "boss@acme.com")).toEqual({ ok: false, error: "invalid_message" });
    expect(await createClientRequest(w.control, tid, "upgrade", "x".repeat(1001), 2, "boss@acme.com")).toEqual({ ok: false, error: "invalid_message" });
    expect(await createClientRequest(w.control, tid, "upgrade", "We would like Business please", 9, "boss@acme.com")).toEqual({ ok: false, error: "invalid_tier" });
    expect(await createClientRequest(w.control, tid, "upgrade", "We would like Business please", "abc", "boss@acme.com")).toEqual({ ok: false, error: "invalid_tier" });
    expect(await createClientRequest(w.control, tid, "upgrade", "We would like Business please", 2, "boss@acme.com")).toEqual({ ok: true });
    expect(await createClientRequest(w.control, tid, "support", "My logo is not showing", undefined, "boss@acme.com")).toEqual({ ok: true });
    const rows = (await w.control.query("SELECT kind, requested_tier, status FROM client_requests ORDER BY created_at")).rows;
    expect(rows).toEqual([{ kind: "upgrade", requested_tier: 2, status: "open" }, { kind: "support", requested_tier: null, status: "open" }]);
  });
  it("limits open requests and lets the admin close them", async () => {
    for (let i = 0; i < MAX_OPEN_REQUESTS; i++) await createClientRequest(w.control, tid, "support", "Another question " + i, undefined, "boss@acme.com");
    expect(await createClientRequest(w.control, tid, "support", "One more question", undefined, "boss@acme.com")).toEqual({ ok: false, error: "too_many_open" });
    const id = (await w.control.query("SELECT id FROM client_requests LIMIT 1")).rows[0].id;
    expect(await markRequestDone(w.control, "bad-id", "o@x.com")).toBe(false);
    expect(await markRequestDone(w.control, id, "o@x.com")).toBe(true);
    expect(await markRequestDone(w.control, id, "o@x.com")).toBe(false);
    expect(await createClientRequest(w.control, tid, "support", "Now there is room", undefined, "boss@acme.com")).toEqual({ ok: true });
  });
  it("saves the agency contact details safely", async () => {
    expect(await saveSettings(w.control, { agency_name: "x".repeat(81) }, "o")).toEqual({ ok: false, error: "too_long" });
    expect(await saveSettings(w.control, { agency_whatsapp: "wa.me/evil" }, "o")).toEqual({ ok: false, error: "invalid_whatsapp" });
    expect(await saveSettings(w.control, { agency_name: "My Agency", agency_whatsapp: "+880 1700-000000", agency_note: "Sat-Thu 10-6" }, "o")).toEqual({ ok: true });
    expect(await getSettings(w.control)).toEqual({ agency_name: "My Agency", agency_whatsapp: "8801700000000", agency_note: "Sat-Thu 10-6" });
    expect(await saveSettings(w.control, { agency_name: "My Agency" }, "o")).toEqual({ ok: true });
    expect(await getSettings(w.control)).toEqual({ agency_name: "My Agency" });
  });
});

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { provisionTenant } from "../src/provisioning/provisionTenant";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { loadSiteForHost } from "../src/web/tenantSite";
import { parseSiteConfig, DEFAULT_SITE_CONFIG } from "../src/config/siteConfig";
import { isAdminAllowed, isPlatformHost } from "../src/web/adminAccess";

describe("site config validation", () => {
  it("accepts a valid config", () => {
    const r = parseSiteConfig({ theme: { primary: "#aa22cc" }, sections: ["hero", "contact"], content: { whatsapp: "8801700000000" } });
    expect(r.valid).toBe(true);
    expect(r.config.theme.primary).toBe("#aa22cc");
  });
  it("rejects CSS/script injection in colours and falls back to defaults", () => {
    for (const bad of ["red; background:url(x)", "#12", "javascript:alert(1)", "#gggggg", "</style><script>"]) {
      const r = parseSiteConfig({ theme: { primary: bad } });
      expect(r.valid).toBe(false);
      expect(r.config).toEqual(DEFAULT_SITE_CONFIG);
    }
  });
  it("rejects unknown sections and bad phone/whatsapp values", () => {
    expect(parseSiteConfig({ sections: ["hero", "evil"] }).valid).toBe(false);
    expect(parseSiteConfig({ content: { whatsapp: "wa.me/evil" } }).valid).toBe(false);
    expect(parseSiteConfig({ content: { phone: "<b>1</b>" } }).valid).toBe(false);
  });
  it("never throws on garbage", () => {
    for (const g of [null, undefined, 42, "x", [], { theme: 5 }]) expect(() => parseSiteConfig(g)).not.toThrow();
  });
});

describe("platform host rules", () => {
  const dev = { APP_ENV: "development" as const, PLATFORM_HOSTS: undefined };
  it("development defaults to local hosts only", () => {
    expect(isAdminAllowed(dev, "localhost:3000")).toBe(true);
    expect(isAdminAllowed(dev, "ADMIN.localhost:3000")).toBe(true);
    expect(isAdminAllowed(dev, "client.com")).toBe(false);
    expect(isPlatformHost(dev, "localhost.evil.com")).toBe(false);
  });
  it("demo and production have no admin host until PLATFORM_HOSTS is set", () => {
    expect(isAdminAllowed({ APP_ENV: "demo", PLATFORM_HOSTS: undefined }, "localhost:3000")).toBe(false);
    expect(isAdminAllowed({ APP_ENV: "production", PLATFORM_HOSTS: undefined }, "localhost")).toBe(false);
  });
  it("uses exactly the configured hosts", () => {
    const prod = { APP_ENV: "production" as const, PLATFORM_HOSTS: "Admin.MyAgency.com, ops.myagency.com" };
    expect(isAdminAllowed(prod, "admin.myagency.com")).toBe(true);
    expect(isAdminAllowed(prod, "ops.myagency.com:443")).toBe(true);
    expect(isAdminAllowed(prod, "myagency.com")).toBe(false);
    expect(isAdminAllowed(prod, "localhost")).toBe(false);
  });
});

describe("loadSiteForHost (host -> tenant database -> config)", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  let mgr: TenantConnectionManager;
  beforeAll(async () => {
    w = await createTestWorld();
    mgr = new TenantConnectionManager(w.control, w.masterKey);
    for (const s of ["webone", "webtwo"])
      await provisionTenant(w.control, w.provider, w.masterKey, { slug: s, businessName: `Shop ${s}`, packageTier: 1, templateKey: "starter", hostname: `${s}.example.com` });
    await w.control.query("UPDATE domains SET status='verified'");
  }, 180_000);
  afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

  it("serves each tenant its own config from its own database", async () => {
    const ids = (await w.control.query("SELECT id, slug FROM tenants")).rows;
    const two = ids.find((r) => r.slug === "webtwo")!;
    const pool = await mgr.getPool(two.id);
    await pool.query(`UPDATE site_config SET config = '{"theme":{"primary":"#112233"}}'::jsonb WHERE id = 1`);
    const a = await loadSiteForHost(w.control, mgr, "webone.example.com");
    const b = await loadSiteForHost(w.control, mgr, "webtwo.example.com:443");
    expect(a.kind === "site" && a.tenant.businessName).toBe("Shop webone");
    expect(a.kind === "site" && a.config.theme.primary).toBe("#1f6feb");
    expect(b.kind === "site" && b.config.theme.primary).toBe("#112233");
  });
  it("returns not-found for unknown hosts", async () => {
    expect((await loadSiteForHost(w.control, mgr, "unknown.example.com")).kind).toBe("not-found");
  });
  it("survives a corrupt stored config by falling back to defaults", async () => {
    const id = (await w.control.query("SELECT id FROM tenants WHERE slug='webone'")).rows[0].id;
    await (await mgr.getPool(id)).query(`UPDATE site_config SET config = '{"theme":{"primary":"bad;css"}}'::jsonb WHERE id = 1`);
    const r = await loadSiteForHost(w.control, mgr, "webone.example.com");
    expect(r.kind === "site" && r.configValid).toBe(false);
    expect(r.kind === "site" && r.config.theme.primary).toBe("#1f6feb");
  });
});

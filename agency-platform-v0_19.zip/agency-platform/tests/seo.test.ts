import { describe, it, expect } from "vitest";
import { parseSiteConfig, DEFAULT_SITE_CONFIG } from "../src/config/siteConfig";
import { entitlementsFor, applyEntitlements } from "../src/config/entitlements";
import { buildConfigFromForm, type EditorInput } from "../src/store/siteEditor";

const T1 = entitlementsFor(1), T2 = entitlementsFor(2);
const IMG = "11111111-1111-4111-8111-111111111111", OTHER = "22222222-2222-4222-8222-222222222222";
const ctx = { mediaIds: new Set([IMG]) };
const form = (over: Partial<EditorInput> = {}): EditorInput => ({
  primary: "#0a7d4b", heroTitle: "Hi", heroSubtitle: "", about: "", phone: "", whatsapp: "", address: "",
  sectionOrder: { hero: "1", about: "2", contact: "3" }, ...over,
});

describe("expanded SEO", () => {
  it("Professional can choose a sharing image and hide the site from search engines", () => {
    const r = buildConfigFromForm(form({ seoShareImage: IMG, seoNoindex: true }), DEFAULT_SITE_CONFIG, T2, ctx);
    expect(r.ok && r.config.seo).toEqual({ shareImage: IMG, noindex: true });
  });
  it("saving the title and description keeps the sharing image and the hide switch", () => {
    const base = parseSiteConfig({ seo: { title: "Old", shareImage: IMG, noindex: true } }).config;
    const r = buildConfigFromForm(form({ seoTitle: "New title", seoDescription: "Desc" }), base, T2, ctx);
    expect(r.ok && r.config.seo).toEqual({ title: "New title", description: "Desc", shareImage: IMG, noindex: true });
  });
  it("turning the switch off and clearing the image removes them", () => {
    const base = parseSiteConfig({ seo: { shareImage: IMG, noindex: true } }).config;
    const r = buildConfigFromForm(form({ seoShareImage: "", seoNoindex: false }), base, T2, ctx);
    expect(r.ok && r.config.seo.shareImage).toBeUndefined();
    expect(r.ok && r.config.seo.noindex).toBeUndefined();
  });
  it("refuses an image that is not one of the client's uploads, or is not a valid id", () => {
    for (const bad of [OTHER, "not-an-id", "../../etc/passwd"]) {
      const r = buildConfigFromForm(form({ seoShareImage: bad }), DEFAULT_SITE_CONFIG, T2, ctx);
      expect(r.ok ? "ok" : r.error, bad).toBe("invalid_media");
    }
  });
  it("Starter owners are refused both, even with a forged request, but may clear them", () => {
    const err = (o: Partial<EditorInput>) => { const r = buildConfigFromForm(form(o), DEFAULT_SITE_CONFIG, T1, ctx); return r.ok ? "ok" : r.error; };
    expect(err({ seoShareImage: IMG })).toBe("not_in_package");
    expect(err({ seoNoindex: true })).toBe("not_in_package");
    expect(err({ seoShareImage: "", seoNoindex: false })).toBe("ok");
  });
  it("after a downgrade the site is visible to search engines again, but the choices are kept", () => {
    const rich = parseSiteConfig({ seo: { title: "T", description: "D", shareImage: IMG, noindex: true } }).config;
    expect(applyEntitlements(rich, T1).seo).toEqual({ title: "T", description: "D" });
    expect(applyEntitlements(rich, T2).seo).toEqual(rich.seo);
    expect(rich.seo.noindex).toBe(true);
  });
  it("old configs without the new fields still load", () => {
    expect(parseSiteConfig({ seo: { title: "x" } }).valid).toBe(true);
    expect(parseSiteConfig({ seo: { shareImage: "nope" } }).valid).toBe(false);
  });
});

import React from "react";
import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { entitlementsFor, applyEntitlements } from "../src/config/entitlements";
import { parseSiteConfig, DEFAULT_SITE_CONFIG } from "../src/config/siteConfig";
import { contrastRatio, MIN_TEXT_CONTRAST } from "../src/config/color";
import { BLOCK_TYPES, blockSchema, newBlock, newId, MAX_BLOCKS, type Block } from "../src/builder/schema";
import { validateBuilder, blockAllowed } from "../src/builder/rules";
import { blocksFromConfig } from "../src/builder/convert";
import { PRESETS, applyPreset } from "../src/builder/presets";
(globalThis as unknown as { React: typeof React }).React = React;

const T1 = entitlementsFor(1), T2 = entitlementsFor(2), T5 = entitlementsFor(5);
const theme = { background: "#ffffff", text: "#111111" };
const ok = (blocks: unknown, ent = T5, th = theme) => validateBuilder(ent, { blocks }, th);
const err = (blocks: unknown, ent = T5) => { const r = ok(blocks, ent); return r.ok ? "ok" : r.error; };

describe("builder blocks", () => {
  it("every block type has valid starter content", () => {
    for (const t of BLOCK_TYPES) expect(() => blockSchema.parse(newBlock(t)), t).not.toThrow();
    expect(new Set(Array.from({ length: 200 }, newId)).size).toBe(200);
  });
  it("every template is valid, readable, and only uses blocks the package allows", () => {
    for (const p of PRESETS) {
      const blocks = p.blocks("Test Shop");
      expect(ok(blocks, T5, { background: p.theme.background, text: p.theme.text }).ok, p.key).toBe(true);
      expect(contrastRatio(p.theme.text, p.theme.background), p.key).toBeGreaterThanOrEqual(MIN_TEXT_CONTRAST);
      for (const b of blocks) if (b.style.text) expect(contrastRatio(b.style.text, b.style.bg ?? p.theme.background), `${p.key}/${b.type}`).toBeGreaterThanOrEqual(MIN_TEXT_CONTRAST);
      const small = applyPreset(DEFAULT_SITE_CONFIG, p, "Test Shop", T1).builder!.blocks;
      expect(small.every((b) => blockAllowed(b.type, T1)), p.key).toBe(true);
      expect(small.length).toBeGreaterThan(0);
    }
  });
  it("accepts a good page and refuses bad input with a reason", () => {
    const hero = newBlock("hero");
    expect(ok([hero]).ok).toBe(true);
    expect(err([{ ...hero, type: "script" }])).toBe("invalid");
    expect(err([{ ...hero, props: { ...hero.props, buttonUrl: "javascript:alert(1)" } }])).toBe("invalid");
    expect(err([{ ...hero, props: { ...hero.props, buttonUrl: "//evil.example" } }])).toBe("invalid");
    expect(err([{ ...hero, props: { ...hero.props, imageId: "../../etc/passwd" } }])).toBe("invalid");
    expect(err([{ ...hero, style: { ...hero.style, padTop: 99999 } }])).toBe("invalid");
    expect(err([{ ...hero, style: { ...hero.style, bg: "red" } }])).toBe("invalid");
    expect(err([{ ...hero, style: { ...hero.style, fontScale: 50 } }])).toBe("invalid");
    expect(err([{ ...hero, id: "x" }])).toBe("invalid");
    expect(err([hero, { ...newBlock("text"), id: hero.id }])).toBe("duplicate_ids");
    expect(err(Array.from({ length: MAX_BLOCKS + 1 }, () => newBlock("spacer")))).toBe("invalid");
    expect(err("nope")).toBe("invalid");
  });
  it("applies the plan: simple packages cannot use shop, highlights, FAQ, gallery, reviews or forms", () => {
    for (const t of ["features", "faq", "gallery", "testimonials", "inquiry"] as const) {
      expect(err([newBlock(t)], T1), t).toBe("not_in_package");
      expect(err([newBlock(t)], T5), t).toBe("ok");
    }
    for (const t of ["hero", "text", "imageText", "services", "cta", "contact", "spacer"] as const) expect(err([newBlock(t)], T1), t).toBe("ok");
    expect(blockAllowed("products", entitlementsFor(2))).toBe(true); // every package has the shop
  });
  it("limits services and reviews to the package", () => {
    const many = (n: number) => ({ ...newBlock("services"), props: { heading: "S", items: Array.from({ length: n }, (_, i) => ({ name: `s${i}`, text: "", price: "" })) } });
    expect(err([many(T1.maxServices)], T1)).toBe("ok");
    expect(err([many(T1.maxServices + 1)], T1)).toBe("too_many_items");
  });
  it("refuses unreadable colours but allows any readable choice", () => {
    const t = newBlock("text");
    expect(err([{ ...t, style: { ...t.style, bg: "#202020", text: "#252525" } }])).toBe("low_contrast");
    expect(err([{ ...t, style: { ...t.style, text: "#222222" } }])).toBe("ok"); // dark text on the white page is fine
    expect(err([{ ...t, style: { ...t.style, text: "#f0f0f0" } }])).toBe("low_contrast"); // pale text on the white page background
    expect(err([{ ...t, style: { ...t.style, bg: "#000000" } }])).toBe("ok"); // background only: the page picks white text itself
    expect(err([{ ...t, style: { ...t.style, bg: "#101820", text: "#ffffff" } }])).toBe("ok");
  });
  it("turns an existing site into blocks without losing what was written", () => {
    const cfg = parseSiteConfig({ sections: ["hero", "about", "services", "highlights", "faq", "testimonials", "contact"],
      content: { heroTitle: "Hello", heroSubtitle: "Sub", about: "About text", services: [{ name: "Cut", description: "d", price: "5" }], highlights: [{ title: "Fast", text: "t" }], faqs: [{ question: "Q?", answer: "A" }], testimonials: [{ name: "N", quote: "Q" }], cta: { label: "Go", url: "/products" } },
      sectionTitles: undefined } as never).config;
    const blocks = blocksFromConfig(cfg, "Biz");
    expect(blocks.map((b) => b.type)).toEqual(["hero", "text", "services", "features", "faq", "testimonials", "contact"]);
    expect(blocks[0]!.props).toMatchObject({ title: "Hello", subtitle: "Sub", buttonLabel: "Go", buttonUrl: "/products" });
    expect(blocks[1]!.props).toMatchObject({ body: "About text" });
    expect(ok(blocks).ok).toBe(true);
    expect(blocksFromConfig(DEFAULT_SITE_CONFIG, "Biz")[0]!.props).toMatchObject({ title: "Biz" });
  });
  it("a downgraded site hides blocks and items its package no longer allows, but keeps them saved", () => {
    const blocks = [newBlock("hero"), newBlock("faq"), newBlock("products"), { ...newBlock("services"), props: { heading: "S", items: Array.from({ length: 12 }, (_, i) => ({ name: `s${i}`, text: "", price: "" })) } } as Block];
    const cfg = parseSiteConfig({ builder: { blocks } }).config;
    const shown = applyEntitlements(cfg, T1).builder!.blocks;
    expect(shown.map((b) => b.type)).toEqual(["hero", "products", "services"]);
    expect((shown[2]!.props as { items: unknown[] }).items).toHaveLength(T1.maxServices);
    expect(cfg.builder!.blocks).toHaveLength(4);
    expect(applyEntitlements(cfg, T5).builder!.blocks).toHaveLength(4);
  });
});

describe("builder public page", () => {
  const render = async (blocks: Block[], extra: object = {}) => {
    const { BuilderSite } = await import("../src/builder/BuilderSite");
    const config = parseSiteConfig({ builder: { blocks }, content: { phone: "01710000000", address: "Dhaka" }, hours: { mon: "9-5" } }).config;
    return renderToStaticMarkup(React.createElement(BuilderSite as never, { businessName: "Biz", config, page: "home", interactive: false, shop: null, ...extra }));
  };
  it("draws every block type and every template", async () => {
    for (const p of PRESETS) {
      const html = await render(p.blocks("Biz Name"));
      expect(html, p.key).toContain("Biz Name");
      expect(html).toContain('class="pro bx"');
    }
    const all = BLOCK_TYPES.map((t) => newBlock(t));
    const html = await render(all);
    for (const t of BLOCK_TYPES) expect(html, t).toContain(`t-${t}`);
    expect(html).toContain('id="contact"');
  });
  it("escapes text, hides hidden blocks and applies size, spacing and colour settings", async () => {
    const evil = { ...newBlock("text"), props: { heading: "<script>alert(1)</script>", body: "<img src=x onerror=alert(1)>" } } as Block;
    const hidden = { ...newBlock("cta"), style: { ...newBlock("cta").style, hidden: true } } as Block;
    const styled = { ...newBlock("text"), style: { ...newBlock("text").style, padTop: 120, padBottom: 10, fontScale: 1.5, headingScale: 2, bg: "#101820", align: "center" as const } } as Block;
    const html = await render([evil, hidden, styled]);
    expect(html).not.toContain("<script>alert");
    expect(html).not.toContain("<img src=x");
    expect(html).toContain("&lt;script&gt;");
    expect(html).not.toContain("t-cta");
    expect(html).toContain("padding-top:120px"); expect(html).toContain("padding-bottom:10px");
    expect(html).toContain("--bx-fs:1.5"); expect(html).toContain("--bx-hs:2"); expect(html).toContain("background:#101820"); expect(html).toContain("text-align:center");
    expect(html).toContain("color:#ffffff"); // readable text is chosen for a dark background
  });
});

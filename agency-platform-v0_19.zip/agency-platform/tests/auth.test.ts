import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { hashPassword, verifyPassword, passwordPolicyError } from "../src/auth/password";
import { createPlatformAdmin, deactivateAdmin, AdminError } from "../src/auth/admins";
import { attemptLogin, MAX_FAILS_PER_EMAIL, WINDOW_MS } from "../src/auth/login";
import { getSessionAdmin, revokeSession, hashToken, SESSION_IDLE_MS, SESSION_ABSOLUTE_MS } from "../src/auth/sessions";

const GOOD = "correct horse battery staple";

describe("password hashing", () => {
  it("verifies the right password and rejects others", async () => {
    const h = await hashPassword(GOOD);
    expect(h).not.toContain(GOOD);
    expect(await verifyPassword(GOOD, h)).toBe(true);
    expect(await verifyPassword(GOOD + "x", h)).toBe(false);
    expect(await verifyPassword("", h)).toBe(false);
  });
  it("salts every hash and rejects malformed stored values", async () => {
    expect(await hashPassword(GOOD)).not.toEqual(await hashPassword(GOOD));
    for (const bad of ["", "plain", "scrypt$1$2", "bcrypt$a$b$c$d$e"]) expect(await verifyPassword(GOOD, bad)).toBe(false);
  });
  it("enforces the password policy", () => {
    expect(passwordPolicyError("short")).toMatch(/12/);
    expect(passwordPolicyError("a".repeat(129))).toMatch(/128/);
    expect(passwordPolicyError("aaaaaaaaaaaaaaaa")).toMatch(/repetitive/);
    expect(passwordPolicyError("maruf-secret-pass-1", "maruf@example.com")).toMatch(/email name/);
    expect(passwordPolicyError(GOOD, "owner@example.com")).toBeNull();
  });
});

describe("admin accounts, login and sessions", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  beforeAll(async () => { w = await createTestWorld(); }, 180_000);
  afterAll(async () => { await w.cleanup(); }, 180_000);
  const ip = "203.0.113.7";
  const login = (email: string, password: string, theIp = ip, now?: Date) => attemptLogin(w.control, { email, password, ip: theIp }, now);

  it("creates an admin, stores only a hash, and refuses duplicates and weak input", async () => {
    const a = await createPlatformAdmin(w.control, "  Owner@Example.com ", GOOD);
    expect(a.email).toBe("owner@example.com");
    const row = (await w.control.query("SELECT password_hash FROM platform_admins WHERE email='owner@example.com'")).rows[0];
    expect(row.password_hash).toMatch(/^scrypt\$/);
    expect(row.password_hash).not.toContain(GOOD);
    await expect(createPlatformAdmin(w.control, "owner@example.com", GOOD)).rejects.toThrow(AdminError);
    await expect(createPlatformAdmin(w.control, "not-an-email", GOOD)).rejects.toThrow(/valid email/);
    await expect(createPlatformAdmin(w.control, "x@example.com", "short")).rejects.toThrow(/12/);
  });

  it("logs in with the right password, creating a session that stores only a token hash", async () => {
    const r = await login("OWNER@example.com", GOOD, "198.51.100.1");
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const stored = (await w.control.query("SELECT token_hash FROM admin_sessions")).rows.map((x) => x.token_hash);
    expect(stored).toContain(hashToken(r.token));
    expect(stored).not.toContain(r.token);
    expect((await getSessionAdmin(w.control, r.token))?.email).toBe("owner@example.com");
  });

  it("gives the same answer for unknown emails and wrong passwords", async () => {
    const a = await login("nobody@example.com", GOOD, "198.51.100.2");
    const b = await login("owner@example.com", "wrong password here", "198.51.100.3");
    expect(a).toEqual({ ok: false, reason: "invalid" });
    expect(b).toEqual({ ok: false, reason: "invalid" });
  });

  it("rejects garbage session tokens", async () => {
    for (const t of [undefined, "", "abc", "a".repeat(43) + "!", "' OR 1=1 --"]) expect(await getSessionAdmin(w.control, t)).toBeNull();
  });

  it("locks an email after repeated failures, even for the correct password, then recovers", async () => {
    await createPlatformAdmin(w.control, "locked@example.com", GOOD);
    const t0 = new Date();
    for (let i = 0; i < MAX_FAILS_PER_EMAIL; i++) expect((await login("locked@example.com", "bad password " + i, `192.0.2.${i}`, t0)).ok).toBe(false);
    expect(await login("locked@example.com", GOOD, "192.0.2.99", t0)).toEqual({ ok: false, reason: "rate_limited" });
    const later = new Date(t0.getTime() + WINDOW_MS + 1000);
    expect((await login("locked@example.com", GOOD, "192.0.2.99", later)).ok).toBe(true);
  });

  it("sessions expire when idle and at the absolute limit", async () => {
    const t0 = new Date();
    const r = await login("owner@example.com", GOOD, "198.51.100.9", t0);
    if (!r.ok) throw new Error("login failed");
    expect(await getSessionAdmin(w.control, r.token, new Date(t0.getTime() + SESSION_IDLE_MS - 1000))).not.toBeNull();
    const r2 = await login("owner@example.com", GOOD, "198.51.100.10", t0);
    if (!r2.ok) throw new Error("login failed");
    expect(await getSessionAdmin(w.control, r2.token, new Date(t0.getTime() + SESSION_IDLE_MS + 1000))).toBeNull();
    const r3 = await login("owner@example.com", GOOD, "198.51.100.11", t0);
    if (!r3.ok) throw new Error("login failed");
    // keep it active but pass the absolute limit
    expect(await getSessionAdmin(w.control, r3.token, new Date(t0.getTime() + SESSION_ABSOLUTE_MS + 1000))).toBeNull();
  });

  it("logout revokes the session", async () => {
    const r = await login("owner@example.com", GOOD, "198.51.100.20");
    if (!r.ok) throw new Error("login failed");
    await revokeSession(w.control, r.token);
    expect(await getSessionAdmin(w.control, r.token)).toBeNull();
  });

  it("deactivating an admin kills open sessions and blocks new logins", async () => {
    await createPlatformAdmin(w.control, "temp@example.com", GOOD);
    const r = await login("temp@example.com", GOOD, "198.51.100.30");
    if (!r.ok) throw new Error("login failed");
    expect(await deactivateAdmin(w.control, "temp@example.com")).toBe(true);
    expect(await getSessionAdmin(w.control, r.token)).toBeNull();
    expect(await login("temp@example.com", GOOD, "198.51.100.31")).toEqual({ ok: false, reason: "invalid" });
  });

  it("writes audit entries without passwords", async () => {
    const rows = (await w.control.query("SELECT action, detail::text AS d FROM audit_log WHERE action LIKE 'admin.%'")).rows;
    expect(rows.some((r) => r.action === "admin.login.success")).toBe(true);
    expect(rows.some((r) => r.action === "admin.login.failed")).toBe(true);
    expect(rows.some((r) => r.action === "admin.login.blocked")).toBe(true);
    for (const r of rows) expect(r.d).not.toContain(GOOD);
  });
});

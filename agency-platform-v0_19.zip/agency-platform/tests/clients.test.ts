import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createTestWorld } from "./helpers";
import { createClient, retryProvisioning } from "../src/clients/createClient";
import { redactSecrets } from "../src/util/redact";
import { isTemplateBuilt } from "../src/config/templates";
import type { DatabaseProvider } from "../src/provisioning/providers/types";

describe("redactSecrets", () => {
  it("hides connection strings and password-like values", () => {
    const out = redactSecrets('connect failed postgres://postgres:hunter2@db.example.com:5432/x password=hunter2 token: abc123');
    expect(out).not.toContain("hunter2");
    expect(out).not.toContain("abc123");
    expect(out).toContain("[redacted");
  });
});
describe("templates", () => {
  it("only the built template can be assigned", () => {
    expect(isTemplateBuilt("starter")).toBe(true);
    expect(isTemplateBuilt("professional")).toBe(true);
    for (const t of ["ecommerce", "ecommerce-pro", "ecommerce-premium"]) expect(isTemplateBuilt(t)).toBe(true);
    for (const t of ["__proto__", "constructor", "", "nope"]) expect(isTemplateBuilt(t)).toBe(false);
  });
});

describe("createClient", () => {
  let w: Awaited<ReturnType<typeof createTestWorld>>;
  beforeAll(async () => { w = await createTestWorld(); }, 180_000);
  afterAll(async () => { await w.cleanup(); }, 180_000);
  const base = { businessName: "Rahim Traders", slug: "rahim-traders", packageTier: 1, templateKey: "starter", hostname: "rahimtraders.com" };
  const make = (over: Partial<typeof base> = {}) => createClient(w.control, w.provider, w.masterKey, { ...base, ...over }, "owner@example.com");
  const count = async (sql: string, args: unknown[] = []) => (await w.control.query(sql, args)).rowCount;

  it("creates a client with its own database, a pending domain and an audit entry", async () => {
    const r = await make();
    expect(r.ok).toBe(true);
    expect(await count("SELECT 1 FROM tenants WHERE slug='rahim-traders' AND status='active'")).toBe(1);
    expect(await count("SELECT 1 FROM tenant_databases d JOIN tenants t ON t.id=d.tenant_id WHERE t.slug='rahim-traders'")).toBe(1);
    expect(await count("SELECT 1 FROM domains WHERE hostname='rahimtraders.com' AND status='pending'")).toBe(1);
    const a = (await w.control.query("SELECT actor, detail::text d FROM audit_log WHERE action='client.created'")).rows[0];
    expect(a.actor).toBe("owner@example.com");
    expect(a.d).not.toMatch(/postgres:\/\//);
  });

  it("refuses duplicates without creating anything", async () => {
    const before = await count("SELECT 1 FROM tenants");
    expect(await make()).toEqual({ ok: false, error: "slug_taken" });
    expect(await make({ slug: "other-shop", hostname: "rahimtraders.com" })).toEqual({ ok: false, error: "host_taken" });
    expect(await count("SELECT 1 FROM tenants")).toBe(before);
    expect(await count("SELECT 1 FROM tenants WHERE slug='other-shop'")).toBe(0);
  });

  it("rejects bad input before touching the database", async () => {
    const before = await count("SELECT 1 FROM tenants");
    const cases: [Parameters<typeof make>[0], string][] = [
      [{ businessName: "x", slug: "ok-slug" }, "invalid_name"],
      [{ businessName: "<script>alert(1)</script>", slug: "ok-slug" }, "invalid_name"],
      [{ slug: "Has Space" }, "invalid_slug"], [{ slug: "-lead" }, "invalid_slug"], [{ slug: "trail-" }, "invalid_slug"],
      [{ slug: "x" }, "invalid_slug"], [{ slug: "a/../b" }, "invalid_slug"],
      [{ packageTier: 0, slug: "t0" }, "invalid_tier"], [{ packageTier: 6, slug: "t6" }, "invalid_tier"], [{ packageTier: 1.5, slug: "t15" }, "invalid_tier"],
      [{ templateKey: "nope", slug: "tmpl" }, "template_unavailable"], [{ templateKey: "professional", packageTier: 1, slug: "tmpl3" }, "template_tier_mismatch"], [{ templateKey: "__proto__", slug: "tmpl2" }, "template_unavailable"],
      [{ hostname: "not a host", slug: "badhost" }, "invalid_host"], [{ hostname: "localhost", slug: "badhost2" }, "invalid_host"],
    ];
    for (const [over, err] of cases) expect(await make(over)).toEqual({ ok: false, error: err });
    expect(await count("SELECT 1 FROM tenants")).toBe(before);
  });

  it("allows a client without a domain", async () => {
    const r = await make({ slug: "no-domain-shop", businessName: "No Domain Shop", hostname: "" });
    expect(r.ok).toBe(true);
    expect(await count("SELECT 1 FROM domains d JOIN tenants t ON t.id=d.tenant_id WHERE t.slug='no-domain-shop'")).toBe(0);
  });

  it("reports a provider failure, marks the client failed, redacts the log, and a retry recovers", async () => {
    let broken = true;
    const flaky: DatabaseProvider = {
      name: w.provider.name,
      dropDatabase: (n) => w.provider.dropDatabase(n),
      ensureDatabase: async (i) => {
        if (broken) throw new Error("could not connect to postgres://postgres:hunter2@db.internal:5432/postgres");
        return w.provider.ensureDatabase(i);
      },
    };
    const r = await createClient(w.control, flaky, w.masterKey, { ...base, slug: "flaky-shop", businessName: "Flaky Shop", hostname: "flaky.example.com" }, "owner@example.com");
    expect(r).toEqual({ ok: false, error: "provision_failed", slug: "flaky-shop" });
    expect((await w.control.query("SELECT status FROM tenants WHERE slug='flaky-shop'")).rows[0].status).toBe("failed");
    const job = (await w.control.query("SELECT detail FROM provisioning_jobs j JOIN tenants t ON t.id=j.tenant_id WHERE t.slug='flaky-shop' AND j.status='failed'")).rows[0];
    expect(job.detail).not.toContain("hunter2");

    expect(await retryProvisioning(w.control, flaky, w.masterKey, "flaky-shop", "owner@example.com")).toEqual({ ok: false, error: "provision_failed" });
    broken = false;
    expect(await retryProvisioning(w.control, flaky, w.masterKey, "flaky-shop", "owner@example.com")).toEqual({ ok: true });
    expect((await w.control.query("SELECT status FROM tenants WHERE slug='flaky-shop'")).rows[0].status).toBe("active");
    expect(await count("SELECT 1 FROM domains d JOIN tenants t ON t.id=d.tenant_id WHERE t.slug='flaky-shop'")).toBe(1);
    expect(await count("SELECT 1 FROM tenant_databases d JOIN tenants t ON t.id=d.tenant_id WHERE t.slug='flaky-shop'")).toBe(1);
  });

  it("does not retry healthy or unknown clients", async () => {
    expect(await retryProvisioning(w.control, w.provider, w.masterKey, "rahim-traders", "o")).toEqual({ ok: false, error: "not_retryable" });
    expect(await retryProvisioning(w.control, w.provider, w.masterKey, "ghost", "o")).toEqual({ ok: false, error: "not_found" });
  });
});

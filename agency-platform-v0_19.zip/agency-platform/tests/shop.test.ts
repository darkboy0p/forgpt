import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { Pool } from "pg";
import { createTestWorld } from "./helpers";
import { createClient } from "../src/clients/createClient";
import { TenantConnectionManager } from "../src/tenancy/connectionManager";
import { entitlementsFor } from "../src/config/entitlements";
import { createProduct, updateProduct, deleteProduct, getProductAdmin, listPublicProducts, homeProducts, getPublicProduct, addProductImage, removeProductImage, makeMainImage, createCategory, listCategories, listProductsAdmin } from "../src/shop/products";
import { createOrder, buildQuote, setOrderStatus, updateOrderDetails, getOrder, getOrderByToken, listOrders, countNewOrders } from "../src/shop/orders";
import { createDiscount, saveShopSettings, listCustomers, lowStock, salesReport, advancedReport, getShopSettings, listDiscounts } from "../src/shop/extras";
import { deleteMedia } from "../src/store/media";

const T1 = entitlementsFor(1), T2 = entitlementsFor(2), T3 = entitlementsFor(3), T4 = entitlementsFor(4);
const PNG = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1]);
const who = { name: "Rahim", phone: "01710200935", address: "House 1, Road 2, Dhaka", ip: "1.1.1.1" };

let w: Awaited<ReturnType<typeof createTestWorld>>;
let mgr: TenantConnectionManager;
let p3: Pool, p1: Pool;
let n = 0;
const phone = () => `0171${String(1000000 + ++n)}`; // a fresh phone number so rate limits do not interfere
const mk = async (pool: Pool, ent = T4, over: Record<string, unknown> = {}) => {
  const r = await createProduct(pool, ent, { name: `Item ${++n}`, priceBdt: 500, ...over });
  if (!r.ok) throw new Error("setup: " + r.error);
  return r.id;
};

beforeAll(async () => {
  w = await createTestWorld();
  mgr = new TenantConnectionManager(w.control, w.masterKey);
  const c3 = await createClient(w.control, w.provider, w.masterKey, { businessName: "Shop3", slug: "shop3", packageTier: 3, templateKey: "professional" }, "t");
  const c1 = await createClient(w.control, w.provider, w.masterKey, { businessName: "Shop1", slug: "shop1", packageTier: 1, templateKey: "starter" }, "t");
  if (!c3.ok || !c1.ok) throw new Error("setup");
  p3 = await mgr.getPool(c3.tenantId); p1 = await mgr.getPool(c1.tenantId);
}, 180_000);
afterAll(async () => { await mgr.closeAll(); await w.cleanup(); }, 180_000);

describe("products", () => {
  it("validates input with a specific reason", async () => {
    const err = async (o: Record<string, unknown>) => { const r = await createProduct(p3, T4, { name: "Good name", priceBdt: 100, ...o }); return r.ok ? "ok" : r.error; };
    expect(await err({ name: "x" })).toBe("invalid_name");
    expect(await err({ name: "<b>bad</b>" })).toBe("invalid_name");
    expect(await err({ priceBdt: "-5" })).toBe("invalid_price");
    expect(await err({ priceBdt: "12.5" })).toBe("invalid_price");
    expect(await err({ priceBdt: 100, comparePriceBdt: 90 })).toBe("invalid_compare");
    expect(await err({ status: "deleted" })).toBe("invalid_status");
    expect(await err({ categoryId: "not-a-uuid" })).toBe("invalid_category");
    expect(await err({ categoryId: "11111111-1111-4111-8111-111111111111" })).toBe("invalid_category");
    expect(await err({ description: "x".repeat(3001) })).toBe("invalid_description");
    expect(await err({ variants: [{ label: "S" }, { label: "s" }] })).toBe("invalid_variants");
    expect(await err({ stockQty: "abc", trackStock: true })).toBe("invalid_stock");
  });
  it("gives every package products, but only higher packages the extras", async () => {
    expect((await createProduct(p1, T1, { name: "Plain product", priceBdt: 100 })).ok).toBe(true);
    const err = async (o: Record<string, unknown>) => { const r = await createProduct(p1, T1, { name: "Another one", priceBdt: 100, ...o }); return r.ok ? "ok" : r.error; };
    expect(await err({ isFeatured: true })).toBe("not_in_package");
    expect(await err({ trackStock: true, stockQty: 5 })).toBe("not_in_package");
    expect(await err({ variants: [{ label: "S" }] })).toBe("not_in_package");
    expect(await err({ comparePriceBdt: 200 })).toBe("ok"); // a sale price is for everyone
  });
  it("stops at the package's product limit", async () => {
    const small = { ...T1, shop: { ...T1.shop, maxProducts: 2 } };
    const { rows } = await listProductsAdmin(p1);
    const have = rows.length;
    for (let i = have; i < 2; i++) await createProduct(p1, small, { name: `Fill ${i}`, priceBdt: 1 });
    const r = await createProduct(p1, small, { name: "One too many", priceBdt: 1 });
    expect(r.ok ? "ok" : r.error).toBe("too_many_products");
  });
  it("makes a unique address; it only changes when the name changes", async () => {
    const a = await createProduct(p3, T4, { name: "Cotton Shirt", priceBdt: 100 }), b = await createProduct(p3, T4, { name: "Cotton Shirt", priceBdt: 100 });
    expect(a.ok && b.ok && a.slug === "cotton-shirt" && b.slug === "cotton-shirt-2").toBe(true);
    if (!a.ok) return;
    await updateProduct(p3, T4, a.id, { name: "Cotton Shirt", priceBdt: 120 });
    expect((await getProductAdmin(p3, a.id))!.product.slug).toBe("cotton-shirt");
    await updateProduct(p3, T4, a.id, { name: "Linen Shirt", priceBdt: 120 });
    expect((await getProductAdmin(p3, a.id))!.product.slug).toBe("linen-shirt");
  });
  it("keeps option ids when options are edited, and removes dropped ones", async () => {
    const id = await mk(p3, T4, { variants: [{ label: "S", stockQty: 5 }, { label: "M", stockQty: 5, priceBdt: 600 }] });
    const before = (await p3.query("SELECT id, label FROM shop_product_variants WHERE product_id = $1", [id])).rows;
    await updateProduct(p3, T4, id, { name: "Renamed option item", priceBdt: 500, variants: [{ label: "M", stockQty: 9, priceBdt: 650 }, { label: "L", stockQty: 1 }] });
    const after = (await p3.query("SELECT id, label, stock_qty, price_bdt FROM shop_product_variants WHERE product_id = $1 ORDER BY sort_order", [id])).rows;
    expect(after.map((r) => r.label)).toEqual(["M", "L"]);
    expect(after[0].id).toBe(before.find((r) => r.label === "M")!.id);
    expect([after[0].stock_qty, Number(after[0].price_bdt)]).toEqual([9, 650]);
  });
  it("stores photos with the product, limits them, and removes them with it", async () => {
    const id = await mk(p3, T4);
    const a = await addProductImage(p3, T4, id, { filename: "a.png", bytes: PNG }, "o"), b = await addProductImage(p3, T4, id, { filename: "b.png", bytes: PNG }, "o");
    expect(a.ok && b.ok).toBe(true);
    if (!a.ok || !b.ok) return;
    expect((await getProductAdmin(p3, id))!.images).toEqual([a.mediaId, b.mediaId]);
    expect(await makeMainImage(p3, id, b.mediaId)).toBe(true);
    expect((await getProductAdmin(p3, id))!.images).toEqual([b.mediaId, a.mediaId]);
    expect(await deleteMedia(p3, a.mediaId)).toEqual({ ok: false, error: "in_use" }); // not through the generic media page
    expect(await removeProductImage(p3, id, a.mediaId)).toBe(true);
    expect((await p3.query("SELECT 1 FROM media WHERE id = $1", [a.mediaId])).rowCount).toBe(0);
    const bad = await addProductImage(p3, T4, id, { filename: "x.svg", bytes: new TextEncoder().encode("<svg onload=alert(1)>") }, "o");
    expect(bad).toEqual({ ok: false, error: "bad_type" });
    const small = { ...T4, shop: { ...T4.shop, maxProductImages: 1 } };
    expect(await addProductImage(p3, small, id, { filename: "c.png", bytes: PNG }, "o")).toEqual({ ok: false, error: "too_many_images" });
    expect(await removeProductImage(p3, "11111111-1111-4111-8111-111111111111", b.mediaId)).toBe(false); // not this product's photo
    await deleteProduct(p3, id);
    expect((await p3.query("SELECT 1 FROM media WHERE id = $1", [b.mediaId])).rowCount).toBe(0);
  });
  it("shows visitors only visible products, and gates search and sorting by package", async () => {
    const cat = await createCategory(p3, T4, "Shirts");
    if (!cat.ok) throw new Error();
    const cheap = await mk(p3, T4, { name: "Zeta Searchable", priceBdt: 100, categoryId: cat.id });
    const dear = await mk(p3, T4, { name: "Alpha Searchable", priceBdt: 900, categoryId: cat.id });
    const hidden = await mk(p3, T4, { name: "Hidden Searchable", priceBdt: 50, status: "hidden" });
    const full = await listPublicProducts(p3, T4, { q: "searchable", sort: "price_desc" });
    expect(full.items.map((i) => i.name)).toEqual(["Alpha Searchable", "Zeta Searchable"]);
    expect(full.items.some((i) => i.id === hidden)).toBe(false);
    expect((await listPublicProducts(p3, T4, { category: "shirts" })).total).toBe(2);
    const basic = await listPublicProducts(p3, T1, { q: "searchable", sort: "price_desc" }); // T1 cannot search or sort
    expect(basic.q).toBe("");
    expect(basic.sort).toBe("newest");
    expect(basic.total).toBeGreaterThan(2);
    expect(await getPublicProduct(p3, T4, "hidden-searchable")).toBeNull();
    expect((await getPublicProduct(p3, T4, "alpha-searchable"))!.card.id).toBe(dear);
    void cheap;
  });
  it("treats search text literally, not as a pattern", async () => {
    await mk(p3, T4, { name: "100% Cotton Towel", priceBdt: 10 });
    expect((await listPublicProducts(p3, T4, { q: "100%" })).items.map((i) => i.name)).toEqual(["100% Cotton Towel"]);
    expect((await listPublicProducts(p3, T4, { q: "%" })).items.length).toBe(1);
    expect((await listPublicProducts(p3, T4, { q: "'; DROP TABLE shop_products; --" })).total).toBe(0);
  });
  it("shows featured products first on the home page for packages that have them", async () => {
    const f = await mk(p3, T4, { name: "Star Product", priceBdt: 1, isFeatured: true });
    expect((await homeProducts(p3, T4, 8))[0]!.id).toBe(f);
    expect((await homeProducts(p3, T4, 8))[0]!.featured).toBe(true);
  });
  it("marks an item sold out when tracked stock reaches zero", async () => {
    const id = await mk(p3, T4, { name: "Last One", trackStock: true, stockQty: 0 });
    expect((await getPublicProduct(p3, T4, "last-one"))!.card.soldOut).toBe(true);
    const noTrack = await mk(p3, T4, { name: "Untracked Zero", stockQty: 0 });
    expect((await getPublicProduct(p3, T4, "untracked-zero"))!.card.soldOut).toBe(false);
    void id; void noTrack;
  });
  it("lists categories with product counts and removes them safely", async () => {
    const c = await createCategory(p3, T4, "Temp Cat");
    if (!c.ok) throw new Error();
    const id = await mk(p3, T4, { categoryId: c.id });
    expect((await listCategories(p3)).find((x) => x.id === c.id)!.count).toBe(1);
    await p3.query("DELETE FROM shop_categories WHERE id = $1", [c.id]);
    expect((await getProductAdmin(p3, id))!.product.category_id).toBeNull(); // the product stays
    expect((await createCategory(p3, T4, "<i>x</i>")).ok).toBe(false);
  });
});

describe("orders", () => {
  it("prices the order from the database, ignoring anything the browser claims", async () => {
    const id = await mk(p3, T3, { name: "Priced Item", priceBdt: 700 });
    const r = await createOrder(p3, T3, { channel: "checkout", items: [{ productId: id, qty: 2, price: 1, unitPrice: 1, total: 1 }], ...who, phone: phone() });
    expect(r.ok && !("silent" in r && r.silent) && r.total).toBe(1400);
    if (r.ok && !r.silent) {
      const o = await getOrder(p3, r.id);
      expect(o!.items[0]).toMatchObject({ name: "Priced Item", qty: 2, line_total_bdt: 1400 });
      expect(r.number).toBeGreaterThanOrEqual(1001);
      expect((await getOrderByToken(p3, r.token))!.order.id).toBe(r.id);
    }
    expect(await getOrderByToken(p3, "short")).toBeNull();
    expect(await getOrderByToken(p3, "x".repeat(24))).toBeNull();
  });
  it("applies option prices, delivery fee and free delivery", async () => {
    await saveShopSettings(p3, { deliveryFee: "60", freeOver: "2000", orderNote: "Cash on delivery" });
    const id = await mk(p3, T3, { name: "Option Item", priceBdt: 500, variants: [{ label: "L", priceBdt: 800, stockQty: 3 }] });
    const v = (await p3.query("SELECT id FROM shop_product_variants WHERE product_id = $1", [id])).rows[0].id;
    const small = await buildQuote(p3, T3, [{ productId: id, variantId: v, qty: 1 }], "", false);
    expect(small.ok && small.quote).toMatchObject({ subtotal: 800, deliveryFee: 60, total: 860 });
    const big = await buildQuote(p3, T3, [{ productId: id, variantId: v, qty: 3 }], "", false);
    expect(big.ok && big.quote).toMatchObject({ subtotal: 2400, deliveryFee: 0, total: 2400 });
    const noOpt = await buildQuote(p3, T3, [{ productId: id, qty: 1 }], "", false);
    expect(noOpt.ok && noOpt.quote.lines[0]!.problem).toBe("choose_option");
    await saveShopSettings(p3, { deliveryFee: "0", freeOver: "", orderNote: "" });
  });
  it("takes stock with the order, refuses more than is left, and gives it back on cancel", async () => {
    const id = await mk(p3, T4, { name: "Stock Item", priceBdt: 100, trackStock: true, stockQty: 3 });
    const o1 = await createOrder(p3, T4, { channel: "checkout", items: [{ productId: id, qty: 2 }], ...who, phone: phone() });
    expect(o1.ok).toBe(true);
    expect((await getProductAdmin(p3, id))!.product.stock_qty).toBe(1);
    const o2 = await createOrder(p3, T4, { channel: "checkout", items: [{ productId: id, qty: 2 }], ...who, phone: phone() });
    expect(o2).toMatchObject({ ok: false, error: "out_of_stock", item: "Stock Item" });
    expect((await getProductAdmin(p3, id))!.product.stock_qty).toBe(1); // a refused order takes nothing
    if (!o1.ok || o1.silent) return;
    expect(await setOrderStatus(p3, T4, o1.id, "cancelled", "owner")).toEqual({ ok: true });
    expect((await getProductAdmin(p3, id))!.product.stock_qty).toBe(3);
    expect(await setOrderStatus(p3, T4, o1.id, "confirmed", "owner")).toEqual({ ok: false, error: "closed" }); // cancelled is final
    expect((await setOrderStatus(p3, T4, o1.id, "cancelled", "owner")).ok).toBe(false);
    expect((await getProductAdmin(p3, id))!.product.stock_qty).toBe(3); // not given back twice
  });
  it("lets only one of two simultaneous buyers take the last item", async () => {
    const id = await mk(p3, T4, { name: "Race Item", priceBdt: 100, trackStock: true, stockQty: 1 });
    const buy = (i: number) => createOrder(p3, T4, { channel: "checkout", items: [{ productId: id, qty: 1 }], ...who, phone: phone(), ip: `9.9.9.${i}` });
    const [a, b] = await Promise.all([buy(1), buy(2)]);
    expect([a.ok, b.ok].sort()).toEqual([false, true]);
    expect((await getProductAdmin(p3, id))!.product.stock_qty).toBe(0);
  });
  it("refuses sold out, hidden and unknown products", async () => {
    const so = await mk(p3, T4, { name: "Sold Item", status: "sold_out" }), hid = await mk(p3, T4, { name: "Hidden Item", status: "hidden" });
    for (const [pid, err] of [[so, "sold_out"], [hid, "not_available"], ["11111111-1111-4111-8111-111111111111", "not_available"]] as const)
      expect(await createOrder(p3, T4, { channel: "checkout", items: [{ productId: pid, qty: 1 }], ...who, phone: phone() })).toMatchObject({ ok: false, error: err });
    expect(await createOrder(p3, T4, { channel: "checkout", items: [{ productId: "nope", qty: 1 }], ...who, phone: phone() })).toMatchObject({ ok: false, error: "invalid_items" });
    for (const qty of [0, -1, 51, 1.5, "abc", null]) expect(await createOrder(p3, T4, { channel: "checkout", items: [{ productId: so, qty }], ...who, phone: phone() })).toMatchObject({ ok: false, error: "invalid_items" });
    expect(await createOrder(p3, T4, { channel: "checkout", items: [], ...who, phone: phone() })).toMatchObject({ ok: false, error: "invalid_items" });
  });
  it("validates the customer's details", async () => {
    const id = await mk(p3, T3);
    const err = async (o: Record<string, unknown>) => { const r = await createOrder(p3, T3, { channel: "request", items: [{ productId: id, qty: 1 }], ...who, phone: phone(), ...o }); return r.ok ? "ok" : r.error; };
    expect(await err({ name: "A" })).toBe("invalid_name");
    expect(await err({ name: "<script>" })).toBe("invalid_name");
    expect(await err({ phone: "abc" })).toBe("invalid_phone");
    expect(await err({ email: "nope" })).toBe("invalid_email");
    expect(await err({ address: "x" })).toBe("invalid_address");
    expect(await err({ note: "x".repeat(501) })).toBe("invalid_note");
    expect(await err({ channel: "gift" })).toBe("invalid_items");
  });
  it("drops robot submissions and rate-limits repeat orders", async () => {
    const id = await mk(p3, T3);
    expect(await createOrder(p3, T3, { channel: "request", items: [{ productId: id, qty: 1 }], ...who, phone: phone(), website: "http://spam" })).toEqual({ ok: true, silent: true });
    const ph = phone();
    for (let i = 0; i < 6; i++) expect((await createOrder(p3, T3, { channel: "request", items: [{ productId: id, qty: 1 }], ...who, phone: ph, ip: `7.7.7.${i}` })).ok).toBe(true);
    expect(await createOrder(p3, T3, { channel: "request", items: [{ productId: id, qty: 1 }], ...who, phone: ph, ip: "7.7.7.99" })).toMatchObject({ ok: false, error: "rate_limited" });
    for (let i = 0; i < 8; i++) await createOrder(p3, T3, { channel: "request", items: [{ productId: id, qty: 1 }], ...who, phone: phone(), ip: "8.8.8.8" });
    expect(await createOrder(p3, T3, { channel: "request", items: [{ productId: id, qty: 1 }], ...who, phone: phone(), ip: "8.8.8.8" })).toMatchObject({ ok: false, error: "rate_limited" });
  });
  it("gives simple packages order requests for one product, and the cart only to packages that include it", async () => {
    const id = await mk(p1, T1, { name: "Request Item" });
    const id2 = await mk(p1, T1, { name: "Request Item Two" });
    expect(await createOrder(p1, T1, { channel: "checkout", items: [{ productId: id, qty: 1 }], ...who, phone: phone() })).toMatchObject({ ok: false, error: "not_in_package" });
    expect(await createOrder(p1, T1, { channel: "request", items: [{ productId: id, qty: 1 }, { productId: id2, qty: 1 }], ...who, phone: phone() })).toMatchObject({ ok: false, error: "one_item_only" });
    expect((await createOrder(p1, T1, { channel: "request", items: [{ productId: id, qty: 2 }], ...who, phone: phone() })).ok).toBe(true);
  });
  it("applies discount codes safely", async () => {
    expect(await createDiscount(p3, T3, { code: "SAVE10", kind: "percent", value: 10 })).toEqual({ ok: false, error: "not_in_package" });
    expect(await createDiscount(p3, T4, { code: "bad code!", kind: "percent", value: 10 })).toEqual({ ok: false, error: "invalid_code" });
    expect(await createDiscount(p3, T4, { code: "BIG", kind: "percent", value: 150 })).toEqual({ ok: false, error: "invalid_value" });
    expect(await createDiscount(p3, T4, { code: "SAVE10", kind: "percent", value: 10, maxUses: 1 })).toEqual({ ok: true });
    expect(await createDiscount(p3, T4, { code: "save10", kind: "percent", value: 5 })).toEqual({ ok: false, error: "code_exists" });
    expect(await createDiscount(p3, T4, { code: "MIN500", kind: "fixed", value: 100, minOrder: 5000 })).toEqual({ ok: true });
    expect(await createDiscount(p3, T4, { code: "OLD", kind: "fixed", value: 100, expiresOn: "2020-01-01" })).toEqual({ ok: true });
    expect(await createDiscount(p3, T4, { code: "BADDATE", kind: "fixed", value: 100, expiresOn: "2026-02-31" })).toEqual({ ok: false, error: "invalid_date" });
    const id = await mk(p3, T4, { name: "Discount Item", priceBdt: 1000 });
    const order = (code: string, ent = T4) => createOrder(p3, ent, { channel: "checkout", items: [{ productId: id, qty: 1 }], discountCode: code, ...who, phone: phone() });
    const ok = await order("save10");
    expect(ok.ok && !ok.silent && ok.total).toBe(900);
    expect(await order("SAVE10")).toMatchObject({ ok: false, error: "invalid_code" }); // used up
    expect(await order("MIN500")).toMatchObject({ ok: false, error: "invalid_code" }); // minimum not reached
    expect(await order("OLD")).toMatchObject({ ok: false, error: "invalid_code" });
    expect(await order("NOPE")).toMatchObject({ ok: false, error: "invalid_code" });
    expect(await order("SAVE10", T3)).toMatchObject({ ok: false, error: "invalid_code" }); // package without discounts
    expect((await listDiscounts(p3)).find((d) => d.code === "SAVE10")!.used_count).toBe(1);
  });
  it("lets simple packages confirm or cancel, and full order management move it along", async () => {
    const id = await mk(p3, T3);
    const r = await createOrder(p3, T3, { channel: "checkout", items: [{ productId: id, qty: 1 }], ...who, phone: phone() });
    if (!r.ok || r.silent) throw new Error();
    expect(await setOrderStatus(p3, T1, r.id, "shipped", "o")).toEqual({ ok: false, error: "not_in_package" });
    expect(await setOrderStatus(p3, T3, r.id, "teleported", "o")).toEqual({ ok: false, error: "invalid_status" });
    expect(await setOrderStatus(p3, T1, r.id, "confirmed", "o")).toEqual({ ok: true });
    expect(await setOrderStatus(p3, T3, r.id, "shipped", "o")).toEqual({ ok: true });
    expect(await updateOrderDetails(p3, T1, r.id, { paymentStatus: "paid" })).toEqual({ ok: false, error: "not_in_package" });
    expect(await updateOrderDetails(p3, T3, r.id, { paymentStatus: "paid", courier: "Pathao", trackingCode: "PX123", internalNote: "Call first" })).toEqual({ ok: true });
    expect(await updateOrderDetails(p3, T3, r.id, { paymentStatus: "maybe" })).toEqual({ ok: false, error: "invalid_value" });
    const o = (await getOrder(p3, r.id))!;
    expect(o.order).toMatchObject({ status: "shipped", payment_status: "paid", courier: "Pathao", tracking_code: "PX123" });
    expect(o.events.map((e) => e.status)).toEqual(["new", "confirmed", "shipped"]);
  });
  it("lists orders with filters and counts new ones", async () => {
    expect((await countNewOrders(p3))).toBeGreaterThan(0);
    const all = await listOrders(p3, {});
    expect(all.total).toBeGreaterThan(5);
    expect((await listOrders(p3, { status: "shipped" })).rows.every((o) => o.status === "shipped")).toBe(true);
    expect((await listOrders(p3, { q: "%" })).total).toBe(0);
    expect((await listOrders(p3, { q: String(all.rows[0]!.number) })).rows[0]!.number).toBe(all.rows[0]!.number);
  });
});

describe("customers, stock alerts and reports", () => {
  it("builds the customer list from orders", async () => {
    const id = await mk(p3, T4, { name: "Report Item", priceBdt: 250 });
    const ph = phone();
    for (const name of ["Karim", "Karim B"]) await createOrder(p3, T4, { channel: "checkout", items: [{ productId: id, qty: 2 }], ...who, name, phone: ph });
    const c = (await listCustomers(p3)).find((x) => x.phone === ph)!;
    expect(c).toMatchObject({ name: "Karim B", orders: 2, spent: 1000 });
  });
  it("warns about low stock only for packages that have the alert", async () => {
    await mk(p3, T4, { name: "Nearly Gone", trackStock: true, stockQty: 2, lowStockAt: 3 });
    await mk(p3, T4, { name: "Plenty", trackStock: true, stockQty: 50 });
    expect((await lowStock(p3, T4)).map((r) => r.name)).toContain("Nearly Gone");
    expect((await lowStock(p3, T4)).map((r) => r.name)).not.toContain("Plenty");
    expect(await lowStock(p3, T3)).toEqual([]);
  });
  it("reports sales without counting cancelled orders, and detailed numbers only for packages that include them", async () => {
    const id = await mk(p3, T4, { name: "Totals Item", priceBdt: 1000 });
    const before = await salesReport(p3, 30);
    const a = await createOrder(p3, T4, { channel: "checkout", items: [{ productId: id, qty: 1 }], ...who, phone: phone() });
    const b = await createOrder(p3, T4, { channel: "checkout", items: [{ productId: id, qty: 1 }], ...who, phone: phone() });
    if (!a.ok || a.silent || !b.ok || b.silent) throw new Error();
    await setOrderStatus(p3, T4, b.id, "cancelled", "o");
    const after = await salesReport(p3, 30);
    expect(after.orders - before.orders).toBe(1);
    expect(after.revenue - before.revenue).toBe(1000);
    expect(after.cancelled - before.cancelled).toBe(1);
    expect(after.byDay).toHaveLength(30);
    expect(after.top.find((t) => t.name === "Totals Item")).toMatchObject({ qty: 1, revenue: 1000 });
    expect(await salesReport(p3, "9999")).toMatchObject({ days: 30 });
    expect(await advancedReport(p3, T3, 30)).toBeNull();
    const adv = (await advancedReport(p3, T4, 30))!;
    expect(adv.customers).toBeGreaterThan(0);
    expect(adv.byCategory.length).toBeGreaterThan(0);
  });
  it("validates shop settings", async () => {
    expect(await saveShopSettings(p3, { deliveryFee: "abc", freeOver: "", orderNote: "" })).toEqual({ ok: false, error: "invalid_fee" });
    expect(await saveShopSettings(p3, { deliveryFee: "60", freeOver: "x", orderNote: "" })).toEqual({ ok: false, error: "invalid_free_over" });
    expect(await saveShopSettings(p3, { deliveryFee: "60", freeOver: "1500", orderNote: "Pay on delivery" })).toEqual({ ok: true });
    expect(await getShopSettings(p3)).toMatchObject({ delivery_fee_bdt: 60, free_delivery_over_bdt: 1500, order_note: "Pay on delivery" });
  });
});

describe("promotional campaigns", () => {
  const today = new Date().toISOString().slice(0, 10), tomorrow = new Date(Date.now() + 86_400_000).toISOString().slice(0, 10), yesterday = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);
  it("is refused for packages without it and validates input", async () => {
    const { createCampaign } = await import("../src/shop/campaigns");
    expect(await createCampaign(p3, T3, { name: "Sale", percent: 10, appliesTo: "all", startsOn: today, endsOn: tomorrow })).toEqual({ ok: false, error: "not_in_package" });
    const err = async (o: Record<string, unknown>) => { const r = await createCampaign(p3, T4, { name: "Sale", percent: 10, appliesTo: "all", startsOn: today, endsOn: tomorrow, ...o }); return r.ok ? "ok" : r.error; };
    expect(await err({ name: "x" })).toBe("invalid_name");
    expect(await err({ percent: 0 })).toBe("invalid_percent");
    expect(await err({ percent: 95 })).toBe("invalid_percent");
    expect(await err({ appliesTo: "some" })).toBe("invalid_applies");
    expect(await err({ appliesTo: "category", categoryId: "11111111-1111-4111-8111-111111111111" })).toBe("invalid_category");
    expect(await err({ startsOn: tomorrow, endsOn: today })).toBe("invalid_dates");
    expect(await err({ endsOn: "2999-01-01" })).toBe("invalid_dates");
    expect(await err({ startsOn: "2026-02-31" })).toBe("invalid_dates");
  });
  it("lowers prices on cards, the product page and orders while it runs, and not outside its dates", async () => {
    const { createCampaign, listCampaigns, setCampaignActive } = await import("../src/shop/campaigns");
    const id = await mk(p3, T4, { name: "Campaign Item", priceBdt: 1000, comparePriceBdt: 1500 });
    const slug = "campaign-item";
    await p3.query("DELETE FROM shop_campaigns");
    expect((await getPublicProduct(p3, T4, slug))!.card).toMatchObject({ priceBdt: 1000, comparePriceBdt: 1500, salePercent: null });
    expect(await createCampaign(p3, T4, { name: "Future", percent: 50, appliesTo: "all", startsOn: tomorrow, endsOn: tomorrow })).toEqual({ ok: true });
    expect(await createCampaign(p3, T4, { name: "Past", percent: 50, appliesTo: "all", startsOn: yesterday, endsOn: yesterday })).toEqual({ ok: true });
    expect((await getPublicProduct(p3, T4, slug))!.card.priceBdt).toBe(1000);
    expect(await createCampaign(p3, T4, { name: "Small", percent: 10, appliesTo: "all", startsOn: today, endsOn: tomorrow })).toEqual({ ok: true });
    expect(await createCampaign(p3, T4, { name: "Big", percent: 25, appliesTo: "all", startsOn: yesterday, endsOn: tomorrow })).toEqual({ ok: true });
    const card = (await getPublicProduct(p3, T4, slug))!.card;
    expect(card).toMatchObject({ priceBdt: 750, comparePriceBdt: 1000, salePercent: 25 }); // the biggest running campaign wins; the old price is the normal price
    expect((await listPublicProducts(p3, T4, { q: "Campaign Item" })).items[0]!.priceBdt).toBe(750);
    expect((await homeProducts(p3, T4, 24)).find((c) => c.id === id)!.priceBdt).toBe(750);
    const q = await buildQuote(p3, T4, [{ productId: id, qty: 2 }], "", false);
    expect(q.ok && q.quote.subtotal).toBe(1500);
    expect((await getPublicProduct(p3, T3, slug))!.card.priceBdt).toBe(1000); // a package without campaigns charges the normal price
    await saveShopSettings(p3, { deliveryFee: "0", freeOver: "", orderNote: "" });
    const o = await createOrder(p3, T4, { channel: "checkout", items: [{ productId: id, qty: 1 }], ...who, phone: phone(), ip: "3.3.3.3" });
    expect(o.ok && !o.silent && o.total).toBe(750);
    const big = (await listCampaigns(p3)).find((c) => c.name === "Big")!;
    expect(big.running).toBe(true);
    await setCampaignActive(p3, big.id, false);
    expect((await getPublicProduct(p3, T4, slug))!.card.salePercent).toBe(10);
  });
  it("can be limited to one category and applies to option prices", async () => {
    const { createCampaign } = await import("../src/shop/campaigns");
    await p3.query("DELETE FROM shop_campaigns");
    const cat = await createCategory(p3, T4, "Sale Cat");
    if (!cat.ok) throw new Error();
    const inCat = await mk(p3, T4, { name: "In Sale Cat", priceBdt: 200, categoryId: cat.id, variants: [{ label: "A", priceBdt: 400 }] });
    const outCat = await mk(p3, T4, { name: "Out Of Sale Cat", priceBdt: 200 });
    expect(await createCampaign(p3, T4, { name: "Cat sale", percent: 50, appliesTo: "category", categoryId: cat.id, startsOn: today, endsOn: tomorrow })).toEqual({ ok: true });
    const a = (await getPublicProduct(p3, T4, "in-sale-cat"))!;
    expect(a.card.priceBdt).toBe(100);
    expect(a.variants[0]!.priceBdt).toBe(200);
    expect((await getPublicProduct(p3, T4, "out-of-sale-cat"))!.card.priceBdt).toBe(200);
    void inCat; void outCat;
    await p3.query("DELETE FROM shop_categories WHERE id = $1", [cat.id]); // deleting the category removes its campaign
    expect((await p3.query("SELECT 1 FROM shop_campaigns")).rowCount).toBe(0);
  });
});

/** Runs once when the server starts. It upgrades the databases so an update can never leave the websites broken. */
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { bootstrap } = await import("./src/web/bootstrap");
    await bootstrap();
  }
}

# Agency Platform (managed website platform for Bangladesh clients)

One shared application, many client websites, **one separate PostgreSQL database per client**.
Status: **Phases 1-2 plus admin login, client creation and manual billing, suspend/reactivate, data export, the client's own website dashboard and Template 2, editable packages and a pricing page (development build)**. Read `docs/04-status.md` for exactly what works.

## What you need on your computer (all free)
1. **Node.js 22 or newer** - https://nodejs.org (choose "LTS").
2. **Docker Desktop** - https://www.docker.com/products/docker-desktop/ (runs the local database).
   Check the Docker Desktop license terms for your situation; if it is a problem, any local PostgreSQL 16 works instead.
3. A code editor is optional. You will mostly copy and paste commands.

## First-time setup (about 10 minutes)
Open a terminal inside this folder, then run these one at a time:

```
docker compose up -d            # starts the local database (wait ~10 seconds)
npm install                     # downloads the code libraries
cp .env.development.example .env
npm run secrets:generate        # prints a line starting with SECRETS_MASTER_KEY=
```
Open the new `.env` file in any text editor and replace the `SECRETS_MASTER_KEY=...` line with the line the last command printed. Save. Then:

```
npm run db:migrate              # creates the control-plane tables
npm run tenant:provision-demo   # creates a demo client with its OWN database
npm test                        # runs the automated checks
```
Windows users: use PowerShell; replace `cp` with `copy`.

## Create your admin login (needed once)
```
npm run db:migrate
npm run admin:create
```
It asks for your email, then a password twice (at least 12 characters; the typing is hidden, so nothing appears as you type). The password is never saved in any file; only a scrambled hash goes into the database. Keep it in a password manager. If you forget it, run the command again with a different email.

## Run the website on your computer
After the setup above works, and after `npm install` (new libraries were added):
```
npm run domain:verify-dev -- demo-starter.localtest.me
npm run dev
```
Wait for `Ready`, then open these in your browser (the first load is slow on a low-end PC):
| Address | What you should see |
|---|---|
| http://localhost:3000 | Platform home page with an "Open admin" button |
| http://localhost:3000/admin | Admin login, then create clients and see the client list |
| http://demo-starter.localtest.me:3000 | The demo client's Starter website |
| http://localhost:3000/api/health | `{"status":"ok"}` |
`localtest.me` is a public name that points to your own computer, so it needs internet. Press Ctrl+C in the terminal to stop the website.

## Create a client from the dashboard
1. Log in at http://localhost:3000/admin.
2. Fill the **Create client** form (business name, a short name like `rahim-traders`, package, template, optional domain) and press the button.
3. You land on the client's page showing its separate database, domain and a setup log. If setup fails, press **Retry setup**; it is safe to repeat.
4. To see the client's website on your PC, press **Mark verified (development shortcut)** on its page, then open the client's domain with `:3000` at the end. A made-up domain like `testshop.example.com` will not open in your browser by itself; use `something.localtest.me` (needs internet) or `something.localhost` instead.
Only the Starter template exists so far; the other four show as "not built yet".

## Billing (manual, no online payments)
Open a client's page and scroll to **Billing**:
1. Enter the price you agreed (setup fee, monthly fee, optional discount and the date it ends, service start date, grace days) and press **Save agreement**. The standard package prices are only suggestions.
2. Press **Create setup invoice**, then **Create monthly invoice** each month when it is due.
3. When you have confirmed that money arrived (bKash, Nagad, bank, cash...), open **Record payment** on the invoice. Partial payments are allowed. An invoice only becomes paid through recorded payments.
4. A mistaken invoice with no payments can be **voided**. The **Money overview** on the admin home shows monthly recurring revenue, outstanding and overdue amounts; **See all unpaid invoices** lists every open invoice.
Run `npm run db:migrate` after updating so the billing tables exist.

## Suspend, reactivate and export a client
On a client's page, under **Website access and data**:
- **Suspend this website** (a reason is required): visitors see a "temporarily unavailable" page. Nothing is deleted: the database, domain, billing records and settings all stay. **Reactivate website** brings the site back exactly as it was. Nothing is ever suspended automatically; the **Unpaid invoices** page helps you decide.
- **Download this client's data (JSON)**: a file with only that client's own website data, for handover or backup. Your prices, invoices, notes and any passwords are never included. It works for suspended clients too. Very large stores (over about 100,000 rows or 50 MB) need a full database dump instead.
Run `npm run db:migrate` after updating (adds `0005_suspension.sql`).

## Give a client their own dashboard login
Each client manages their own website at **their own domain + `/dashboard`** (for example `http://myshop.localtest.me:3000/dashboard` on your PC). The domain must be verified first.
1. On the client's page in your admin, under **Owner login**, type the owner's email and press **Create owner login**. A temporary password appears **once**: copy it and send it privately. (Command-line alternative: `npm run owner:create -- <short-name> <email>`.)
2. The owner logs in, is asked to choose their own password, then can **Edit website**: main colour, headline, texts, contact details, and which sections show and in what order.
3. **Save draft** keeps changes private; **Preview** shows them; **Save and publish** makes them live. The previous version is kept in history (last 20).
4. If the owner forgets the password, press **New temporary password** on their row. **Deactivate** blocks them and ends their sessions.
Clients cannot see prices, billing or other clients. `npm run db:migrate` now also updates every existing client's database; run it after each update.

## Packages, prices and the pricing page
Default prices (setup / monthly): Starter ৳7,000 / ৳1,000, Business ৳17,000 / ৳1,800, E-commerce ৳27,000 / ৳2,500, Professional ৳40,000 / ৳3,500, Premium ৳50,000 / ৳5,000.
- **Admin > Packages and pricing**: edit each package's default prices, description, every feature (on/off) and the limits (services, reviews, image storage, products...). Features marked "not built yet" have no effect until they are built. Every change is in the audit log. Add your WhatsApp number there so the pricing page buttons work.
- **Public pricing page**: open `/pricing` on the platform address (for example `http://localhost:3000/pricing`): five package cards, a comparison table and "coming soon" labels on anything not built yet.
- **Existing clients are never changed** when you change a default price: each client's agreement and invoices keep the price you agreed with them. Change a client's own price under Billing on their page.
- **Owner dashboard > My package**: shows the owner's package, what is included and what is not (with the package that includes it), their billing (agreement and invoices, read-only), and forms to request an upgrade or support. You see those under **Admin > Client requests**. A package only changes when you apply it.
- A feature outside the owner's package shows an upgrade message, and the server refuses it even if someone sends the request by hand.
Run `npm run db:migrate` after updating (adds `0006_package_system.sql`).

## Packages and templates
- **Tier 1 (Starter template):** one page; colour, texts, contact, up to 6 services, section order.
- **Tier 2 and above (Professional template):** everything in Tier 1, plus separate Services / Reviews / Contact pages, up to 12 services, customer reviews, a public **inquiry / quote form** (messages go to the owner's **Inquiries** inbox), accent colour, font and button style, banner style, and an optional Google Analytics ID. Tiers 3 to 5 get the same for now; the e-commerce templates are not built yet.
- Rules are enforced on the server: a Tier 1 owner cannot save or see Tier 2 features, even with a forged request.
- To change a client's package, open the client page and use **Package and template**. A downgrade needs a tick-box confirmation and **deletes nothing**: extra features are only hidden until you upgrade again. Changing the package does not change the agreed prices; update those under Billing.
- Run `npm run db:migrate` after updating (adds the inquiries table to every client database).

## Layout options, announcement banner and extra sections (Tier 2 and above)
- **Edit website > Layout:** 21 choices in four groups (top of the page, sections, look and feel, page) plus three one-click starting looks (Classic, Modern, Compact). Presets only fill in the choices; nothing changes until the owner saves, and **Preview saved draft** shows the result.
- **Headings and main button:** custom section headings and a main button (link, phone or page) in the top banner.
- **Announcement banner:** a thin bar above the menu with an optional button and an optional end date (it hides itself after that date). Links may only be `https://...` addresses or a page of the same site such as `/contact`.
- **Why choose us** (up to 6) and **Questions and answers** (up to 10) are new home-page sections. Tick them in **Sections and order** to show them.
- Owners whose package does not include these see a "Not in your package" card that links to **My package**. The server also refuses forged requests. After a downgrade the saved choices are kept and come back on upgrade.
- You can switch each feature on or off per package under **Admin > Packages and pricing** ("More layout options", "Promotional banners", "Advanced homepage sections").
- The admin now has a top menu (Clients, Billing, Packages and pricing, Client requests with an open-request count), summary tiles, and a searchable client list with status and package filters.

## Expanded SEO and the preview beside the editor
- **Google search appearance** shows character counts and a picture of how the result may look in Google. Tier 2 and above can also choose the **picture shown when the link is shared** (WhatsApp, Facebook; it defaults to the banner photo) and **ask Google not to show the site** (a noindex tag, and the sitemap is switched off; the site still opens for anyone with the address).
- **Show preview beside the editor** (screens wider than 1100 px) displays the last *saved* draft next to the form, in Phone or Wide size, for any page. Press Save draft to update it. Only `/dashboard/preview` may be framed, and only by the same website; every other page still refuses framing.

## The visual builder (Edit website)
**Dashboard > Edit website** opens a full-screen editor that works on the page itself:
- Click any text on the page and type. Click a block to select it.
- Drag the blue handles on a block's top and bottom edge to change the space above and below. Sliders set text size, heading size, photo height, columns, gaps, corner roundness and content width; buttons set alignment; each block has its own background and text colour.
- Drag blocks in the left list (or use the arrows) to reorder; hide, duplicate or delete them; add new ones (big banner, text, photo and text, highlights, services, products, gallery, reviews, questions, call to action, contact, message form, space).
- Switch between Desktop, Tablet and Phone widths; Undo and Redo (Ctrl+Z, Ctrl+Y); Save draft or Publish.
- **Choose a template** switches the whole page to one of four designed looks (Studio, Bold, Elegant, Market). It replaces the blocks and colours; Undo restores them.
A site made with the older settings form is converted automatically the first time it is opened in the builder; nothing is lost, and the live site does not change until you press Publish. The older form is still available as **Site settings** (contact details, hours, social links, search appearance).
Plans: the look and size controls are in every package. The block types follow the plan (shop, highlights and questions, gallery, reviews and the message form need the matching feature), and services and reviews are limited by package. Every limit is checked again on the server when saving, and a photo can only be one that belongs to that website.

## Updating an existing installation
If you copy a new version over your old folder, old files that were renamed stay behind (for example `migrations/tenant/0005_shop.sql`). The app ignores those known leftovers, and `npm run doctor` lists them; you may delete them.
Copy the new version over the old one, run `npm install`, then start the app as usual (`npm run dev`). **The app upgrades the main database and every client's database by itself when it starts** (it applies only what is missing, under a database lock, and prints `[startup] ...` lines). `npm run dev` also runs the upgrade first. You can run it yourself any time with `npm run db:migrate`, and set `AUTO_MIGRATE=false` in `.env` if you prefer to control it.
If a website ever does not open, run **`npm run doctor`**. It checks Node, `.env`, the database connection, every database's version and prints the exact web addresses to open, with a fix for each problem it finds.
The shop's tables all start with `shop_` (`shop_products`, `shop_orders`, ...), so they can never clash with tables already in a client's database. Older tables with names such as `products` or `orders` are left untouched and are not used.

## Design for every package, and the plans
Colours (main, accent, background, text, card tint), font, buttons, 28 layout choices (text, heading, button and logo sizes; banner height, gradient direction and curved or slanted edge; photo shape; card, corner and section styles; widths and spacing; header and footer) are now in **every** package, on every template. Plans are unchanged in what they differentiate: limits (products, images, storage, services), the gallery, reviews, inquiry form, FAQ and highlights, announcement banner, expanded SEO, analytics, the shop features below, and for the top package the **Section designer** (own colours, alignment and spacing per section). You can still switch any feature on or off per package under **Admin > Packages and pricing**. The editor is split into tabs (Design, Content, Contact and hours, Sections and order, Search and statistics). Text and background colours must keep a readable contrast; the server refuses unreadable combinations, and button text turns dark or white by itself.

## The shop (every package, with limits)
| | Basic packages | Higher packages |
|---|---|---|
| Products, photos, categories, sale price, Active / Sold out / Hidden | yes (limits by package) | yes |
| Order | an order request for one product (name, phone, address), plus an "Ask on WhatsApp" link | cart, checkout, cash on delivery, delivery charge, free-delivery amount |
| Options (size, colour) with own price and stock | | yes |
| Search, sorting, featured products | | yes |
| Stock counting (orders reduce it, cancelling returns it), low-stock warnings | | yes |
| Order handling | new / confirmed / cancelled | full pipeline, payment status, courier and tracking (typed in by hand), private notes, print |
| Customers, sales reports | | yes |
| Discount codes | | higher |
| Promotional campaigns (automatic % off for a period) | | higher |
| Detailed reports (by category, repeat customers, discounts) | | higher |
Prices, stock, delivery and discounts are always worked out on the server from the database; the browser only sends product ids and quantities. Product photos are shrunk in the browser before upload. Visitors' addresses: `/products`, `/products/<name>`, `/cart`, `/checkout`, `/order/<private link>`.

## Domains (DNS)
Owners add up to 3 domains. Each needs a TXT proof record (`_agency-verify`) and must point at your platform. Set `DOMAIN_CNAME_TARGET` and/or `DOMAIN_A_RECORD` so the page tells owners where to point, and so **Check DNS** can tell whether a domain really points to you. **Admin > Domains** lists every domain with its state and lets you re-check; each client's page has the same checks.

## Super panel additions
Domains overview, Templates (all five are ready and say what they start with), per-client **Template look** (gives a client's *draft* the template's sections, colours and layout, never touching content or publishing), plus Orders from the public Buy page.

## Not built yet (still marked "coming soon" on the pricing page)
Customer accounts (shoppers logging in), Steadfast courier integration (courier name and tracking code are entered by hand today), advanced business analytics.

## Where things live (routing)
| Address | Who | What |
|---|---|---|
| `localhost` (platform host) `/` `/pricing` `/buy` `/buy/thanks` | public | Platform home, packages, order form, thank-you page |
| platform host `/admin/...` | you | Clients, Orders, Domains, Templates, Billing, Packages and pricing, Client requests |
| a client's own domain `/` `/about` `/services` `/contact` ... | visitors | The client's website. `www.` and the bare name show the same site |
| a client's own domain `/dashboard/...` | the owner | Home, Edit website, Themes, Images, Domain, Products, Categories, Orders, Customers, Discount codes, Campaigns, Reports, Shop settings, Inquiries, My package, Password |
`/buy` and `/pricing` do not exist on a client's domain, and `/dashboard` does not exist on the platform host (in development it sends you to the list of client sites).

## Buying, orders and domains
- **Buy page** (`/buy`): the customer picks a package and sends their details. Nothing is paid on the site. It records an order, with limits per phone/email and a hidden trap field for robots.
- **Admin > Orders**: call or message the customer (links are provided), mark Contacted / Paid / Rejected, then **Create client from this order**. The create form is filled in and the order becomes "client created". Set the payment instructions customers see after ordering under **Admin > Packages and pricing**.
- **Owner > Domain**: the owner adds a domain (up to 3), adds a TXT record (`_agency-verify`) at their registrar, and presses **Check now**. Only a matching record makes it live; the first verified domain becomes the main one. Set `DOMAIN_CNAME_TARGET` / `DOMAIN_A_RECORD` in `.env` so the page shows where to point the domain. The development shortcut `npm run domain:verify-dev` still works for local names.
- **Themes** (owner > Themes): eight ready-made looks. Every package can change the main colour; packages with branding and layout options also get the font, buttons and layout. Applying a theme only changes the draft (or publishes if the owner chooses), and never touches text or images.
- **Dark mode** for the owner dashboard and the admin: the switch is in the top bar and is remembered in the browser.

## Everyday commands
| Command | What it does |
|---|---|
| `docker compose up -d` / `docker compose down` | start / stop the local database (data is kept) |
| `npm test` | run all automated tests |
| `npm run typecheck` | check the code for mistakes |
| `npm run dev` | start the website at http://localhost:3000 |
| `npm run domain:verify-dev -- <host>` | development shortcut that marks a domain verified |
| `npm run owner:create -- <short-name> <email>` | create a client's dashboard login |
| `npm run admin:create` | create a platform admin login |
| `npm run db:migrate` | apply new database changes (safe to repeat) |

## If something fails
- `connection refused` -> Docker is not running. Start Docker Desktop, then `docker compose up -d`.
- `Invalid environment configuration` -> your `.env` is missing a value or the key is wrong; redo the `.env` step.
- Anything else: copy the full error message to Claude and say what command you ran.

## Safety rules for you
- Never commit or share `.env`. It is already in `.gitignore`.
- Development, demo and production use **different** keys and databases. See `docs/03-environments.md`.

## Documents
- `docs/01-architecture.md` - how the system is designed
- `docs/02-hosting-options.md` - free vs paid hosting, with limits and sources (checked 30 Oct 2026)
- `docs/03-environments.md` - development / demo / production separation
- `docs/04-status.md` - what is built, tested, not built

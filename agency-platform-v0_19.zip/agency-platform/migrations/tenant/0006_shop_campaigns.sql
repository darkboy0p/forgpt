-- Promotional campaigns: an automatic percentage off, for every product or one category, between two dates.
CREATE TABLE IF NOT EXISTS shop_campaigns (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  percent     INTEGER NOT NULL CHECK (percent BETWEEN 1 AND 90),
  applies_to  TEXT NOT NULL CHECK (applies_to IN ('all','category')),
  category_id UUID REFERENCES shop_categories(id) ON DELETE CASCADE,
  starts_on   DATE NOT NULL,
  ends_on     DATE NOT NULL,
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (ends_on >= starts_on),
  CHECK ((applies_to = 'category') = (category_id IS NOT NULL))
);

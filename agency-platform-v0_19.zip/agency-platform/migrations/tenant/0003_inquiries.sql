-- Messages sent through the public inquiry / quotation form on the client's website.
CREATE TABLE IF NOT EXISTS inquiries (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name       TEXT NOT NULL,
  phone      TEXT,
  email      TEXT,
  message    TEXT NOT NULL,
  ip         TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','done')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS inquiries_created ON inquiries(created_at DESC);
CREATE INDEX IF NOT EXISTS inquiries_ip_time ON inquiries(ip, created_at);

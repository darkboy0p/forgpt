-- Images uploaded by the owner (logo, banner, about photo, gallery), stored inside the client's own database.
CREATE TABLE IF NOT EXISTS media (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind         TEXT NOT NULL CHECK (kind IN ('logo','hero','about','gallery')),
  filename     TEXT NOT NULL,
  content_type TEXT NOT NULL CHECK (content_type IN ('image/png','image/jpeg','image/webp')),
  size_bytes   INTEGER NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 3145728),
  alt          TEXT NOT NULL DEFAULT '',
  data         BYTEA NOT NULL,
  created_by   TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS media_kind ON media(kind, created_at DESC);

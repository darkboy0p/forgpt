-- Store-owner dashboard: draft/publish for the site, owner accounts, sessions. Lives inside each client's OWN database.
ALTER TABLE site_config ADD COLUMN IF NOT EXISTS draft JSONB;
ALTER TABLE site_config ADD COLUMN IF NOT EXISTS draft_updated_at TIMESTAMPTZ;
ALTER TABLE site_config ADD COLUMN IF NOT EXISTS draft_updated_by TEXT;
ALTER TABLE site_config ADD COLUMN IF NOT EXISTS published_at TIMESTAMPTZ;
ALTER TABLE site_config ADD COLUMN IF NOT EXISTS published_by TEXT;

CREATE TABLE IF NOT EXISTS site_config_history (
  id           BIGSERIAL PRIMARY KEY,
  config       JSONB NOT NULL,
  published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS staff_users (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email                TEXT NOT NULL UNIQUE CHECK (email = lower(email)),
  password_hash        TEXT NOT NULL,
  role                 TEXT NOT NULL DEFAULT 'owner' CHECK (role IN ('owner')),
  is_active            BOOLEAN NOT NULL DEFAULT true,
  must_change_password BOOLEAN NOT NULL DEFAULT false,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at        TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS staff_sessions (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id     UUID NOT NULL REFERENCES staff_users(id) ON DELETE CASCADE,
  token_hash   TEXT NOT NULL UNIQUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at   TIMESTAMPTZ NOT NULL,
  ip           TEXT,
  user_agent   TEXT
);
CREATE INDEX IF NOT EXISTS staff_sessions_staff ON staff_sessions(staff_id);
CREATE TABLE IF NOT EXISTS staff_login_attempts (
  id         BIGSERIAL PRIMARY KEY,
  email      TEXT NOT NULL,
  ip         TEXT NOT NULL,
  ok         BOOLEAN NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS staff_attempts_email ON staff_login_attempts(email, created_at);
CREATE INDEX IF NOT EXISTS staff_attempts_ip ON staff_login_attempts(ip, created_at);

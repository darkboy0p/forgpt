-- Shop: categories, products (photos, options, stock), orders, discount codes and shop settings.
-- Product photos are stored in the media table with kind 'product'.
DO $$
DECLARE c text;
BEGIN
  SELECT conname INTO c FROM pg_constraint WHERE conrelid = 'media'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%kind%';
  IF c IS NOT NULL THEN EXECUTE format('ALTER TABLE media DROP CONSTRAINT %I', c); END IF;
END $$;
ALTER TABLE media ADD CONSTRAINT media_kind_check CHECK (kind IN ('logo','hero','about','gallery','product'));

CREATE TABLE IF NOT EXISTS shop_categories (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name       TEXT NOT NULL,
  slug       TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_visible BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS shop_products (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name              TEXT NOT NULL,
  slug              TEXT NOT NULL UNIQUE,
  category_id       UUID REFERENCES shop_categories(id) ON DELETE SET NULL,
  description       TEXT NOT NULL DEFAULT '',
  price_bdt         BIGINT NOT NULL CHECK (price_bdt >= 0 AND price_bdt <= 100000000),
  compare_price_bdt BIGINT CHECK (compare_price_bdt IS NULL OR (compare_price_bdt >= 0 AND compare_price_bdt <= 100000000)),
  sku               TEXT,
  status            TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','sold_out','hidden')),
  is_featured       BOOLEAN NOT NULL DEFAULT false,
  track_stock       BOOLEAN NOT NULL DEFAULT false,
  stock_qty         INTEGER NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
  low_stock_at      INTEGER NOT NULL DEFAULT 3 CHECK (low_stock_at >= 0),
  sort_order        INTEGER NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS shop_products_list ON shop_products(status, sort_order, created_at DESC);
CREATE INDEX IF NOT EXISTS shop_products_category ON shop_products(category_id);

CREATE TABLE IF NOT EXISTS shop_product_images (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES shop_products(id) ON DELETE CASCADE,
  media_id   UUID NOT NULL UNIQUE REFERENCES media(id) ON DELETE CASCADE,
  position   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS shop_product_images_product ON shop_product_images(product_id, position);

CREATE TABLE IF NOT EXISTS shop_product_variants (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES shop_products(id) ON DELETE CASCADE,
  label      TEXT NOT NULL,
  price_bdt  BIGINT CHECK (price_bdt IS NULL OR (price_bdt >= 0 AND price_bdt <= 100000000)),
  stock_qty  INTEGER NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
  sort_order INTEGER NOT NULL DEFAULT 0,
  UNIQUE (product_id, label)
);

CREATE TABLE IF NOT EXISTS shop_config (
  id                     SMALLINT PRIMARY KEY CHECK (id = 1),
  delivery_fee_bdt       BIGINT NOT NULL DEFAULT 0 CHECK (delivery_fee_bdt >= 0),
  free_delivery_over_bdt BIGINT CHECK (free_delivery_over_bdt IS NULL OR free_delivery_over_bdt >= 0),
  order_note             TEXT NOT NULL DEFAULT '',
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO shop_config (id) VALUES (1) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS shop_discount_codes (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code          TEXT NOT NULL UNIQUE,
  kind          TEXT NOT NULL CHECK (kind IN ('percent','fixed')),
  value         BIGINT NOT NULL CHECK (value > 0),
  min_order_bdt BIGINT NOT NULL DEFAULT 0 CHECK (min_order_bdt >= 0),
  max_uses      INTEGER CHECK (max_uses IS NULL OR max_uses > 0),
  used_count    INTEGER NOT NULL DEFAULT 0,
  expires_on    DATE,
  is_active     BOOLEAN NOT NULL DEFAULT true,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS shop_orders (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  number          INTEGER GENERATED ALWAYS AS IDENTITY (START WITH 1001) UNIQUE,
  public_token    TEXT NOT NULL UNIQUE,
  channel         TEXT NOT NULL CHECK (channel IN ('request','checkout')),
  customer_name   TEXT NOT NULL,
  phone           TEXT NOT NULL,
  email           TEXT,
  address         TEXT NOT NULL,
  area            TEXT NOT NULL DEFAULT '',
  note            TEXT NOT NULL DEFAULT '',
  status          TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','confirmed','processing','shipped','delivered','cancelled')),
  payment_method  TEXT NOT NULL DEFAULT 'cod',
  payment_status  TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','paid')),
  subtotal_bdt    BIGINT NOT NULL CHECK (subtotal_bdt >= 0),
  delivery_fee_bdt BIGINT NOT NULL DEFAULT 0 CHECK (delivery_fee_bdt >= 0),
  discount_bdt    BIGINT NOT NULL DEFAULT 0 CHECK (discount_bdt >= 0),
  total_bdt       BIGINT NOT NULL CHECK (total_bdt >= 0),
  discount_code   TEXT,
  courier         TEXT NOT NULL DEFAULT '',
  tracking_code   TEXT NOT NULL DEFAULT '',
  internal_note   TEXT NOT NULL DEFAULT '',
  ip              TEXT NOT NULL DEFAULT 'unknown',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS shop_orders_status ON shop_orders(status, created_at DESC);
CREATE INDEX IF NOT EXISTS shop_orders_phone ON shop_orders(phone, created_at DESC);
CREATE INDEX IF NOT EXISTS shop_orders_ip ON shop_orders(ip, created_at DESC);

CREATE TABLE IF NOT EXISTS shop_order_items (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id       UUID NOT NULL REFERENCES shop_orders(id) ON DELETE CASCADE,
  product_id     UUID REFERENCES shop_products(id) ON DELETE SET NULL,
  variant_id     UUID,
  variant_label  TEXT NOT NULL DEFAULT '',
  name           TEXT NOT NULL,
  unit_price_bdt BIGINT NOT NULL CHECK (unit_price_bdt >= 0),
  qty            INTEGER NOT NULL CHECK (qty > 0 AND qty <= 100),
  line_total_bdt BIGINT NOT NULL CHECK (line_total_bdt >= 0),
  stock_taken    BOOLEAN NOT NULL DEFAULT false
);
CREATE INDEX IF NOT EXISTS shop_order_items_order ON shop_order_items(order_id);

CREATE TABLE IF NOT EXISTS shop_order_events (
  id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES shop_orders(id) ON DELETE CASCADE,
  status   TEXT NOT NULL,
  actor    TEXT NOT NULL,
  at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS shop_order_events_order ON shop_order_events(order_id, at);

-- Tenant schema: runs INSIDE each client's own separate database.
CREATE TABLE IF NOT EXISTS store_settings (
  key        TEXT PRIMARY KEY,
  value      JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS site_config (
  id             SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  schema_version INTEGER NOT NULL,
  config         JSONB NOT NULL,
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

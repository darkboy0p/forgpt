-- Purchase requests from the public "Buy a website" page, and DNS-check bookkeeping for owner-added domains.
CREATE TABLE IF NOT EXISTS purchase_requests (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  package_tier     SMALLINT NOT NULL CHECK (package_tier BETWEEN 1 AND 5),
  business_name    TEXT NOT NULL,
  contact_name     TEXT NOT NULL,
  phone            TEXT NOT NULL,
  whatsapp         TEXT,
  email            TEXT,
  desired_hostname TEXT,
  message          TEXT NOT NULL DEFAULT '',
  payment_method   TEXT NOT NULL DEFAULT 'bkash' CHECK (payment_method IN ('bkash','nagad','rocket','bank','cash')),
  status           TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','contacted','paid','client_created','rejected')),
  tenant_id        UUID REFERENCES tenants(id) ON DELETE SET NULL,
  handled_by       TEXT,
  handled_at       TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS purchase_requests_status ON purchase_requests(status, created_at DESC);
CREATE INDEX IF NOT EXISTS purchase_requests_phone ON purchase_requests(phone, created_at DESC);
CREATE INDEX IF NOT EXISTS purchase_requests_email ON purchase_requests(lower(email), created_at DESC) WHERE email IS NOT NULL;

ALTER TABLE domains ADD COLUMN IF NOT EXISTS last_checked_at TIMESTAMPTZ;
ALTER TABLE domains ADD COLUMN IF NOT EXISTS check_note TEXT;

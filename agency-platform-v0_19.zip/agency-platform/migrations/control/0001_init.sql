-- Control-plane schema: platform-level data only. No customer store data lives here.
CREATE TABLE IF NOT EXISTS tenants (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug          TEXT NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9][a-z0-9-]{1,40}$'),
  business_name TEXT NOT NULL,
  package_tier  SMALLINT NOT NULL DEFAULT 1 CHECK (package_tier BETWEEN 1 AND 5),
  template_key  TEXT NOT NULL DEFAULT 'starter',
  status        TEXT NOT NULL DEFAULT 'provisioning'
                CHECK (status IN ('provisioning','active','suspended','failed','archived')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One row per tenant: where its separate database lives. Connection string is ENCRYPTED.
CREATE TABLE IF NOT EXISTS tenant_databases (
  tenant_id        UUID PRIMARY KEY REFERENCES tenants(id) ON DELETE RESTRICT,
  provider         TEXT NOT NULL,
  database_name    TEXT NOT NULL UNIQUE,
  conn_encrypted   TEXT NOT NULL,
  schema_version   INTEGER NOT NULL DEFAULT 0,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS domains (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    UUID NOT NULL REFERENCES tenants(id) ON DELETE RESTRICT,
  hostname     TEXT NOT NULL UNIQUE CHECK (hostname = lower(hostname)),
  status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','verified','failed','removed')),
  is_primary   BOOLEAN NOT NULL DEFAULT false,
  verify_token TEXT NOT NULL,
  verified_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS one_primary_domain_per_tenant ON domains(tenant_id) WHERE is_primary;

CREATE TABLE IF NOT EXISTS provisioning_jobs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   UUID NOT NULL REFERENCES tenants(id),
  step        TEXT NOT NULL,
  status      TEXT NOT NULL CHECK (status IN ('done','failed')),
  detail      TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_log (
  id         BIGSERIAL PRIMARY KEY,
  actor      TEXT NOT NULL,
  action     TEXT NOT NULL,
  tenant_id  UUID,
  detail     JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

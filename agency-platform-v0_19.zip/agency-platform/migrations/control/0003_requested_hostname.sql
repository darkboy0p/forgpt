-- Remember the domain the owner asked for, so a retry after a failed provisioning still registers it.
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS requested_hostname TEXT;

-- Packages (standard prices are DEFAULTS, not limits), per-client agreements, invoices and manual payments.
-- Money is stored as whole Bangladeshi taka (BDT) integers.
CREATE TABLE IF NOT EXISTS packages (
  tier          SMALLINT PRIMARY KEY CHECK (tier BETWEEN 1 AND 5),
  name          TEXT NOT NULL,
  setup_min_bdt BIGINT NOT NULL CHECK (setup_min_bdt >= 0),
  setup_max_bdt BIGINT NOT NULL CHECK (setup_max_bdt >= setup_min_bdt),
  monthly_bdt   BIGINT NOT NULL CHECK (monthly_bdt >= 0)
);
INSERT INTO packages (tier, name, setup_min_bdt, setup_max_bdt, monthly_bdt) VALUES
  (1,'Starter',7000,11000,1000), (2,'Business',15000,20000,1800), (3,'E-commerce',22000,30000,2500),
  (4,'Professional',34500,42000,3500), (5,'Premium',44000,55000,5000)
ON CONFLICT (tier) DO NOTHING;

CREATE TABLE IF NOT EXISTS tenant_billing (
  tenant_id            UUID PRIMARY KEY REFERENCES tenants(id) ON DELETE RESTRICT,
  setup_fee_bdt        BIGINT NOT NULL CHECK (setup_fee_bdt >= 0),
  monthly_fee_bdt      BIGINT NOT NULL CHECK (monthly_fee_bdt >= 0),
  monthly_discount_bdt BIGINT NOT NULL DEFAULT 0 CHECK (monthly_discount_bdt >= 0),
  discount_until       DATE,                       -- NULL = the discount has no end date
  service_start        DATE NOT NULL CHECK (EXTRACT(DAY FROM service_start) <= 28),
  grace_days           SMALLINT NOT NULL DEFAULT 7 CHECK (grace_days BETWEEN 0 AND 90),
  notes                TEXT NOT NULL DEFAULT '',
  updated_by           TEXT NOT NULL,
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (monthly_discount_bdt <= monthly_fee_bdt)
);

CREATE SEQUENCE IF NOT EXISTS invoice_number_seq;
CREATE TABLE IF NOT EXISTS invoices (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    UUID NOT NULL REFERENCES tenants(id) ON DELETE RESTRICT,
  number       TEXT NOT NULL UNIQUE,
  kind         TEXT NOT NULL CHECK (kind IN ('setup','monthly')),
  period_start DATE,
  description  TEXT NOT NULL,
  amount_bdt   BIGINT NOT NULL CHECK (amount_bdt >= 0),
  due_date     DATE NOT NULL,
  status       TEXT NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid','partial','paid','void')),
  issued_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  paid_at      TIMESTAMPTZ,
  voided_at    TIMESTAMPTZ,
  void_reason  TEXT,
  created_by   TEXT NOT NULL
);
-- Duplicate protection enforced by the database itself:
CREATE UNIQUE INDEX IF NOT EXISTS one_setup_invoice ON invoices(tenant_id) WHERE kind = 'setup' AND status <> 'void';
CREATE UNIQUE INDEX IF NOT EXISTS one_monthly_per_period ON invoices(tenant_id, period_start) WHERE kind = 'monthly' AND status <> 'void';
CREATE INDEX IF NOT EXISTS invoices_status_due ON invoices(status, due_date);

CREATE TABLE IF NOT EXISTS payments (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id  UUID NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE RESTRICT,
  amount_bdt  BIGINT NOT NULL CHECK (amount_bdt > 0),
  method      TEXT NOT NULL CHECK (method IN ('bkash','nagad','rocket','bank','cash','other')),
  reference   TEXT NOT NULL DEFAULT '',
  received_on DATE NOT NULL,
  recorded_by TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- The same transaction reference cannot be recorded twice for one invoice (protects against double clicks).
CREATE UNIQUE INDEX IF NOT EXISTS payments_no_duplicate_reference ON payments(invoice_id, method, reference) WHERE reference <> '';

-- Final package system: one default setup price per package, editable descriptions, editable features and limits,
-- owner upgrade/support requests and platform contact settings.
-- Existing client agreements (tenant_billing) and invoices are NOT touched: they keep their own agreed prices.
ALTER TABLE packages ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT '';
ALTER TABLE packages ADD COLUMN IF NOT EXISTS setup_bdt BIGINT;
UPDATE packages SET setup_bdt = CASE tier WHEN 1 THEN 7000 WHEN 2 THEN 17000 WHEN 3 THEN 27000 WHEN 4 THEN 40000 ELSE 50000 END WHERE setup_bdt IS NULL;
ALTER TABLE packages ALTER COLUMN setup_bdt SET NOT NULL;
ALTER TABLE packages ADD CONSTRAINT packages_setup_nonneg CHECK (setup_bdt >= 0);
-- keep the old range columns consistent so nothing that still reads them shows an outdated range
UPDATE packages SET setup_min_bdt = setup_bdt, setup_max_bdt = setup_bdt;
UPDATE packages SET description = CASE tier
  WHEN 1 THEN 'A professional website with a product catalogue and WhatsApp ordering.'
  WHEN 2 THEN 'A fuller business website with more pages, richer products and inquiry forms.'
  WHEN 3 THEN 'A complete online shop with cart, checkout, customer accounts and courier booking.'
  WHEN 4 THEN 'Advanced shop management: discounts, campaigns, stock alerts and detailed reports.'
  ELSE 'Premium design and customization with advanced analytics and priority support.' END
 WHERE description = '';

-- Only DIFFERENCES from the built-in defaults are stored here (an empty table means "use the defaults").
CREATE TABLE IF NOT EXISTS package_features (
  tier        SMALLINT NOT NULL REFERENCES packages(tier) ON DELETE CASCADE,
  feature_key TEXT NOT NULL,
  enabled     BOOLEAN,
  limit_value INTEGER CHECK (limit_value IS NULL OR limit_value >= 0),
  updated_by  TEXT NOT NULL,
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (tier, feature_key)
);

CREATE TABLE IF NOT EXISTS client_requests (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id      UUID NOT NULL REFERENCES tenants(id) ON DELETE RESTRICT,
  kind           TEXT NOT NULL CHECK (kind IN ('upgrade','support')),
  requested_tier SMALLINT CHECK (requested_tier BETWEEN 1 AND 5),
  message        TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','done')),
  created_by     TEXT NOT NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  handled_at     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS client_requests_open ON client_requests(status, created_at DESC);

CREATE TABLE IF NOT EXISTS platform_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

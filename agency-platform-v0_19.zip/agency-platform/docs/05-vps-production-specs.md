# VPS specifications for production (starting estimates, NOT load-tested)

Written 31 Oct 2026. Nothing here has been measured. These are engineering estimates from the architecture
(Next.js app + PostgreSQL with one database per client). Re-check provider locations and prices before buying.

## What will run on the server
1. The Next.js application (Node.js 22, one process or a few).
2. PostgreSQL (control database + one database per client).
3. PgBouncer (connection pooler, so many client databases do not exhaust connections).
4. A reverse proxy that serves HTTPS for many client domains (for example Caddy). Not built or tested yet.
5. Backup scripts and monitoring. Not built or tested yet.
Images and uploads should go to separate object storage (for example Cloudflare R2 or any S3-compatible service), not the VPS disk.

## Starting specs
| Stage | Clients (rough) | vCPU | RAM | Disk | Notes |
|---|---|---|---|---|---|
| Launch | 1 to 10, mostly small sites | 2 | 4 GB | 60 to 80 GB NVMe SSD | Add 2 GB swap. Do NOT run `next build` on this server; build elsewhere. |
| Growth | 10 to 30, some e-commerce | 4 | 8 GB | 160 GB NVMe SSD | Watch database memory and disk I/O. |
| Split | 30+ or busy shops | App server 2 to 4 vCPU / 4 to 8 GB; separate database server 4 vCPU / 16 GB | | NVMe SSD | Move PostgreSQL to its own server or a managed PostgreSQL service. |

## Why these numbers (assumptions to verify)
- Node/Next.js process: roughly 0.3 to 0.6 GB RAM each. PostgreSQL works best with about a quarter of RAM for its cache.
- Each client database adds some fixed overhead, so dozens of tiny databases are fine; hundreds need testing.
- The app limits itself to 20 open tenant pools of 3 connections each by default (60 connections), which PgBouncer smooths.
- Building a Next.js app can need over 2 GB of RAM, so build on your PC or a free CI service and upload the result.

## Requirements when choosing a provider
- Data centre location: Singapore is usually the nearest major region to Bangladesh. Test latency from your own internet connection using the provider's test page before buying.
- SSD or NVMe storage (never HDD), a dedicated public IPv4 address, SSH key login, and the ability to resize later.
- Automatic backups or snapshots available, in addition to your own database backups stored at a different provider.
- Check that the provider accepts a payment method you can actually use from Bangladesh.
- Monthly traffic allowance of a few terabytes is normally plenty at this size (assumption).
- Ubuntu 24.04 LTS (or another long-term-support Linux) available as an image.

## Do not buy yet
The deployment steps for a VPS (firewall, PostgreSQL and PgBouncer setup, HTTPS for client domains, backups, monitoring, updates) are Phase 8 and are not written or tested yet. A server bought now would sit idle. Buy when the main features are finished and you are ready for a private test deployment, and tell Claude the provider so the guide matches it.

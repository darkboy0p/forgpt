# Hosting options (researched 30 Oct 2026)

**How to read this:** figures come from vendor documentation and third-party summaries found on the dates shown. Free plans change often. I did not test any of these services. Re-check the official page before relying on a number. Prices are in USD as published; I have not converted them to taka.

## 1. Where tenant databases can live

| Option | What the sources say | Fit for this project | Open questions |
|---|---|---|---|
| **Local PostgreSQL in Docker** | Free, runs on your PC | Development only | Not reachable by the internet, so it is not a demo host |
| **Neon Free** | 100 projects; per project: 0.5 GB storage, 100 CU-hours/month, 5 GB egress, 10 branches; compute scales to zero after 5 min idle; no card required; compute suspends when monthly limits are reached (neon.com FAQ/pricing, Sept 2026 summaries) | Good for **demo**: 1 Neon project per demo client gives a genuinely separate database; 1 project for the control plane | (a) Is commercial use allowed on Free? **Not verified.** (b) Creating projects automatically needs Neon's API; free-plan API access **not verified**. (c) Cold start after idle: not measured |
| **Neon paid (Launch)** | Usage-based: about $0.106 per CU-hour and $0.35 per GB-month (third-party summaries, Sept 2026); no monthly minimum; scale-to-zero available | Plausible **production** path for many small tenants because idle databases cost mostly storage | Real cost depends on traffic. One source notes always-on workloads can cost more than flat-priced plans. Needs measuring with real tenants |
| **Render free Postgres** | Expires 30 days after creation, then deleted after a 14-day grace period; 1 GB cap; no backups; one per workspace (render.com/docs/free) | **Not suitable** (expiry, no backups, one DB) | None, ruled out |
| **Self-managed Postgres on a VPS** | Not researched in this round | Probably cheapest per client at scale, but you carry backups and uptime | Requires paid VPS, so excluded for now |

## 2. Where the application can run

| Option | What the sources say | Fit | Open questions |
|---|---|---|---|
| **Vercel Hobby** | Free but **personal, non-commercial use only**; client work and revenue-generating projects need Pro at $20/seat/month (Vercel docs, Sept 2026) | **Do not use** for this business. Even a sales demo is a grey area, so avoid it | None |
| **Render free web service** | Sleeps after 15 min idle (about 1 min to wake); 750 free hours/month per workspace; ephemeral filesystem; Render says not to use free instances for production | Acceptable for a slow **demo** only | Uploaded images do not persist, so demo images must come from object storage or be seeded |
| **Cloudflare Workers/Pages free** | Free plan: 100,000 requests/day, **10 ms CPU per request**, 50 subrequests/request; Hyperdrive (Postgres connection pooling) free up to 100,000 queries/day; paid plan has a $5/month minimum (Cloudflare docs) | Promising for demo and later production | (a) Whether our Next.js code runs within 10 ms CPU on the free plan is **unknown until tested**. (b) Commercial-use terms of the free plan **not verified by me** (a third-party article says allowed). (c) Next.js-on-Workers adapter compatibility **not tested** |

## 3. Custom domains and HTTPS
**Cloudflare for SaaS** (custom hostnames): Cloudflare's plans table lists 100 hostnames included on Free, Pro and Business, then $0.10 per extra hostname per month, up to 50,000 on pay-as-you-go. It issues certificates automatically.
Cautions:
- It needs a domain **you own** on Cloudflare as the "SaaS zone". Registering a domain costs money, so true zero-budget testing of custom domains has to wait, or use a domain you already own.
- A community answer says proxying a client's **apex domain** (`clientbrand.com`, no `www`) is an Enterprise add-on; the workaround is a subdomain like `www.clientbrand.com` or DNS-provider CNAME flattening. **I have not verified this on current docs.** It affects how you onboard clients.
- Alternative (not researched): running your own reverse proxy with on-demand certificates requires a server.

## 4. Recommended zero-budget path (a proposal, not yet built or tested)
1. **Development:** Docker Postgres on your PC. Free. Done and tested.
2. **Demo:** control plane + demo tenants on Neon Free (after verifying terms and API), app on Cloudflare free or Render free. Demo only, fake data only, no real orders.
3. **Production:** decided later with real numbers. Expect to pay for at least a database plan and an always-on app host. Free tiers are not recommended for live commercial e-commerce.

## 5. Things to check yourself before the demo phase
1. Neon terms: commercial use on Free; API access for creating projects.
2. Cloudflare terms for the free plan and Next.js support.
3. Whether any card is required at sign-up (do not give a card if you want to be sure nothing is billed).

# Architecture (Phase 1)

## The idea in plain words
- There is **one application**. It serves every client's website.
- A **control-plane database** (the "address book") records clients, their domains, packages and billing.
- Every client also has **their own separate database** holding their products, orders, customers and settings.
- When a visitor opens `clientbrand.com`, the app looks the domain up in the address book, finds which client it belongs to, then connects to *that client's* database. The visitor can never choose the database.

```
Visitor -> clientbrand.com -> App
                               |-- 1. normalize host name
                               |-- 2. control-plane DB: is this domain VERIFIED and tenant ACTIVE?
                               |-- 3. connection manager: decrypt that tenant's connection string (server only)
                               '-- 4. query ONLY that tenant's own database
```

## Components (what exists in code today)
| Component | File | Status |
|---|---|---|
| Environment rules (dev/demo/prod guards) | `src/config/env.ts` | built + tested |
| Secret encryption (AES-256-GCM) | `src/crypto/secrets.ts` | built + tested |
| Control-plane schema | `migrations/control/` | built + tested |
| Tenant schema (inside each client DB) | `migrations/tenant/` | built (minimal) + tested |
| Migration runner | `src/db/migrate.ts` | built + tested |
| Database provider interface | `src/provisioning/providers/types.ts` | built |
| Local Postgres provider (dev) | `.../localPostgres.ts` | built + tested |
| Neon / managed providers | `.../providers/index.ts` | **not implemented** (throws a clear error) |
| Idempotent tenant provisioning | `src/provisioning/provisionTenant.ts` | built + tested |
| Host -> tenant resolver | `src/tenancy/resolver.ts` | built + tested |
| Per-tenant connection manager (LRU cap, idle close) | `src/tenancy/connectionManager.ts` | built + tested |

## Key decisions
1. **Provider interface (requirement 7).** The app only talks to `DatabaseProvider.ensureDatabase()`. Moving from local Docker to Neon to your own server means writing one new provider file. The app, tenancy and provisioning logic stay unchanged.
2. **Deterministic database names** (`tenant_<slug>_<8 chars of id>`) built only from server-side values, so retries find the same database instead of creating a second.
3. **Encrypted connection strings.** Stored with AES-256-GCM using `SECRETS_MASTER_KEY` (environment variable). The key is not in the database, so a database leak alone does not reveal tenant credentials.
4. **Domain gate.** Only `verified` domains of `active` tenants resolve. Registering a domain creates it as `pending`.
5. **Pools are small and capped.** Default: at most 20 tenant pools open, 3 connections each, idle pools closed after 30s. These are starting assumptions, not tested capacity.
6. **Idempotent provisioning.** Every step is "create if missing"; failures are logged to `provisioning_jobs` and the tenant is marked `failed`; retrying recovers it.

## Known limits / honest notes
- Dev provider uses one admin login for all local databases. This is acceptable only on your own computer. Production providers must issue a **separate database user per tenant** (planned requirement for the production provider).
- A databases-per-tenant design means migrations must run against every tenant database. Today this happens during provisioning; a "migrate all tenants" job is a later phase.
- Verification of domain ownership (DNS TXT check) is **not built yet**; the status column and token exist.
- Nothing here has been load-tested. No capacity numbers are claimed.

## Planned phases (unchanged from the master spec)
2 Foundation (continuing) -> 3 Templates -> 4 Dashboards + manual billing -> 5 E-commerce -> 6 Steadfast + domain onboarding -> 7 Hardening -> 8 Deployment.

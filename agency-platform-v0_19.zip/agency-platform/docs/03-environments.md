# Environments: development, demo, production

| | Development | Demo | Production |
|---|---|---|---|
| Purpose | Building and testing on your computer | Showing the product to prospects | Real clients, real orders |
| Where | Your PC + Docker | Free hosting tiers | Paid, supported infrastructure |
| Tenant databases | Local Postgres (`local-postgres`) | Free managed Postgres (planned: `neon`) | Paid managed Postgres (`managed-postgres` or paid Neon) |
| Real customer data | Never | Never | Yes |
| Secrets (`SECRETS_MASTER_KEY`) | Your own dev key | A different key | A unique key kept in the host's secret store |
| Seed/sample data | Allowed | Allowed (clearly fake) | Forbidden (`provision-demo` refuses to run) |

## Rules enforced by code (`src/config/env.ts`, tested)
- Production cannot use the local provider.
- Production cannot point at a localhost control database.
- Demo cannot use the production provider.
- The master key must be 32 random bytes.

## Rules enforced by you
- Use a different `SECRETS_MASTER_KEY` in each environment. Keys are not interchangeable: data encrypted in one environment cannot be read in another.
- Never store real client data, real phone numbers or real customer orders in demo.
- Back up the production master key somewhere safe (offline). If it is lost, stored tenant connection strings cannot be decrypted.

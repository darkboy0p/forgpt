"use client";

/** Shown if a page fails unexpectedly. It never shows technical details to visitors. */
export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="wrap" style={{ padding: "64px 20px", maxWidth: 640 }}>
      <h1>Something went wrong</h1>
      <p>Sorry about that. Please try again. If it keeps happening, contact the owner of this website.</p>
      <p><button className="btn" type="button" onClick={reset} style={{ border: 0, cursor: "pointer" }}>Try again</button> <a href="/">Go to the home page</a></p>
    </div>
  );
}

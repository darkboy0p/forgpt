import { headers } from "next/headers";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { runtime } from "../../../src/web/server";
import { isPlatformHost } from "../../../src/web/adminAccess";
import { TemplateSite, loadShopContext } from "../../../src/web/renderSite";
import { ProductPage } from "../../../src/web/templates/ShopBlocks";
import { getPublicProduct } from "../../../src/shop/products";

export const dynamic = "force-dynamic";
const hostOf = async () => (await headers()).get("host") ?? "";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const host = await hostOf();
  if (isPlatformHost(runtime().env, host)) return { title: "Not found", robots: { index: false } };
  try {
    const { slug } = await params;
    const ctx = await loadShopContext(host);
    const p = await getPublicProduct(ctx.pool, ctx.ent, slug);
    if (!p) return { title: "Not found", robots: { index: false } };
    const title = `${p.card.name} | ${ctx.config.seo.title || ctx.site.tenant.businessName}`;
    const description = (p.description || ctx.config.seo.description || "").replace(/\s+/g, " ").slice(0, 160) || undefined;
    const img = p.images[0] ? [{ url: `${ctx.siteUrl}/media/${p.images[0]}` }] : undefined;
    return { title, description, ...(ctx.config.seo.noindex ? { robots: { index: false, follow: false } } : {}), openGraph: { title, description, images: img } };
  } catch { return { title: "Not found", robots: { index: false } }; }
}

export default async function ProductRoute({ params }: { params: Promise<{ slug: string }> }) {
  const host = await hostOf();
  if (isPlatformHost(runtime().env, host)) notFound();
  const { slug } = await params;
  const ctx = await loadShopContext(host);
  const product = await getPublicProduct(ctx.pool, ctx.ent, slug);
  if (!product) notFound();
  return (
    <TemplateSite templateKey={ctx.site.tenant.templateKey} businessName={ctx.site.tenant.businessName} config={ctx.config} page="products" siteUrl={ctx.siteUrl} shop={ctx.shop}
      body={<ProductPage product={product} cart={ctx.ent.shop.cart} whatsapp={ctx.config.content.whatsapp} orderNote={ctx.settings.order_note || undefined} shopHref="/products" />} />
  );
}

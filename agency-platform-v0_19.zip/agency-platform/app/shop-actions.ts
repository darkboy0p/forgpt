"use server";

import { headers } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { runtime } from "../src/web/server";
import { resolveHostState } from "../src/tenancy/resolver";
import { entitlementsOf } from "../src/web/entitlements";
import { createOrder, buildQuote, type Quote } from "../src/shop/orders";

export interface OrderState { error?: string; item?: string; values?: Record<string, string> }
export type QuoteResult = { ok: true; quote: Quote } | { ok: false };

/** Works only on a verified, active client website whose package includes the shop. */
async function shopContext() {
  const h = await headers();
  const { control, mgr } = runtime();
  const state = await resolveHostState(control, h.get("host") ?? "");
  if (state.kind !== "active") notFound();
  const ent = await entitlementsOf(state.tenant.packageTier);
  if (!ent.shop.products) notFound();
  return { h, ent, pool: await mgr.getPool(state.tenant.tenantId) };
}

/** Records an order. The customer's browser sends only product ids and quantities; prices, stock and discounts are decided here. */
export async function placeOrderAction(_prev: OrderState, formData: FormData): Promise<OrderState> {
  const { h, ent, pool } = await shopContext();
  const s = (k: string, max: number) => { const v = formData.get(k); return typeof v === "string" ? v.slice(0, max) : ""; };
  const values = { name: s("name", 200), phone: s("phone", 60), email: s("email", 300), address: s("address", 600), area: s("area", 100), note: s("note", 800), discountCode: s("discountCode", 60) };
  let items: unknown;
  try { items = JSON.parse(s("items", 8000)); } catch { return { error: "invalid_items", values }; }
  const ip = (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
  const r = await createOrder(pool, ent, { channel: s("channel", 20), items, ...values, ip, website: s("website", 300) });
  if (!r.ok) return { error: r.error, item: r.item, values };
  redirect(r.silent ? "/" : `/order/${r.token}`);
}

/** Current prices and availability for the cart on screen. Read only. */
export async function quoteCartAction(items: unknown, code: unknown): Promise<QuoteResult> {
  const { ent, pool } = await shopContext();
  const q = await buildQuote(pool, ent, items, typeof code === "string" ? code.slice(0, 40) : "", false);
  return q.ok ? { ok: true, quote: q.quote } : { ok: false };
}

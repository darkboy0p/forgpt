import { clientHidesFromSearch, listClientPages, listClientProductSlugs, siteBaseUrl } from "../../src/web/renderSite";
import { pagePath } from "../../src/web/templates/pages";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const pages = await listClientPages(req.headers.get("host") ?? "");
  if (!pages || (await clientHidesFromSearch(req.headers.get("host") ?? ""))) return new Response("Not found", { status: 404 });
  const base = await siteBaseUrl();
  const urls = [...pages.map((p) => pagePath(p)), ...(await listClientProductSlugs(req.headers.get("host") ?? "")).map((s) => `/products/${s}`)];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${base}${u}</loc></url>`).join("\n")}\n</urlset>\n`;
  return new Response(xml, { headers: { "Content-Type": "application/xml; charset=utf-8", "Cache-Control": "no-store" } });
}

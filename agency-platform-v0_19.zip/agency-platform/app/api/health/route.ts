import { runtime } from "../../../src/web/server";

export const dynamic = "force-dynamic";

/** Minimal health check. Reveals no details. */
export async function GET() {
  try {
    await runtime().control.query("SELECT 1");
    return Response.json({ status: "ok" }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ status: "error" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}

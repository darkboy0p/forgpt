import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { runtime } from "../../src/web/server";
import { isPlatformHost } from "../../src/web/adminAccess";
import { renderClientSite, siteMetadata } from "../../src/web/renderSite";
import { isPageKey } from "../../src/web/templates/pages";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ page: string }> }) {
  const { page } = await params;
  const host = (await headers()).get("host") ?? "";
  if (!isPageKey(page) || page === "home" || isPlatformHost(runtime().env, host)) return { title: "Not found", robots: { index: false } };
  return siteMetadata(host, page);
}

export default async function SubPage({ params, searchParams }: { params: Promise<{ page: string }>; searchParams: Promise<{ sent?: string; ie?: string; q?: string; category?: string; sort?: string; page?: string }> }) {
  const { page } = await params;
  const host = (await headers()).get("host") ?? "";
  if (!isPageKey(page) || page === "home" || isPlatformHost(runtime().env, host)) notFound();
  return renderClientSite(host, page, await searchParams);
}

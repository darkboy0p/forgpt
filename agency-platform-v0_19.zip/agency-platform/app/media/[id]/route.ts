import { runtime } from "../../../src/web/server";
import { resolveHostState } from "../../../src/tenancy/resolver";
import { getMedia } from "../../../src/store/media";
import { UUID_RE } from "../../../src/config/siteConfig";

export const dynamic = "force-dynamic";

/** Public image of the client whose domain this is. The id must be an unguessable UUID that exists in THAT client's database. */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) return new Response("Not found", { status: 404 });
  const { control, mgr } = runtime();
  const state = await resolveHostState(control, req.headers.get("host") ?? "");
  if (state.kind !== "active") return new Response("Not found", { status: 404 });
  const m = await getMedia(await mgr.getPool(state.tenant.tenantId), id);
  if (!m) return new Response("Not found", { status: 404 });
  return new Response(new Uint8Array(m.data), {
    headers: {
      "Content-Type": m.content_type, "Content-Length": String(m.size_bytes),
      "Cache-Control": "public, max-age=3600", Vary: "Host",
      "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'; sandbox", "Cross-Origin-Resource-Policy": "same-origin",
    },
  });
}

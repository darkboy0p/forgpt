import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { runtime } from "../../src/web/server";
import { isPlatformHost } from "../../src/web/adminAccess";
import { getPricingData } from "../../src/packages/pricing";
import { PricingView } from "../../src/web/PricingView";

export const dynamic = "force-dynamic";
export const metadata = { title: "Website packages and pricing" };

/** Public pricing page, shown on the platform's own address (not on a client's domain). */
export default async function PricingPage() {
  const { env, control } = runtime();
  if (!isPlatformHost(env, (await headers()).get("host") ?? "")) notFound();
  const data = await getPricingData(control);
  return (
    <div className="wrap" style={{ padding: "40px 20px" }}>
      <h1>Website packages</h1>
      <p style={{ color: "#5b6573" }}>{data.settings.agency_name ? `${data.settings.agency_name}: ` : ""}a managed website service. We build it, host it, back it up and keep it running.{data.settings.agency_note ? ` ${data.settings.agency_note}` : ""}</p>
      <PricingView data={data} />
    </div>
  );
}

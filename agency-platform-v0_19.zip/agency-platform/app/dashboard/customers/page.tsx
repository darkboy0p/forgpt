import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { taka } from "../../../src/web/dashboard/bits";
import { listCustomers } from "../../../src/shop/extras";

export const dynamic = "force-dynamic";

export default async function CustomersPage() {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.customers) return <StoreShell businessName={businessName} email={staff.email}><h1>Customers</h1><LockedCard title="Customer list" text="See everyone who ordered, how many times and how much they spent." /></StoreShell>;
  const rows = await listCustomers(pool);
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <h1>Customers</h1>
      <p className="lead">Built automatically from your orders (cancelled orders are not counted).</p>
      <div className="tbl-wrap"><table>
        <thead><tr><th>Customer</th><th>Phone</th><th className="num">Orders</th><th className="num">Spent</th><th>Last order</th></tr></thead>
        <tbody>
          {rows.map((c) => <tr key={c.phone}><td>{c.name}{c.email && <><br /><small className="hint">{c.email}</small></>}</td><td><a href={`tel:${c.phone}`}>{c.phone}</a></td><td className="num">{c.orders}{c.orders > 1 && <> <span className="chip">Repeat</span></>}</td><td className="num">{taka(Number(c.spent))}</td><td>{new Date(c.last_order).toISOString().slice(0, 10)}</td></tr>)}
          {rows.length === 0 && <tr><td colSpan={5} className="hint">No customers yet.</td></tr>}
        </tbody>
      </table></div>
    </StoreShell>
  );
}

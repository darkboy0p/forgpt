"use server";

import { requireStaff } from "../../src/web/storeSession";
import { entitlementsOf } from "../../src/web/entitlements";
import { saveBuilder, type SaveResult, type ThemeIn } from "../../src/builder/save";

/** Called by the visual editor. The checks live in src/builder/save.ts. */
export async function saveBuilderAction(payload: { blocks: unknown; theme: ThemeIn }, publish: boolean): Promise<SaveResult> {
  const { pool, staff, tenant } = await requireStaff();
  return saveBuilder(pool, await entitlementsOf(tenant.packageTier), staff.email, payload, publish === true);
}

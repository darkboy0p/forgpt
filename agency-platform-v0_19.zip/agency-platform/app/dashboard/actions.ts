"use server";

import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { requireStaff, storeContext, STORE_COOKIE } from "../../src/web/storeSession";
import { attemptStoreLogin, revokeStaffSession, changeStaffPassword } from "../../src/store/auth";
import { buildConfigFromForm, saveDraft, publishDraft, discardDraft, loadEditorState } from "../../src/store/siteEditor";
import { entitlementsOf } from "../../src/web/entitlements";
import { markInquiry } from "../../src/store/inquiries";
import type { Pool } from "pg";
import { DAYS, LAYOUT_CHOICES, SECTION_KEYS, SOCIAL_KEYS, STYLABLE_SECTIONS, TITLE_KEYS } from "../../src/config/siteConfig";
import { listMedia, saveMedia, deleteMedia } from "../../src/store/media";

function clientIp(h: Headers): string {
  return (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
}
const str = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.slice(0, max) : "");

export async function storeLoginAction(formData: FormData): Promise<void> {
  const ctx = await storeContext();
  const email = formData.get("email"), password = formData.get("password");
  if (typeof email !== "string" || typeof password !== "string" || email.length > 254 || password.length > 1000) redirect("/dashboard/login?error=1");
  const h = await headers();
  const r = await attemptStoreLogin(ctx.pool, { email, password, ip: clientIp(h), userAgent: h.get("user-agent") ?? undefined });
  if (!r.ok) redirect(r.reason === "rate_limited" ? "/dashboard/login?error=2" : "/dashboard/login?error=1");
  (await cookies()).set(STORE_COOKIE, r.token, {
    httpOnly: true, sameSite: "strict", secure: ctx.env.APP_ENV !== "development", path: "/dashboard", expires: r.expiresAt,
  });
  redirect(r.mustChangePassword ? "/dashboard/password" : "/dashboard");
}

export async function storeLogoutAction(): Promise<void> {
  const ctx = await storeContext();
  const jar = await cookies();
  await revokeStaffSession(ctx.pool, jar.get(STORE_COOKIE)?.value);
  jar.delete({ name: STORE_COOKIE, path: "/dashboard" });
  redirect("/dashboard/login");
}

export async function changePasswordAction(formData: FormData): Promise<void> {
  const { pool, staff, token } = await requireStaff({ allowMustChange: true });
  const next = str(formData.get("next"), 200), again = str(formData.get("again"), 200);
  if (next !== again) redirect("/dashboard/password?error=mismatch");
  const r = await changeStaffPassword(pool, staff.staffId, str(formData.get("current"), 200), next, token);
  if (!r.ok) redirect(`/dashboard/password?error=${r.error}`);
  redirect("/dashboard?notice=password");
}

async function readEditorForm(formData: FormData, pool: Pool, tier: number) {
  const sectionOrder: Record<string, string> = {};
  for (const k of SECTION_KEYS) sectionOrder[k] = str(formData.get(`pos_${k}`), 3);
  const rows = (prefix: string, fields: string[], max: number) => {
    if (!formData.has(`${prefix}_${fields[0]}_0`)) return undefined; // not on this form: keep what is stored
    return Array.from({ length: max }, (_, i) => Object.fromEntries(fields.map((f) => [f, str(formData.get(`${prefix}_${f}_${i}`), 500)])));
  };
  const opt = (k: string, max: number) => (formData.has(k) ? str(formData.get(k), max) : undefined);
  const state = await loadEditorState(pool);
  const mediaIds = new Set((await listMedia(pool)).map((m) => m.id));
  const picked = (k: string) => str(formData.get(k), 40);
  const gallery = [...formData.keys()].filter((k) => k.startsWith("gallery_") && formData.get(k) === "on").map((k) => k.slice("gallery_".length)).slice(0, 20);
  return buildConfigFromForm({
    primary: str(formData.get("primary"), 10), heroTitle: str(formData.get("heroTitle"), 300), heroSubtitle: str(formData.get("heroSubtitle"), 500),
    about: str(formData.get("about"), 2500), phone: str(formData.get("phone"), 40), whatsapp: str(formData.get("whatsapp"), 40),
    address: str(formData.get("address"), 300), sectionOrder,
    accent: opt("accent", 10), background: opt("background", 10), text: opt("text", 10), surface: opt("surface", 10), font: opt("font", 20), buttonStyle: opt("buttonStyle", 20),
    layout: Object.fromEntries(Object.keys(LAYOUT_CHOICES).filter((k) => formData.has(k)).map((k) => [k, str(formData.get(k), 30)])),
    sectionTitles: formData.has("title_about") ? Object.fromEntries(TITLE_KEYS.map((k) => [k, str(formData.get(`title_${k}`), 100)])) : undefined,
    cta: formData.has("cta_label") ? { label: str(formData.get("cta_label"), 100), url: str(formData.get("cta_url"), 400) } : undefined,
    sectionStyles: formData.has("ss_marker") ? Object.fromEntries(STYLABLE_SECTIONS.map((k) => [k, {
      background: formData.has(`ss_${k}_bgOn`) ? str(formData.get(`ss_${k}_bg`), 10) : "", text: formData.has(`ss_${k}_textOn`) ? str(formData.get(`ss_${k}_text`), 10) : "",
      align: str(formData.get(`ss_${k}_align`), 12), spacing: str(formData.get(`ss_${k}_spacing`), 14),
    }])) : undefined,
    highlights: rows("hl", ["title", "text"], 6) as never, faqs: rows("faq", ["question", "answer"], 10) as never,
    promo: formData.has("promo_text") ? { text: str(formData.get("promo_text"), 300), linkLabel: str(formData.get("promo_linkLabel"), 100), linkUrl: str(formData.get("promo_linkUrl"), 400), until: str(formData.get("promo_until"), 20), style: formData.has("promo_style") ? str(formData.get("promo_style"), 20) : undefined } : undefined, ga4: opt("ga4", 30),
    services: rows("svc", ["name", "description", "price"], 12) as never, testimonials: rows("tm", ["name", "quote"], 10) as never,
    email: opt("email", 300), seoTitle: opt("seoTitle", 200), seoDescription: opt("seoDescription", 400),
    seoShareImage: opt("seoShareImage", 40), seoNoindex: formData.has("seoShareImage") ? formData.get("seoNoindex") === "on" : undefined,
    hours: formData.has("hours_mon") ? Object.fromEntries(DAYS.map((d) => [d, str(formData.get(`hours_${d}`), 100)])) : undefined,
    social: formData.has("social_facebook") ? Object.fromEntries(SOCIAL_KEYS.map((k) => [k, str(formData.get(`social_${k}`), 400)])) : undefined,
    images: formData.has("img_logo") ? { logo: picked("img_logo"), hero: picked("img_hero"), about: picked("img_about"), gallery } : undefined,
  }, state.draft ?? state.live, await entitlementsOf(tier), { mediaIds });
}

export async function saveDraftAction(formData: FormData): Promise<void> {
  const { pool, staff, tenant } = await requireStaff();
  const built = await readEditorForm(formData, pool, tenant.packageTier);
  if (!built.ok) redirect(`/dashboard/editor?error=${built.error}`);
  await saveDraft(pool, built.config, staff.email);
  redirect("/dashboard/editor?notice=saved");
}

export async function saveAndPublishAction(formData: FormData): Promise<void> {
  const { pool, staff, tenant } = await requireStaff();
  const built = await readEditorForm(formData, pool, tenant.packageTier);
  if (!built.ok) redirect(`/dashboard/editor?error=${built.error}`);
  await saveDraft(pool, built.config, staff.email);
  const r = await publishDraft(pool, staff.email);
  redirect(r.ok ? "/dashboard?notice=published" : `/dashboard/editor?error=${r.error}`);
}

export async function discardDraftAction(): Promise<void> {
  const { pool } = await requireStaff();
  await discardDraft(pool);
  redirect("/dashboard/editor?notice=discarded");
}

export async function markInquiryAction(formData: FormData): Promise<void> {
  const { pool, tenant } = await requireStaff();
  if (!(await entitlementsOf(tenant.packageTier)).inquiries) redirect("/dashboard");
  const status = str(formData.get("status"), 10) === "new" ? "new" : "done";
  await markInquiry(pool, str(formData.get("id"), 40), status);
  redirect("/dashboard/inquiries");
}

const MEDIA_MESSAGES = ["invalid_kind", "not_in_package", "empty", "too_large", "bad_type", "quota", "too_many", "alt_required", "not_found", "in_use"];

export async function uploadMediaAction(formData: FormData): Promise<void> {
  const { pool, staff, tenant } = await requireStaff();
  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) redirect("/dashboard/media?error=empty");
  if (file.size > 3 * 1024 * 1024) redirect("/dashboard/media?error=too_large");
  const r = await saveMedia(pool, await entitlementsOf(tenant.packageTier), {
    kind: str(formData.get("kind"), 20), filename: file.name, alt: str(formData.get("alt"), 200), bytes: new Uint8Array(await file.arrayBuffer()),
  }, staff.email);
  redirect(r.ok ? "/dashboard/media?notice=uploaded" : `/dashboard/media?error=${MEDIA_MESSAGES.includes(r.error) ? r.error : "bad_type"}`);
}

export async function deleteMediaAction(formData: FormData): Promise<void> {
  const { pool } = await requireStaff();
  const r = await deleteMedia(pool, str(formData.get("id"), 40));
  redirect(r.ok ? "/dashboard/media?notice=deleted" : `/dashboard/media?error=${r.error}`);
}

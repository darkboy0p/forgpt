import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { Msg, taka } from "../../../src/web/dashboard/bits";
import { listDiscounts } from "../../../src/shop/extras";
import { createDiscountAction, deleteDiscountAction, toggleDiscountAction } from "../shop-actions";

export const dynamic = "force-dynamic";

export default async function DiscountsPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.discounts) return <StoreShell businessName={businessName} email={staff.email}><h1>Discount codes</h1><LockedCard title="Discount codes" text="Create codes such as EID10 that customers type at checkout." /></StoreShell>;
  const codes = await listDiscounts(pool);
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <h1>Discount codes</h1>
      <p className="lead">Customers type a code at checkout. The discount is worked out on the server, so it cannot be faked.</p>
      <Msg error={error} notice={notice} />
      <section className="card">
        <h2>New code</h2>
        <form action={createDiscountAction}>
          <div className="ed-cols">
            <label>Code<span className="hint">3 to 20 letters or numbers</span><input name="code" required minLength={3} maxLength={20} placeholder="EID10" style={{ textTransform: "uppercase" }} /></label>
            <label>Type<select name="kind" defaultValue="percent"><option value="percent">Percent off</option><option value="fixed">Fixed amount off (taka)</option></select></label>
            <label>Amount<input name="value" required inputMode="numeric" pattern="[0-9]+" placeholder="10" /></label>
            <label>Minimum order (taka)<input name="minOrder" inputMode="numeric" pattern="[0-9]*" placeholder="0" /></label>
            <label>Maximum uses<input name="maxUses" inputMode="numeric" pattern="[0-9]*" placeholder="No limit" /></label>
            <label>Last day<input name="expiresOn" type="date" /></label>
          </div>
          <button className="btn" type="submit">Create code</button>
        </form>
      </section>
      <div className="tbl-wrap"><table>
        <thead><tr><th>Code</th><th>Discount</th><th>Rules</th><th className="num">Used</th><th></th></tr></thead>
        <tbody>
          {codes.map((d) => (
            <tr key={d.id}>
              <td><strong>{d.code}</strong> {!d.is_active && <span className="chip off">Off</span>}</td>
              <td>{d.kind === "percent" ? `${d.value}% off` : `${taka(Number(d.value))} off`}</td>
              <td><small className="hint">{Number(d.min_order_bdt) > 0 ? `Min ${taka(Number(d.min_order_bdt))}. ` : ""}{d.expires_on ? `Until ${d.expires_on}. ` : ""}{d.max_uses ? `Max ${d.max_uses} uses.` : ""}</small></td>
              <td className="num">{d.used_count}</td>
              <td className="num"><span style={{ display: "inline-flex", gap: 6 }}>
                <form action={toggleDiscountAction}><input type="hidden" name="id" value={d.id} /><input type="hidden" name="active" value={d.is_active ? "0" : "1"} /><button type="submit" style={{ padding: "4px 10px", fontSize: ".8rem" }}>{d.is_active ? "Turn off" : "Turn on"}</button></form>
                <form action={deleteDiscountAction}><input type="hidden" name="id" value={d.id} /><button type="submit" className="linkish">Delete</button></form></span></td>
            </tr>
          ))}
          {codes.length === 0 && <tr><td colSpan={5} className="hint">No codes yet.</td></tr>}
        </tbody>
      </table></div>
    </StoreShell>
  );
}

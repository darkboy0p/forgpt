import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { Stat, taka } from "../../../src/web/dashboard/bits";
import { STATUS_LABELS } from "../../../src/web/dashboard/shopMessages";
import { advancedReport, salesReport } from "../../../src/shop/extras";

export const dynamic = "force-dynamic";

export default async function ReportsPage({ searchParams }: { searchParams: Promise<{ days?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { days } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.reports) return <StoreShell businessName={businessName} email={staff.email}><h1>Reports</h1><LockedCard title="Sales reports" text="See your sales, best-selling products and order totals for the last 7, 30 or 90 days." /></StoreShell>;
  const r = await salesReport(pool, days);
  const adv = await advancedReport(pool, ent, days);
  const max = Math.max(1, ...r.byDay.map((d) => d.revenue));
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <div className="toolbar" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <h1>Reports</h1>
        <span className="seg" aria-label="Period">{[7, 30, 90].map((d) => <a key={d} href={`/dashboard/reports?days=${d}`} aria-current={d === r.days ? "true" : undefined}>{d} days</a>)}</span>
      </div>
      <div className="kpis">
        <Stat label="Sales" value={taka(r.revenue)} sub={`${r.orders} orders`} />
        <Stat label="Average order" value={taka(r.avgOrder)} />
        <Stat label="Cancelled" value={r.cancelled} alert={r.cancelled > 0 && r.cancelled > r.orders / 3} />
        {adv && <Stat label="Customers" value={adv.customers} sub={`${adv.repeatCustomers} ordered again`} />}
        {adv && <Stat label="Discounts given" value={taka(adv.discountsGiven)} sub={`${adv.ordersWithCode} orders with a code`} />}
      </div>
      <section className="card">
        <h2>Sales per day</h2>
        <div className="bars" role="img" aria-label="Sales per day">{r.byDay.map((d) => <i key={d.day} title={`${d.day}: ${taka(d.revenue)} (${d.orders} orders)`} style={{ height: `${Math.max(1, (d.revenue / max) * 100)}%` }} />)}</div>
        <p className="hint" style={{ display: "flex", justifyContent: "space-between", margin: 0 }}><span>{r.byDay[0]?.day}</span><span>{r.byDay.at(-1)?.day} (UTC days)</span></p>
      </section>
      <div className="ed-cols" style={{ alignItems: "start", gap: 16 }}>
        <section className="card"><h2>Best-selling products</h2>
          <table><thead><tr><th>Product</th><th className="num">Sold</th><th className="num">Sales</th></tr></thead><tbody>
            {r.top.map((t) => <tr key={t.name}><td>{t.name}</td><td className="num">{t.qty}</td><td className="num">{taka(t.revenue)}</td></tr>)}
            {r.top.length === 0 && <tr><td colSpan={3} className="hint">No sales in this period.</td></tr>}</tbody></table></section>
        <section className="card"><h2>Orders by status</h2>
          <table><tbody>{Object.entries(r.byStatus).map(([s, n]) => <tr key={s}><td>{STATUS_LABELS[s] ?? s}</td><td className="num">{n}</td></tr>)}{Object.keys(r.byStatus).length === 0 && <tr><td className="hint">No orders in this period.</td></tr>}</tbody></table></section>
      </div>
      {adv ? (
        <section className="card"><h2>Sales by category</h2>
          <table><thead><tr><th>Category</th><th className="num">Sold</th><th className="num">Sales</th></tr></thead><tbody>{adv.byCategory.map((c) => <tr key={c.name}><td>{c.name}</td><td className="num">{c.qty}</td><td className="num">{taka(c.revenue)}</td></tr>)}</tbody></table>
          <p className="hint">Average {adv.itemsPerOrder} items per order.</p></section>
      ) : <LockedCard title="Detailed reports" text="Sales by category, repeat customers and discount results are in higher packages." />}
    </StoreShell>
  );
}

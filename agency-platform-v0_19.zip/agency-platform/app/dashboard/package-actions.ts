"use server";

import { redirect } from "next/navigation";
import { runtime } from "../../src/web/server";
import { requireStaff } from "../../src/web/storeSession";
import { createClientRequest } from "../../src/packages/requests";

const str = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.slice(0, max) : "");

/** Owners can only ASK for an upgrade. Only the platform admin can change a package. */
export async function requestUpgradeAction(formData: FormData): Promise<void> {
  const { staff, tenant } = await requireStaff();
  const r = await createClientRequest(runtime().control, tenant.tenantId, "upgrade", str(formData.get("message"), 1500), str(formData.get("tier"), 3), staff.email);
  redirect(`/dashboard/package?${r.ok ? "notice=upgrade_sent" : `error=${r.error}`}#requests`);
}

export async function requestSupportAction(formData: FormData): Promise<void> {
  const { staff, tenant } = await requireStaff();
  const r = await createClientRequest(runtime().control, tenant.tenantId, "support", str(formData.get("message"), 1500), undefined, staff.email);
  redirect(`/dashboard/package?${r.ok ? "notice=support_sent" : `error=${r.error}`}#requests`);
}

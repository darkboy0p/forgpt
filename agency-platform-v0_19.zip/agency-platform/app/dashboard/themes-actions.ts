"use server";
import { redirect } from "next/navigation";
import { requireStaff } from "../../src/web/storeSession";
import { entitlementsOf } from "../../src/web/entitlements";
import { loadEditorState, saveDraft, publishDraft } from "../../src/store/siteEditor";
import { applyTheme, themeByKey } from "../../src/config/themes";

export async function applyThemeAction(formData: FormData): Promise<void> {
  const { pool, staff, tenant } = await requireStaff();
  const raw = formData.get("theme");
  const theme = themeByKey(typeof raw === "string" ? raw.slice(0, 30) : "");
  if (!theme) redirect("/dashboard/themes?error=unknown_theme");
  const ent = await entitlementsOf(tenant.packageTier);
  const state = await loadEditorState(pool);
  const next = applyTheme(state.draft ?? state.live, theme, { branding: ent.branding, layout: ent.layout });
  await saveDraft(pool, next, staff.email);
  if (formData.get("publish") === "1") {
    const r = await publishDraft(pool, staff.email);
    redirect(r.ok ? "/dashboard/themes?notice=published" : "/dashboard/themes?error=publish_failed");
  }
  redirect("/dashboard/themes?notice=applied");
}

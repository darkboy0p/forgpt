import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { loadEditorState } from "../../../src/store/siteEditor";
import { THEMES, currentThemeKey } from "../../../src/config/themes";
import { applyThemeAction } from "../themes-actions";

export const dynamic = "force-dynamic";
const RADIUS = { rounded: "8px", square: "0", pill: "999px" } as const;
const FONT = { sans: "system-ui, sans-serif", serif: "Georgia, 'Times New Roman', serif", rounded: "'Trebuchet MS', 'Segoe UI', sans-serif" } as const;
const NOTICES: Record<string, string> = { applied: "Theme applied to your draft. Check it with Preview, then publish when you are happy.", published: "Theme applied and published. Your website now uses it." };

export default async function ThemesPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  const state = await loadEditorState(pool);
  const current = currentThemeKey(state.draft ?? state.live);
  const full = ent.branding && ent.layout;
  return (
    <StoreShell businessName={businessName} email={staff.email} inquiries={ent.inquiries}>
      <h1>Themes</h1>
      <p className="lead">Switch the whole look of your website in one click: colours, font, buttons and layout. Your text, images and prices stay exactly as they are. You can always change details afterwards in <a href="/dashboard/editor">Edit website</a>.</p>
      {error && <p className="warn" role="alert">Something went wrong. Please try again.</p>}
      {notice && NOTICES[notice] && <p className="ok" role="status">{NOTICES[notice]} <a href="/dashboard/preview" target="_blank" rel="noopener">Preview saved draft</a></p>}
      {!full && <p className="warn">Your package changes the <strong>main colour</strong> only. Higher packages also change the font, buttons and layout. <a href="/dashboard/package#upgrade">See packages</a></p>}
      <div className="theme-grid">
        {THEMES.map((t) => (
          <section className={current === t.key ? "card theme current" : "card theme"} key={t.key}>
            <div className="theme-mini" aria-hidden="true" style={{ fontFamily: full ? FONT[t.font] : FONT.sans }}>
              <div className="bar"><i style={{ background: t.primary }} /><span /><span /><span /></div>
              <div className="hero" style={{ background: t.layout.heroStyle === "light" ? "#f3f5f7" : t.primary, color: t.layout.heroStyle === "light" ? "#1b1f24" : "#fff", textAlign: t.layout.heroAlign === "center" && full ? "center" : "left" }}>
                <b>Welcome</b><small>Your tagline here</small>
                <em style={{ background: full ? t.accent : "#f59e0b", borderRadius: full ? RADIUS[t.buttonStyle] : RADIUS.rounded }}>Contact</em>
              </div>
              <div className="cards"><u /><u /><u /></div>
            </div>
            <h2 style={{ margin: "10px 0 2px" }}>{t.name} {current === t.key && <span className="chip">In use</span>}</h2>
            <p className="hint" style={{ margin: "0 0 10px" }}>{t.blurb}</p>
            <div className="swatches"><i style={{ background: t.primary }} title="Main colour" />{full && <i style={{ background: t.accent }} title="Accent colour" />}</div>
            <form action={applyThemeAction} className="ed-tools">
              <input type="hidden" name="theme" value={t.key} />
              <button className="btn ghost" type="submit">Apply to draft</button>
              <button className="btn" type="submit" name="publish" value="1">Apply and publish</button>
            </form>
          </section>
        ))}
      </div>
    </StoreShell>
  );
}

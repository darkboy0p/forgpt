import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { changePasswordAction } from "../actions";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  mismatch: "The two new passwords do not match.", wrong_password: "Your current password is not correct.",
  same_password: "Choose a different password from the current one.", weak_password: "The new password must be 12 to 128 characters and not contain your email name.",
};

export default async function PasswordPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { staff, businessName } = await requireStaff({ allowMustChange: true });
  const { error } = await searchParams;
  const input = { width: "100%", padding: 8 } as const;
  return (
    <StoreShell businessName={businessName} email={staff.mustChangePassword ? undefined : staff.email}>
      <div style={{ maxWidth: 460 }}>
        <h1>{staff.mustChangePassword ? "Choose your own password" : "Change password"}</h1>
        {staff.mustChangePassword && <p>You are using a temporary password. Please choose your own before continuing.</p>}
        {error && <p className="warn">{ERRORS[error] ?? "Could not change the password."}</p>}
        <form action={changePasswordAction} className="card">
          <p><label>Current password<br /><input name="current" type="password" required autoComplete="current-password" style={input} /></label></p>
          <p><label>New password (at least 12 characters)<br /><input name="next" type="password" required minLength={12} maxLength={128} autoComplete="new-password" style={input} /></label></p>
          <p><label>New password again<br /><input name="again" type="password" required minLength={12} maxLength={128} autoComplete="new-password" style={input} /></label></p>
          <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Save password</button>
        </form>
      </div>
    </StoreShell>
  );
}

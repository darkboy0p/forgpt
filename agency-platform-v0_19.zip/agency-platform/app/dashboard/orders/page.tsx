import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { Msg, Pager, taka } from "../../../src/web/dashboard/bits";
import { STATUS_LABELS } from "../../../src/web/dashboard/shopMessages";
import { ALL_STATUSES, BASIC_STATUSES, listOrders } from "../../../src/shop/orders";
import { setOrderStatusAction } from "../shop-actions";

export const dynamic = "force-dynamic";
const chip = (s: string) => (s === "new" ? "chip warn" : s === "cancelled" ? "chip off" : "chip");

export default async function OrdersPage({ searchParams }: { searchParams: Promise<{ status?: string; q?: string; page?: string; error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const sp = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.products) return <StoreShell businessName={businessName} email={staff.email}><LockedCard title="Orders" text="Your package does not include the shop." /></StoreShell>;
  const tab = sp.status && ([...ALL_STATUSES, "all"] as string[]).includes(sp.status) ? sp.status : "open";
  const list = await listOrders(pool, { status: tab === "all" ? undefined : tab, q: sp.q, page: sp.page });
  const tabs = ent.shop.orderManagement ? [["open", "Open"], ...ALL_STATUSES.map((s) => [s, STATUS_LABELS[s]!]), ["all", "All"]] : [["open", "Open"], ...BASIC_STATUSES.map((s) => [s, STATUS_LABELS[s]!]), ["all", "All"]];
  const back = `/dashboard/orders?status=${tab}`;
  const href = (p: number) => `/dashboard/orders?${new URLSearchParams({ status: tab, ...(sp.q ? { q: sp.q } : {}), page: String(p) })}`;
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <h1>Orders</h1>
      <p className="lead">{ent.shop.orderManagement ? "Orders from your website. Confirm them, follow delivery and record payment." : "Order requests from your website. Call the customer to confirm, then mark the order confirmed."}</p>
      <Msg error={sp.error} notice={sp.notice} />
      <div className="toolbar" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <span className="seg" role="tablist" aria-label="Order status">{tabs.map(([k, l]) => <a key={k} href={`/dashboard/orders?status=${k}`} aria-current={k === tab ? "true" : undefined}>{l}</a>)}</span>
        <form method="get" className="toolbar" style={{ margin: 0 }}><input type="hidden" name="status" value={tab} /><input type="search" name="q" defaultValue={sp.q ?? ""} placeholder="Name, phone or order number" aria-label="Search orders" style={{ width: 240 }} /><button className="btn ghost" type="submit">Search</button></form>
      </div>
      <div className="tbl-wrap"><table>
        <thead><tr><th>Order</th><th>Customer</th><th className="num">Items</th><th className="num">Total</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {list.rows.map((o) => (
            <tr key={o.id}>
              <td><a href={`/dashboard/orders/${o.id}`}><strong>#{o.number}</strong></a><br /><small className="hint">{new Date(o.created_at).toISOString().slice(0, 16).replace("T", " ")} UTC</small></td>
              <td>{o.customer_name}<br /><a href={`tel:${o.phone}`}>{o.phone}</a></td>
              <td className="num">{o.item_count}</td>
              <td className="num">{taka(o.total_bdt)}{ent.shop.orderManagement && <><br /><small className={o.payment_status === "paid" ? "chip" : "hint"}>{o.payment_status === "paid" ? "Paid" : "Unpaid"}</small></>}</td>
              <td><span className={chip(o.status)}>{STATUS_LABELS[o.status]}</span></td>
              <td className="num">
                {o.status === "new" && <form action={setOrderStatusAction} style={{ display: "inline" }}><input type="hidden" name="id" value={o.id} /><input type="hidden" name="status" value="confirmed" /><input type="hidden" name="back" value={back} /><button type="submit" style={{ padding: "4px 10px", fontSize: ".8rem" }}>Confirm</button></form>} <a className="btn ghost" style={{ padding: "4px 10px", fontSize: ".8rem" }} href={`/dashboard/orders/${o.id}`}>Open</a>
              </td>
            </tr>
          ))}
          {list.rows.length === 0 && <tr><td colSpan={6} className="hint">No orders here yet.</td></tr>}
        </tbody>
      </table></div>
      <Pager page={list.page} pages={list.pages} href={href} />
    </StoreShell>
  );
}

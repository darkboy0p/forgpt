import { notFound } from "next/navigation";
import { requireStaff } from "../../../../src/web/storeSession";
import { StoreShell } from "../../../../src/web/StoreShell";
import { entitlementsOf } from "../../../../src/web/entitlements";
import { Msg, taka } from "../../../../src/web/dashboard/bits";
import { STATUS_LABELS } from "../../../../src/web/dashboard/shopMessages";
import { PrintButton } from "../../../../src/web/dashboard/PrintButton";
import { ALL_STATUSES, BASIC_STATUSES, getOrder } from "../../../../src/shop/orders";
import { setOrderStatusAction, updateOrderDetailsAction } from "../../shop-actions";

export const dynamic = "force-dynamic";

export default async function OrderDetail({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { id } = await params;
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.products) notFound();
  const found = await getOrder(pool, id);
  if (!found) notFound();
  const { order: o, items, events } = found;
  const allowed = ent.shop.orderManagement ? ALL_STATUSES : BASIC_STATUSES;
  const wa = o.phone.replace(/^\+/, "").replace(/^0/, "880");
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <p className="noprint"><a href="/dashboard/orders">&larr; Orders</a></p>
      <h1>Order #{o.number} <span className={o.status === "cancelled" ? "chip off" : o.status === "new" ? "chip warn" : "chip"}>{STATUS_LABELS[o.status]}</span></h1>
      <Msg error={error} notice={notice} />
      <div className="ed-cols" style={{ alignItems: "start", gap: 16 }}>
        <section className="card">
          <h2>Customer</h2>
          <p style={{ margin: "0 0 6px" }}><strong>{o.customer_name}</strong><br /><a href={`tel:${o.phone}`}>{o.phone}</a> &middot; <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>{o.email && <> &middot; <a href={`mailto:${o.email}`}>{o.email}</a></>}</p>
          <p style={{ margin: "0 0 6px", whiteSpace: "pre-wrap" }}>{o.address}{o.area && `, ${o.area}`}</p>
          {o.note && <p className="hint" style={{ whiteSpace: "pre-wrap" }}>Customer note: {o.note}</p>}
          <p className="hint" style={{ margin: 0 }}>{new Date(o.created_at).toISOString().slice(0, 16).replace("T", " ")} UTC &middot; {o.channel === "checkout" ? "Checkout (cash on delivery)" : "Order request"}</p>
        </section>
        <section className="card noprint">
          <h2>Status</h2>
          {o.status === "cancelled" ? <p className="hint">Cancelled orders cannot be changed.</p> : (
            <div className="ed-tools">
              {allowed.filter((s) => s !== o.status).map((s) => (
                <form action={setOrderStatusAction} key={s}><input type="hidden" name="id" value={o.id} /><input type="hidden" name="status" value={s} />
                  <button type="submit" className={s === "cancelled" ? "linkish" : undefined}>{s === "cancelled" ? "Cancel order" : `Mark ${STATUS_LABELS[s]!.toLowerCase()}`}</button></form>
              ))}
            </div>
          )}
          {!ent.shop.orderManagement && <p className="hint">Delivery steps, payment and courier details are in higher packages. <a href="/dashboard/package#upgrade">See packages</a></p>}
        </section>
      </div>
      <section className="card">
        <h2>Items</h2>
        <div className="tbl-wrap"><table><thead><tr><th>Product</th><th className="num">Price</th><th className="num">Qty</th><th className="num">Total</th></tr></thead>
          <tbody>{items.map((i) => <tr key={i.id}><td>{i.name}{i.variant_label && <small className="hint"> ({i.variant_label})</small>}</td><td className="num">{taka(i.unit_price_bdt)}</td><td className="num">{i.qty}</td><td className="num">{taka(i.line_total_bdt)}</td></tr>)}</tbody></table></div>
        <div className="totals-d" style={{ marginLeft: "auto", maxWidth: 320 }}>
          <p style={{ display: "flex", justifyContent: "space-between", margin: "8px 0 2px" }}><span>Subtotal</span><span>{taka(o.subtotal_bdt)}</span></p>
          {o.channel === "checkout" && <p style={{ display: "flex", justifyContent: "space-between", margin: "2px 0" }}><span>Delivery</span><span>{taka(o.delivery_fee_bdt)}</span></p>}
          {o.discount_bdt > 0 && <p style={{ display: "flex", justifyContent: "space-between", margin: "2px 0" }}><span>Discount {o.discount_code && `(${o.discount_code})`}</span><span>-{taka(o.discount_bdt)}</span></p>}
          <p style={{ display: "flex", justifyContent: "space-between", margin: "6px 0 0", fontWeight: 700, fontSize: "1.1rem" }}><span>Total</span><span>{taka(o.total_bdt)}</span></p>
        </div>
        <p className="noprint"><PrintButton /></p>
      </section>
      {ent.shop.orderManagement && (
        <section className="card noprint">
          <h2>Payment and delivery</h2>
          <form action={updateOrderDetailsAction}>
            <input type="hidden" name="id" value={o.id} />
            <div className="ed-cols">
              <label>Payment<select name="paymentStatus" defaultValue={o.payment_status}><option value="unpaid">Not paid yet</option><option value="paid">Paid</option></select></label>
              <label>Courier<input name="courier" maxLength={60} defaultValue={o.courier} placeholder="Pathao, Steadfast, RedX..." /></label>
              <label>Tracking code<input name="trackingCode" maxLength={60} defaultValue={o.tracking_code} /></label>
            </div>
            <label>Private note (only you see this)<textarea name="internalNote" rows={2} maxLength={500} defaultValue={o.internal_note} /></label>
            <button className="btn" type="submit">Save</button> <span className="hint">The customer sees the courier and tracking code on their order page.</span>
          </form>
        </section>
      )}
      <section className="card noprint"><h2>History</h2><ul style={{ margin: 0, paddingLeft: 18 }}>{events.map((e, i) => <li key={i}>{STATUS_LABELS[e.status] ?? e.status} <span className="hint">by {e.actor} &middot; {new Date(e.at).toISOString().slice(0, 16).replace("T", " ")} UTC</span></li>)}</ul></section>
    </StoreShell>
  );
}

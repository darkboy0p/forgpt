"use server";

import { redirect } from "next/navigation";
import { requireStaff } from "../../src/web/storeSession";
import { entitlementsOf } from "../../src/web/entitlements";
import { loadEditorState, saveDraft } from "../../src/store/siteEditor";
import { MAX_VARIANTS, addProductImage, createCategory, createProduct, deleteCategory, deleteProduct, makeMainImage, removeProductImage, updateCategory, updateProduct, PRODUCT_STATUSES, type ProductInput } from "../../src/shop/products";
import { setOrderStatus, updateOrderDetails } from "../../src/shop/orders";
import { createDiscount, deleteDiscount, getShopSettings, saveShopSettings, setDiscountActive } from "../../src/shop/extras";
import { createCampaign, deleteCampaign, setCampaignActive } from "../../src/shop/campaigns";
import { siteConfigV1 } from "../../src/config/siteConfig";

async function ctx() {
  const c = await requireStaff();
  return { ...c, ent: await entitlementsOf(c.tenant.packageTier) };
}
const str = (f: FormData, k: string, max = 4000) => { const v = f.get(k); return typeof v === "string" ? v.slice(0, max) : ""; };
const go = (path: string, kind: "notice" | "error", code: string): never => redirect(`${path}${path.includes("?") ? "&" : "?"}${kind}=${code}`);

function productFields(f: FormData): ProductInput {
  const variants = Array.from({ length: MAX_VARIANTS }, (_, i) => ({ label: str(f, `var_label_${i}`, 100), priceBdt: str(f, `var_price_${i}`, 20), stockQty: str(f, `var_stock_${i}`, 20) }));
  return {
    name: str(f, "name", 300), description: str(f, "description", 4000), priceBdt: str(f, "priceBdt", 20), comparePriceBdt: str(f, "comparePriceBdt", 20), sku: str(f, "sku", 100),
    status: str(f, "status", 20), categoryId: str(f, "categoryId", 50), isFeatured: f.has("isFeatured"), trackStock: f.has("trackStock"),
    stockQty: str(f, "stockQty", 20), lowStockAt: str(f, "lowStockAt", 20),
    // The option rows are only on the form for packages that include options; leaving them out keeps what is stored.
    variants: f.has("var_label_0") ? variants : undefined,
  };
}

export async function saveProductAction(formData: FormData): Promise<void> {
  const { pool, ent } = await ctx();
  const id = str(formData, "id", 50);
  const input = productFields(formData);
  if (id) {
    const r = await updateProduct(pool, ent, id, input);
    if (!r.ok) go(`/dashboard/products/${id}`, "error", r.error);
    go(`/dashboard/products/${id}`, "notice", "saved");
  }
  const r = await createProduct(pool, ent, input);
  if (!r.ok) go("/dashboard/products/new", "error", r.error);
  else go(`/dashboard/products/${r.id}`, "notice", "created");
}

export async function deleteProductAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  await deleteProduct(pool, str(formData, "id", 50));
  go("/dashboard/products", "notice", "deleted");
}

/** Quick change from the product list: Active, Sold out or Hidden. */
export async function quickStatusAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  const status = str(formData, "status", 20);
  if ((PRODUCT_STATUSES as readonly string[]).includes(status)) await pool.query("UPDATE shop_products SET status = $2, updated_at = now() WHERE id = $1 AND $2 IN ('active','sold_out','hidden')", [str(formData, "id", 50), status]);
  go(str(formData, "back", 200).startsWith("/dashboard/products") ? str(formData, "back", 200) : "/dashboard/products", "notice", "status");
}

export async function uploadProductPhotosAction(formData: FormData): Promise<void> {
  const { pool, ent, staff } = await ctx();
  const id = str(formData, "id", 50);
  const back = `/dashboard/products/${id}`;
  const files = formData.getAll("photos").filter((x): x is File => typeof x !== "string" && x.size > 0).slice(0, 12);
  if (files.length === 0) go(back, "error", "empty");
  let added = 0;
  for (const file of files) {
    const r = await addProductImage(pool, ent, id, { filename: file.name, bytes: new Uint8Array(await file.arrayBuffer()) }, staff.email);
    if (!r.ok) { if (added === 0) go(back, "error", r.error); break; }
    added++;
  }
  go(back, "notice", added > 1 ? "photos" : "photo");
}
export async function removeProductPhotoAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  const id = str(formData, "id", 50);
  await removeProductImage(pool, id, str(formData, "mediaId", 50));
  go(`/dashboard/products/${id}`, "notice", "photo_removed");
}
export async function makeMainPhotoAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  const id = str(formData, "id", 50);
  await makeMainImage(pool, id, str(formData, "mediaId", 50));
  go(`/dashboard/products/${id}`, "notice", "main");
}

/** Adds the Products section to the owner's draft home page so the shop is visible without hunting for the setting. */
export async function showProductsOnHomeAction(): Promise<void> {
  const { pool, staff, ent } = await ctx();
  if (!ent.shop.products) go("/dashboard/products", "error", "not_in_package");
  const state = await loadEditorState(pool);
  const cfg = structuredClone(state.draft ?? state.live);
  if (!(cfg.sections as string[]).includes("products")) {
    const i = (cfg.sections as string[]).indexOf("contact");
    (cfg.sections as string[]).splice(i < 0 ? cfg.sections.length : i, 0, "products");
    await saveDraft(pool, siteConfigV1.parse(cfg), staff.email);
  }
  go("/dashboard/products", "notice", "home");
}

// ---------- categories ----------
export async function createCategoryAction(formData: FormData): Promise<void> {
  const { pool, ent } = await ctx();
  const r = await createCategory(pool, ent, str(formData, "name", 200));
  r.ok ? go("/dashboard/categories", "notice", "category") : go("/dashboard/categories", "error", r.error);
}
export async function updateCategoryAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  const r = await updateCategory(pool, str(formData, "id", 50), { name: str(formData, "name", 200), isVisible: formData.has("isVisible"), sortOrder: str(formData, "sortOrder", 10) });
  r.ok ? go("/dashboard/categories", "notice", "category") : go("/dashboard/categories", "error", r.error);
}
export async function deleteCategoryAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  await deleteCategory(pool, str(formData, "id", 50));
  go("/dashboard/categories", "notice", "deleted");
}

// ---------- orders ----------
export async function setOrderStatusAction(formData: FormData): Promise<void> {
  const { pool, ent, staff } = await ctx();
  const id = str(formData, "id", 50);
  const back = str(formData, "back", 200).startsWith("/dashboard/orders") ? str(formData, "back", 200) : `/dashboard/orders/${id}`;
  const r = await setOrderStatus(pool, ent, id, str(formData, "status", 20), staff.email);
  r.ok ? go(back, "notice", "status") : go(back, "error", r.error);
}
export async function updateOrderDetailsAction(formData: FormData): Promise<void> {
  const { pool, ent } = await ctx();
  const id = str(formData, "id", 50);
  const r = await updateOrderDetails(pool, ent, id, { paymentStatus: str(formData, "paymentStatus", 10), courier: str(formData, "courier", 100), trackingCode: str(formData, "trackingCode", 100), internalNote: str(formData, "internalNote", 700) });
  r.ok ? go(`/dashboard/orders/${id}`, "notice", "saved") : go(`/dashboard/orders/${id}`, "error", r.error);
}

// ---------- discounts and settings ----------
export async function createDiscountAction(formData: FormData): Promise<void> {
  const { pool, ent } = await ctx();
  const r = await createDiscount(pool, ent, { code: str(formData, "code", 40), kind: str(formData, "kind", 10), value: str(formData, "value", 12), minOrder: str(formData, "minOrder", 12), maxUses: str(formData, "maxUses", 12), expiresOn: str(formData, "expiresOn", 12) });
  r.ok ? go("/dashboard/discounts", "notice", "discount") : go("/dashboard/discounts", "error", r.error);
}
export async function toggleDiscountAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  await setDiscountActive(pool, str(formData, "id", 50), str(formData, "active", 5) === "1");
  go("/dashboard/discounts", "notice", "saved");
}
export async function deleteDiscountAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  await deleteDiscount(pool, str(formData, "id", 50));
  go("/dashboard/discounts", "notice", "deleted");
}
export async function saveShopSettingsAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  // Delivery fields are disabled (and so not sent) for packages without checkout: keep what is stored.
  const cur = formData.has("deliveryFee") ? null : await getShopSettings(pool);
  const r = await saveShopSettings(pool, {
    deliveryFee: cur ? String(cur.delivery_fee_bdt) : str(formData, "deliveryFee", 12),
    freeOver: cur ? (cur.free_delivery_over_bdt == null ? "" : String(cur.free_delivery_over_bdt)) : str(formData, "freeOver", 12),
    orderNote: str(formData, "orderNote", 600),
  });
  r.ok ? go("/dashboard/shop-settings", "notice", "saved") : go("/dashboard/shop-settings", "error", r.error);
}

// ---------- campaigns ----------
export async function createCampaignAction(formData: FormData): Promise<void> {
  const { pool, ent } = await ctx();
  const r = await createCampaign(pool, ent, { name: str(formData, "name", 200), percent: str(formData, "percent", 6), appliesTo: str(formData, "appliesTo", 12), categoryId: str(formData, "categoryId", 50), startsOn: str(formData, "startsOn", 12), endsOn: str(formData, "endsOn", 12) });
  r.ok ? go("/dashboard/campaigns", "notice", "campaign") : go("/dashboard/campaigns", "error", r.error);
}
export async function toggleCampaignAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  await setCampaignActive(pool, str(formData, "id", 50), str(formData, "active", 5) === "1");
  go("/dashboard/campaigns", "notice", "saved");
}
export async function deleteCampaignAction(formData: FormData): Promise<void> {
  const { pool } = await ctx();
  await deleteCampaign(pool, str(formData, "id", 50));
  go("/dashboard/campaigns", "notice", "deleted");
}

import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { runtime } from "../../../src/web/server";
import { entitlementsOf } from "../../../src/web/entitlements";
import { FEATURES } from "../../../src/packages/features";
import { getFeatureValues } from "../../../src/packages/resolve";
import { getAgreement } from "../../../src/billing/service";
import { effectiveMonthlyFee, formatTaka, todayUtc } from "../../../src/billing/values";
import { mediaUsage } from "../../../src/store/media";
import { requestUpgradeAction, requestSupportAction } from "../package-actions";

export const dynamic = "force-dynamic";

const NOTICES: Record<string, string> = { upgrade_sent: "Your upgrade request was sent. Your website provider will contact you.", support_sent: "Your support request was sent." };
const ERRORS: Record<string, string> = { invalid_message: "Please write a message of 5 to 1000 characters.", invalid_tier: "Choose a package.", too_many_open: "You already have several open requests. Please wait for a reply." };
const GROUPS = ["Website", "Products", "Selling", "Reports", "Support"] as const;

export default async function PackagePage({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { notice, error } = await searchParams;
  const { control } = runtime();
  const ent = await entitlementsOf(tenant.packageTier);
  const mine = await getFeatureValues(control, tenant.packageTier);
  const pkg = (await control.query("SELECT name, description FROM packages WHERE tier = $1", [tenant.packageTier])).rows[0];
  // the lowest package that includes each feature, for the "available from" hint
  const byTier = await Promise.all([1, 2, 3, 4, 5].map((t) => getFeatureValues(control, t)));
  const names: Record<number, string> = Object.fromEntries((await control.query("SELECT tier, name FROM packages")).rows.map((r) => [r.tier, r.name]));
  const availableFrom = (key: string) => { const i = byTier.findIndex((v) => Boolean(v[key])); return i >= 0 ? names[i + 1] : "a higher package"; };

  const agreement = await getAgreement(control, tenant.tenantId);
  const invoices = (await control.query(
    `SELECT i.number, i.description, i.amount_bdt, i.due_date, i.status, COALESCE((SELECT sum(amount_bdt) FROM payments p WHERE p.invoice_id = i.id), 0) AS paid
       FROM invoices i WHERE i.tenant_id = $1 AND i.status <> 'void' ORDER BY i.issued_at DESC LIMIT 24`, [tenant.tenantId])).rows;
  const requests = (await control.query("SELECT kind, requested_tier, message, status, created_at FROM client_requests WHERE tenant_id = $1 ORDER BY created_at DESC LIMIT 10", [tenant.tenantId])).rows;
  const usage = await mediaUsage(pool);
  const field = { width: "100%", padding: 8 } as const;

  return (
    <StoreShell businessName={businessName} email={staff.email} inquiries={ent.inquiries}>
      <h1>My package</h1>
      {notice && NOTICES[notice] && <p className="card">{NOTICES[notice]}</p>}
      {error && <p className="warn">{ERRORS[error] ?? "Something went wrong."}</p>}

      <div className="card">
        <h2>{pkg?.name ?? names[tenant.packageTier]} package</h2>
        <p>{pkg?.description}</p>
        <p style={{ color: "#5b6573" }}>Image storage used: {Math.round(usage.bytes / 1024)} KB of {Math.round(ent.maxMediaBytes / 1048576)} MB. Services you can list: {ent.maxServices}.</p>
      </div>

      <div className="card">
        <h2>What is included</h2>
        {GROUPS.map((g) => (
          <div key={g}><h3>{g}</h3>
            <ul style={{ listStyle: "none", padding: 0 }}>
              {FEATURES.filter((f) => f.group === g && f.kind === "flag").map((f) => {
                const on = Boolean(mine[f.key]);
                return (
                  <li key={f.key} style={{ padding: "2px 0", color: on ? undefined : "#8a93a0" }}>
                    {on ? "✓" : "✗"} {f.label}
                    {on && !f.implemented && <> <span className="tag">coming soon</span></>}
                    {!on && <> <small>(available from {availableFrom(f.key)})</small></>}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>

      <div className="card" id="billing">
        <h2>Billing</h2>
        {agreement ? (
          <p>Monthly fee: <strong>{formatTaka(effectiveMonthlyFee(agreement, todayUtc()))}</strong>{agreement.monthlyDiscount > 0 && <> (after a {formatTaka(agreement.monthlyDiscount)} discount{agreement.discountUntil ? ` until ${agreement.discountUntil}` : ""})</>}.
            Setup fee: {formatTaka(agreement.setupFee)}. Service started {agreement.serviceStart}.</p>
        ) : <p>Your agreement has not been recorded yet. Please contact your website provider.</p>}
        {invoices.length > 0 && (
          <table><thead><tr><th>Invoice</th><th>Due</th><th>Amount</th><th>Paid</th><th>Status</th></tr></thead><tbody>
            {invoices.map((i) => <tr key={i.number}><td>{i.number}<br /><small>{i.description}</small></td><td>{i.due_date}</td><td>{formatTaka(i.amount_bdt)}</td><td>{formatTaka(i.paid)}</td><td>{i.status}</td></tr>)}
          </tbody></table>
        )}
        <p style={{ color: "#5b6573" }}><small>Payments are recorded by your website provider after they confirm receipt.</small></p>
      </div>

      <div className="card" id="upgrade">
        <h2>Request an upgrade</h2>
        <form action={requestUpgradeAction}>
          <p><label>Package you are interested in<br /><select name="tier" defaultValue={String(Math.min(5, tenant.packageTier + 1))}>
            {[1, 2, 3, 4, 5].filter((t) => t !== tenant.packageTier).map((t) => <option key={t} value={t}>{names[t]}</option>)}</select></label></p>
          <p><label>Message<br /><textarea name="message" required minLength={5} maxLength={1000} rows={3} style={field} defaultValue="I would like to upgrade my package." /></label></p>
          <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Send upgrade request</button>
        </form>
        <p style={{ color: "#5b6573" }}><small>Your provider will contact you to agree the price. Your package only changes after they apply it.</small></p>
      </div>

      <div className="card" id="requests">
        <h2>Ask for support</h2>
        <form action={requestSupportAction}>
          <p><label>How can we help?<br /><textarea name="message" required minLength={5} maxLength={1000} rows={3} style={field} /></label></p>
          <button type="submit">Send support request</button>
        </form>
        {requests.length > 0 && (
          <><h3>Your recent requests</h3>
            <ul>{requests.map((r, i) => <li key={i}><strong>{r.kind === "upgrade" ? "Upgrade" : "Support"}</strong> <span className="tag">{r.status}</span> {new Date(r.created_at).toISOString().slice(0, 10)}: {r.message.slice(0, 120)}</li>)}</ul></>
        )}
      </div>
    </StoreShell>
  );
}

import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { Msg } from "../../../src/web/dashboard/bits";
import { getShopSettings } from "../../../src/shop/extras";
import { saveShopSettingsAction } from "../shop-actions";

export const dynamic = "force-dynamic";

export default async function ShopSettingsPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.products) return <StoreShell businessName={businessName} email={staff.email}><LockedCard title="Shop settings" text="Your package does not include the shop." /></StoreShell>;
  const s = await getShopSettings(pool);
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <h1>Shop settings</h1>
      <p className="lead">Delivery charge and the message customers see when they order. Payment is cash on delivery{ent.shop.cart ? "" : ", and customers send an order request that you confirm by phone"}.</p>
      <Msg error={error} notice={notice} />
      <form action={saveShopSettingsAction} className="card">
        <div className="ed-cols">
          <label>Delivery charge (taka)<span className="hint">Added to every checkout order. 0 = free.</span><input name="deliveryFee" inputMode="numeric" pattern="[0-9]*" defaultValue={String(s.delivery_fee_bdt)} disabled={!ent.shop.cart} /></label>
          <label>Free delivery over (taka)<span className="hint">Leave blank for no free-delivery offer.</span><input name="freeOver" inputMode="numeric" pattern="[0-9]*" defaultValue={s.free_delivery_over_bdt == null ? "" : String(s.free_delivery_over_bdt)} disabled={!ent.shop.cart} /></label>
        </div>
        {!ent.shop.cart && <p className="hint">Delivery charges apply to cart checkout, which is in higher packages.</p>}
        <label>Message shown to customers<span className="hint">For example: &quot;Delivery in 2 to 3 days. Pay cash when you receive the order.&quot;</span><textarea name="orderNote" rows={3} maxLength={300} defaultValue={s.order_note} /></label>
        <button className="btn" type="submit">Save</button>
      </form>
    </StoreShell>
  );
}

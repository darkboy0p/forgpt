import { headers } from "next/headers";
import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { runtime } from "../../../src/web/server";
import { dnsInstructions, listDomains, MAX_DOMAINS_PER_TENANT } from "../../../src/domains/service";
import { addDomainAction, checkDomainAction, checkRoutingAction, makePrimaryAction, removeDomainAction } from "../domain-actions";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  invalid_host: "That does not look like a domain name. Type something like www.myshop.com",
  reserved_host: "That name cannot be used as a website address.",
  host_taken: "That domain is already used by another website.",
  too_many_domains: `You can connect up to ${MAX_DOMAINS_PER_TENANT} domains. Remove one first.`,
  rate_limited: "Too many domains were added today. Please try again tomorrow.",
  not_found: "We could not find the proof record yet. DNS changes can take from a few minutes up to a few hours. Check again later.",
  dns_error: "The DNS lookup did not answer. Please try again in a minute.",
  too_soon: "Please wait about 10 seconds between checks.",
  is_primary: "This is your main domain. Choose another main domain first, then remove this one.",
  not_verified: "Only a verified domain can be made the main domain.",
  unknown_domain: "That domain was not found.",
  routing_no: "The domain is verified, but it does not point to your website yet. Follow the steps under \"Point your domain\" below.",
};
const NOTICES: Record<string, string> = { added: "Domain added. Now create the DNS records shown below.", verified: "Your domain is verified and live.", already: "This domain is already verified.", primary: "Main domain changed.", removed: "Domain removed.", routing_yes: "Your domain points to your website correctly.", routing_unknown: "We could not compare where your domain points. Please contact us." };

export default async function DomainPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string; open?: string }> }) {
  const { staff, businessName, tenant } = await requireStaff();
  const { error, notice, open } = await searchParams;
  const { env, control } = runtime();
  const ent = await entitlementsOf(tenant.packageTier);
  const domains = await listDomains(control, tenant.tenantId);
  const viewing = ((await headers()).get("host") ?? "").replace(/:\d+$/, "");
  const secure = env.APP_ENV !== "development";

  return (
    <StoreShell businessName={businessName} email={staff.email} inquiries={ent.inquiries}>
      <h1>Your domain names</h1>
      <p className="lead">Connect your own web address, like <strong>www.myshop.com</strong>. We keep your website running; you only add two small records at the company where you bought the domain.</p>
      {error && <p className="warn" role="alert">{ERRORS[error] ?? "Something went wrong."}</p>}
      {notice && NOTICES[notice] && <p className="ok" role="status">{NOTICES[notice]}</p>}

      {domains.map((d) => {
        const ins = dnsInstructions(env, d.hostname, d.verify_token);
        const live = d.status === "verified";
        return (
          <section className="card" key={d.hostname} id={`d-${d.hostname}`}>
            <h2 style={{ marginBottom: 6 }}>{d.hostname} {d.is_primary && <span className="chip">Main domain</span>} {live ? <span className="chip">Live</span> : <span className="chip warn">Waiting for DNS</span>}</h2>
            {live ? (
              <>
              <div style={{ margin: "0 0 12px" }}>
                <p style={{ margin: "0 0 8px" }}>{d.check_note === "points_yes" ? <span className="chip">Points to your website</span> : d.check_note === "points_no" ? <span className="chip bad">Not pointing yet</span> : <span className="chip off">Pointing not checked</span>}{" "}
                  <form action={checkRoutingAction} style={{ display: "inline" }}><input type="hidden" name="hostname" value={d.hostname} /><button type="submit" style={{ padding: "3px 10px", fontSize: ".82rem" }}>Check DNS</button></form></p>
                {d.check_note !== "points_yes" && (
                  <details className="card" style={{ background: "var(--d-bg)" }}><summary>Point your domain</summary>
                    <p>At your domain company, {ins.cnameTarget || ins.aRecord ? <>{ins.cnameTarget && <>add a <strong>CNAME</strong> for <code>www</code> to <code>{ins.cnameTarget}</code></>}{ins.cnameTarget && ins.aRecord && "; "}{ins.aRecord && <>add an <strong>A</strong> record for the plain name to <code>{ins.aRecord}</code></>}.</> : <>ask us for the address to point to.</>} It can take a few minutes up to a few hours. HTTPS (the padlock) is set up by the hosting platform once the domain points here.</p></details>
                )}
              </div>
              <p style={{ margin: "0 0 12px" }}>Your website opens at <a href={`${secure ? "https" : "http"}://${d.hostname}`} target="_blank" rel="noopener noreferrer">{d.hostname}</a>. The version with or without <code>www.</code> shows the same website.</p>
              </>
            ) : (
              <details className="card" open={open === d.hostname || domains.length === 1} style={{ background: "var(--d-bg)" }}>
                <summary>How to connect {d.hostname}</summary>
                <ol style={{ paddingLeft: 20 }}>
                  <li><strong>Prove it is yours.</strong> At your domain company, add this <strong>TXT</strong> record:
                    <div className="tbl-wrap"><table><thead><tr><th>Type</th><th>Name / Host</th><th>Value</th></tr></thead><tbody><tr><td>TXT</td><td><code>{ins.txtName}</code></td><td><code style={{ wordBreak: "break-all" }}>{ins.txtValue}</code></td></tr></tbody></table></div>
                    <p className="hint">Some companies want only the first part, <code>_agency-verify</code>, as the name.</p></li>
                  <li><strong>Point the domain to your website.</strong>{" "}
                    {ins.cnameTarget || ins.aRecord
                      ? <>For a name like <code>www.</code> add a <strong>CNAME</strong>{ins.cnameTarget && <> to <code>{ins.cnameTarget}</code></>}{ins.aRecord && <>; for the plain name add an <strong>A</strong> record to <code>{ins.aRecord}</code></>}.</>
                      : <>Ask us for the address to point to. We will send it on WhatsApp or phone.</>}</li>
                  <li>Press <strong>Check now</strong>. It can take a few minutes, sometimes a few hours, for the records to appear.</li>
                </ol>
                {d.check_note && <p className="hint">Last check{d.last_checked_at ? ` (${new Date(d.last_checked_at).toISOString().slice(0, 16).replace("T", " ")} UTC)` : ""}: {d.check_note === "dns_error" ? "the DNS lookup did not answer." : "the proof record was not found yet."}</p>}
                <form action={checkDomainAction}><input type="hidden" name="hostname" value={d.hostname} /><button className="btn" type="submit">Check now</button></form>
              </details>
            )}
            <div className="ed-tools">
              {live && !d.is_primary && <form action={makePrimaryAction}><input type="hidden" name="hostname" value={d.hostname} /><button type="submit">Make this the main domain</button></form>}
              {!d.is_primary && <form action={removeDomainAction}><input type="hidden" name="hostname" value={d.hostname} /><button type="submit" className="linkish">Remove</button></form>}
            </div>
          </section>
        );
      })}
      {domains.length === 0 && <p className="card">You have not connected a domain yet. You are currently viewing this site at <strong>{viewing}</strong>.</p>}

      {domains.length < MAX_DOMAINS_PER_TENANT && (
        <section className="card">
          <h2>Add a domain</h2>
          <form action={addDomainAction}>
            <label>Domain name<span className="hint">Type only the name, for example www.myshop.com. Do not include https://</span>
              <input name="hostname" required maxLength={253} placeholder="www.myshop.com" autoCapitalize="none" autoCorrect="off" spellCheck={false} style={{ maxWidth: 420 }} /></label>
            <button className="btn" type="submit">Add domain</button>
          </form>
          <p className="hint" style={{ marginTop: 12 }}>You do not have a domain yet? Buy one from any domain company, then come back here. Need help? Use <a href="/dashboard/package">My package</a> to contact us.</p>
        </section>
      )}
    </StoreShell>
  );
}

"use server";
import { redirect } from "next/navigation";
import { requireStaff } from "../../src/web/storeSession";
import { runtime } from "../../src/web/server";
import { normalizeHostname } from "../../src/tenancy/hostname";
import { addDomain, checkDomain, checkRouting, removeDomain, setPrimaryDomain } from "../../src/domains/service";

const host = (v: FormDataEntryValue | null) => normalizeHostname(typeof v === "string" ? v.slice(0, 300) : "") ?? "";
const back = (kind: "notice" | "error", code: string): never => redirect(`/dashboard/domain?${kind}=${code}`);

export async function addDomainAction(formData: FormData): Promise<void> {
  const { staff, tenant } = await requireStaff();
  const { env, control } = runtime();
  const raw = formData.get("hostname");
  const r = await addDomain(control, env, tenant.tenantId, typeof raw === "string" ? raw.slice(0, 300) : "", staff.email);
  if (!r.ok) back("error", r.error);
  else redirect(`/dashboard/domain?notice=added&open=${encodeURIComponent(r.hostname)}`);
}

export async function checkDomainAction(formData: FormData): Promise<void> {
  const { staff, tenant } = await requireStaff();
  const h = host(formData.get("hostname"));
  const r = await checkDomain(runtime().control, tenant.tenantId, h, staff.email);
  if (r.ok) back("notice", r.already ? "already" : "verified");
  else redirect(`/dashboard/domain?error=${r.error}&open=${encodeURIComponent(h)}`);
}

export async function makePrimaryAction(formData: FormData): Promise<void> {
  const { staff, tenant } = await requireStaff();
  const r = await setPrimaryDomain(runtime().control, tenant.tenantId, host(formData.get("hostname")), staff.email);
  r.ok ? back("notice", "primary") : back("error", r.error);
}

export async function removeDomainAction(formData: FormData): Promise<void> {
  const { staff, tenant } = await requireStaff();
  const r = await removeDomain(runtime().control, tenant.tenantId, host(formData.get("hostname")), staff.email);
  r.ok ? back("notice", "removed") : back("error", r.error);
}

/** Where does this (verified) domain point? The answer is saved and shown on the page. */
export async function checkRoutingAction(formData: FormData): Promise<void> {
  const { staff, tenant } = await requireStaff();
  const { control, env } = runtime();
  const h = host(formData.get("hostname"));
  const r = await checkRouting(control, env, tenant.tenantId, h, staff.email);
  r.ok ? back("notice", `routing_${r.report.points}`) : back("error", r.error);
}

import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { UpgradeNotice } from "../../../src/web/UpgradeNotice";
import { PACKAGE_NAMES } from "../../../src/config/templates";
import { entitlementsOf } from "../../../src/web/entitlements";
import { listInquiries } from "../../../src/store/inquiries";
import { markInquiryAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function InquiriesPage() {
  const { pool, staff, businessName, tenant } = await requireStaff();
  if (!(await entitlementsOf(tenant.packageTier)).inquiries) {
    // enforced on the server: the inbox data is never loaded for a package without inquiry forms
    return <StoreShell businessName={businessName} email={staff.email}><UpgradeNotice feature="Inquiry forms and the inquiry inbox" packageName={PACKAGE_NAMES[tenant.packageTier]} /></StoreShell>;
  }
  const items = await listInquiries(pool, 100);
  return (
    <StoreShell businessName={businessName} email={staff.email} inquiries>
      <h1>Inquiries</h1>
      <p style={{ color: "#5b6573" }}>Messages sent through the form on your website. You are not emailed yet, so check here regularly.</p>
      {items.map((i) => (
        <div className="card" key={i.id}>
          <p><strong>{i.name}</strong> <span className="tag">{i.status}</span> <small>{new Date(i.created_at).toISOString().replace("T", " ").slice(0, 16)} UTC</small></p>
          <p>{[i.phone, i.email].filter(Boolean).join(" · ")}</p>
          <p style={{ whiteSpace: "pre-wrap" }}>{i.message}</p>
          <form action={markInquiryAction}>
            <input type="hidden" name="id" value={i.id} /><input type="hidden" name="status" value={i.status === "new" ? "done" : "new"} />
            <button type="submit">{i.status === "new" ? "Mark as handled" : "Mark as new"}</button>
          </form>
        </div>
      ))}
      {items.length === 0 && <p className="card">No messages yet.</p>}
    </StoreShell>
  );
}

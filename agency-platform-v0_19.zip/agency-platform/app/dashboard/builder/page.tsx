import { requireStaff } from "../../../src/web/storeSession";
import { entitlementsOf } from "../../../src/web/entitlements";
import { loadEditorState } from "../../../src/store/siteEditor";
import { buildShopView } from "../../../src/shop/view";
import { Builder } from "../../../src/builder/Builder";
import { blockAllowed } from "../../../src/builder/rules";
import { blocksFromConfig } from "../../../src/builder/convert";
import { BLOCK_TYPES } from "../../../src/builder/schema";

export const dynamic = "force-dynamic";
export const metadata = { title: "Edit website" };

/** The visual editor. It opens full screen, without the dashboard menu, so the page has room. */
export default async function BuilderPage() {
  const { pool, businessName, tenant } = await requireStaff();
  const ent = await entitlementsOf(tenant.packageTier);
  const state = await loadEditorState(pool);
  const cfg = state.draft ?? state.live;
  const converted = !cfg.builder;
  const blocks = (cfg.builder?.blocks ?? blocksFromConfig(cfg, businessName)).filter((b) => blockAllowed(b.type, ent));
  const media = (await pool.query("SELECT id, filename FROM media WHERE kind <> 'product' ORDER BY created_at DESC LIMIT 100")).rows.map((r) => ({ id: r.id as string, name: r.filename as string }));
  const shopHome = await buildShopView(pool, ent, { page: "home" });
  return (
    <div className="dash">
      <div className="bld-mobile">
        <h1>Use a bigger screen</h1>
        <p>The visual editor needs a tablet or a computer. On a phone you can still change texts and colours in the settings page.</p>
        <p><a className="btn" href="/dashboard/editor">Open settings</a> <a className="btn ghost" href="/dashboard">Back to dashboard</a></p>
      </div>
      <Builder initial={blocks} converted={converted} published={Boolean(state.publishedAt)} businessName={businessName}
        theme={{ primary: cfg.theme.primary, accent: cfg.theme.accent, background: cfg.theme.background, text: cfg.theme.text, surface: cfg.theme.surface, font: cfg.theme.font }}
        allowed={BLOCK_TYPES.filter((t) => blockAllowed(t, ent))} canBrand={ent.branding} media={media}
        contact={{ phone: cfg.content.phone, whatsapp: cfg.content.whatsapp, address: cfg.content.address, email: cfg.content.email }} hours={cfg.hours}
        shopHome={shopHome} limits={{ services: ent.maxServices, testimonials: ent.maxTestimonials }} />
    </div>
  );
}

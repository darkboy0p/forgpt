import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { KIND_LIMITS, MAX_MEDIA_COUNT, listMedia, mediaUsage } from "../../../src/store/media";
import { uploadMediaAction, deleteMediaAction } from "../actions";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  invalid_kind: "Choose what the image is for.", not_in_package: "Gallery photos are not included in your package.", empty: "Choose an image file first.",
  too_large: "That image is too large. Logo: 300 KB, gallery photo: 800 KB, banner or About photo: 1 MB.", bad_type: "Only PNG, JPG and WebP images are accepted.",
  quota: "You have used all of your image storage. Delete an image you no longer use.", too_many: "You have reached the maximum number of images.",
  alt_required: "Describe the gallery photo in a few words.", not_found: "Image not found.", in_use: "That image is used on your website or in your saved draft. Remove it in the editor and publish first.",
};
const KIND_LABELS: Record<string, string> = { logo: "Logo", hero: "Banner photo", about: "About photo", gallery: "Gallery photo" };
const kb = (n: number) => `${Math.round(n / 1024)} KB`;

export default async function MediaPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  const [items, usage] = await Promise.all([listMedia(pool), mediaUsage(pool)]);
  return (
    <StoreShell businessName={businessName} email={staff.email} inquiries={ent.inquiries}>
      <h1>Images</h1>
      {error && <p className="warn">{ERRORS[error] ?? "Something went wrong."}</p>}
      {notice === "uploaded" && <p className="card">Image uploaded. Choose it in <a href="/dashboard/editor">Edit website</a>, then publish.</p>}
      {notice === "deleted" && <p className="card">Image deleted.</p>}
      <div className="card">
        <h2>Upload an image</h2>
        <form action={uploadMediaAction}>
          <p><label>What is it for?<br /><select name="kind" defaultValue="logo">
            {Object.entries(KIND_LABELS).filter(([k]) => k !== "gallery" || ent.gallery).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label></p>
          <p><label>Image file (PNG, JPG or WebP)<br /><input type="file" name="file" accept="image/png,image/jpeg,image/webp" required /></label></p>
          {ent.gallery && <p><label>Short description (required for gallery photos)<br /><input name="alt" maxLength={120} style={{ width: "100%", padding: 6 }} /></label></p>}
          <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Upload</button>
          <p style={{ color: "#5b6573" }}><small>Limits: logo {kb(KIND_LIMITS.logo)}, banner and About photo {kb(KIND_LIMITS.hero)}, gallery photo {kb(KIND_LIMITS.gallery)}. Storage used: {kb(usage.bytes)} of {kb(ent.maxMediaBytes)} ({usage.count} of {MAX_MEDIA_COUNT} images). Resize large photos first.</small></p>
        </form>
      </div>
      <div className="card">
        <h2>Your images ({items.length})</h2>
        <div className="grid">
          {items.map((m) => (
            <div key={m.id} style={{ border: "1px solid #e5e8ec", borderRadius: 8, padding: 10 }}>
              <img src={`/media/${m.id}`} alt={m.alt || m.filename} loading="lazy" style={{ width: "100%", height: 120, objectFit: "contain", background: "#f5f7fa" }} />
              <p style={{ margin: "8px 0 4px" }}><span className="tag">{KIND_LABELS[m.kind]}</span> <small>{kb(m.size_bytes)}</small></p>
              <p style={{ margin: 0, wordBreak: "break-all" }}><small>{m.filename}</small></p>
              <form action={deleteMediaAction} style={{ marginTop: 8 }}><input type="hidden" name="id" value={m.id} /><button type="submit">Delete</button></form>
            </div>
          ))}
          {items.length === 0 && <p>No images yet.</p>}
        </div>
      </div>
    </StoreShell>
  );
}

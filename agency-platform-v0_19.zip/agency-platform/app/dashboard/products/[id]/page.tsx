import { notFound } from "next/navigation";
import { requireStaff } from "../../../../src/web/storeSession";
import { StoreShell } from "../../../../src/web/StoreShell";
import { entitlementsOf } from "../../../../src/web/entitlements";
import { Msg } from "../../../../src/web/dashboard/bits";
import { ProductForm } from "../../../../src/web/dashboard/ProductForm";
import { getProductAdmin, listCategories } from "../../../../src/shop/products";

export const dynamic = "force-dynamic";

export default async function EditProduct({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { id } = await params;
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.products) notFound();
  const found = await getProductAdmin(pool, id);
  if (!found) notFound();
  const p = found.product;
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <p><a href="/dashboard/products">&larr; Products</a> {p.status !== "hidden" && <> &middot; <a href={`/products/${p.slug}`} target="_blank" rel="noopener">View in shop</a></>}</p>
      <h1>{p.name}</h1>
      <Msg error={error} notice={notice} />
      <ProductForm ent={ent} categories={ent.shop.categories ? await listCategories(pool) : []} data={{
        id: p.id, name: p.name, description: p.description, price: String(p.price_bdt), compare: p.compare_price_bdt == null ? "" : String(p.compare_price_bdt), sku: p.sku ?? "",
        status: p.status, categoryId: p.category_id ?? "", featured: p.is_featured, track: p.track_stock, stock: String(p.stock_qty), low: String(p.low_stock_at),
        variants: found.variants.map((v) => ({ label: v.label, price: v.price_bdt == null ? "" : String(v.price_bdt), stock: String(v.stock_qty) })), images: found.images,
      }} />
    </StoreShell>
  );
}

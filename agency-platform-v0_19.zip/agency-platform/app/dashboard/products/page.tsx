import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { Msg, Pager, Thumb, taka } from "../../../src/web/dashboard/bits";
import { STATUS_LABELS } from "../../../src/web/dashboard/shopMessages";
import { listCategories, listProductsAdmin, productCount } from "../../../src/shop/products";
import { lowStock } from "../../../src/shop/extras";
import { loadEditorState } from "../../../src/store/siteEditor";
import { quickStatusAction, showProductsOnHomeAction } from "../shop-actions";

export const dynamic = "force-dynamic";
type SP = { q?: string; status?: string; category?: string; page?: string; error?: string; notice?: string };

export default async function ProductsPage({ searchParams }: { searchParams: Promise<SP> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const sp = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.products) return <StoreShell businessName={businessName} email={staff.email}><LockedCard title="Products" text="Your package does not include the shop." /></StoreShell>;
  const [list, total, cats, low, state] = await Promise.all([listProductsAdmin(pool, { q: sp.q, status: sp.status, categoryId: sp.category, page: sp.page }), productCount(pool), ent.shop.categories ? listCategories(pool) : Promise.resolve([]), lowStock(pool, ent), loadEditorState(pool)]);
  const onHome = ((state.draft ?? state.live).sections as string[]).includes("products");
  const back = `/dashboard/products?${new URLSearchParams(Object.entries({ q: sp.q ?? "", status: sp.status ?? "", category: sp.category ?? "", page: sp.page ?? "" }).filter(([, v]) => v)).toString()}`;
  const q = (p: number) => `/dashboard/products?${new URLSearchParams({ ...(sp.q ? { q: sp.q } : {}), ...(sp.status ? { status: sp.status } : {}), ...(sp.category ? { category: sp.category } : {}), page: String(p) })}`;
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <div className="toolbar" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <div><h1>Products</h1><p className="lead" style={{ margin: 0 }}>{total} of {ent.shop.maxProducts} products used.</p></div>
        <a className="btn" href="/dashboard/products/new">Add product</a>
      </div>
      <Msg error={sp.error} notice={sp.notice} />
      {total > 0 && !onHome && (
        <form action={showProductsOnHomeAction} className="card"><strong>Show your products on the home page?</strong> <span className="hint">Your shop page is already in the menu. This also adds a Products section to your home page.</span> <button className="btn" type="submit">Show on home page</button></form>
      )}
      {low.length > 0 && (
        <div className="warn"><strong>Low stock:</strong> {low.slice(0, 8).map((r, i) => <span key={`${r.id}${r.variant}`}>{i > 0 && ", "}<a href={`/dashboard/products/${r.id}`}>{r.name}{r.variant ? ` (${r.variant})` : ""}</a> ({r.qty} left)</span>)}</div>
      )}
      {total === 0 ? (
        <section className="card empty"><h2>Add your first product</h2><p className="hint">Add a name, a price and a photo. It appears on your website straight away.</p><a className="btn" href="/dashboard/products/new">Add product</a></section>
      ) : (
        <>
          <form className="toolbar" method="get">
            <input type="search" name="q" defaultValue={sp.q ?? ""} placeholder="Search by name or code" aria-label="Search products" style={{ flex: "1 1 220px", width: "auto" }} />
            <select name="status" defaultValue={sp.status ?? ""} aria-label="Availability" style={{ width: "auto" }}><option value="">All</option><option value="active">Active</option><option value="sold_out">Sold out</option><option value="hidden">Hidden</option></select>
            {cats.length > 0 && <select name="category" defaultValue={sp.category ?? ""} aria-label="Category" style={{ width: "auto" }}><option value="">All categories</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>}
            <button className="btn ghost" type="submit">Filter</button>
          </form>
          <div className="tbl-wrap"><table>
            <thead><tr><th></th><th>Product</th><th className="num">Price</th><th>Status</th>{ent.shop.stockQty && <th className="num">Stock</th>}<th></th></tr></thead>
            <tbody>
              {list.rows.map((p) => {
                const stock = p.variant_count > 0 ? p.variant_stock : p.stock_qty;
                const next = p.status === "hidden" ? ["active", "Show"] : ["hidden", "Hide"];
                const sold = p.status === "sold_out" ? ["active", "Back in stock"] : ["sold_out", "Sold out"];
                return (
                  <tr key={p.id}>
                    <td><Thumb id={p.image_id} /></td>
                    <td><a href={`/dashboard/products/${p.id}`}><strong>{p.name}</strong></a><br /><small className="hint">{p.category_name ?? "No category"}{p.is_featured ? " · Featured" : ""}{p.variant_count > 0 ? ` · ${p.variant_count} options` : ""}</small></td>
                    <td className="num">{taka(p.price_bdt)}{p.compare_price_bdt && <><br /><small className="hint" style={{ textDecoration: "line-through" }}>{taka(p.compare_price_bdt)}</small></>}</td>
                    <td><span className={p.status === "active" ? "chip" : p.status === "hidden" ? "chip off" : "chip warn"}>{STATUS_LABELS[p.status]}</span></td>
                    {ent.shop.stockQty && <td className="num">{p.track_stock ? <span className={stock <= p.low_stock_at ? "chip warn" : ""}>{stock}</span> : <span className="hint">not counted</span>}</td>}
                    <td className="num">
                      <span style={{ display: "inline-flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
                        {[next, sold].map(([s, l]) => <form key={s} action={quickStatusAction} style={{ margin: 0 }}><input type="hidden" name="id" value={p.id} /><input type="hidden" name="status" value={s} /><input type="hidden" name="back" value={back} /><button type="submit" style={{ padding: "4px 10px", fontSize: ".8rem" }}>{l}</button></form>)}
                        <a className="btn ghost" style={{ padding: "4px 10px", fontSize: ".8rem" }} href={`/dashboard/products/${p.id}`}>Edit</a>
                      </span>
                    </td>
                  </tr>
                );
              })}
              {list.rows.length === 0 && <tr><td colSpan={6} className="hint">No product matches. Clear the search or filters.</td></tr>}
            </tbody>
          </table></div>
          <Pager page={list.page} pages={list.pages} href={q} />
        </>
      )}
    </StoreShell>
  );
}

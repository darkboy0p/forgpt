import { requireStaff } from "../../../../src/web/storeSession";
import { StoreShell } from "../../../../src/web/StoreShell";
import { entitlementsOf } from "../../../../src/web/entitlements";
import { LockedCard } from "../../../../src/web/LockedCard";
import { Msg } from "../../../../src/web/dashboard/bits";
import { EMPTY_PRODUCT, ProductForm } from "../../../../src/web/dashboard/ProductForm";
import { listCategories, productCount } from "../../../../src/shop/products";

export const dynamic = "force-dynamic";

export default async function NewProduct({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  const used = await productCount(pool);
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <p><a href="/dashboard/products">&larr; Products</a></p>
      <h1>Add product</h1>
      <Msg error={error} />
      {!ent.shop.products ? <LockedCard title="Products" text="Your package does not include the shop." />
        : used >= ent.shop.maxProducts ? <p className="warn">You have used all {ent.shop.maxProducts} products your package allows. <a href="/dashboard/package#upgrade">See packages</a></p>
        : <ProductForm ent={ent} data={EMPTY_PRODUCT} categories={ent.shop.categories ? await listCategories(pool) : []} />}
    </StoreShell>
  );
}

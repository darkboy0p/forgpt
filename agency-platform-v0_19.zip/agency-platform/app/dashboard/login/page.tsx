import { redirect } from "next/navigation";
import { currentStaffOrNull } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { storeLoginAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function StoreLogin({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { ctx, staff } = await currentStaffOrNull();
  if (staff) redirect("/dashboard");
  const { error } = await searchParams;
  return (
    <StoreShell businessName={ctx.businessName}>
      <div style={{ maxWidth: 420 }}>
        <h1>Log in</h1>
        {error === "1" && <p className="warn">Incorrect email or password.</p>}
        {error === "2" && <p className="warn">Too many attempts. Please wait 15 minutes and try again.</p>}
        <form action={storeLoginAction} className="card">
          <p><label>Email<br /><input name="email" type="email" required autoComplete="username" maxLength={254} style={{ width: "100%", padding: 8 }} /></label></p>
          <p><label>Password<br /><input name="password" type="password" required autoComplete="current-password" maxLength={1000} style={{ width: "100%", padding: 8 }} /></label></p>
          <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Log in</button>
        </form>
        <p style={{ color: "#5b6573" }}>Forgot your password? Contact your website provider.</p>
      </div>
    </StoreShell>
  );
}

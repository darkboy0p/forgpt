import { requireStaff } from "../../../src/web/storeSession";
import { loadEditorState } from "../../../src/store/siteEditor";
import { applyEntitlements } from "../../../src/config/entitlements";
import { entitlementsOf } from "../../../src/web/entitlements";
import { TemplateSite } from "../../../src/web/renderSite";
import { buildShopView } from "../../../src/shop/view";
import { isPageKey, type PageKey } from "../../../src/web/templates/pages";
import { listMedia } from "../../../src/store/media";

export const dynamic = "force-dynamic";

export default async function PreviewPage({ searchParams }: { searchParams: Promise<{ page?: string; embed?: string }> }) {
  const { pool, businessName, tenant } = await requireStaff();
  const { page: pageParam, embed } = await searchParams;
  const embedded = embed === "1";
  const qs = (p: string) => `/dashboard/preview?page=${p}${embedded ? "&embed=1" : ""}`;
  const state = await loadEditorState(pool);
  const config = applyEntitlements(state.draft ?? state.live, await entitlementsOf(tenant.packageTier));
  const alts = Object.fromEntries((await listMedia(pool)).map((m) => [m.id, m.alt]));
  const page: PageKey = pageParam && isPageKey(pageParam) ? pageParam : "home";
  const ent = await entitlementsOf(tenant.packageTier);
  const shop = await buildShopView(pool, ent, { page });
  return (
    <div>
      <meta name="robots" content="noindex" />
      {!embedded && (
        <div className="warn" style={{ textAlign: "center", borderRadius: 0 }}>
          Preview of your {state.draft ? "saved draft" : "published website"}. This is not live. <a href="/dashboard/editor">Back to editor</a>
        </div>
      )}
      <TemplateSite templateKey={tenant.templateKey} businessName={businessName} config={config} page={page} interactive={false} galleryAlts={alts} linkFor={qs} shop={shop} productHref={() => "#"} />
    </div>
  );
}

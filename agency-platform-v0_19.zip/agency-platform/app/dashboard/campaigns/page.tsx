import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { Msg } from "../../../src/web/dashboard/bits";
import { listCampaigns } from "../../../src/shop/campaigns";
import { listCategories } from "../../../src/shop/products";
import { createCampaignAction, deleteCampaignAction, toggleCampaignAction } from "../shop-actions";

export const dynamic = "force-dynamic";

export default async function CampaignsPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.campaigns) return <StoreShell businessName={businessName} email={staff.email}><h1>Campaigns</h1><LockedCard title="Promotional campaigns" text="Run a sale such as Eid 15% off, on everything or one category, with start and end dates. Prices change by themselves." /></StoreShell>;
  const [list, cats] = await Promise.all([listCampaigns(pool), listCategories(pool)]);
  const today = new Date().toISOString().slice(0, 10);
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <h1>Campaigns</h1>
      <p className="lead">A campaign lowers prices automatically between two dates. Customers see the new price, the old price crossed out and a percent badge. If several campaigns match a product, the biggest discount is used. Dates are in UTC.</p>
      <Msg error={error} notice={notice} />
      <section className="card">
        <h2>New campaign</h2>
        <form action={createCampaignAction}>
          <div className="ed-cols">
            <label>Name<input name="name" required minLength={2} maxLength={60} placeholder="Eid sale" /></label>
            <label>Percent off<input name="percent" required inputMode="numeric" pattern="[0-9]+" placeholder="15" /></label>
            <label>Applies to<select name="appliesTo" defaultValue="all"><option value="all">All products</option>{cats.length > 0 && <option value="category">One category</option>}</select></label>
            {cats.length > 0 && <label>Category (if one category)<select name="categoryId" defaultValue="">{<option value="">Choose...</option>}{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>}
            <label>First day<input name="startsOn" type="date" required defaultValue={today} /></label>
            <label>Last day<input name="endsOn" type="date" required /></label>
          </div>
          <button className="btn" type="submit">Create campaign</button>
        </form>
      </section>
      <div className="tbl-wrap"><table>
        <thead><tr><th>Campaign</th><th>Discount</th><th>Dates</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {list.map((c) => (
            <tr key={c.id}>
              <td><strong>{c.name}</strong><br /><small className="hint">{c.applies_to === "all" ? "All products" : `Category: ${c.category_name}`}</small></td>
              <td>{c.percent}% off</td>
              <td>{c.starts_on} to {c.ends_on}</td>
              <td>{c.running ? <span className="chip">Running now</span> : !c.is_active ? <span className="chip off">Off</span> : c.ends_on < today ? <span className="chip off">Finished</span> : <span className="chip warn">Starts {c.starts_on}</span>}</td>
              <td className="num"><span style={{ display: "inline-flex", gap: 6 }}>
                <form action={toggleCampaignAction}><input type="hidden" name="id" value={c.id} /><input type="hidden" name="active" value={c.is_active ? "0" : "1"} /><button type="submit" style={{ padding: "4px 10px", fontSize: ".8rem" }}>{c.is_active ? "Turn off" : "Turn on"}</button></form>
                <form action={deleteCampaignAction}><input type="hidden" name="id" value={c.id} /><button type="submit" className="linkish">Delete</button></form></span></td>
            </tr>
          ))}
          {list.length === 0 && <tr><td colSpan={5} className="hint">No campaigns yet.</td></tr>}
        </tbody>
      </table></div>
    </StoreShell>
  );
}

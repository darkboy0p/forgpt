import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { entitlementsOf } from "../../../src/web/entitlements";
import { LockedCard } from "../../../src/web/LockedCard";
import { Msg } from "../../../src/web/dashboard/bits";
import { listCategories } from "../../../src/shop/products";
import { createCategoryAction, deleteCategoryAction, updateCategoryAction } from "../shop-actions";

export const dynamic = "force-dynamic";

export default async function CategoriesPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error, notice } = await searchParams;
  const ent = await entitlementsOf(tenant.packageTier);
  if (!ent.shop.categories) return <StoreShell businessName={businessName} email={staff.email}><LockedCard title="Categories" text="Group your products into categories that visitors can filter by." /></StoreShell>;
  const cats = await listCategories(pool);
  return (
    <StoreShell businessName={businessName} email={staff.email}>
      <h1>Categories</h1>
      <p className="lead">Groups such as Men, Women or Electronics. Visitors can filter the shop by category. Lower numbers appear first.</p>
      <Msg error={error} notice={notice} />
      <section className="card">
        <h2>Add a category</h2>
        <form action={createCategoryAction} className="toolbar"><input name="name" required minLength={2} maxLength={60} placeholder="For example: Shirts" aria-label="Category name" style={{ flex: "1 1 240px", width: "auto" }} /><button className="btn" type="submit">Add</button></form>
      </section>
      {cats.map((c) => (
        <section className="card" key={c.id}>
          <form action={updateCategoryAction} className="toolbar" style={{ alignItems: "end" }}>
            <input type="hidden" name="id" value={c.id} />
            <label style={{ margin: 0, flex: "1 1 220px" }}>Name<input name="name" defaultValue={c.name} required minLength={2} maxLength={60} /></label>
            <label style={{ margin: 0, width: 90 }}>Order<input name="sortOrder" inputMode="numeric" defaultValue={c.sort_order} /></label>
            <label style={{ margin: 0, fontWeight: 400 }}><input type="checkbox" name="isVisible" defaultChecked={c.is_visible} />Shown in shop</label>
            <button className="btn ghost" type="submit">Save</button>
            <span className="hint">{c.count} products</span>
          </form>
          <form action={deleteCategoryAction} style={{ marginTop: 8 }}><input type="hidden" name="id" value={c.id} /><button type="submit" className="linkish">Delete (products stay, without a category)</button></form>
        </section>
      ))}
      {cats.length === 0 && <p className="hint">No categories yet.</p>}
    </StoreShell>
  );
}

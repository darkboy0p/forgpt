import { headers } from "next/headers";
import { ColourFields } from "../../../src/web/ColourFields";
import { EditorTabs } from "../../../src/web/EditorTabs";
import { EditorSplit } from "../../../src/web/EditorSplit";
import { SeoFields } from "../../../src/web/SeoFields";
import { requireStaff } from "../../../src/web/storeSession";
import { StoreShell } from "../../../src/web/StoreShell";
import { loadEditorState } from "../../../src/store/siteEditor";
import { entitlementsOf } from "../../../src/web/entitlements";
import { applyEntitlements } from "../../../src/config/entitlements";
import { PAGE_LABELS, starterPages, visiblePages } from "../../../src/web/templates/pages";
import { STYLABLE_SECTIONS } from "../../../src/config/siteConfig";
import { SectionOrder } from "../../../src/web/SectionOrder";
import { LayoutPresets } from "../../../src/web/LayoutPresets";
import { LockedCard } from "../../../src/web/LockedCard";
import { LAYOUT_GROUPS, LAYOUT_PRESETS } from "../../../src/web/layoutFields";
import { BUTTON_STYLES, DAYS, DAY_LABELS, FONTS, MAX_FAQS, MAX_HIGHLIGHTS, PROMO_STYLES, TITLE_KEYS, SECTION_KEYS, SOCIAL_KEYS, SOCIAL_LABELS } from "../../../src/config/siteConfig";
import { listMedia } from "../../../src/store/media";
import { saveDraftAction, saveAndPublishAction, discardDraftAction } from "../actions";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  invalid_color: "Choose a valid colour.", invalid_contact: "Phone may contain digits, + and - only. WhatsApp must be digits with the country code, for example 8801700000000.",
  too_long: "One of the texts is too long.", no_sections: "Show at least one section.", invalid: "Please check the form.",
  no_draft: "There is no saved draft to publish.", invalid_draft: "The saved draft is not valid. Save it again.",
  not_in_package: "Something in your changes is not included in your package. Contact your provider to upgrade.",
  invalid_choice: "One of the style choices is not valid.", invalid_analytics: "The Google Analytics ID must look like G-XXXXXXXXXX.",
  incomplete_row: "A service or review has text but no name. Add the name or clear the row.",
  invalid_social: "Social links must be full https:// addresses of the matching network, for example https://www.facebook.com/yourpage.",
  invalid_media: "One of the chosen images is not available. Upload it again on the Images page.",
  low_contrast: "Your text colour and background colour are too similar to read. Pick colours with more contrast.",
  invalid_link: "A link must be a full https:// address, a phone link like tel:+8801700000000, or a page of your site such as /contact.", invalid_date: "Choose a valid end date for the banner.",
};
const NOTICES: Record<string, string> = { saved: "Draft saved. Visitors still see your published website until you publish.", discarded: "Unpublished changes were discarded." };
const SECTION_LABELS: Record<string, string> = { hero: "Top banner", highlights: "Why choose us", about: "About us", services: "Services", gallery: "Photo gallery", testimonials: "Customer reviews", faq: "Questions and answers", inquiry: "Inquiry / quote form", contact: "Contact" };
const FONT_LABELS: Record<string, string> = { sans: "Modern (sans-serif)", serif: "Classic (serif)", rounded: "Friendly (rounded)" };
const BUTTON_LABELS: Record<string, string> = { rounded: "Rounded", square: "Square", pill: "Pill" };
const TITLE_DEFAULTS: Record<string, string> = { highlights: "Why choose us", about: "About us", services: "Our services", gallery: "Gallery", testimonials: "What customers say", faq: "Frequently asked questions", inquiry: "Request a quote or ask a question", contact: "Contact" };
const PROMO_LABELS: Record<string, string> = { accent: "Accent colour", primary: "Main colour", dark: "Dark" };

export default async function EditorPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const { error, notice } = await searchParams;
  const host = (await headers()).get("host") ?? "";
  const ent = await entitlementsOf(tenant.packageTier);
  const state = await loadEditorState(pool);
  const media = await listMedia(pool);
  const cfg = state.draft ?? state.live;
  const c = cfg.content;
  const svcRows = Array.from({ length: ent.maxServices }, (_, i) => c.services[i] ?? { name: "", description: "", price: "" });
  const tmRows = Array.from({ length: ent.maxTestimonials }, (_, i) => c.testimonials[i] ?? { name: "", quote: "" });
  const sections = SECTION_KEYS.filter((k) => ent.sections.includes(k));
  const hlRows = Array.from({ length: MAX_HIGHLIGHTS }, (_, i) => c.highlights[i] ?? { title: "", text: "" });
  const faqRows = Array.from({ length: MAX_FAQS }, (_, i) => c.faqs[i] ?? { question: "", answer: "" });
  const pr = cfg.promo;
  const shown = applyEntitlements(cfg, ent);
  const pageList = (tenant.templateKey === "professional" ? visiblePages(shown) : starterPages(shown)).map((k) => ({ key: k, label: PAGE_LABELS[k] }));
  const galleryMedia = media.filter((m) => m.kind === "gallery");
  const shownKeys = cfg.sections as string[];
  const orderItems = [...shownKeys.filter((k) => sections.includes(k as never)), ...sections.filter((k) => !shownKeys.includes(k))].map((k) => ({ key: k, label: SECTION_LABELS[k] ?? k, shown: shownKeys.includes(k) }));
  return (
    <StoreShell businessName={businessName} email={staff.email} inquiries={ent.inquiries}>
      <h1>Edit website</h1>
      <p className="lead">Change anything below, then press <strong>Save and publish</strong> to make it live. <strong>Save draft</strong> keeps your changes private so you can check them first.</p>
      {error && <p className="warn" role="alert">{ERRORS[error] ?? "Something went wrong."}</p>}
      {notice && NOTICES[notice] && <p className="ok" role="status">{NOTICES[notice]}</p>}

      <EditorSplit pages={pageList}>
      <div className="ed">
        <EditorTabs tabs={[{ id: "design", label: "Design" }, { id: "content", label: "Content" }, { id: "contact", label: "Contact and hours" }, { id: "sections", label: "Sections and order" }, { id: "settings", label: "Search and statistics" }]} />

        <form id="editor-form" className="ed-form" data-active="design">
          <section id="style" data-tab="design" className="card ed-section">
            <header><h2>Colours, font and buttons</h2><p className="hint">Pick colours that match your logo. Or start from a ready-made look on the <a href="/dashboard/themes">Themes</a> page.</p></header>
            {ent.branding
              ? <ColourFields initial={{ primary: cfg.theme.primary, accent: cfg.theme.accent, background: cfg.theme.background, text: cfg.theme.text, surface: cfg.theme.surface }} />
              : <div className="ed-colour"><label>Main colour<input name="primary" type="color" defaultValue={cfg.theme.primary} /></label></div>}
            {ent.branding && (
              <div className="ed-cols" style={{ marginTop: 14 }}>
                <label>Font<select name="font" defaultValue={cfg.theme.font}>{FONTS.map((f) => <option key={f} value={f}>{FONT_LABELS[f]}</option>)}</select></label>
                <label>Buttons<select name="buttonStyle" defaultValue={cfg.theme.buttonStyle}>{BUTTON_STYLES.map((f) => <option key={f} value={f}>{BUTTON_LABELS[f]}</option>)}</select></label>
              </div>
            )}
          </section>

          {ent.layout ? (
            <section id="layout" data-tab="design" className="card ed-section">
              <header><h2>Layout</h2><p className="hint">How your pages are arranged. Check the result with Preview saved draft.</p></header>
              <LayoutPresets presets={LAYOUT_PRESETS} />
              {LAYOUT_GROUPS.map((g) => (
                <div key={g.title}>
                  <h3 className="ed-group">{g.title}</h3><p className="hint">{g.hint}</p>
                  <div className="ed-cols">
                    {g.fields.map((f) => (
                      <label key={f.key}>{f.label}
                        <select name={f.key} defaultValue={cfg.layout[f.key]}>{f.options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </section>
          ) : <LockedCard id="layout" tab="design" title="Layout options" text="Choose how your banner, services, reviews, cards, spacing and footer look. Your package keeps the standard layout." />}

          {ent.promo ? (
            <section id="promo" data-tab="content" className="card ed-section">
              <header><h2>Announcement banner</h2><p className="hint">A thin bar above your menu for an offer or notice, such as &quot;Eid sale: 10% off until Friday&quot;. Leave the message blank to hide it.</p></header>
              <label>Message<input name="promo_text" maxLength={140} defaultValue={pr.text ?? ""} placeholder="Eid sale: 10% off all services" /></label>
              <div className="ed-cols">
                <label>Button text<input name="promo_linkLabel" maxLength={30} defaultValue={pr.linkLabel ?? ""} placeholder="See offer" /></label>
                <label>Button link<input name="promo_linkUrl" maxLength={300} defaultValue={pr.linkUrl ?? ""} placeholder="/contact or https://..." /></label>
                <label>Hide after this date (optional)<input name="promo_until" type="date" defaultValue={pr.until ?? ""} /></label>
                <label>Colour<select name="promo_style" defaultValue={pr.style}>{PROMO_STYLES.map((v) => <option key={v} value={v}>{PROMO_LABELS[v]}</option>)}</select></label>
              </div>
            </section>
          ) : <LockedCard id="promo" tab="content" title="Announcement banner" text="Show an offer or notice in a bar at the top of every page, and have it switch off by itself on a date you choose." />}

          {ent.layout && (
            <section id="headings" data-tab="content" className="card ed-section">
              <header><h2>Headings and main button</h2><p className="hint">Use your own words for the section headings, and add a main button to the top banner. Leave a box blank to use the standard wording.</p></header>
              <div className="ed-cols">
                <label>Main button text<input name="cta_label" maxLength={30} defaultValue={c.cta.label ?? ""} placeholder="Order now" /></label>
                <label>Main button link<span className="hint">https://..., tel:+880..., or /contact</span><input name="cta_url" maxLength={300} defaultValue={c.cta.url ?? ""} placeholder="/contact" /></label>
              </div>
              <h3 className="ed-group">Section headings</h3>
              <div className="ed-cols">
                {TITLE_KEYS.map((k) => <label key={k}>{SECTION_LABELS[k] ?? k}<input name={`title_${k}`} maxLength={40} defaultValue={c.sectionTitles[k] ?? ""} placeholder={TITLE_DEFAULTS[k]} /></label>)}
              </div>
            </section>
          )}

          <section id="text" data-tab="content" className="card ed-section">
            <header><h2>Text</h2><p className="hint">The first words visitors read.</p></header>
            <label>Main headline<input name="heroTitle" maxLength={120} defaultValue={c.heroTitle ?? ""} placeholder="For example: Fresh sweets, delivered in Dhaka" /></label>
            <label>Sub-headline<input name="heroSubtitle" maxLength={240} defaultValue={c.heroSubtitle ?? ""} placeholder="One short line about what you offer" /></label>
            <label>About your business<textarea name="about" rows={5} maxLength={2000} defaultValue={c.about ?? ""} placeholder="Who you are, what you sell, and why customers trust you" /></label>
          </section>

          {ent.advancedSections ? (
            <section id="highlights" data-tab="content" className="card ed-section">
              <header><h2>Why choose us (up to {MAX_HIGHLIGHTS})</h2><p className="hint">Short selling points, for example &quot;Free delivery in Dhaka&quot;. Add the section on the order list below to show it.</p></header>
              {hlRows.map((r, i) => (
                <div className="ed-row two" key={i}>
                  <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>Title</span><input name={`hl_title_${i}`} maxLength={60} defaultValue={r.title} /></label>
                  <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>One short sentence</span><input name={`hl_text_${i}`} maxLength={160} defaultValue={r.text} /></label>
                </div>
              ))}
            </section>
          ) : <LockedCard id="highlights" tab="content" title="Why choose us" text="Add up to 6 selling points as a section on your home page." />}

          <section id="contact" data-tab="contact" className="card ed-section">
            <header><h2>Contact</h2><p className="hint">Customers use these to reach you. The WhatsApp number adds a chat button to your site.</p></header>
            <div className="ed-cols">
              <label>Phone<input name="phone" type="tel" inputMode="tel" maxLength={20} defaultValue={c.phone ?? ""} placeholder="01700000000" /></label>
              <label>WhatsApp number<span className="hint">Digits with country code, for example 8801700000000</span><input name="whatsapp" inputMode="numeric" maxLength={15} defaultValue={c.whatsapp ?? ""} /></label>
            </div>
            <label>Address<input name="address" maxLength={200} defaultValue={c.address ?? ""} placeholder="Shop, road, area, city" /></label>
            <label>Public email (optional)<input name="email" type="email" maxLength={254} defaultValue={c.email ?? ""} /></label>
          </section>

          <section id="hours" data-tab="contact" className="card ed-section">
            <header><h2>Opening hours</h2><p className="hint">For example &quot;9:00 AM - 6:00 PM&quot; or &quot;Closed&quot;. Leave a day blank to hide it.</p></header>
            <div className="ed-cols">
              {DAYS.map((d) => <label key={d}>{DAY_LABELS[d]}<input name={`hours_${d}`} maxLength={40} defaultValue={cfg.hours[d] ?? ""} placeholder="9:00 AM - 6:00 PM" /></label>)}
            </div>
          </section>

          <section id="social" data-tab="contact" className="card ed-section">
            <header><h2>Social media links</h2><p className="hint">Full https:// addresses. Leave blank to hide.</p></header>
            <div className="ed-cols">
              {SOCIAL_KEYS.map((k) => <label key={k}>{SOCIAL_LABELS[k]}<input name={`social_${k}`} type="url" inputMode="url" maxLength={250} defaultValue={cfg.social[k] ?? ""} placeholder="https://" /></label>)}
            </div>
          </section>

          <section id="seo" data-tab="settings" className="card ed-section">
            <header><h2>Google search appearance</h2><p className="hint">What people see when your website shows up in Google.</p></header>
            <SeoFields businessName={businessName} address={host} initialTitle={cfg.seo.title ?? ""} initialDescription={cfg.seo.description ?? ""} fallbackDescription={(c.about ?? c.heroSubtitle ?? "").replace(/\s+/g, " ")} />
            {ent.seoExpanded ? (
              <>
                <label>Picture shown when your link is shared
                  <span className="hint">Used on WhatsApp, Facebook and similar. Leave on &quot;Automatic&quot; to use your banner photo.</span>
                  <select name="seoShareImage" defaultValue={cfg.seo.shareImage ?? ""}>
                    <option value="">Automatic (banner photo)</option>
                    {media.map((m) => <option key={m.id} value={m.id}>{m.filename}</option>)}
                  </select>
                </label>
                <label style={{ fontWeight: 400 }}><input type="checkbox" name="seoNoindex" defaultChecked={Boolean(cfg.seo.noindex)} />Ask Google not to show my website in search results
                  <span className="hint" style={{ marginLeft: 26 }}>Useful while you are still building. Turn it off when you are ready to be found. Visitors with your address can still open the site.</span>
                </label>
              </>
            ) : (
              <p className="hint">Choosing the picture shown when your link is shared, and hiding your website from Google while you build it, are available in higher packages. <a href="/dashboard/package#upgrade">See packages</a></p>
            )}
          </section>

          <section id="images" data-tab="content" className="card ed-section">
            <header><h2>Images</h2><p className="hint">Upload pictures on the <a href="/dashboard/media">Images page</a>, then choose them here.</p></header>
            <div className="ed-cols">
              {(["logo", "hero", "about"] as const).map((kind) => (
                <label key={kind}>{{ logo: "Logo", hero: "Banner photo", about: "About photo" }[kind]}
                  <select name={`img_${kind}`} defaultValue={cfg.images[kind] ?? ""}>
                    <option value="">None</option>
                    {media.filter((m) => m.kind === kind).map((m) => <option key={m.id} value={m.id}>{m.filename} ({Math.round(m.size_bytes / 1024)} KB)</option>)}
                  </select></label>
              ))}
            </div>
            {ent.gallery && (
              <div>
                <p style={{ fontWeight: 600, margin: "4px 0 8px" }}>Gallery photos <span className="hint" style={{ display: "inline" }}>(tick the ones to show)</span></p>
                {galleryMedia.map((m) => (
                  <label key={m.id} style={{ fontWeight: 400, marginBottom: 8 }}><input type="checkbox" name={`gallery_${m.id}`} defaultChecked={cfg.images.gallery.includes(m.id)} />{m.filename} &mdash; {m.alt}</label>
                ))}
                {galleryMedia.length === 0 && <p className="hint">No gallery photos uploaded yet. <a href="/dashboard/media">Upload photos</a></p>}
              </div>
            )}
          </section>

          <section id="services" data-tab="content" className="card ed-section">
            <header><h2>Services (up to {ent.maxServices})</h2><p className="hint">Fill in as many rows as you need. Rows with a blank name are not shown.</p></header>
            {svcRows.map((r, i) => (
              <div className="ed-row" key={i}>
                <label style={{ margin: 0 }}>{i === 0 ? "Name" : <span className="hint" style={{ margin: 0 }}>Name</span>}<input name={`svc_name_${i}`} maxLength={80} defaultValue={r.name} /></label>
                <label style={{ margin: 0 }}>{i === 0 ? "Description" : <span className="hint" style={{ margin: 0 }}>Description</span>}<input name={`svc_description_${i}`} maxLength={300} defaultValue={r.description} /></label>
                <label style={{ margin: 0 }}>{i === 0 ? "Price" : <span className="hint" style={{ margin: 0 }}>Price</span>}<input name={`svc_price_${i}`} maxLength={40} defaultValue={r.price} placeholder="৳500" /></label>
              </div>
            ))}
          </section>

          {ent.maxTestimonials > 0 && (
            <section id="reviews" data-tab="content" className="card ed-section">
              <header><h2>Customer reviews (up to {ent.maxTestimonials})</h2><p className="hint">Only add real reviews from your customers.</p></header>
              {tmRows.map((r, i) => (
                <div className="ed-row two" key={i}>
                  <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>Customer name</span><input name={`tm_name_${i}`} maxLength={60} defaultValue={r.name} /></label>
                  <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>What they said</span><input name={`tm_quote_${i}`} maxLength={400} defaultValue={r.quote} /></label>
                </div>
              ))}
            </section>
          )}

          {ent.advancedSections ? (
            <section id="faq" data-tab="content" className="card ed-section">
              <header><h2>Questions and answers (up to {MAX_FAQS})</h2><p className="hint">Answer what customers ask most. Add the section on the order list below to show it.</p></header>
              {faqRows.map((r, i) => (
                <div className="ed-row two" key={i}>
                  <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>Question</span><input name={`faq_question_${i}`} maxLength={120} defaultValue={r.question} /></label>
                  <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>Answer</span><textarea name={`faq_answer_${i}`} rows={2} maxLength={600} defaultValue={r.answer} /></label>
                </div>
              ))}
            </section>
          ) : <LockedCard id="faq" tab="content" title="Questions and answers" text="Add up to 10 common questions with answers that open and close on your home page." />}

          <section id="order" data-tab="sections" className="card ed-section">
            <header><h2>Sections and order</h2><p className="hint">Tick the sections you want to show, then use the arrows to move them. The top one appears first on your home page.</p></header>
            <SectionOrder initial={orderItems} />
          </section>

          {(ent.sectionColours || ent.sectionLayout) ? (
            <section id="designer" data-tab="sections" className="card ed-section">
              <header><h2>Section designer</h2><p className="hint">Give each section of your home page its own look. Leave a box unticked to follow your site-wide colours and spacing.{!ent.sectionColours && " Section colours are not in your package."}{!ent.sectionLayout && " Section alignment and spacing are not in your package."}</p></header>
              <input type="hidden" name="ss_marker" value="1" />
              <div className="tbl-wrap"><table className="designer">
                <thead><tr><th>Section</th>{ent.sectionColours && <><th>Background</th><th>Text colour</th></>}{ent.sectionLayout && <><th>Align</th><th>Spacing</th></>}</tr></thead>
                <tbody>
                  {STYLABLE_SECTIONS.filter((k) => sections.includes(k as never)).map((k) => {
                    const st = cfg.sectionStyles[k as keyof typeof cfg.sectionStyles] ?? {};
                    return (
                      <tr key={k}>
                        <td><strong>{SECTION_LABELS[k] ?? k}</strong></td>
                        {ent.sectionColours && <>
                          <td><label><input type="checkbox" name={`ss_${k}_bgOn`} defaultChecked={Boolean(st.background)} aria-label={`Custom background for ${SECTION_LABELS[k] ?? k}`} /><input type="color" name={`ss_${k}_bg`} defaultValue={st.background ?? cfg.theme.surface} /></label></td>
                          <td><label><input type="checkbox" name={`ss_${k}_textOn`} defaultChecked={Boolean(st.text)} aria-label={`Custom text colour for ${SECTION_LABELS[k] ?? k}`} /><input type="color" name={`ss_${k}_text`} defaultValue={st.text ?? cfg.theme.text} /></label></td>
                        </>}
                        {ent.sectionLayout && <>
                          <td><select name={`ss_${k}_align`} defaultValue={st.align ?? ""}><option value="">Site default</option><option value="left">Left</option><option value="center">Centred</option></select></td>
                          <td><select name={`ss_${k}_spacing`} defaultValue={st.spacing ?? ""}><option value="">Site default</option><option value="compact">Compact</option><option value="comfortable">Comfortable</option><option value="airy">Roomy</option></select></td>
                        </>}
                      </tr>
                    );
                  })}
                </tbody>
              </table></div>
              <p className="hint">Text and background must stay readable; very similar colours cannot be saved.</p>
            </section>
          ) : <LockedCard id="designer" tab="sections" title="Section designer" text="Give each section its own background colour, text colour, alignment and spacing." />}

          {ent.analytics && (
            <section id="stats" data-tab="settings" className="card ed-section">
              <header><h2>Visitor statistics (optional)</h2></header>
              <label>Google Analytics ID<span className="hint">Looks like G-XXXXXXXXXX</span><input name="ga4" maxLength={20} defaultValue={cfg.analytics.ga4 ?? ""} style={{ maxWidth: 260 }} /></label>
              <p className="hint">Adding this loads Google&apos;s tracking script for your visitors. You are responsible for telling visitors, as local rules require.</p>
            </section>
          )}

          <div className="ed-bar">
            <div className="inner">
              <span className="status">{state.hasUnpublishedChanges ? <b>Saved changes are not live yet.</b> : "No unpublished changes."}</span>
              {state.draft && <button type="submit" form="discard-form" className="linkish">Discard unpublished changes</button>}
              <a className="btn ghost" href="/dashboard/preview" target="_blank" rel="noopener">Preview saved draft</a>
              <button className="btn ghost" formAction={saveDraftAction} type="submit">Save draft</button>
              <button className="btn" formAction={saveAndPublishAction} type="submit">Save and publish</button>
            </div>
          </div>
        </form>
      </div>
      </EditorSplit>
      <form id="discard-form" action={discardDraftAction} />
    </StoreShell>
  );
}

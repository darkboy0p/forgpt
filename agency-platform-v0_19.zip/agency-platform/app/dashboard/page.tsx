import { requireStaff } from "../../src/web/storeSession";
import { StoreShell } from "../../src/web/StoreShell";
import { loadEditorState } from "../../src/store/siteEditor";
import { entitlementsOf } from "../../src/web/entitlements";
import { countNewInquiries } from "../../src/store/inquiries";
import { countNewOrders } from "../../src/shop/orders";
import { productCount } from "../../src/shop/products";
import { lowStock } from "../../src/shop/extras";
import { orIfMissingSchema } from "../../src/shop/safe";


export const dynamic = "force-dynamic";

const NOTICES: Record<string, string> = { published: "Your changes are now live on your website.", password: "Your password was changed." };

export default async function StoreHome({ searchParams }: { searchParams: Promise<{ notice?: string }> }) {
  const { pool, staff, businessName, tenant } = await requireStaff();
  const ent = await entitlementsOf(tenant.packageTier);
  const newInquiries = ent.inquiries ? await countNewInquiries(pool) : 0;
  const shopOn = ent.shop.products;
  const [products, newOrders, low] = shopOn ? await orIfMissingSchema(() => Promise.all([productCount(pool), countNewOrders(pool), lowStock(pool, ent)]), [0, 0, []] as [number, number, Awaited<ReturnType<typeof lowStock>>]) : [0, 0, []];
  const { notice } = await searchParams;
  const state = await loadEditorState(pool);
  const cfg = state.draft ?? state.live;
  const steps = [
    { done: Boolean(cfg.content.heroTitle), label: "Write your main headline", href: "/dashboard/builder" },
    { done: Boolean(cfg.content.about), label: "Tell customers about your business", href: "/dashboard/builder" },
    { done: Boolean(cfg.content.phone || cfg.content.whatsapp), label: "Add a phone or WhatsApp number", href: "/dashboard/editor#tab-contact" },
    { done: cfg.content.services.length > 0, label: "List your services", href: "/dashboard/builder" },
    { done: Boolean(cfg.images.logo), label: "Upload your logo", href: "/dashboard/media" },
    ...(shopOn ? [{ done: products > 0, label: "Add your first product", href: "/dashboard/products/new" }] : []),
    { done: Boolean(state.publishedAt), label: "Publish your website", href: "/dashboard/builder" },
  ];
  const doneCount = steps.filter((x) => x.done).length;
  const live = Boolean(state.publishedAt);
  return (
    <StoreShell businessName={businessName} email={staff.email} inquiries={ent.inquiries}>
      {notice && NOTICES[notice] && <p className="ok" role="status">{NOTICES[notice]}</p>}
      <section className="home-hero">
        <div>
          <span className="pill">{state.hasUnpublishedChanges ? "Unpublished changes" : live ? "Your website is live" : "Not published yet"}</span>
          <h2 style={{ marginTop: 10 }}>{businessName}</h2>
          <p>Click anything on your page to change it. Drag to move. Resize with sliders and handles.</p>
        </div>
        <div className="actions"><a className="btn" href="/dashboard/builder">Edit your website</a><a className="btn ghost" href="/" target="_blank" rel="noopener">View live site</a></div>
      </section>
      {shopOn && products > 0 && (
        <div className="kpis">
          <a className={newOrders > 0 ? "kpi alert" : "kpi"} href="/dashboard/orders?status=new"><span>New orders</span><b>{newOrders}</b></a>
          <a className="kpi" href="/dashboard/products"><span>Products</span><b>{products}</b><span>of {ent.shop.maxProducts}</span></a>
          {ent.shop.lowStock && <a className={low.length > 0 ? "kpi alert" : "kpi"} href="/dashboard/products"><span>Low stock</span><b>{low.length}</b></a>}
          {ent.inquiries && <a className={newInquiries > 0 ? "kpi alert" : "kpi"} href="/dashboard/inquiries"><span>New messages</span><b>{newInquiries}</b></a>}
        </div>
      )}
      <div className="quick">
        <a href="/dashboard/builder"><i>🎨</i><b>Design your page</b><span>Blocks, text, sizes, colours</span></a>
        {shopOn && <a href="/dashboard/products/new"><i>🛍</i><b>Add a product</b><span>Photos, price, stock</span></a>}
        {shopOn && <a href="/dashboard/orders"><i>📦</i><b>Orders</b><span>Confirm and deliver</span></a>}
        <a href="/dashboard/media"><i>🖼</i><b>Photos</b><span>Upload your pictures</span></a>
        <a href="/dashboard/domain"><i>🌐</i><b>Your domain</b><span>Connect your own address</span></a>
        <a href="/dashboard/editor"><i>⚙️</i><b>Site settings</b><span>Contact, hours, SEO, social</span></a>
      </div>
      {doneCount < steps.length && (
        <div className="card">
          <h2>Get your website ready</h2>
          <p className="hint" style={{ margin: 0 }}>{doneCount} of {steps.length} done</p>
          <div className="meter" role="progressbar" aria-valuemin={0} aria-valuemax={steps.length} aria-valuenow={doneCount}><i style={{ width: `${Math.round((doneCount / steps.length) * 100)}%` }} /></div>
          <ul className="steps">
            {steps.map((x) => (
              <li key={x.label} className={x.done ? "done" : ""}><span className="tick" aria-hidden="true">{x.done ? "✓" : ""}</span><span className="t">{x.label}</span>{!x.done && <a href={x.href}>Do this</a>}</li>
            ))}
          </ul>
        </div>
      )}
      <div className="card"><h2>Need help or an upgrade?</h2><p style={{ margin: 0 }}>Contact your website provider. Package changes and pricing are handled by them. <a href="/dashboard/package">See your package</a></p></div>
    </StoreShell>
  );
}

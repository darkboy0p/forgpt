"use server";

import { headers } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { runtime } from "../src/web/server";
import { resolveHostState } from "../src/tenancy/resolver";
import { entitlementsOf } from "../src/web/entitlements";
import { submitInquiry } from "../src/store/inquiries";

const BACK = new Set(["/", "/contact"]); // only these return addresses are accepted

/** Public form on a client's website. Works only on a verified, active client domain whose package includes inquiries. */
export async function submitInquiryAction(formData: FormData): Promise<void> {
  const h = await headers();
  const { control, mgr } = runtime();
  const state = await resolveHostState(control, h.get("host") ?? "");
  if (state.kind !== "active" || !(await entitlementsOf(state.tenant.packageTier)).inquiries) notFound();
  const backRaw = formData.get("back");
  const back = typeof backRaw === "string" && BACK.has(backRaw) ? backRaw : "/";
  const ip = (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
  const s = (k: string, max: number) => { const v = formData.get(k); return typeof v === "string" ? v.slice(0, max) : ""; };
  const r = await submitInquiry(await mgr.getPool(state.tenant.tenantId), {
    name: s("name", 200), phone: s("phone", 60), email: s("email", 300), message: s("message", 3000), ip, honeypot: s("website", 300),
  });
  redirect(r.ok ? `${back}?sent=1#inquiry` : `${back}?ie=${r.error}#inquiry`);
}

import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { runtime } from "../../src/web/server";
import { isPlatformHost } from "../../src/web/adminAccess";
import { getPricingData } from "../../src/packages/pricing";
import { formatTaka } from "../../src/billing/values";
import { BuyForm, type BuyPackage } from "../../src/web/BuyForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "Buy a website" };

/** Public order page, on the platform's own address only. */
export default async function BuyPage({ searchParams }: { searchParams: Promise<{ package?: string }> }) {
  const { env, control } = runtime();
  if (!isPlatformHost(env, (await headers()).get("host") ?? "")) notFound();
  const { package: pk } = await searchParams;
  const data = await getPricingData(control);
  const packages: BuyPackage[] = data.packages.map((p) => ({ tier: p.tier, name: p.name, description: p.description, setup: formatTaka(p.setup), monthly: formatTaka(p.monthly), points: p.summary }));
  const wanted = Number(pk);
  const initial = packages.some((p) => p.tier === wanted) ? wanted : (packages[0]?.tier ?? 1);
  return (
    <div className="buy">
      <div className="wrap" style={{ padding: "36px 20px 60px" }}>
        <p><a href="/pricing">&larr; All packages</a></p>
        <h1>Order your website</h1>
        <p className="buy-lead">{data.settings.agency_name ? `${data.settings.agency_name} builds, hosts and looks after your website. ` : ""}Tell us about your business and we will contact you.</p>
        <ol className="buy-steps"><li><b>1</b> Send this form</li><li><b>2</b> We contact you and confirm</li><li><b>3</b> You pay, we build your site</li><li><b>4</b> You get your own dashboard</li></ol>
        <BuyForm packages={packages} initialTier={initial} />
      </div>
    </div>
  );
}

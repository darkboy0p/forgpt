import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { runtime } from "../../../src/web/server";
import { isPlatformHost } from "../../../src/web/adminAccess";
import { getSettings } from "../../../src/packages/requests";

export const dynamic = "force-dynamic";
export const metadata = { title: "Thank you", robots: { index: false, follow: false } };

export default async function Thanks({ searchParams }: { searchParams: Promise<{ ref?: string }> }) {
  const { env, control } = runtime();
  if (!isPlatformHost(env, (await headers()).get("host") ?? "")) notFound();
  const { ref: raw } = await searchParams;
  const ref = raw && /^[0-9A-F]{8}$/.test(raw) ? raw : null;
  const s = await getSettings(control);
  const wa = s.agency_whatsapp;
  const text = encodeURIComponent(`Hello, I just sent an order request${ref ? ` (reference ${ref})` : ""}.`);
  return (
    <div className="buy">
      <div className="wrap" style={{ padding: "48px 20px", maxWidth: 640 }}>
        <h1>Thank you! We received your request.</h1>
        {ref && <p className="buy-ref">Your reference: <strong>{ref}</strong></p>}
        <p>We will contact you on the phone number you gave to confirm your package and details.</p>
        <ol className="buy-next">
          <li>We call or message you to confirm.</li>
          <li>You pay{s.agency_payment_note ? <>: <strong>{s.agency_payment_note}</strong></> : " using the method we agree on"}.</li>
          <li>We build your website and set up your domain.</li>
          <li>You receive your dashboard login to edit it yourself.</li>
        </ol>
        {s.agency_note && <p className="buy-hint">{s.agency_note}</p>}
        <p>{wa && <a className="btn" href={`https://wa.me/${wa}?text=${text}`} target="_blank" rel="noopener noreferrer">Message us on WhatsApp</a>} <a href="/pricing">Back to packages</a></p>
      </div>
    </div>
  );
}

"use server";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { runtime } from "../../src/web/server";
import { isPlatformHost } from "../../src/web/adminAccess";
import { createPurchaseRequest, orderRef } from "../../src/orders/service";

export interface BuyState { error?: string; values?: Record<string, string> }

const FIELDS = ["packageTier", "businessName", "contactName", "phone", "whatsapp", "email", "desiredHostname", "paymentMethod", "message"] as const;

/** Public order form. It never takes payment; it records the request so the agency can contact the customer. */
export async function submitPurchaseAction(_prev: BuyState, formData: FormData): Promise<BuyState> {
  const { env, control } = runtime();
  if (!isPlatformHost(env, (await headers()).get("host") ?? "")) return { error: "unavailable" };
  const values = Object.fromEntries(FIELDS.map((k) => [k, String(formData.get(k) ?? "").slice(0, 1200)]));
  const v = (k: (typeof FIELDS)[number]) => values[k] ?? "";
  const r = await createPurchaseRequest(control, {
    packageTier: v("packageTier"), businessName: v("businessName"), contactName: v("contactName"), phone: v("phone"), whatsapp: v("whatsapp"),
    email: v("email"), desiredHostname: v("desiredHostname"), paymentMethod: v("paymentMethod"), message: v("message"), website: String(formData.get("website") ?? ""),
  });
  if (!r.ok) return { error: r.error, values };
  redirect(r.id ? `/buy/thanks?ref=${orderRef(r.id)}` : "/buy/thanks");
}

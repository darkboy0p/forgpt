import { clientHidesFromSearch, listClientPages, siteBaseUrl } from "../../src/web/renderSite";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const host = req.headers.get("host") ?? "";
  const pages = await listClientPages(host);
  const hidden = pages ? await clientHidesFromSearch(host) : false;
  const body = pages
    ? `User-agent: *\nAllow: /\nDisallow: /dashboard\nDisallow: /admin\n${hidden ? "" : `Sitemap: ${await siteBaseUrl()}/sitemap.xml\n`}`
    : "User-agent: *\nDisallow: /\n"; // platform home, unknown or suspended: keep search engines out
  return new Response(body, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
}

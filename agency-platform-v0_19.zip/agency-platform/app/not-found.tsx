import { headers } from "next/headers";
import { runtime } from "../src/web/server";
import { isPlatformHost, hostWithoutPort } from "../src/web/adminAccess";

/** Hosts that open on a developer PC without any setup. Anything else needs a hosts-file entry. */
function worksOffline(h: string) {
  return h.endsWith(".localhost") || h.endsWith(".localtest.me");
}

export default async function NotFound() {
  const host = (await headers()).get("host") ?? "";
  const { env, control } = runtime();
  const dev = env.APP_ENV === "development";
  const port = host.includes(":") ? ":" + host.split(":")[1] : "";
  const onPlatformHost = isPlatformHost(env, host);
  const sites = dev
    ? (await control.query(
        `SELECT t.business_name, d.hostname FROM domains d JOIN tenants t ON t.id = d.tenant_id
          WHERE d.status = 'verified' AND t.status = 'active' ORDER BY t.business_name LIMIT 30`)).rows
    : [];
  return (
    <div className="wrap" style={{ padding: "64px 20px", maxWidth: 720 }}>
      <h1>Site not found</h1>
      <p>This address is not connected to a website.</p>
      {dev && (
        <div className="card">
          <h2 style={{ marginTop: 0 }}>Development help</h2>
          <p style={{ color: "#5b6573" }}>Only shown on your own computer.</p>
          <p>
            You opened <code>{host}</code>.{" "}
            {onPlatformHost
              ? <>That is the <strong>platform</strong> address: it shows the admin and pricing pages, and has no website or owner dashboard of its own. <a href="/admin">Open admin</a></>
              : <>No verified client uses that address. Each client website and its dashboard open on the client&apos;s <strong>own</strong> address, listed below.</>}
          </p>
          <p><strong>Client websites you can open now</strong></p>
          <ul style={{ paddingLeft: 18 }}>
            {sites.map((s) => {
              const h = hostWithoutPort(s.hostname);
              return (
                <li key={s.hostname} style={{ marginBottom: 8 }}>
                  <strong>{s.business_name}</strong>{" "}
                  <a href={`http://${s.hostname}${port}/`}>website</a> &middot; <a href={`http://${s.hostname}${port}/dashboard`}>owner dashboard</a>
                  <br /><small style={{ color: "#5b6573" }}>
                    {s.hostname}{worksOffline(h) ? (h.endsWith(".localtest.me") ? " (needs internet)" : "") : " (will not open unless this name is added to your computer's hosts file)"}
                  </small>
                </li>
              );
            })}
            {sites.length === 0 && <li>No verified client domains yet. Create a client in the admin, then press &quot;Mark verified&quot;.</li>}
          </ul>
        </div>
      )}
    </div>
  );
}

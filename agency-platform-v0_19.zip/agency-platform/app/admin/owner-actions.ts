"use server";

import { runtime } from "../../src/web/server";
import { requireAdmin } from "../../src/web/adminSession";
import { createStaffOwner, resetStaffPassword, setStaffActive, StaffError } from "../../src/store/auth";

export interface OwnerState { message?: string; error?: string; email?: string; tempPassword?: string }

const SLUG = /^[a-z0-9][a-z0-9-]{1,40}$/;

/** Creates / resets / deactivates the CLIENT's own dashboard login. The temporary password is returned once and never stored. */
export async function ownerAction(_prev: OwnerState, formData: FormData): Promise<OwnerState> {
  const admin = await requireAdmin();
  const slug = String(formData.get("slug") ?? "").slice(0, 60);
  const intent = String(formData.get("intent") ?? "");
  const email = String(formData.get("email") ?? "").trim().slice(0, 254);
  if (!SLUG.test(slug) || !["create", "reset", "deactivate", "activate"].includes(intent)) return { error: "Invalid request." };

  const { control, mgr } = runtime();
  const t = (await control.query("SELECT id FROM tenants t WHERE slug = $1 AND status IN ('active','suspended') AND EXISTS (SELECT 1 FROM tenant_databases d WHERE d.tenant_id = t.id)", [slug])).rows[0];
  if (!t) return { error: "This client's database is not ready." };
  const audit = (action: string, detail: object) =>
    control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,$2,$3,$4)", [admin.email, action, t.id, JSON.stringify(detail)]);

  try {
    return await mgr.withAdminPool(t.id, async (pool): Promise<OwnerState> => {
      if (intent === "create") {
        const o = await createStaffOwner(pool, email);
        await audit("owner.created", { email: o.email });
        return { message: `Owner login created for ${o.email}. Give them the temporary password below and the dashboard address. They must choose their own password at first sign-in.`, email: o.email, tempPassword: o.tempPassword };
      }
      if (intent === "reset") {
        const r = await resetStaffPassword(pool, email);
        if (!r) return { error: "No owner login with that email." };
        await audit("owner.password.reset", { email });
        return { message: `New temporary password for ${email}. All their open sessions were ended.`, email, tempPassword: r.tempPassword };
      }
      const active = intent === "activate";
      if (!(await setStaffActive(pool, email, active))) return { error: "No owner login with that email." };
      await audit(active ? "owner.activated" : "owner.deactivated", { email });
      return { message: `${email} is now ${active ? "active" : "deactivated (their sessions were ended)"}.` };
    });
  } catch (err) {
    if (err instanceof StaffError) return { error: err.message };
    console.error("[owner-action]", (err as Error).message);
    return { error: "Something went wrong. Nothing was changed." };
  }
}

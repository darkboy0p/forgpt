import { requireAdmin } from "../../../src/web/adminSession";
import { runtime } from "../../../src/web/server";
import { AdminShell } from "../../../src/web/AdminShell";
import { listPurchaseRequests, orderRef, ORDER_STATUSES, PAYMENT_LABELS, type OrderStatus } from "../../../src/orders/service";
import { PACKAGE_NAMES } from "../../../src/config/templates";
import { setOrderStatusAction } from "../order-actions";

export const dynamic = "force-dynamic";
const TABS: [string, string][] = [["open", "Open"], ["new", "New"], ["contacted", "Contacted"], ["paid", "Paid"], ["client_created", "Client created"], ["rejected", "Rejected"], ["all", "All"]];
const LABEL: Record<OrderStatus, string> = { new: "New", contacted: "Contacted", paid: "Paid", client_created: "Client created", rejected: "Rejected" };
const chip = (s: OrderStatus) => (s === "new" ? "chip warn" : s === "rejected" ? "chip off" : "chip");

export default async function OrdersPage({ searchParams }: { searchParams: Promise<{ status?: string; error?: string }> }) {
  await requireAdmin();
  const { status: raw, error } = await searchParams;
  const tab = TABS.some(([k]) => k === raw) ? (raw as string) : "open";
  const { control } = runtime();
  const rows = await listPurchaseRequests(control, tab === "all" ? undefined : (tab as OrderStatus | "open"));
  const slugs = new Map<string, string>();
  const ids = rows.map((r) => r.tenant_id).filter((x): x is string => Boolean(x));
  if (ids.length) for (const t of (await control.query("SELECT id, slug FROM tenants WHERE id = ANY($1::uuid[])", [ids])).rows) slugs.set(t.id, t.slug);
  return (
    <AdminShell>
      <h1>Orders</h1>
      <p className="lead">Requests from the public Buy page. Call or message the customer, confirm payment, then create their client.</p>
      {error && <p className="warn" role="alert">That change could not be made. The order may already be a client.</p>}
      <div className="toolbar" role="tablist" aria-label="Filter orders">
        {TABS.map(([k, l]) => <a key={k} className={k === tab ? "btn" : "btn ghost"} href={`/admin/orders?status=${k}`} aria-current={k === tab ? "page" : undefined}>{l}</a>)}
      </div>
      {rows.length === 0 && <p className="card">No orders here.</p>}
      {rows.map((o) => {
        const wa = (o.whatsapp ?? o.phone).replace(/^\+/, "").replace(/^0/, "880");
        return (
          <section className="card" key={o.id}>
            <h2 style={{ marginBottom: 4 }}>{o.business_name} <span className={chip(o.status)}>{LABEL[o.status]}</span> <small className="hint">#{orderRef(o.id)} &middot; {new Date(o.created_at).toISOString().slice(0, 16).replace("T", " ")} UTC</small></h2>
            <p style={{ margin: "0 0 6px" }}><strong>{PACKAGE_NAMES[o.package_tier as keyof typeof PACKAGE_NAMES] ?? `Tier ${o.package_tier}`}</strong> &middot; pays by {PAYMENT_LABELS[o.payment_method as keyof typeof PAYMENT_LABELS] ?? o.payment_method}{o.desired_hostname ? <> &middot; wants <code>{o.desired_hostname}</code></> : null}</p>
            <p style={{ margin: "0 0 6px" }}>{o.contact_name} &middot; <a href={`tel:${o.phone}`}>{o.phone}</a> &middot; <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>{o.email && <> &middot; <a href={`mailto:${o.email}`}>{o.email}</a></>}</p>
            {o.message && <p className="hint" style={{ whiteSpace: "pre-wrap" }}>{o.message}</p>}
            <div className="ed-tools">
              {o.status !== "client_created" && (
                <>
                  <a className="btn" href={`/admin?order=${o.id}#new-client`}>Create client from this order</a>
                  {ORDER_STATUSES.filter((s) => s !== "client_created" && s !== o.status).map((s) => (
                    <form action={setOrderStatusAction} key={s}><input type="hidden" name="id" value={o.id} /><input type="hidden" name="filter" value={tab} /><input type="hidden" name="status" value={s} /><button type="submit">Mark {LABEL[s].toLowerCase()}</button></form>
                  ))}
                </>
              )}
              {o.tenant_id && slugs.get(o.tenant_id) && <a href={`/admin/clients/${slugs.get(o.tenant_id)}`}>Open client</a>}
            </div>
          </section>
        );
      })}
    </AdminShell>
  );
}

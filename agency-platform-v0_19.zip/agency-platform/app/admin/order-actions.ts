"use server";
import { redirect } from "next/navigation";
import { requireAdmin } from "../../src/web/adminSession";
import { runtime } from "../../src/web/server";
import { setPurchaseStatus } from "../../src/orders/service";

export async function setOrderStatusAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = String(formData.get("id") ?? "").slice(0, 40), status = String(formData.get("status") ?? "").slice(0, 20);
  const filter = String(formData.get("filter") ?? "open").replace(/[^a-z_]/g, "").slice(0, 20) || "open";
  const ok = await setPurchaseStatus(runtime().control, id, status, admin.email);
  redirect(`/admin/orders?status=${filter}${ok ? "" : "&error=1"}`);
}

import { headers } from "next/headers";
import { runtime } from "../../src/web/server";
import { requireAdmin } from "../../src/web/adminSession";
import { TEMPLATES, PACKAGE_NAMES } from "../../src/config/templates";
import { createClientAction } from "./actions";
import { orIfMissingSchema } from "../../src/shop/safe";
import { countNewPurchases, getPurchaseRequest, suggestSlug, orderRef } from "../../src/orders/service";
import { AdminShell } from "../../src/web/AdminShell";
import { ClientTable, type ClientRow } from "../../src/web/ClientTable";
import { billingSummary } from "../../src/billing/service";
import { formatTaka } from "../../src/billing/values";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  invalid_name: "Business name must be 2 to 80 characters and cannot contain < or > characters.",
  invalid_slug: "Short name must be 2 to 41 characters: lowercase letters, numbers and hyphens, not ending with a hyphen.",
  slug_taken: "A client with that short name already exists.",
  invalid_tier: "Choose a package from 1 to 5.",
  template_unavailable: "That template is not built yet.",
  template_tier_mismatch: "That template needs a higher package.",
  invalid_host: "That domain is not a valid website address (example: clientbrand.com).",
  host_taken: "That domain is already registered to a client.",
  provider_unavailable: "The database provider for this environment is not available yet.",
};

export default async function AdminHome({ searchParams }: { searchParams: Promise<{ error?: string; order?: string }> }) {
  const admin = await requireAdmin();
  const { control } = runtime();
  const { error, order: orderId } = await searchParams;
  const hostHeader = (await headers()).get("host") ?? "";
  const port = hostHeader.includes(":") ? ":" + hostHeader.split(":")[1] : "";
  const sum = await billingSummary(control);
  const openRequests = (await control.query("SELECT count(*) AS n FROM client_requests WHERE status = 'open'")).rows[0].n as number;

  const r = await control.query(
    `SELECT t.slug, t.business_name, t.package_tier, t.template_key, t.status,
            d.hostname, d.status AS domain_status
       FROM tenants t LEFT JOIN domains d ON d.tenant_id = t.id AND d.is_primary
      ORDER BY t.created_at DESC LIMIT 200`
  );
  const field = { width: "100%", padding: 8 } as const;
  const order = orderId ? await getPurchaseRequest(control, orderId) : null;
  const fromOrder = order && order.status !== "client_created" ? order : null;
  const newOrders = await orIfMissingSchema(() => countNewPurchases(control), 0);
  const rows: ClientRow[] = r.rows.map((t) => {
    const live = t.hostname && t.domain_status === "verified" && t.status === "active";
    return { slug: t.slug, name: t.business_name, tier: t.package_tier, packageName: PACKAGE_NAMES[t.package_tier as keyof typeof PACKAGE_NAMES] ?? `Tier ${t.package_tier}`, template: t.template_key, status: t.status,
      hostname: t.hostname ?? null, domainStatus: t.domain_status ?? null, siteUrl: live ? `http://${t.hostname}${port}/` : null, dashUrl: live ? `http://${t.hostname}${port}/dashboard` : null };
  });
  const activeCount = rows.filter((x) => x.status === "active").length;
  const setupNeeded = rows.filter((x) => x.status !== "active" && x.status !== "suspended").length;
  return (
    <AdminShell>
      <h1>Clients</h1>
      <p className="lead">Everything you manage in one place. Open a client to change their package, billing, owner login or website access.</p>

      <div className="kpis">
        <a className="kpi" href="/admin/billing"><span>Monthly recurring revenue</span><b>{formatTaka(sum.monthlyRecurring)}</b></a>
        <a className="kpi" href="/admin/billing"><span>Outstanding invoices</span><b>{formatTaka(sum.outstanding)}</b></a>
        <a className={sum.overdueCount > 0 ? "kpi alert" : "kpi"} href="/admin/billing"><span>Overdue</span><b>{sum.overdueCount}</b><span>{formatTaka(sum.overdueAmount)}</span></a>
        <a className={newOrders > 0 ? "kpi alert" : "kpi"} href="/admin/orders"><span>New orders</span><b>{newOrders}</b></a>
        <a className={openRequests > 0 ? "kpi alert" : "kpi"} href="/admin/requests"><span>Open client requests</span><b>{openRequests}</b></a>
        <div className="kpi"><span>Active clients</span><b>{activeCount} <small style={{ fontWeight: 400, fontSize: ".85rem" }}>of {rows.length}</small></b>{setupNeeded > 0 && <span>{setupNeeded} need attention</span>}</div>
      </div>

      {error && <p className="warn" role="alert">{ERRORS[error] ?? "Something went wrong."}</p>}

      <details className="card" id="new-client" open={Boolean(error) || rows.length === 0 || Boolean(fromOrder)}>
        <summary>{fromOrder ? `Create a client from order #${orderRef(fromOrder.id)}` : "Add a new client"}</summary>
        {fromOrder && <p className="ok">Details were filled in from the order. Check them, then create the client. The order will be marked as &quot;client created&quot;.</p>}
        <form action={createClientAction}>
          {fromOrder && <input type="hidden" name="orderId" value={fromOrder.id} />}
          <div className="ed-cols">
            <label>Business name<input name="businessName" required minLength={2} maxLength={80} defaultValue={fromOrder?.business_name ?? ""} /></label>
            <label>Short name<span className="hint">Used internally. Lowercase letters, numbers and hyphens. Cannot be changed later.</span><input name="slug" required minLength={2} maxLength={41} pattern="[a-z0-9][a-z0-9\-]{1,40}" placeholder="rahim-traders" defaultValue={fromOrder ? suggestSlug(fromOrder.business_name) : ""} /></label>
            <label>Package<select name="packageTier" defaultValue={String(fromOrder?.package_tier ?? 1)}>{Object.entries(PACKAGE_NAMES).map(([tier, name]) => <option key={tier} value={tier}>{name}</option>)}</select></label>
            <label>Template<select name="templateKey" defaultValue={fromOrder && fromOrder.package_tier >= 2 ? "professional" : "starter"}>
              {Object.entries(TEMPLATES).map(([key, t]) => <option key={key} value={key} disabled={!t.built}>{t.label}{t.built ? "" : " (not built yet)"}</option>)}
            </select></label>
            <label>Domain (optional)<span className="hint">You can add it later.</span><input name="hostname" placeholder="clientbrand.com" maxLength={253} defaultValue={fromOrder?.desired_hostname ?? ""} /></label>
          </div>
          <button className="btn" type="submit">Create client and its database</button>
          <p className="hint">This makes a separate database for the client and can take a few seconds.</p>
        </form>
      </details>

      <section className="card">
        <h2 style={{ marginBottom: 10 }}>All clients</h2>
        {rows.length === 0 ? <p>No clients yet. Add your first client above.</p> : <ClientTable rows={rows} />}
      </section>
    </AdminShell>
  );
}

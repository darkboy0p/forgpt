import { runtime } from "../../../src/web/server";
import { AdminShell } from "../../../src/web/AdminShell";
import { requireAdmin } from "../../../src/web/adminSession";
import { addDays, formatTaka, todayUtc } from "../../../src/billing/values";

export const dynamic = "force-dynamic";

export default async function BillingOverview() {
  await requireAdmin();
  const today = todayUtc();
  const r = await runtime().control.query(
    `SELECT t.slug, t.business_name, i.number, i.due_date, i.amount_bdt, i.status, COALESCE(b.grace_days, 7) AS grace,
            COALESCE((SELECT sum(amount_bdt) FROM payments p WHERE p.invoice_id = i.id), 0) AS paid
       FROM invoices i JOIN tenants t ON t.id = i.tenant_id LEFT JOIN tenant_billing b ON b.tenant_id = i.tenant_id
      WHERE i.status IN ('unpaid','partial') ORDER BY i.due_date ASC LIMIT 300`);
  return (
    <AdminShell>
      <p><a href="/admin">&larr; Admin home</a></p>
      <h1>Unpaid invoices</h1>
      <p style={{ color: "#5b6573" }}>
        Websites are never suspended automatically. When an invoice is overdue past its grace days, you decide whether to suspend
        (on the client&apos;s page). Suspending deletes nothing.
      </p>
      <div className="card">
        <table>
          <thead><tr><th>Client</th><th>Invoice</th><th>Due</th><th>Still owed</th><th>Status</th></tr></thead>
          <tbody>
            {r.rows.map((i) => {
              const overdue = addDays(i.due_date, i.grace) < today;
              return (
                <tr key={i.number}>
                  <td><a href={`/admin/clients/${i.slug}#billing`}>{i.business_name}</a></td>
                  <td>{i.number}</td><td>{i.due_date}</td><td>{formatTaka(i.amount_bdt - i.paid)}</td><td>{overdue ? "overdue" : i.status}</td>
                </tr>
              );
            })}
            {r.rows.length === 0 && <tr><td colSpan={5}>Nothing is unpaid.</td></tr>}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}

import { requireAdmin } from "../../../src/web/adminSession";
import { runtime } from "../../../src/web/server";
import { AdminShell } from "../../../src/web/AdminShell";
import { dnsInstructions, listAllDomains } from "../../../src/domains/service";
import { recheckDomainAction } from "../domain-actions";

export const dynamic = "force-dynamic";
const NOTICES: Record<string, string> = {
  domain_verified: "Domain verified and live.", routing_yes: "The domain points to the platform.", routing_no: "The domain does NOT point to the platform yet.", routing_unknown: "No DNS target is configured (set DOMAIN_CNAME_TARGET or DOMAIN_A_RECORD), so pointing cannot be checked.",
  domain_not_found: "The proof record was not found yet.", domain_dns_error: "DNS did not answer.", domain_too_soon: "Please wait 10 seconds between checks.", domain_unknown: "Domain not found.", domain_unknown_domain: "Domain not found.", domain_not_verified: "Verify the domain first.",
};
const TABS: [string, string][] = [["all", "All"], ["pending", "Waiting for DNS"], ["attention", "Needs attention"], ["live", "Live"]];

export default async function DomainsPage({ searchParams }: { searchParams: Promise<{ tab?: string; notice?: string }> }) {
  await requireAdmin();
  const { tab: t, notice } = await searchParams;
  const tab = TABS.some(([k]) => k === t) ? (t as string) : "all";
  const { control, env } = runtime();
  const all = await listAllDomains(control);
  const bad = (d: (typeof all)[number]) => d.status === "verified" && d.check_note === "points_no";
  const rows = all.filter((d) => tab === "all" || (tab === "pending" && d.status === "pending") || (tab === "live" && d.status === "verified" && !bad(d)) || (tab === "attention" && (bad(d) || (d.status === "pending" && d.check_note === "dns_error"))));
  const count = (k: string) => k === "all" ? all.length : all.filter((d) => (k === "pending" ? d.status === "pending" : k === "live" ? d.status === "verified" && !bad(d) : bad(d))).length;
  const secure = env.APP_ENV !== "development";
  return (
    <AdminShell>
      <h1>Domains</h1>
      <p className="lead">Every domain your clients added. Clients prove ownership with a TXT record; you can also check where each live domain points.</p>
      {!env.DOMAIN_CNAME_TARGET && !env.DOMAIN_A_RECORD && <p className="warn">Set <code>DOMAIN_CNAME_TARGET</code> or <code>DOMAIN_A_RECORD</code> in your environment so the platform can tell whether a domain points at you, and so clients are shown where to point it.</p>}
      {notice && NOTICES[notice] && <p className={notice === "routing_no" || notice.startsWith("domain_") && notice !== "domain_verified" ? "warn" : "ok"} role="status">{NOTICES[notice]}</p>}
      <div className="toolbar"><span className="seg">{TABS.map(([k, l]) => <a key={k} href={`/admin/domains?tab=${k}`} aria-current={k === tab ? "true" : undefined}>{l} ({count(k)})</a>)}</span></div>
      <div className="tbl-wrap"><table>
        <thead><tr><th>Domain</th><th>Client</th><th>Status</th><th>Pointing</th><th></th></tr></thead>
        <tbody>
          {rows.map((d) => {
            const ins = dnsInstructions(env, d.hostname, d.verify_token);
            return (
              <tr key={d.hostname}>
                <td><strong>{d.hostname}</strong>{d.is_primary && <> <span className="chip">Main</span></>}<br />{d.status === "verified" && <a href={`${secure ? "https" : "http"}://${d.hostname}`} target="_blank" rel="noopener noreferrer"><small>Open site</small></a>}</td>
                <td><a href={`/admin/clients/${d.slug}`}>{d.business_name}</a></td>
                <td><span className={d.status === "verified" ? "chip" : "chip warn"}>{d.status === "verified" ? "Verified" : "Waiting for DNS"}</span></td>
                <td>{d.status !== "verified" ? <details><summary><small>TXT record to create</small></summary><code style={{ wordBreak: "break-all" }}>{ins.txtName}<br />{ins.txtValue}</code></details>
                  : d.check_note === "points_yes" ? <span className="chip">Points here</span> : d.check_note === "points_no" ? <span className="chip bad">Points elsewhere</span> : <span className="hint">{d.check_note === "points_unknown" ? "Not comparable" : "Not checked"}</span>}
                  {d.last_checked_at && <><br /><small className="hint">{new Date(d.last_checked_at).toISOString().slice(0, 16).replace("T", " ")} UTC</small></>}</td>
                <td className="num"><form action={recheckDomainAction}><input type="hidden" name="hostname" value={d.hostname} /><button type="submit" style={{ padding: "4px 12px", fontSize: ".85rem" }}>{d.status === "verified" ? "Check pointing" : "Check proof"}</button></form></td>
              </tr>
            );
          })}
          {rows.length === 0 && <tr><td colSpan={5} className="hint">No domains here.</td></tr>}
        </tbody>
      </table></div>
    </AdminShell>
  );
}

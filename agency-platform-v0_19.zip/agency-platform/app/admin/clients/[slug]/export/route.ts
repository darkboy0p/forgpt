import { redirect } from "next/navigation";
import { runtime } from "../../../../../src/web/server";
import { requireAdmin } from "../../../../../src/web/adminSession";
import { exportClientData } from "../../../../../src/clients/exportTenant";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const admin = await requireAdmin(); // not logged in -> login page; not an admin host -> 404
  const { slug } = await params;
  if (!/^[a-z0-9][a-z0-9-]{1,40}$/.test(slug)) return new Response("Not found", { status: 404 });
  const { control, mgr } = runtime();
  const r = await exportClientData(control, mgr, slug);
  if (!r.ok) {
    if (r.error === "not_found" || r.error === "no_database") return new Response("Not found", { status: 404 });
    redirect(`/admin/clients/${slug}?notice=${r.error === "too_large" ? "export_too_large" : "export_failed"}`);
  }
  // The audit log records WHO exported and how much, never the contents.
  await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) SELECT $1,'client.exported',id,$3 FROM tenants WHERE slug=$2",
    [admin.email, slug, JSON.stringify({ filename: r.filename, bytes: Buffer.byteLength(r.json), tables: r.tables })]);
  return new Response(r.json, {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="${r.filename}"`,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}

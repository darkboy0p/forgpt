import { notFound } from "next/navigation";
import { AdminShell } from "../../../../src/web/AdminShell";
import { runtime } from "../../../../src/web/server";
import { requireAdmin } from "../../../../src/web/adminSession";
import { PACKAGE_NAMES, TEMPLATES } from "../../../../src/config/templates";
import { redactSecrets } from "../../../../src/util/redact";
import { recheckDomainAction, applyTemplateLookAction } from "../../domain-actions";
import { dnsInstructions } from "../../../../src/domains/service";
import { retryProvisioningAction, verifyDomainDevAction, suspendClientAction, reactivateClientAction, changePackageAction } from "../../actions";
import { saveAgreementAction, createSetupInvoiceAction, generateMonthlyAction, recordPaymentAction, voidInvoiceAction } from "../../billing-actions";
import { OwnerPanel } from "./OwnerPanel";
import { getAgreement, nextMonthlyPeriod } from "../../../../src/billing/service";
import { BILLING_ERRORS, BILLING_NOTICES } from "../../../../src/billing/messages";
import { addDays, effectiveMonthlyFee, formatTaka, todayUtc } from "../../../../src/billing/values";

export const dynamic = "force-dynamic";

const NOTICES: Record<string, string> = {
  created: "Client created. Its separate database is ready.",
  failed: "Client was registered but setup failed. See the log below, then press Retry setup.",
  retried: "Setup finished successfully.",
  provision_failed: "Setup failed again. See the log below.",
  not_retryable: "This client does not need a retry.",
  not_found: "Client not found.",
  provider_unavailable: "The database provider for this environment is not available yet.",
  verified: "Domain marked as verified (development shortcut, no DNS check).",
  look_applied: "The template look was applied to the client's draft. Nothing is published.",
  domain_verified: "Domain verified and live.", routing_yes: "The domain points to the platform.", routing_no: "The domain does NOT point to the platform yet.", routing_unknown: "No DNS target is configured, so pointing cannot be checked.",
  domain_not_found: "The proof record was not found yet.", domain_dns_error: "DNS did not answer.", domain_too_soon: "Please wait 10 seconds between checks.", domain_unknown: "Domain not found.",
  package_changed: "Package and template updated. Remember to update the agreed prices under Billing.",
  package_downgraded: "Package lowered. Features outside the new package are now hidden from the website and dashboard, and nothing was deleted. Remember to update the agreed prices under Billing.",
  downgrade_needs_confirmation: "This lowers the package. Tick the confirmation box to continue.",
  template_tier_mismatch: "That template needs a higher package.",
  template_unavailable: "That template is not built yet.",
  invalid_tier: "Choose a package from 1 to 5.",
  unchanged: "Nothing changed.",
  suspended: "Website suspended. Nothing was deleted, and you can reactivate it at any time.",
  reactivated: "Website reactivated.",
  reason_required: "Write a reason before suspending.",
  not_active: "Only an active website can be suspended.",
  not_suspended: "This website is not suspended.",
  export_failed: "The export could not be created. If the store is very large, use a full database dump instead.",
  export_too_large: "This client's data is too large for the simple export. Use a full database dump instead.",
};

export default async function ClientPage({ params, searchParams }: {
  params: Promise<{ slug: string }>; searchParams: Promise<{ notice?: string; b?: string; be?: string }>;
}) {
  await requireAdmin();
  const { slug } = await params;
  const { notice, b, be } = await searchParams;
  if (!/^[a-z0-9][a-z0-9-]{1,40}$/.test(slug)) notFound();
  const { env, control } = runtime();

  const t = (await control.query(
    `SELECT t.id, t.slug, t.business_name, t.package_tier, t.template_key, t.status, t.created_at, t.suspended_reason, t.suspended_at,
            db.provider, db.database_name, db.schema_version
       FROM tenants t LEFT JOIN tenant_databases db ON db.tenant_id = t.id WHERE t.slug = $1`, [slug])).rows[0];
  if (!t) notFound();
  const domains = (await control.query("SELECT hostname, status, is_primary, verify_token FROM domains WHERE tenant_id=$1 ORDER BY is_primary DESC", [t.id])).rows;
  const jobs = (await control.query("SELECT step, status, detail, created_at FROM provisioning_jobs WHERE tenant_id=$1 ORDER BY id DESC LIMIT 30", [t.id])).rows;
  let owners: { email: string; isActive: boolean; lastLogin: string | null }[] = [];
  let ownersError = false;
  if (t.database_name) {
    try {
      owners = await runtime().mgr.withAdminPool(t.id, async (p) =>
        (await p.query("SELECT email, is_active, last_login_at FROM staff_users ORDER BY created_at")).rows.map((r) => ({
          email: r.email as string, isActive: r.is_active as boolean, lastLogin: r.last_login_at ? new Date(r.last_login_at).toISOString() : null })));
    } catch { ownersError = true; }
  }
  const verifiedHost = domains.find((d) => d.status === "verified" && d.is_primary)?.hostname ?? null;
  const today = todayUtc();
  const agreement = await getAgreement(control, t.id);
  const pkg = (await control.query("SELECT name, setup_bdt, monthly_bdt FROM packages WHERE tier=$1", [t.package_tier])).rows[0];
  const invoices = (await control.query(
    `SELECT i.id, i.number, i.kind, i.description, i.amount_bdt, i.due_date, i.status, i.void_reason,
            COALESCE((SELECT sum(amount_bdt) FROM payments p WHERE p.invoice_id = i.id), 0) AS paid
       FROM invoices i WHERE i.tenant_id = $1 ORDER BY i.issued_at DESC, i.number DESC LIMIT 60`, [t.id])).rows;
  const payments = (await control.query("SELECT p.amount_bdt, p.method, p.reference, p.received_on, i.number FROM payments p JOIN invoices i ON i.id = p.invoice_id WHERE p.tenant_id = $1 ORDER BY p.created_at DESC LIMIT 30", [t.id])).rows;
  const nextPeriod = agreement ? await nextMonthlyPeriod(control, t.id, agreement) : null;
  const hasSetupInvoice = invoices.some((i) => i.kind === "setup" && i.status !== "void");
  const retryable = t.status === "failed" || t.status === "provisioning";

  return (
    <AdminShell>
      <p><a href="/admin">&larr; All clients</a></p>
      <h1>{t.business_name} <span className="tag">{t.slug}</span></h1>
      {notice && <p className={notice === "failed" || notice === "provision_failed" ? "warn" : "card"}>{NOTICES[notice] ?? ""}</p>}

      <div className="card">
        <h2>Overview</h2>
        <table><tbody>
          <tr><th>Status</th><td>{t.status}</td></tr>
          <tr><th>Package</th><td>{PACKAGE_NAMES[t.package_tier] ?? `Tier ${t.package_tier}`}</td></tr>
          <tr><th>Template</th><td>{t.template_key}</td></tr>
          <tr><th>Created</th><td>{new Date(t.created_at).toISOString().replace("T", " ").slice(0, 16)} UTC</td></tr>
          <tr><th>Database</th><td>{t.database_name ? <>{t.database_name} <span className="tag">{t.provider}</span></> : "not created yet"}</td></tr>
        </tbody></table>
        {retryable && (
          <form action={retryProvisioningAction} style={{ marginTop: 12 }}>
            <input type="hidden" name="slug" value={t.slug} />
            <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Retry setup</button>
          </form>
        )}
      </div>

      <div className="card">
        <h2>Package and template</h2>
        <form action={changePackageAction}>
          <input type="hidden" name="slug" value={t.slug} />
          <p><label>Package <select name="packageTier" defaultValue={String(t.package_tier)}>
            {Object.entries(PACKAGE_NAMES).map(([tier, name]) => <option key={tier} value={tier}>{name}</option>)}</select></label></p>
          <p><label>Template <select name="templateKey" defaultValue={t.template_key}>
            {Object.entries(TEMPLATES).map(([key, tpl]) => <option key={key} value={key} disabled={!tpl.built}>{tpl.label}{tpl.built ? "" : " (not built yet)"}</option>)}</select></label></p>
          <p><label><input type="checkbox" name="confirmDowngrade" value="yes" /> This lowers the package: I understand features outside it will be hidden (nothing is deleted).</label></p>
          <p><label><input type="checkbox" name="applyLook" value="yes" /> Also give the client&apos;s <em>draft</em> this template&apos;s starting look (sections, colours, layout). Nothing is published.</label></p>
          <button type="submit">Apply package change</button>
          <p style={{ color: "#5b6573" }}><small>Upgrades keep all the client&apos;s content. Changing the package does not change the agreed prices; update those under Billing.</small></p>
        </form>
      </div>

      <div className="card">
        <h2>Website access and data</h2>
        {t.status === "suspended" && (
          <p className="warn">
            Suspended{t.suspended_at ? ` on ${new Date(t.suspended_at).toISOString().slice(0, 10)}` : ""}: {t.suspended_reason}.
            Visitors currently see a "temporarily unavailable" page. Nothing has been deleted.
          </p>
        )}
        {t.status === "active" && (
          <details><summary>Suspend this website</summary>
            <form action={suspendClientAction}>
              <input type="hidden" name="slug" value={t.slug} />
              <p><label>Reason (kept in the audit log) <input name="reason" required maxLength={300} style={{ width: "100%", padding: 6 }} /></label></p>
              <button type="submit">Suspend website</button>
            </form>
          </details>
        )}
        {t.status === "suspended" && (
          <form action={reactivateClientAction}>
            <input type="hidden" name="slug" value={t.slug} />
            <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Reactivate website</button>
          </form>
        )}
        {t.database_name && (
          <p style={{ marginTop: 12 }}>
            <a className="btn" href={`/admin/clients/${t.slug}/export`}>Download this client&apos;s data (JSON)</a>
            <br /><small style={{ color: "#5b6573" }}>Contains only this client&apos;s own website data. Your prices, invoices, notes and passwords are never included.</small>
          </p>
        )}
      </div>

      <div className="card">
        <h2>Owner login (the client's own dashboard)</h2>
        {ownersError
          ? <p className="warn">Could not read this client's owner logins. If this client was created before this update, run <code>npm run db:migrate</code>.</p>
          : <OwnerPanel slug={t.slug} owners={owners} dashboardHost={verifiedHost} />}
      </div>

      <div className="card">
        <h2>Template look</h2>
        <p style={{ color: "#5b6573" }}>Gives this client&apos;s draft the starting look of <strong>{TEMPLATES[t.template_key as keyof typeof TEMPLATES]?.label ?? t.template_key}</strong>: its sections, colours and layout. Their text, images, products and prices are not touched, and nothing is published.</p>
        <form action={applyTemplateLookAction}><input type="hidden" name="slug" value={t.slug} /><button type="submit">Apply template look to draft</button></form>
      </div>

      <div className="card">
        <h2>Domain</h2>
        {domains.length === 0 && <p>No domain registered yet.</p>}
        {domains.map((d) => (
          <div key={d.hostname}>
            <p><strong>{d.hostname}</strong> <span className="tag">{d.status}</span>{d.is_primary && <> <span className="tag">primary</span></>}</p>
            {d.status === "pending" && (() => { const ins = dnsInstructions(env, d.hostname, d.verify_token); return (
              <>
                <p style={{ color: "#5b6573" }}>Waiting for DNS. The client (or you) creates this record at the domain registrar, then presses Check:</p>
                <p><code style={{ wordBreak: "break-all" }}>TXT {ins.txtName} = {ins.txtValue}</code></p>
                <form action={recheckDomainAction}><input type="hidden" name="hostname" value={d.hostname} /><input type="hidden" name="slug" value={t.slug} /><input type="hidden" name="back" value="client" /><button type="submit">Check proof record now</button></form>
                {env.APP_ENV === "development" && (
                  <form action={verifyDomainDevAction}>
                    <input type="hidden" name="slug" value={t.slug} />
                    <input type="hidden" name="hostname" value={d.hostname} />
                    <button type="submit">Mark verified (development shortcut)</button>
                  </form>
                )}
              </>
            ); })()}
            {d.status === "verified" && (
              <form action={recheckDomainAction}>
                <input type="hidden" name="hostname" value={d.hostname} /><input type="hidden" name="slug" value={t.slug} /><input type="hidden" name="back" value="client" />
                <button type="submit">Check where it points</button>
              </form>
            )}
          </div>
        ))}
      </div>

      <div className="card" id="billing">
        <h2>Billing</h2>
        {b && <p className="card">{BILLING_NOTICES[b] ?? ""}</p>}
        {be && <p className="warn">{(BILLING_ERRORS as Record<string, string>)[be] ?? "Something went wrong."}</p>}
        <p style={{ color: "#5b6573" }}>
          Default price for {pkg?.name}: setup {formatTaka(pkg?.setup_bdt ?? 0)}, monthly {formatTaka(pkg?.monthly_bdt ?? 0)}.
          These are only defaults. Enter the price you agreed with the client. Clients cannot see or change any of this.
        </p>
        <form action={saveAgreementAction}>
          <input type="hidden" name="slug" value={t.slug} />
          <table><tbody>
            <tr><th>Setup fee (৳)</th><td><input name="setupFee" required defaultValue={agreement?.setupFee ?? pkg?.setup_bdt} /></td></tr>
            <tr><th>Monthly fee (৳)</th><td><input name="monthlyFee" required defaultValue={agreement?.monthlyFee ?? pkg?.monthly_bdt} /></td></tr>
            <tr><th>Monthly discount (৳)</th><td><input name="monthlyDiscount" defaultValue={agreement?.monthlyDiscount ?? 0} /></td></tr>
            <tr><th>Discount valid until</th><td><input name="discountUntil" type="date" defaultValue={agreement?.discountUntil ?? ""} /> <small>(empty = no end date)</small></td></tr>
            <tr><th>Service start date</th><td><input name="serviceStart" type="date" required defaultValue={agreement?.serviceStart ?? ""} /> <small>(day 1 to 28; monthly invoices fall on this day)</small></td></tr>
            <tr><th>Grace days</th><td><input name="graceDays" defaultValue={agreement?.graceDays ?? 7} /></td></tr>
            <tr><th>Notes</th><td><textarea name="notes" rows={2} maxLength={2000} defaultValue={agreement?.notes ?? ""} style={{ width: "100%" }} /></td></tr>
          </tbody></table>
          <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Save agreement</button>
        </form>

        {agreement && (
          <div style={{ marginTop: 16, display: "flex", gap: 24, flexWrap: "wrap" }}>
            {!hasSetupInvoice && (
              <form action={createSetupInvoiceAction}>
                <input type="hidden" name="slug" value={t.slug} />
                <label>Setup invoice due <input name="dueDate" type="date" required defaultValue={addDays(today, 7)} /></label>{" "}
                <button type="submit">Create setup invoice ({formatTaka(agreement.setupFee)})</button>
              </form>
            )}
            {nextPeriod && (
              <form action={generateMonthlyAction}>
                <input type="hidden" name="slug" value={t.slug} />
                <input type="hidden" name="periodStart" value={nextPeriod} />
                <button type="submit">Create monthly invoice for {nextPeriod} ({formatTaka(effectiveMonthlyFee(agreement, nextPeriod))})</button>
              </form>
            )}
          </div>
        )}

        <h3>Invoices</h3>
        <table>
          <thead><tr><th>Invoice</th><th>Due</th><th>Amount</th><th>Paid</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {invoices.map((i) => {
              const open = i.status === "unpaid" || i.status === "partial";
              const overdue = open && addDays(i.due_date, agreement?.graceDays ?? 7) < today;
              return (
                <tr key={i.id}>
                  <td>{i.number}<br /><small>{i.description}</small></td>
                  <td>{i.due_date}</td><td>{formatTaka(i.amount_bdt)}</td><td>{formatTaka(i.paid)}</td>
                  <td>{overdue ? "overdue" : i.status}{i.void_reason && <><br /><small>{i.void_reason}</small></>}</td>
                  <td>
                    {open && (
                      <details><summary>Record payment</summary>
                        <form action={recordPaymentAction}>
                          <input type="hidden" name="invoiceId" value={i.id} />
                          <p><label>Amount received (৳) <input name="amount" required defaultValue={i.amount_bdt - i.paid} /></label></p>
                          <p><label>Method <select name="method" defaultValue="bkash">
                            {["bkash", "nagad", "rocket", "bank", "cash", "other"].map((m) => <option key={m} value={m}>{m}</option>)}</select></label></p>
                          <p><label>Transaction ID / reference <input name="reference" maxLength={100} /></label></p>
                          <p><label>Received on <input name="receivedOn" type="date" required defaultValue={today} /></label></p>
                          <button type="submit">Save payment (only after you confirmed the money arrived)</button>
                        </form>
                      </details>
                    )}
                    {open && i.paid === 0 && (
                      <details><summary>Void</summary>
                        <form action={voidInvoiceAction}>
                          <input type="hidden" name="invoiceId" value={i.id} />
                          <p><label>Reason <input name="reason" required maxLength={300} /></label></p>
                          <button type="submit">Void invoice</button>
                        </form>
                      </details>
                    )}
                  </td>
                </tr>
              );
            })}
            {invoices.length === 0 && <tr><td colSpan={6}>No invoices yet.</td></tr>}
          </tbody>
        </table>

        <h3>Payments received</h3>
        <table>
          <thead><tr><th>Date</th><th>Invoice</th><th>Amount</th><th>Method</th><th>Reference</th></tr></thead>
          <tbody>
            {payments.map((p, k) => <tr key={k}><td>{p.received_on}</td><td>{p.number}</td><td>{formatTaka(p.amount_bdt)}</td><td>{p.method}</td><td>{p.reference}</td></tr>)}
            {payments.length === 0 && <tr><td colSpan={5}>No payments recorded.</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2>Setup log</h2>
        <table>
          <thead><tr><th>When (UTC)</th><th>Step</th><th>Result</th><th>Details</th></tr></thead>
          <tbody>
            {jobs.map((j, i) => (
              <tr key={i}>
                <td>{new Date(j.created_at).toISOString().replace("T", " ").slice(0, 19)}</td>
                <td>{j.step}</td><td>{j.status}</td><td>{j.detail ? redactSecrets(j.detail) : ""}</td>
              </tr>
            ))}
            {jobs.length === 0 && <tr><td colSpan={4}>No entries.</td></tr>}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}

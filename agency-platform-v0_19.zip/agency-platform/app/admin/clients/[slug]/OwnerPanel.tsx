"use client";

import { useActionState } from "react";
import { ownerAction, type OwnerState } from "../../owner-actions";

interface Owner { email: string; isActive: boolean; lastLogin: string | null }

export function OwnerPanel({ slug, owners, dashboardHost }: { slug: string; owners: Owner[]; dashboardHost: string | null }) {
  const [state, formAction, pending] = useActionState<OwnerState, FormData>(ownerAction, {});
  return (
    <div>
      {state.error && <p className="warn">{state.error}</p>}
      {state.message && <p className="card">{state.message}</p>}
      {state.tempPassword && (
        <div className="warn">
          <p><strong>Temporary password for {state.email} (shown only once, copy it now):</strong></p>
          <p style={{ fontFamily: "monospace", fontSize: "1.3rem", userSelect: "all" }}>{state.tempPassword}</p>
          <p>Send it privately. It is not stored anywhere in readable form.</p>
        </div>
      )}
      <p style={{ color: "#5b6573" }}>
        Owner dashboard address: {dashboardHost ? <strong>{dashboardHost}/dashboard</strong> : "available once the client's domain is verified"}
      </p>
      <table>
        <thead><tr><th>Owner login</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead>
        <tbody>
          {owners.map((o) => (
            <tr key={o.email}>
              <td>{o.email}</td><td>{o.isActive ? "active" : "deactivated"}</td><td>{o.lastLogin ? o.lastLogin.slice(0, 16).replace("T", " ") + " UTC" : "never"}</td>
              <td>
                <form action={formAction} style={{ display: "inline" }}>
                  <input type="hidden" name="slug" value={slug} /><input type="hidden" name="email" value={o.email} />
                  <button name="intent" value="reset" type="submit" disabled={pending}>New temporary password</button>{" "}
                  <button name="intent" value={o.isActive ? "deactivate" : "activate"} type="submit" disabled={pending}>{o.isActive ? "Deactivate" : "Activate"}</button>
                </form>
              </td>
            </tr>
          ))}
          {owners.length === 0 && <tr><td colSpan={4}>No owner login yet.</td></tr>}
        </tbody>
      </table>
      <form action={formAction} style={{ marginTop: 12 }}>
        <input type="hidden" name="slug" value={slug} /><input type="hidden" name="intent" value="create" />
        <label>New owner email <input name="email" type="email" required maxLength={254} /></label>{" "}
        <button type="submit" disabled={pending}>Create owner login</button>
      </form>
    </div>
  );
}

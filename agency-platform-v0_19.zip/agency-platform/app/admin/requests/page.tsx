import { runtime } from "../../../src/web/server";
import { AdminShell } from "../../../src/web/AdminShell";
import { requireAdmin } from "../../../src/web/adminSession";
import { PACKAGE_NAMES } from "../../../src/config/templates";
import { markRequestDoneAction } from "../package-actions";

export const dynamic = "force-dynamic";

export default async function RequestsAdmin() {
  await requireAdmin();
  const rows = (await runtime().control.query(
    `SELECT r.id, r.kind, r.requested_tier, r.message, r.status, r.created_by, r.created_at, t.slug, t.business_name, t.package_tier
       FROM client_requests r JOIN tenants t ON t.id = r.tenant_id ORDER BY (r.status = 'open') DESC, r.created_at DESC LIMIT 100`)).rows;
  return (
    <AdminShell>
      <p><a href="/admin">&larr; Admin home</a></p>
      <h1>Client requests</h1>
      <p style={{ color: "#5b6573" }}>Upgrade and support requests sent from clients&apos; dashboards. Nothing is emailed, so check here regularly.</p>
      {rows.map((r) => (
        <div className="card" key={r.id}>
          <p><strong>{r.kind === "upgrade" ? "Upgrade request" : "Support request"}</strong> <span className="tag">{r.status}</span>{" "}
            <a href={`/admin/clients/${r.slug}`}>{r.business_name}</a> <small>({PACKAGE_NAMES[r.package_tier]}{r.requested_tier ? ` → wants ${PACKAGE_NAMES[r.requested_tier]}` : ""})</small></p>
          <p style={{ whiteSpace: "pre-wrap" }}>{r.message}</p>
          <p><small>{r.created_by} &middot; {new Date(r.created_at).toISOString().replace("T", " ").slice(0, 16)} UTC</small></p>
          {r.status === "open" && <form action={markRequestDoneAction}><input type="hidden" name="id" value={r.id} /><button type="submit">Mark as handled</button></form>}
        </div>
      ))}
      {rows.length === 0 && <p className="card">No requests yet.</p>}
    </AdminShell>
  );
}

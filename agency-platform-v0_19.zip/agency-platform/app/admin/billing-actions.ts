"use server";

import { redirect } from "next/navigation";
import { runtime } from "../../src/web/server";
import { requireAdmin } from "../../src/web/adminSession";
import { setAgreement, createSetupInvoice, generateMonthlyInvoice, recordPayment, voidInvoice, type Result } from "../../src/billing/service";

const SLUG = /^[a-z0-9][a-z0-9-]{1,40}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const str = (v: FormDataEntryValue | null, max = 300) => (typeof v === "string" ? v.slice(0, max) : "");

function back(slug: string, r: Result<object>, okCode: string): never {
  redirect(`/admin/clients/${slug}?${r.ok ? `b=${okCode}` : `be=${r.error}`}#billing`);
}
async function slugForInvoice(invoiceId: string): Promise<string> {
  if (!UUID.test(invoiceId)) redirect("/admin");
  const r = await runtime().control.query("SELECT t.slug FROM invoices i JOIN tenants t ON t.id = i.tenant_id WHERE i.id = $1", [invoiceId]);
  if (!r.rows[0]) redirect("/admin");
  return r.rows[0].slug;
}

// Every action re-checks the login. Clients have no access to any of this.
export async function saveAgreementAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = str(formData.get("slug"), 50);
  if (!SLUG.test(slug)) redirect("/admin");
  const r = await setAgreement(runtime().control, slug, {
    setupFee: str(formData.get("setupFee")), monthlyFee: str(formData.get("monthlyFee")), monthlyDiscount: str(formData.get("monthlyDiscount")),
    discountUntil: str(formData.get("discountUntil")), serviceStart: str(formData.get("serviceStart")), graceDays: str(formData.get("graceDays")), notes: str(formData.get("notes"), 2000),
  }, admin.email);
  back(slug, r, "agreement");
}

export async function createSetupInvoiceAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = str(formData.get("slug"), 50);
  if (!SLUG.test(slug)) redirect("/admin");
  back(slug, await createSetupInvoice(runtime().control, slug, str(formData.get("dueDate")), admin.email), "invoice");
}

export async function generateMonthlyAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = str(formData.get("slug"), 50);
  if (!SLUG.test(slug)) redirect("/admin");
  back(slug, await generateMonthlyInvoice(runtime().control, slug, str(formData.get("periodStart")), admin.email), "invoice");
}

export async function recordPaymentAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const invoiceId = str(formData.get("invoiceId"), 40);
  const slug = await slugForInvoice(invoiceId);
  back(slug, await recordPayment(runtime().control, invoiceId, {
    amount: str(formData.get("amount")), method: str(formData.get("method")), reference: str(formData.get("reference"), 100), receivedOn: str(formData.get("receivedOn")),
  }, admin.email), "payment");
}

export async function voidInvoiceAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const invoiceId = str(formData.get("invoiceId"), 40);
  const slug = await slugForInvoice(invoiceId);
  back(slug, await voidInvoice(runtime().control, invoiceId, str(formData.get("reason")), admin.email), "voided");
}

import { runtime } from "../../../src/web/server";
import { AdminShell } from "../../../src/web/AdminShell";
import { requireAdmin } from "../../../src/web/adminSession";
import { getPricingData } from "../../../src/packages/pricing";
import { FEATURES } from "../../../src/packages/features";
import { PricingView } from "../../../src/web/PricingView";
import { updatePackageAction, saveSettingsAction } from "../package-actions";

export const dynamic = "force-dynamic";

const ERRORS: Record<string, string> = {
  invalid_tier: "Invalid package.", invalid_price: "Prices must be whole taka amounts.", description_too_long: "The description is too long (300 characters at most).",
  invalid_limit: "Limits must be whole numbers from 0 to 1,000,000.", unknown_feature: "Unknown feature.", invalid_whatsapp: "WhatsApp must be digits with the country code, for example 8801700000000.", too_long: "One of the texts is too long.",
};
const GROUPS = ["Website", "Products", "Selling", "Reports", "Support", "Limits"] as const;

export default async function PackagesAdmin({ searchParams }: { searchParams: Promise<{ notice?: string; error?: string; tier?: string }> }) {
  await requireAdmin();
  const { notice, error, tier } = await searchParams;
  const data = await getPricingData(runtime().control);
  const field = { width: "100%", padding: 6 } as const;
  return (
    <AdminShell>
      <p><a href="/admin">&larr; Admin home</a></p>
      <h1>Packages and pricing</h1>
      <p style={{ color: "#5b6573" }}>
        Changing a package here changes its <strong>default</strong> price and features for the future. Existing client agreements and invoices are never changed.
        Features marked &quot;not built yet&quot; have no effect until they are built.
      </p>
      {notice === "saved" && <p className="card">Package saved{tier ? ` (Tier ${tier})` : ""}. The change is in the audit log.</p>}
      {notice === "nochange" && <p className="card">Nothing was changed.</p>}
      {notice === "settings" && <p className="card">Contact details saved.</p>}
      {error && <p className="warn">{ERRORS[error] ?? "Something went wrong."}</p>}

      <div className="card">
        <h2>Your contact details (shown on the pricing page)</h2>
        <form action={saveSettingsAction}>
          <p><label>Agency name<br /><input name="agency_name" maxLength={80} defaultValue={data.settings.agency_name ?? ""} style={field} /></label></p>
          <p><label>WhatsApp number for orders (digits with country code)<br /><input name="agency_whatsapp" maxLength={20} defaultValue={data.settings.agency_whatsapp ?? ""} style={field} /></label></p>
          <p><label>Short note (for example your working hours)<br /><input name="agency_note" maxLength={300} defaultValue={data.settings.agency_note ?? ""} style={field} /></label></p>
          <p><label>How customers pay (shown after they send an order, for example &quot;bKash 01XXXXXXXXX, Send Money&quot;)<br /><input name="agency_payment_note" maxLength={300} defaultValue={data.settings.agency_payment_note ?? ""} style={field} /></label></p>
          <button type="submit">Save contact details</button>
        </form>
      </div>

      {data.packages.map((p) => (
        <details className="card" key={p.tier} id={`tier${p.tier}`} open={String(p.tier) === tier}>
          <summary><strong>Tier {p.tier}: {p.name}</strong> &mdash; setup ৳{p.setup.toLocaleString("en-IN")}, monthly ৳{p.monthly.toLocaleString("en-IN")}</summary>
          <form action={updatePackageAction}>
            <input type="hidden" name="tier" value={p.tier} />
            <p><label>Description<br /><input name="description" maxLength={300} defaultValue={p.description} style={field} /></label></p>
            <p><label>Default setup fee (৳)<br /><input name="setupFee" required defaultValue={p.setup} style={{ padding: 6 }} /></label></p>
            <p><label>Default monthly fee (৳)<br /><input name="monthlyFee" required defaultValue={p.monthly} style={{ padding: 6 }} /></label></p>
            {GROUPS.map((g) => (
              <div key={g}><h3>{g}</h3>
                {FEATURES.filter((f) => f.group === g).map((f) => {
                  const cur = p.features.find((x) => x.key === f.key)!;
                  return f.kind === "flag" ? (
                    <p key={f.key} style={{ margin: "4px 0" }}><label><input type="checkbox" name={`flag_${f.key}`} defaultChecked={cur.included} /> {f.label}{!f.implemented && <> <span className="tag">not built yet</span></>}</label></p>
                  ) : (
                    <p key={f.key} style={{ margin: "4px 0" }}><label>{f.label} ({f.unit}){!f.implemented && <> <span className="tag">not built yet</span></>}{" "}
                      <input name={`limit_${f.key}`} defaultValue={String(cur.value)} style={{ width: 90, padding: 4 }} /></label></p>
                  );
                })}
              </div>
            ))}
            <p><button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Save Tier {p.tier}</button></p>
          </form>
        </details>
      ))}

      <h2>How the pricing page looks</h2>
      <p><a href="/pricing" target="_blank" rel="noopener">Open the public pricing page</a></p>
      <PricingView data={data} />
    </AdminShell>
  );
}

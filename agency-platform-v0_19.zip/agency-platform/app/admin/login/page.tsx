import { redirect } from "next/navigation";
import { AdminShell } from "../../../src/web/AdminShell";
import { assertAdminHost, getCurrentAdmin } from "../../../src/web/adminSession";
import { loginAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  await assertAdminHost();
  if (await getCurrentAdmin()) redirect("/admin");
  const { error } = await searchParams;
  return (
    <AdminShell bare narrow>
      <h1>Admin login</h1>
      {error === "1" && <p className="warn">Incorrect email or password.</p>}
      {error === "2" && <p className="warn">Too many attempts. Please wait 15 minutes and try again.</p>}
      <form action={loginAction} className="card">
        <p><label>Email<br /><input name="email" type="email" required autoComplete="username" maxLength={254} style={{ width: "100%", padding: 8 }} /></label></p>
        <p><label>Password<br /><input name="password" type="password" required autoComplete="current-password" maxLength={1000} style={{ width: "100%", padding: 8 }} /></label></p>
        <button className="btn" type="submit" style={{ border: 0, cursor: "pointer" }}>Log in</button>
      </form>
    </AdminShell>
  );
}

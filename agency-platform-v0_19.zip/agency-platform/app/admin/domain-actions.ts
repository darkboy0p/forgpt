"use server";
import { redirect } from "next/navigation";
import { requireAdmin } from "../../src/web/adminSession";
import { runtime } from "../../src/web/server";
import { checkDomain, checkRouting } from "../../src/domains/service";
import { applyTemplateLookToClient } from "../../src/clients/templateLook";

const SLUG = /^[a-z0-9][a-z0-9-]{1,40}$/;
const s = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.slice(0, max) : "");

/** Re-checks one domain: the proof record while it is pending, or where it points once it is verified. */
export async function recheckDomainAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const { control, env } = runtime();
  const hostname = s(formData.get("hostname"), 253).toLowerCase();
  const back = s(formData.get("back"), 40) === "client" ? `/admin/clients/${s(formData.get("slug"), 41)}` : "/admin/domains";
  const row = (await control.query("SELECT tenant_id, status FROM domains WHERE hostname = $1 AND status <> 'removed'", [hostname])).rows[0];
  if (!row) redirect(`${back}?notice=domain_unknown`);
  const r = row.status === "verified" ? await checkRouting(control, env, row.tenant_id, hostname, admin.email) : await checkDomain(control, row.tenant_id, hostname, admin.email);
  const code = r.ok ? ("report" in r ? `routing_${r.report.points}` : "domain_verified") : `domain_${r.error}`;
  redirect(`${back}${back.includes("?") ? "&" : "?"}notice=${code}`);
}

export async function applyTemplateLookAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = s(formData.get("slug"), 41);
  if (!SLUG.test(slug)) redirect("/admin");
  const { control, mgr } = runtime();
  const r = await applyTemplateLookToClient(control, mgr, slug, admin.email);
  redirect(`/admin/clients/${slug}?notice=${r.ok ? "look_applied" : r.error}`);
}

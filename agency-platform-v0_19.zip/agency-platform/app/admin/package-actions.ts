"use server";

import { redirect } from "next/navigation";
import { runtime } from "../../src/web/server";
import { requireAdmin } from "../../src/web/adminSession";
import { updatePackage } from "../../src/packages/admin";
import { saveSettings, markRequestDone } from "../../src/packages/requests";
import { FEATURES } from "../../src/packages/features";

const str = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.slice(0, max) : "");

export async function updatePackageAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const tier = Number(str(formData.get("tier"), 3));
  const flags: Record<string, boolean> = {}, limits: Record<string, string> = {};
  for (const f of FEATURES) {
    if (f.kind === "flag") flags[f.key] = formData.get(`flag_${f.key}`) === "on"; // every feature is on the form, so unticked means off
    else limits[f.key] = str(formData.get(`limit_${f.key}`), 10);
  }
  const r = await updatePackage(runtime().control, tier, { description: str(formData.get("description"), 400), setupFee: str(formData.get("setupFee"), 15), monthlyFee: str(formData.get("monthlyFee"), 15), flags, limits }, admin.email);
  redirect(r.ok ? `/admin/packages?notice=${r.changes ? "saved" : "nochange"}&tier=${tier}#tier${tier}` : `/admin/packages?error=${r.error}&tier=${tier}#tier${tier}`);
}

export async function saveSettingsAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const r = await saveSettings(runtime().control, { agency_name: str(formData.get("agency_name"), 200), agency_whatsapp: str(formData.get("agency_whatsapp"), 40), agency_note: str(formData.get("agency_note"), 500), agency_payment_note: str(formData.get("agency_payment_note"), 500) }, admin.email);
  redirect(r.ok ? "/admin/packages?notice=settings" : `/admin/packages?error=${r.error}`);
}

export async function markRequestDoneAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  await markRequestDone(runtime().control, str(formData.get("id"), 40), admin.email);
  redirect("/admin/requests");
}

import { requireAdmin } from "../../../src/web/adminSession";
import { runtime } from "../../../src/web/server";
import { AdminShell } from "../../../src/web/AdminShell";
import { TEMPLATES } from "../../../src/config/templates";
import { TEMPLATE_LOOKS } from "../../../src/config/templateLooks";
import { themeByKey } from "../../../src/config/themes";
import { PACKAGE_NAMES } from "../../../src/config/templates";

export const dynamic = "force-dynamic";

export default async function TemplatesPage() {
  await requireAdmin();
  const { control } = runtime();
  const users = (await control.query("SELECT template_key, slug, business_name FROM tenants ORDER BY business_name")).rows as { template_key: string; slug: string; business_name: string }[];
  return (
    <AdminShell>
      <h1>Templates</h1>
      <p className="lead">The starting points you can give a client. Every template is drawn by the same engine, so every client can change colours, sizes, angles and layout. A template decides which pages and sections a site begins with and its first look. Change a client&apos;s template on their page, and optionally give their draft the template&apos;s look.</p>
      <div className="theme-grid">
        {Object.entries(TEMPLATES).map(([key, tpl]) => {
          const look = TEMPLATE_LOOKS[key as keyof typeof TEMPLATES], theme = themeByKey(look.themeKey)!;
          const mine = users.filter((u) => u.template_key === key);
          return (
            <section className="card" key={key}>
              <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>{[theme.primary, theme.accent].map((c) => <i key={c} style={{ width: 22, height: 22, borderRadius: "50%", background: c, border: "1px solid rgba(0,0,0,.15)", display: "block" }} />)}</div>
              <h2 style={{ margin: "0 0 4px" }}>{tpl.label} <span className={tpl.built ? "chip" : "chip off"}>{tpl.built ? "Ready" : "Not built"}</span></h2>
              <p className="hint" style={{ margin: "0 0 8px" }}>{tpl.blurb}</p>
              <p style={{ margin: "0 0 6px", fontSize: ".9rem" }}>From <strong>{PACKAGE_NAMES[tpl.minTier as keyof typeof PACKAGE_NAMES]}</strong> and up. Starts with: {look.sections.join(", ")}.</p>
              <p style={{ margin: 0, fontSize: ".9rem" }}><strong>{mine.length}</strong> client{mine.length === 1 ? "" : "s"}{mine.length > 0 && ": "}{mine.slice(0, 6).map((u, i) => <span key={u.slug}>{i > 0 && ", "}<a href={`/admin/clients/${u.slug}`}>{u.business_name}</a></span>)}{mine.length > 6 && ` and ${mine.length - 6} more`}</p>
            </section>
          );
        })}
      </div>
    </AdminShell>
  );
}

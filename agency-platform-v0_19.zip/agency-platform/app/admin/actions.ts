"use server";

import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { runtime } from "../../src/web/server";
import { assertAdminHost, SESSION_COOKIE } from "../../src/web/adminSession";
import { attemptLogin } from "../../src/auth/login";
import { revokeSession } from "../../src/auth/sessions";
import { requireAdmin } from "../../src/web/adminSession";
import { createClient, retryProvisioning } from "../../src/clients/createClient";
import { createProvider } from "../../src/provisioning/providers/index";
import { normalizeHostname } from "../../src/tenancy/hostname";
import { linkPurchaseToClient } from "../../src/orders/service";
import { suspendClient, reactivateClient } from "../../src/clients/lifecycle";
import { changePackage } from "../../src/clients/packages";
import { applyTemplateLookToClient } from "../../src/clients/templateLook";

function clientIp(h: Headers): string {
  // Behind Vercel/Cloudflare the first forwarded address is the visitor. Treated as a hint only.
  return (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
}

export async function loginAction(formData: FormData): Promise<void> {
  await assertAdminHost();
  const email = formData.get("email");
  const password = formData.get("password");
  if (typeof email !== "string" || typeof password !== "string" || email.length > 254 || password.length > 1000) redirect("/admin/login?error=1");

  const h = await headers();
  const { env, control } = runtime();
  const result = await attemptLogin(control, { email, password, ip: clientIp(h), userAgent: h.get("user-agent") ?? undefined });
  if (!result.ok) redirect(result.reason === "rate_limited" ? "/admin/login?error=2" : "/admin/login?error=1");

  (await cookies()).set(SESSION_COOKIE, result.token, {
    httpOnly: true,                       // JavaScript in the page cannot read it
    sameSite: "strict",                   // not sent on cross-site requests
    secure: env.APP_ENV !== "development", // HTTPS only outside local development
    path: "/",
    expires: result.expiresAt,
  });
  redirect("/admin");
}

export async function logoutAction(): Promise<void> {
  await assertAdminHost();
  const jar = await cookies();
  await revokeSession(runtime().control, jar.get(SESSION_COOKIE)?.value);
  jar.delete(SESSION_COOKIE);
  redirect("/admin/login");
}

// ---- Client management (every action re-checks the login: hiding a button is not security) ----

const SLUG_PARAM = /^[a-z0-9][a-z0-9-]{1,40}$/;
const str = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.slice(0, max) : "");

export async function createClientAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const { env, control } = runtime();
  let provider;
  try { provider = createProvider(env); } catch { redirect("/admin?error=provider_unavailable"); }

  const result = await createClient(control, provider, env.SECRETS_MASTER_KEY, {
    businessName: str(formData.get("businessName"), 200),
    slug: str(formData.get("slug"), 100),
    packageTier: Number(str(formData.get("packageTier"), 5)),
    templateKey: str(formData.get("templateKey"), 50),
    hostname: str(formData.get("hostname"), 300),
  }, admin.email);

  const orderId = str(formData.get("orderId"), 40);
  if (result.ok && orderId) await linkPurchaseToClient(control, orderId, result.tenantId, admin.email);
  if (result.ok) redirect(`/admin/clients/${result.slug}?notice=created`);
  if (result.error === "provision_failed") redirect(`/admin/clients/${result.slug}?notice=failed`);
  redirect(`/admin?error=${result.error}${orderId ? `&order=${encodeURIComponent(orderId)}` : ""}`);
}

export async function retryProvisioningAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = str(formData.get("slug"), 100);
  if (!SLUG_PARAM.test(slug)) redirect("/admin");
  const { env, control } = runtime();
  let provider;
  try { provider = createProvider(env); } catch { redirect(`/admin/clients/${slug}?notice=provider_unavailable`); }
  const r = await retryProvisioning(control, provider, env.SECRETS_MASTER_KEY, slug, admin.email);
  redirect(`/admin/clients/${slug}?notice=${r.ok ? "retried" : r.error}`);
}

/** DEVELOPMENT ONLY shortcut (no DNS check). Real domain verification is a later phase. */
export async function verifyDomainDevAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const { env, control } = runtime();
  const slug = str(formData.get("slug"), 100);
  if (env.APP_ENV !== "development" || !SLUG_PARAM.test(slug)) redirect("/admin");
  const host = normalizeHostname(str(formData.get("hostname"), 300));
  if (host) {
    const r = await control.query(
      `UPDATE domains SET status='verified', verified_at=now()
        WHERE hostname=$1 AND status<>'removed' AND tenant_id=(SELECT id FROM tenants WHERE slug=$2) RETURNING tenant_id`, [host, slug]);
    if (r.rowCount) await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,'domain.verified.dev-shortcut',$2,$3)",
      [admin.email, r.rows[0].tenant_id, JSON.stringify({ hostname: host })]);
  }
  redirect(`/admin/clients/${slug}?notice=verified`);
}

export async function suspendClientAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = str(formData.get("slug"), 100);
  if (!SLUG_PARAM.test(slug)) redirect("/admin");
  const { control, mgr } = runtime();
  const r = await suspendClient(control, slug, str(formData.get("reason"), 300), admin.email);
  if (r.ok) await mgr.closePool(r.tenantId); // close any open connection to that client's database right away
  redirect(`/admin/clients/${slug}?notice=${r.ok ? "suspended" : r.error}`);
}

export async function reactivateClientAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = str(formData.get("slug"), 100);
  if (!SLUG_PARAM.test(slug)) redirect("/admin");
  const r = await reactivateClient(runtime().control, slug, admin.email);
  redirect(`/admin/clients/${slug}?notice=${r.ok ? "reactivated" : r.error}`);
}

export async function changePackageAction(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const slug = str(formData.get("slug"), 100);
  if (!SLUG_PARAM.test(slug)) redirect("/admin");
  const r = await changePackage(runtime().control, slug, Number(str(formData.get("packageTier"), 3)), str(formData.get("templateKey"), 50),
    formData.get("confirmDowngrade") === "yes", admin.email);
  if (r.ok && formData.get("applyLook") === "yes") await applyTemplateLookToClient(runtime().control, runtime().mgr, slug, admin.email);
  redirect(`/admin/clients/${slug}?notice=${r.ok ? (r.downgrade ? "package_downgraded" : "package_changed") : r.error}`);
}

import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { runtime } from "../../../src/web/server";
import { isPlatformHost } from "../../../src/web/adminAccess";
import { TemplateSite, loadShopContext } from "../../../src/web/renderSite";
import { OrderPage } from "../../../src/web/templates/ShopBlocks";
import { getOrderByToken } from "../../../src/shop/orders";

export const dynamic = "force-dynamic";
export const metadata = { title: "Your order", robots: { index: false, follow: false } };

export default async function OrderRoute({ params }: { params: Promise<{ token: string }> }) {
  const host = (await headers()).get("host") ?? "";
  if (isPlatformHost(runtime().env, host)) notFound();
  const { token } = await params;
  const ctx = await loadShopContext(host);
  const found = await getOrderByToken(ctx.pool, token);
  if (!found) notFound();
  return (
    <TemplateSite templateKey={ctx.site.tenant.templateKey} businessName={ctx.site.tenant.businessName} config={ctx.config} page="products" siteUrl={ctx.siteUrl} shop={ctx.shop}
      body={<OrderPage order={found.order} items={found.items} whatsapp={ctx.config.content.whatsapp} businessName={ctx.site.tenant.businessName} />} />
  );
}

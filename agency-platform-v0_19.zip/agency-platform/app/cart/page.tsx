import { headers } from "next/headers";
import { notFound } from "next/navigation";
import { runtime } from "../../src/web/server";
import { isPlatformHost } from "../../src/web/adminAccess";
import { TemplateSite, loadShopContext } from "../../src/web/renderSite";
import { CartPage } from "../../src/web/templates/ShopBlocks";

export const dynamic = "force-dynamic";
export const metadata = { title: "Your cart", robots: { index: false, follow: false } };

export default async function CartRoute() {
  const host = (await headers()).get("host") ?? "";
  if (isPlatformHost(runtime().env, host)) notFound();
  const ctx = await loadShopContext(host);
  if (!ctx.ent.shop.cart) notFound(); // simple packages take orders on the product page instead
  return (
    <TemplateSite templateKey={ctx.site.tenant.templateKey} businessName={ctx.site.tenant.businessName} config={ctx.config} page="products" siteUrl={ctx.siteUrl} shop={ctx.shop}
      body={<CartPage checkout={false} discounts={ctx.ent.shop.discounts} orderNote={ctx.settings.order_note || undefined} />} />
  );
}

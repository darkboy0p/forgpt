import { headers } from "next/headers";
import { runtime } from "../src/web/server";
import { isPlatformHost } from "../src/web/adminAccess";
import { renderClientSite, siteMetadata } from "../src/web/renderSite";

export const dynamic = "force-dynamic"; // depends on the visitor's host: never statically cached

export async function generateMetadata() {
  const host = (await headers()).get("host") ?? "";
  if (isPlatformHost(runtime().env, host)) return { title: "Managed Website Platform" };
  return siteMetadata(host, "home");
}

export default async function Home({ searchParams }: { searchParams: Promise<{ sent?: string; ie?: string }> }) {
  const host = (await headers()).get("host") ?? "";
  if (isPlatformHost(runtime().env, host)) {
    const { env, control } = runtime();
    const port = host.includes(":") ? ":" + host.split(":")[1] : "";
    const sites = env.APP_ENV === "development"
      ? (await control.query(
          `SELECT t.business_name, d.hostname FROM domains d JOIN tenants t ON t.id = d.tenant_id
            WHERE d.status = 'verified' AND t.status = 'active' ORDER BY t.business_name LIMIT 30`)).rows
      : [];
    return (
      <div className="wrap" style={{ padding: "48px 20px" }}>
        <h1>Managed Website Platform</h1>
        <p>This is the platform home. Client websites appear on their own verified domains.</p>
        <p><a className="btn" href="/buy">Buy a website</a> <a className="btn" href="/pricing">Packages and pricing</a> <a className="btn" href="/admin">Admin login</a></p>
        {sites.length > 0 && (
          <div className="card">
            <h2 style={{ marginTop: 0 }}>Client websites (shown only on your computer)</h2>
            <p style={{ color: "#5b6573" }}>Each client&apos;s website and dashboard open on the client&apos;s own address, not on localhost.</p>
            <ul>
              {sites.map((s) => (
                <li key={s.hostname}><strong>{s.business_name}</strong>{" "}
                  <a href={`http://${s.hostname}${port}/`}>website</a> &middot; <a href={`http://${s.hostname}${port}/dashboard`}>owner dashboard</a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  }
  return renderClientSite(host, "home", await searchParams);
}

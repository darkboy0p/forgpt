import type { Entitlements } from "../config/entitlements";
import type { SiteConfig } from "../config/siteConfig";
import { blockAllowed } from "./rules";
import { blockSchema, newId, style, type Block } from "./schema";

export interface Preset {
  key: string; name: string; blurb: string;
  theme: { primary: string; accent: string; background: string; text: string; surface: string; font: SiteConfig["theme"]["font"] };
  blocks: (name: string) => Block[];
}
const B = (type: Block["type"], props: Record<string, unknown>, s: Record<string, unknown> = {}): Block => blockSchema.parse({ id: newId(), type, props, style: style.parse(s) });

export const PRESETS: Preset[] = [
  { key: "studio", name: "Studio", blurb: "Clean, modern and airy. Good for most businesses.", theme: { primary: "#2563eb", accent: "#f59e0b", background: "#ffffff", text: "#0f172a", surface: "#f1f5f9", font: "sans" },
    blocks: (n) => [
      B("hero", { title: `${n}: done properly`, subtitle: "A short, confident line about what you do and who you do it for.", buttonLabel: "Get in touch", buttonUrl: "#contact", layout: "split", overlay: 0 }, { padTop: 96, padBottom: 96, headingScale: 1.3, width: "wide", bg: "#f1f5f9" }),
      B("features", { heading: "Why people choose us", items: [{ icon: "⚡", title: "Fast", text: "Quick, reliable service." }, { icon: "💎", title: "Careful", text: "Quality in every detail." }, { icon: "🤝", title: "Friendly", text: "Honest and easy to deal with." }] }, { align: "center" }),
      B("imageText", { heading: "Our story", body: "Tell visitors who you are, how you started and what you care about. A few honest sentences work better than a long speech.", side: "right", buttonLabel: "Contact us", buttonUrl: "#contact" }, { bg: "#f1f5f9", imgHeight: 380, radius: 24 }),
      B("services", { heading: "What we do", items: [{ name: "Service one", text: "A short description of the service.", price: "৳500" }, { name: "Service two", text: "A short description of the service.", price: "৳800" }, { name: "Service three", text: "A short description of the service.", price: "৳1,200" }] }, { align: "center" }),
      B("testimonials", { heading: "Kind words", items: [{ name: "A happy customer", quote: "Great service from start to finish. Highly recommended." }] }, { bg: "#f1f5f9", align: "center" }),
      B("cta", { heading: "Ready when you are", text: "Tell us what you need and we will get back to you today.", buttonLabel: "Message us", buttonUrl: "#contact" }, { bg: "#2563eb", text: "#ffffff", align: "center", padTop: 72, padBottom: 72, radius: 0 }),
      B("contact", { heading: "Contact", showHours: true }, {}),
    ] },
  { key: "bold", name: "Bold", blurb: "Dark, high-contrast and confident. Stands out.", theme: { primary: "#7c5cff", accent: "#22d3ee", background: "#0b1020", text: "#e8ecf8", surface: "#151c33", font: "sans" },
    blocks: (n) => [
      B("hero", { title: n, subtitle: "Make a strong first impression with one clear sentence.", buttonLabel: "Start now", buttonUrl: "#contact", layout: "center", overlay: 0 }, { padTop: 130, padBottom: 130, headingScale: 1.7, align: "center", bg: "#151c33" }),
      B("features", { heading: "What makes us different", items: [{ icon: "🚀", title: "Quick", text: "From idea to done." }, { icon: "🎯", title: "Precise", text: "Exactly what you asked for." }, { icon: "🔒", title: "Reliable", text: "You can count on us." }] }, { align: "center", gap: 28 }),
      B("products", { heading: "Featured", count: 4 }, { bg: "#151c33", columns: 4 }),
      B("cta", { heading: "Let's build something great", text: "Reach out and we will take it from there.", buttonLabel: "Contact us", buttonUrl: "#contact" }, { bg: "#7c5cff", text: "#ffffff", align: "center", padTop: 80, padBottom: 80, radius: 0, headingScale: 1.2 }),
      B("faq", { heading: "Good to know", items: [{ q: "How do I start?", a: "Send us a message. We reply the same day." }, { q: "How much does it cost?", a: "Prices are on this page, or ask us for a quote." }] }, {}),
      B("contact", { heading: "Contact", showHours: true }, { bg: "#151c33" }),
    ] },
  { key: "elegant", name: "Elegant", blurb: "Warm, classic and refined. Great for boutiques and food.", theme: { primary: "#8a5a2b", accent: "#d4a24c", background: "#fbf7f2", text: "#2b2118", surface: "#f1e8dc", font: "serif" },
    blocks: (n) => [
      B("hero", { title: n, subtitle: "Crafted with care. Made to be enjoyed.", buttonLabel: "Visit us", buttonUrl: "#contact", layout: "left", overlay: 0 }, { padTop: 110, padBottom: 110, headingScale: 1.4, bg: "#f1e8dc" }),
      B("imageText", { heading: "A little about us", body: "Share your story: where you began, what you make and what makes it special.", side: "left", buttonLabel: "", buttonUrl: "" }, { imgHeight: 420, radius: 8 }),
      B("services", { heading: "The menu", items: [{ name: "Signature item", text: "Our most loved. Made fresh.", price: "৳450" }, { name: "Seasonal special", text: "Limited, while it lasts.", price: "৳600" }] }, { bg: "#f1e8dc", width: "narrow" }),
      B("gallery", { heading: "A look inside", imageIds: [] }, { columns: 3, radius: 6 }),
      B("testimonials", { heading: "Guests say", items: [{ name: "A regular", quote: "My favourite place. Every time is perfect." }] }, { bg: "#f1e8dc", align: "center", width: "narrow" }),
      B("contact", { heading: "Find us", showHours: true }, { align: "center" }),
    ] },
  { key: "market", name: "Market", blurb: "Shop-first: products up front, easy to buy.", theme: { primary: "#e63946", accent: "#ffb703", background: "#ffffff", text: "#14213d", surface: "#f8f9fb", font: "sans" },
    blocks: (n) => [
      B("hero", { title: `${n}: shop now`, subtitle: "Free delivery over a set amount. Pay cash on delivery.", buttonLabel: "Shop products", buttonUrl: "/products", layout: "center", overlay: 0 }, { padTop: 64, padBottom: 64, headingScale: 1.2, align: "center", bg: "#f8f9fb" }),
      B("products", { heading: "Best sellers", count: 8 }, { columns: 4, gap: 18, padTop: 40 }),
      B("features", { heading: "Shop with confidence", items: [{ icon: "🚚", title: "Fast delivery", text: "Across the country." }, { icon: "💵", title: "Cash on delivery", text: "Pay when it arrives." }, { icon: "↩️", title: "Easy returns", text: "No stress." }] }, { bg: "#f8f9fb", align: "center" }),
      B("testimonials", { heading: "Happy customers", items: [{ name: "A customer", quote: "Fast delivery and exactly as described." }] }, { align: "center" }),
      B("faq", { heading: "Questions", items: [{ q: "How do I order?", a: "Open a product, choose options and add it to your cart." }, { q: "How long is delivery?", a: "Usually two to three days." }] }, { bg: "#f8f9fb" }),
      B("contact", { heading: "Need help?", showHours: true }, {}),
    ] },
];
export const presetByKey = (k: unknown) => PRESETS.find((p) => p.key === k);

/** Gives a site a preset's colours and page. Blocks the package may not use are left out. Text and images the owner wrote are replaced, so the editor warns first. */
export function applyPreset(config: SiteConfig, preset: Preset, businessName: string, ent: Entitlements): SiteConfig {
  const next: SiteConfig = structuredClone(config);
  next.theme = { ...next.theme, ...preset.theme };
  const blocks = preset.blocks(businessName).filter((b) => blockAllowed(b.type, ent));
  next.builder = { blocks };
  return next;
}

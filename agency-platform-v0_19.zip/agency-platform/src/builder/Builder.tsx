"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { saveBuilderAction } from "../../app/dashboard/builder-actions";
import type { SaveResult } from "./save";
import { contrastRatio, MIN_TEXT_CONTRAST } from "../config/color";
import type { ShopView } from "../shop/types";
import { BlockView, type ViewCtx } from "./BlockView";
import { themeVars, viewContext } from "./BuilderSite";
import { PRESETS } from "./presets";
import { BLOCK_LABELS, BLOCK_TYPES, MAX_BLOCKS, newBlock, newId, type Block, type BlockStyle, type BlockType } from "./schema";

export interface Theme { primary: string; accent: string; background: string; text: string; surface: string; font: "sans" | "serif" | "rounded" }
export interface BuilderProps {
  initial: Block[]; theme: Theme; allowed: BlockType[]; canBrand: boolean; media: { id: string; name: string }[];
  contact: { phone?: string; whatsapp?: string; address?: string; email?: string }; hours: Record<string, string | undefined>;
  businessName: string; shopHome: ShopView | null; converted: boolean; limits: { services: number; testimonials: number }; published: boolean;
}
const ERR: Record<string, string> = {
  low_contrast: "Some text is too hard to read on its background. Pick a darker or lighter colour.", not_in_package: "That block is not in your package.", too_many_items: "You have more items than your package allows.",
  invalid: "Something in the page is not valid.", invalid_media: "A photo is no longer available. Choose it again.", invalid_color: "A colour is not valid.", too_many_blocks: "Too many blocks.", publish_failed: "Saved as a draft, but publishing failed.",
};
type Path = (string | number)[];
const setPath = (o: unknown, path: Path, v: unknown) => { let cur = o as Record<string | number, unknown>; path.slice(0, -1).forEach((k) => { cur = cur[k] as Record<string | number, unknown>; }); cur[path[path.length - 1]!] = v; };

function Slider({ label, value, min, max, step = 1, unit = "", onChange }: { label: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (v: number) => void }) {
  return <label className="bld-field"><span>{label}<b>{value}{unit}</b></span><input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} /></label>;
}
function Colour({ label, value, fallback, onChange, onClear }: { label: string; value?: string; fallback: string; onChange: (v: string) => void; onClear?: () => void }) {
  return <div className="bld-field"><span>{label}</span><div className="bld-colour"><input type="color" value={value ?? fallback} onChange={(e) => onChange(e.target.value)} />{onClear && value && <button type="button" onClick={onClear}>Use site colour</button>}</div></div>;
}

export function Builder(props: BuilderProps) {
  const [blocks, setBlocks] = useState<Block[]>(props.initial);
  const [theme, setTheme] = useState<Theme>(props.theme);
  const [sel, setSel] = useState<string | null>(props.initial[0]?.id ?? null);
  const [device, setDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [dirty, setDirty] = useState(props.converted);
  const [msg, setMsg] = useState<{ kind: "ok" | "bad"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [modal, setModal] = useState<null | "add" | "templates">(null);
  const [panel, setPanel] = useState<"block" | "page">("block");
  const history = useRef<{ stack: { blocks: Block[]; theme: Theme }[]; i: number; lastKey: string; at: number }>({ stack: [{ blocks: props.initial, theme: props.theme }], i: 0, lastKey: "", at: 0 });
  const dragFrom = useRef<number | null>(null);

  const commit = useCallback((nb: Block[], nt: Theme, key = "") => {
    const h = history.current, now = Date.now();
    if (key && key === h.lastKey && now - h.at < 900) h.stack[h.i] = { blocks: nb, theme: nt };
    else { h.stack = [...h.stack.slice(0, h.i + 1), { blocks: nb, theme: nt }].slice(-60); h.i = h.stack.length - 1; }
    h.lastKey = key; h.at = now;
    setBlocks(nb); setTheme(nt); setDirty(true); setMsg(null);
  }, []);
  const edit = useCallback((fn: (b: Block[]) => void, key = "") => { const nb = structuredClone(blocks); fn(nb); commit(nb, theme, key); }, [blocks, theme, commit]);
  const undo = () => { const h = history.current; if (h.i > 0) { h.i--; setBlocks(h.stack[h.i]!.blocks); setTheme(h.stack[h.i]!.theme); setDirty(true); } };
  const redo = () => { const h = history.current; if (h.i < h.stack.length - 1) { h.i++; setBlocks(h.stack[h.i]!.blocks); setTheme(h.stack[h.i]!.theme); setDirty(true); } };
  useEffect(() => {
    const key = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && !(e.target as HTMLElement).isContentEditable && !/INPUT|TEXTAREA|SELECT/.test((e.target as HTMLElement).tagName)) { if (e.key === "z") { e.preventDefault(); undo(); } if (e.key === "y") { e.preventDefault(); redo(); } } };
    const leave = (e: BeforeUnloadEvent) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } };
    window.addEventListener("keydown", key); window.addEventListener("beforeunload", leave);
    return () => { window.removeEventListener("keydown", key); window.removeEventListener("beforeunload", leave); };
  });

  const selected = blocks.find((b) => b.id === sel) ?? null;
  const upd = (id: string, fn: (b: Block) => void, key = "") => edit((nb) => { const b = nb.find((x) => x.id === id); if (b) fn(b); }, key ? `${id}:${key}` : "");
  const setStyle = (id: string, patch: Partial<BlockStyle>, key = "style") => upd(id, (b) => { Object.assign(b.style, patch); }, key + Object.keys(patch).join());
  const setProp = (id: string, name: string, v: unknown) => upd(id, (b) => { (b.props as Record<string, unknown>)[name] = v; }, `p:${name}`);
  const move = (i: number, d: number) => edit((nb) => { const j = i + d; if (j < 0 || j >= nb.length) return; [nb[i], nb[j]] = [nb[j]!, nb[i]!]; });

  const ctx: ViewCtx = useMemo(() => viewContext(props.contact, props.hours, {
    businessName: props.businessName, shop: props.shopHome, interactive: false,
    edit: { selectedId: sel, onSelect: (id) => { setSel(id); setPanel("block"); }, onText: (id, path, v) => upd(id, (b) => setPath(b.props, path, v), `t:${path.join(".")}`), onStyle: (id, patch) => setStyle(id, patch, "handle") },
  }), [props.contact, props.hours, props.businessName, props.shopHome, sel, blocks, theme]); // eslint-disable-line react-hooks/exhaustive-deps

  const add = (type: BlockType) => { const nb = newBlock(type); const at = selected ? blocks.findIndex((b) => b.id === selected.id) + 1 : blocks.length; edit((x) => { x.splice(at, 0, nb); }); setSel(nb.id); setModal(null); setPanel("block"); };
  const dup = (i: number) => { const c = structuredClone(blocks[i]!); c.id = newId(); edit((x) => { x.splice(i + 1, 0, c); }); setSel(c.id); };
  const del = (i: number) => { const id = blocks[i]!.id; edit((x) => { x.splice(i, 1); }); if (sel === id) setSel(null); };
  const applyPreset = (key: string) => {
    const p = PRESETS.find((x) => x.key === key)!;
    const nb = p.blocks(props.businessName).filter((b) => props.allowed.includes(b.type));
    commit(nb, props.canBrand ? { ...theme, ...p.theme } : { ...theme, primary: p.theme.primary }); setSel(nb[0]?.id ?? null); setModal(null);
  };

  const save = async (publish: boolean) => {
    setBusy(true); setMsg(null);
    let r: SaveResult;
    try { r = await saveBuilderAction({ blocks: { blocks }.blocks, theme }, publish); } catch { r = { ok: false, error: "invalid" }; }
    setBusy(false);
    if (r.ok) { setDirty(false); setMsg({ kind: "ok", text: publish ? "Published. Your website is updated." : "Draft saved." }); }
    else setMsg({ kind: "bad", text: `${ERR[r.error] ?? "Could not save."}${r.detail && r.error === "low_contrast" ? "" : ""}` });
  };

  const widthPx = device === "desktop" ? "100%" : device === "tablet" ? "820px" : "390px";
  const badContrast = (b: Block) => Boolean(b.style.text) && contrastRatio(b.style.text!, b.style.bg ?? theme.background) < MIN_TEXT_CONTRAST;
  const hasImg = selected && ["hero", "imageText", "gallery"].includes(selected.type);
  const grid = selected && ["features", "services", "products", "gallery", "testimonials"].includes(selected.type);

  return (
    <div className="bld">
      <header className="bld-top">
        <a href="/dashboard" className="bld-back">&larr; Dashboard</a>
        <strong className="bld-title">Edit website</strong>
        <div className="bld-seg" role="group" aria-label="Screen size">{(["desktop", "tablet", "mobile"] as const).map((d) => <button key={d} type="button" aria-pressed={device === d} onClick={() => setDevice(d)}>{d === "desktop" ? "Desktop" : d === "tablet" ? "Tablet" : "Phone"}</button>)}</div>
        <span className="bld-spacer" />
        <button type="button" onClick={undo} disabled={history.current.i === 0} title="Undo (Ctrl+Z)">Undo</button>
        <button type="button" onClick={redo} disabled={history.current.i >= history.current.stack.length - 1} title="Redo (Ctrl+Y)">Redo</button>
        <a className="bld-btn ghost" href="/dashboard/preview" target="_blank" rel="noopener">Preview saved</a>
        <button type="button" className="bld-btn ghost" disabled={busy} onClick={() => save(false)}>Save draft</button>
        <button type="button" className="bld-btn" disabled={busy} onClick={() => save(true)}>{busy ? "Saving..." : "Publish"}</button>
      </header>
      {(msg || dirty || props.converted) && <div className={`bld-msg ${msg?.kind ?? ""}`} role="status">{msg ? msg.text : props.converted && !dirty ? "" : "You have changes that are not saved yet."}{props.converted && dirty && !msg && " Your page was converted to the new builder. Press Save draft or Publish to keep it."}</div>}

      <div className="bld-body">
        <aside className="bld-left" aria-label="Blocks on this page">
          <div className="bld-left-head"><b>Page blocks</b><button type="button" className="bld-btn small" onClick={() => setModal("add")} disabled={blocks.length >= MAX_BLOCKS}>+ Add block</button></div>
          <ol className="bld-list">
            {blocks.map((b, i) => (
              <li key={b.id} className={b.id === sel ? "on" : ""} draggable onDragStart={() => { dragFrom.current = i; }} onDragOver={(e) => e.preventDefault()}
                onDrop={() => { const from = dragFrom.current; dragFrom.current = null; if (from === null || from === i) return; edit((nb) => { const [m] = nb.splice(from, 1); nb.splice(i, 0, m!); }); }}
                onClick={() => { setSel(b.id); setPanel("block"); }}>
                <span className="grip" aria-hidden="true">⋮⋮</span><span className="ico">{BLOCK_LABELS[b.type].icon}</span><span className="nm">{BLOCK_LABELS[b.type].name}{b.style.hidden ? " (hidden)" : ""}</span>
                <span className="acts"><button type="button" aria-label="Move up" onClick={(e) => { e.stopPropagation(); move(i, -1); }} disabled={i === 0}>↑</button><button type="button" aria-label="Move down" onClick={(e) => { e.stopPropagation(); move(i, 1); }} disabled={i === blocks.length - 1}>↓</button></span>
              </li>
            ))}
            {blocks.length === 0 && <li className="empty">No blocks yet. Add one to begin.</li>}
          </ol>
          <button type="button" className="bld-btn ghost wide" onClick={() => setModal("templates")}>Choose a template</button>
        </aside>

        <main className="bld-canvas-wrap" onClick={() => { setSel(null); setPanel("page"); }}>
          <div className="bld-canvas pro bx" style={{ ...themeVars(theme), width: widthPx }} onClick={(e) => e.stopPropagation()}>
            <div className="bx-header"><div className="bx-header-in"><span className="bx-brand">{props.businessName}</span><nav><a>Home</a>{props.shopHome && <a>Shop</a>}</nav></div></div>
            {blocks.map((b) => <BlockView key={b.id} block={b} ctx={ctx} />)}
            {blocks.length === 0 && <div className="bld-empty"><p>This page is empty.</p><button type="button" className="bld-btn" onClick={() => setModal("add")}>Add your first block</button></div>}
          </div>
        </main>

        <aside className="bld-right" aria-label="Settings">
          <div className="bld-tabs"><button type="button" aria-pressed={panel === "block"} onClick={() => setPanel("block")}>Block</button><button type="button" aria-pressed={panel === "page"} onClick={() => setPanel("page")}>Page look</button></div>
          {panel === "page" || !selected ? (
            <div className="bld-panel">
              <h3>Colours and font</h3><p className="bld-hint">Click any text on the page to edit it. These settings change the whole website.</p>
              {(["primary", "accent"] as const).concat(props.canBrand ? ["background", "text", "surface"] as never : []).map((k) => <Colour key={k} label={{ primary: "Main colour", accent: "Accent colour", background: "Page background", text: "Text colour", surface: "Card tint" }[k]} value={theme[k]} fallback={theme[k]} onChange={(v) => commit(blocks, { ...theme, [k]: v }, `th:${k}`)} />)}
              {props.canBrand && <label className="bld-field"><span>Font</span><select value={theme.font} onChange={(e) => commit(blocks, { ...theme, font: e.target.value as Theme["font"] })}><option value="sans">Modern</option><option value="serif">Classic serif</option><option value="rounded">Friendly</option></select></label>}
              {contrastRatio(theme.text, theme.background) < MIN_TEXT_CONTRAST && <p className="bld-warn">Text and background are too similar to read. This cannot be saved.</p>}
            </div>
          ) : (
            <div className="bld-panel" key={selected.id}>
              <h3>{BLOCK_LABELS[selected.type].icon} {BLOCK_LABELS[selected.type].name}</h3>
              <p className="bld-hint">Click the text on the page to type. Drag the blue handles to change the space above and below.</p>
              <div className="bld-row">
                <button type="button" onClick={() => setStyle(selected.id, { hidden: !selected.style.hidden })}>{selected.style.hidden ? "Show block" : "Hide block"}</button>
                <button type="button" onClick={() => dup(blocks.indexOf(selected))}>Duplicate</button>
                <button type="button" className="danger" onClick={() => del(blocks.indexOf(selected))}>Delete</button>
              </div>

              {"buttonLabel" in selected.props && <><label className="bld-field"><span>Button text</span><input value={(selected.props as { buttonLabel: string }).buttonLabel} maxLength={30} onChange={(e) => setProp(selected.id, "buttonLabel", e.target.value)} /></label>
                <label className="bld-field"><span>Button link</span><input value={(selected.props as { buttonUrl: string }).buttonUrl} maxLength={200} placeholder="#contact, /products, https://..., tel:+880..." onChange={(e) => setProp(selected.id, "buttonUrl", e.target.value)} /></label></>}
              {selected.type === "hero" && <><label className="bld-field"><span>Layout</span><select value={selected.props.layout} onChange={(e) => setProp(selected.id, "layout", e.target.value)}><option value="center">Centred</option><option value="left">Left</option><option value="split">Text and photo side by side</option></select></label>
                {selected.props.imageId && selected.props.layout !== "split" && <Slider label="Darkness over photo" value={selected.props.overlay} min={0} max={85} unit="%" onChange={(v) => setProp(selected.id, "overlay", v)} />}</>}
              {selected.type === "imageText" && <label className="bld-field"><span>Photo side</span><select value={selected.props.side} onChange={(e) => setProp(selected.id, "side", e.target.value)}><option value="right">Right</option><option value="left">Left</option></select></label>}
              {selected.type === "products" && <Slider label="Products shown" value={selected.props.count} min={1} max={12} onChange={(v) => setProp(selected.id, "count", v)} />}
              {selected.type === "contact" && <label className="bld-check"><input type="checkbox" checked={selected.props.showHours} onChange={(e) => setProp(selected.id, "showHours", e.target.checked)} /> Show opening hours</label>}

              {(selected.type === "hero" || selected.type === "imageText") && <div className="bld-field"><span>Photo</span><div className="bld-pick">
                <button type="button" aria-pressed={!selected.props.imageId} onClick={() => setProp(selected.id, "imageId", undefined)}>None</button>
                {props.media.map((m) => <button key={m.id} type="button" aria-pressed={selected.props.imageId === m.id} onClick={() => setProp(selected.id, "imageId", m.id)} title={m.name}><img src={`/media/${m.id}`} alt={m.name} /></button>)}</div>
                {props.media.length === 0 && <small>No photos yet. <a href="/dashboard/media" target="_blank" rel="noopener">Upload photos</a>, then reload.</small>}</div>}
              {selected.type === "gallery" && <div className="bld-field"><span>Photos ({selected.props.imageIds.length}/12)</span><div className="bld-pick">
                {props.media.map((m) => { const on = selected.props.imageIds.includes(m.id); return <button key={m.id} type="button" aria-pressed={on} onClick={() => setProp(selected.id, "imageIds", on ? selected.props.imageIds.filter((x) => x !== m.id) : [...selected.props.imageIds, m.id].slice(0, 12))}><img src={`/media/${m.id}`} alt={m.name} /></button>; })}</div>
                {props.media.length === 0 && <small><a href="/dashboard/media" target="_blank" rel="noopener">Upload photos</a>, then reload.</small>}</div>}

              {"items" in selected.props && (() => {
                const max = selected.type === "services" ? props.limits.services : selected.type === "testimonials" ? props.limits.testimonials : selected.type === "features" ? 8 : 10;
                const items = (selected.props as { items: unknown[] }).items;
                const blank = selected.type === "features" ? { icon: "⭐", title: "New point", text: "A short description." } : selected.type === "services" ? { name: "New service", text: "A short description.", price: "" } : selected.type === "testimonials" ? { name: "Customer", quote: "What they said." } : { q: "New question?", a: "The answer." };
                return <div className="bld-field"><span>Items ({items.length}/{max})</span>
                  {items.map((_, i) => <div className="bld-item" key={i}><small>Item {i + 1}: type in it on the page</small><span><button type="button" disabled={i === 0} onClick={() => setProp(selected.id, "items", (() => { const a = [...items]; [a[i - 1], a[i]] = [a[i], a[i - 1]]; return a; })())}>↑</button><button type="button" className="danger" onClick={() => setProp(selected.id, "items", items.filter((_, k) => k !== i))}>Remove</button></span></div>)}
                  <button type="button" disabled={items.length >= max} onClick={() => setProp(selected.id, "items", [...items, blank])}>+ Add item</button></div>;
              })()}

              <h4>Size and spacing</h4>
              <Slider label="Space above" value={selected.style.padTop} min={0} max={240} unit="px" onChange={(v) => setStyle(selected.id, { padTop: v })} />
              <Slider label="Space below" value={selected.style.padBottom} min={0} max={240} unit="px" onChange={(v) => setStyle(selected.id, { padBottom: v })} />
              <label className="bld-field"><span>Content width</span><select value={selected.style.width} onChange={(e) => setStyle(selected.id, { width: e.target.value as BlockStyle["width"] })}><option value="narrow">Narrow</option><option value="normal">Normal</option><option value="wide">Wide</option><option value="full">Full width</option></select></label>
              <div className="bld-field"><span>Alignment</span><div className="bld-seg">{(["left", "center", "right"] as const).map((a) => <button key={a} type="button" aria-pressed={selected.style.align === a} onClick={() => setStyle(selected.id, { align: a })}>{a[0]!.toUpperCase() + a.slice(1)}</button>)}</div></div>
              <Slider label="Text size" value={Math.round(selected.style.fontScale * 100)} min={70} max={200} unit="%" onChange={(v) => setStyle(selected.id, { fontScale: v / 100 })} />
              <Slider label="Heading size" value={Math.round(selected.style.headingScale * 100)} min={60} max={250} unit="%" onChange={(v) => setStyle(selected.id, { headingScale: v / 100 })} />
              {hasImg && <Slider label="Photo height" value={selected.style.imgHeight} min={100} max={720} unit="px" onChange={(v) => setStyle(selected.id, { imgHeight: v })} />}
              {grid && <><Slider label="Columns" value={selected.style.columns} min={1} max={4} onChange={(v) => setStyle(selected.id, { columns: v })} /><Slider label="Gap between items" value={selected.style.gap} min={0} max={64} unit="px" onChange={(v) => setStyle(selected.id, { gap: v })} /></>}
              <Slider label="Corner roundness" value={selected.style.radius} min={0} max={48} unit="px" onChange={(v) => setStyle(selected.id, { radius: v })} />
              <h4>Colours</h4>
              <Colour label="Background" value={selected.style.bg} fallback={theme.background} onChange={(v) => setStyle(selected.id, { bg: v })} onClear={() => setStyle(selected.id, { bg: undefined })} />
              <Colour label="Text colour" value={selected.style.text} fallback={theme.text} onChange={(v) => setStyle(selected.id, { text: v })} onClear={() => setStyle(selected.id, { text: undefined })} />
              {badContrast(selected) && <p className="bld-warn">These colours are too similar to read. This cannot be saved.</p>}
            </div>
          )}
        </aside>
      </div>

      {modal === "add" && (
        <div className="bld-modal" role="dialog" aria-modal="true" aria-label="Add a block" onClick={() => setModal(null)}><div className="bld-sheet" onClick={(e) => e.stopPropagation()}>
          <div className="bld-sheet-head"><h2>Add a block</h2><button type="button" onClick={() => setModal(null)}>Close</button></div>
          <div className="bld-types">{BLOCK_TYPES.map((t) => { const ok = props.allowed.includes(t); return <button key={t} type="button" disabled={!ok} onClick={() => add(t)}><span>{BLOCK_LABELS[t].icon}</span><b>{BLOCK_LABELS[t].name}</b><small>{ok ? BLOCK_LABELS[t].hint : "Not in your package"}</small></button>; })}</div>
        </div></div>
      )}
      {modal === "templates" && (
        <div className="bld-modal" role="dialog" aria-modal="true" aria-label="Choose a template" onClick={() => setModal(null)}><div className="bld-sheet" onClick={(e) => e.stopPropagation()}>
          <div className="bld-sheet-head"><h2>Choose a template</h2><button type="button" onClick={() => setModal(null)}>Close</button></div>
          <p className="bld-hint">A template replaces the blocks and colours on this page with a new design. Your photos stay in your library. You can press Undo straight after if you change your mind.</p>
          <div className="bld-types tpl">{PRESETS.map((p) => (
            <button key={p.key} type="button" onClick={() => applyPreset(p.key)}>
              <span className="swatch" style={{ background: p.theme.background, borderColor: p.theme.primary }}><i style={{ background: p.theme.primary }} /><i style={{ background: p.theme.accent }} /><i style={{ background: p.theme.surface }} /></span>
              <b>{p.name}</b><small>{p.blurb}</small>
            </button>))}</div>
        </div></div>
      )}
    </div>
  );
}

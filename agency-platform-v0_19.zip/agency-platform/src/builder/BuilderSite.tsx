import type { ComponentProps, CSSProperties } from "react";
import { onColor } from "../config/color";
import type { ProfessionalSite } from "../web/templates/ProfessionalSite";
import { CatalogueView } from "../web/templates/ShopBlocks";
import { BusinessJsonLd, Logo, SocialLinks, WhatsAppFloat, mediaUrl } from "../web/templates/blocks";
import { CartLink } from "../web/shop/CartLink";
import { pagePath } from "../web/templates/pages";
import { BlockView, type ViewCtx } from "./BlockView";

const FONT = { sans: 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", sans-serif', serif: 'Georgia, "Times New Roman", serif', rounded: '"Trebuchet MS", "Segoe UI", system-ui, sans-serif' } as const;
const RADIUS = { rounded: "10px", square: "0px", pill: "999px" } as const;

/** CSS variables for a theme. Used by the public site and by the editor canvas so both look the same. */
export function themeVars(th: { primary: string; accent: string; background: string; text: string; surface: string; font: keyof typeof FONT; buttonStyle?: keyof typeof RADIUS }): CSSProperties {
  return {
    ["--primary" as string]: th.primary, ["--accent" as string]: th.accent, ["--bg" as string]: th.background, ["--text" as string]: th.text, ["--soft" as string]: th.surface,
    ["--on-primary" as string]: onColor(th.primary), ["--on-accent" as string]: onColor(th.accent), ["--radius" as string]: RADIUS[th.buttonStyle ?? "rounded"],
    fontFamily: FONT[th.font], background: th.background, color: th.text,
  } as CSSProperties;
}
export function viewContext(c: { phone?: string; whatsapp?: string; address?: string; email?: string }, hours: Record<string, string | undefined>, over: Partial<ViewCtx> & { businessName: string }): ViewCtx {
  return { contact: { ...c, hours }, media: mediaUrl, shop: null, productHref: (s) => `/products/${s}`, interactive: true, ...over };
}

type Props = ComponentProps<typeof ProfessionalSite>;
/** The public website drawn from builder blocks. */
export function BuilderSite({ businessName, config, page, linkFor = (p) => pagePath(p), interactive = true, inquiry, siteUrl, shop = null, body, productHref = (s) => `/products/${s}`, shopNote }: Props) {
  const blocks = config.builder?.blocks ?? [];
  const c = config.content;
  const ctx = viewContext(c, config.hours, { businessName, shop, productHref, interactive, inquiry });
  const ga = config.analytics.ga4;
  const promo = config.promo, promoLive = Boolean(promo.text) && (!promo.until || new Date().toISOString().slice(0, 10) <= promo.until);
  const hasContact = blocks.some((b) => b.type === "contact");
  return (
    <div className="pro bx" style={themeVars(config.theme)}>
      {promoLive && <div className={`promo ${promo.style}`} role="note"><div className="wrap"><span>{promo.text}</span>{promo.linkUrl && <a href={promo.linkUrl}>{promo.linkLabel || "Learn more"}</a>}</div></div>}
      {siteUrl && page === "home" && <BusinessJsonLd config={config} businessName={businessName} url={siteUrl} />}
      {ga && <><script async src={`https://www.googletagmanager.com/gtag/js?id=${ga}`} /><script dangerouslySetInnerHTML={{ __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${ga}');` }} /></>}
      <header className="bx-header"><div className="bx-header-in">
        <a href={linkFor("home")} className="bx-brand"><Logo config={config} businessName={businessName} height={38} /></a>
        <nav>
          <a href={linkFor("home")} aria-current={page === "home" ? "page" : undefined}>Home</a>
          {shop && <a href={linkFor("products")} aria-current={page === "products" ? "page" : undefined}>Shop</a>}
          {hasContact && <a href={page === "home" ? "#contact" : `${linkFor("home")}#contact`}>Contact</a>}
          {shop?.cart && interactive && <CartLink href="/cart" />}
        </nav>
      </div></header>
      <main>
        {body !== undefined ? body : page === "products" && shop ? <CatalogueView shop={shop} baseHref={linkFor("products")} productHref={productHref} interactive={interactive} title="Our products" orderNote={shopNote} />
          : blocks.map((b) => <BlockView key={b.id} block={b} ctx={ctx} />)}
      </main>
      <footer className="bx-footer"><div className="bx-footer-in"><SocialLinks config={config} /><span>&copy; {businessName}</span></div></footer>
      <WhatsAppFloat number={c.whatsapp} side={config.layout.whatsappButton} />
    </div>
  );
}

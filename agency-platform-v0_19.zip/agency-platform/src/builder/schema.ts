import { z } from "zod";

/** The page builder's data. A page is a list of blocks; every block has its own content and its own size, spacing and colour settings. */
const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/);
const txt = (n: number) => z.string().max(n);
const uuid = z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i);
/** https address, phone link or a page/anchor of the same site. Never javascript:, data: or //host. */
export const LINK_RE = /^(https:\/\/[^\s"'<>]{4,300}|tel:\+?[0-9]{5,15}|\/(?!\/)[a-zA-Z0-9\-_\/#]{0,100}|#[a-zA-Z0-9\-_]{1,40})$/;
const link = z.string().regex(LINK_RE).or(z.literal("")).default("");

export const WIDTHS = ["narrow", "normal", "wide", "full"] as const;
export const ALIGNS = ["left", "center", "right"] as const;
export const style = z.object({
  padTop: z.number().int().min(0).max(240).default(56),
  padBottom: z.number().int().min(0).max(240).default(56),
  width: z.enum(WIDTHS).default("normal"),
  align: z.enum(ALIGNS).default("left"),
  fontScale: z.number().min(0.7).max(2).default(1),
  headingScale: z.number().min(0.6).max(2.5).default(1),
  radius: z.number().int().min(0).max(48).default(14),
  imgHeight: z.number().int().min(100).max(720).default(340),
  columns: z.number().int().min(1).max(4).default(3),
  gap: z.number().int().min(0).max(64).default(20),
  bg: hex.optional(),
  text: hex.optional(),
  hidden: z.boolean().default(false),
});
export type BlockStyle = z.infer<typeof style>;
export const DEFAULT_STYLE: BlockStyle = style.parse({});

const id = z.string().regex(/^[a-z0-9]{4,24}$/);
const base = { id, style: style.default({}) };
const item = (shape: z.ZodRawShape, max: number) => z.array(z.object(shape)).max(max).default([]);

export const heroProps = z.object({ title: txt(120).default(""), subtitle: txt(260).default(""), buttonLabel: txt(30).default(""), buttonUrl: link, imageId: uuid.optional(), layout: z.enum(["center", "left", "split"]).default("center"), overlay: z.number().int().min(0).max(85).default(35) });
export const blockSchema = z.discriminatedUnion("type", [
  z.object({ ...base, type: z.literal("hero"), props: heroProps }),
  z.object({ ...base, type: z.literal("text"), props: z.object({ heading: txt(120).default(""), body: txt(3000).default("") }) }),
  z.object({ ...base, type: z.literal("imageText"), props: z.object({ heading: txt(120).default(""), body: txt(3000).default(""), imageId: uuid.optional(), side: z.enum(["left", "right"]).default("right"), buttonLabel: txt(30).default(""), buttonUrl: link }) }),
  z.object({ ...base, type: z.literal("features"), props: z.object({ heading: txt(120).default(""), items: item({ icon: txt(4).default(""), title: txt(60).default(""), text: txt(200).default("") }, 8) }) }),
  z.object({ ...base, type: z.literal("services"), props: z.object({ heading: txt(120).default(""), items: item({ name: txt(80).default(""), text: txt(300).default(""), price: txt(40).default("") }, 12) }) }),
  z.object({ ...base, type: z.literal("products"), props: z.object({ heading: txt(120).default(""), count: z.number().int().min(1).max(12).default(4) }) }),
  z.object({ ...base, type: z.literal("gallery"), props: z.object({ heading: txt(120).default(""), imageIds: z.array(uuid).max(12).default([]) }) }),
  z.object({ ...base, type: z.literal("testimonials"), props: z.object({ heading: txt(120).default(""), items: item({ name: txt(60).default(""), quote: txt(400).default("") }, 8) }) }),
  z.object({ ...base, type: z.literal("faq"), props: z.object({ heading: txt(120).default(""), items: item({ q: txt(120).default(""), a: txt(600).default("") }, 10) }) }),
  z.object({ ...base, type: z.literal("cta"), props: z.object({ heading: txt(120).default(""), text: txt(300).default(""), buttonLabel: txt(30).default(""), buttonUrl: link }) }),
  z.object({ ...base, type: z.literal("contact"), props: z.object({ heading: txt(120).default(""), showHours: z.boolean().default(true) }) }),
  z.object({ ...base, type: z.literal("inquiry"), props: z.object({ heading: txt(120).default(""), text: txt(300).default("") }) }),
  z.object({ ...base, type: z.literal("spacer"), props: z.object({}).default({}) }),
]);
export type Block = z.infer<typeof blockSchema>;
export type BlockType = Block["type"];
export const BLOCK_TYPES: BlockType[] = ["hero", "text", "imageText", "features", "services", "products", "gallery", "testimonials", "faq", "cta", "contact", "inquiry", "spacer"];
export const MAX_BLOCKS = 30;
export const builderSchema = z.object({ blocks: z.array(blockSchema).max(MAX_BLOCKS) });
export type BuilderData = z.infer<typeof builderSchema>;

export const BLOCK_LABELS: Record<BlockType, { name: string; hint: string; icon: string }> = {
  hero: { name: "Big banner", hint: "Headline, text, button and photo", icon: "🏞" }, text: { name: "Text", hint: "A heading and a paragraph", icon: "📝" },
  imageText: { name: "Photo and text", hint: "A photo beside your words", icon: "🖼" }, features: { name: "Highlights", hint: "Short selling points with icons", icon: "✨" },
  services: { name: "Services", hint: "A list with prices", icon: "💼" }, products: { name: "Products", hint: "Your shop items", icon: "🛍" },
  gallery: { name: "Photo gallery", hint: "Your pictures in a grid", icon: "📷" }, testimonials: { name: "Customer reviews", hint: "What customers say", icon: "💬" },
  faq: { name: "Questions", hint: "Common questions and answers", icon: "❓" }, cta: { name: "Call to action", hint: "A bold band with a button", icon: "📣" },
  contact: { name: "Contact", hint: "Phone, address, hours", icon: "📞" }, inquiry: { name: "Message form", hint: "Visitors write to you", icon: "✉️" }, spacer: { name: "Space", hint: "Empty room between blocks", icon: "↕" },
};

let counter = 0;
export const newId = () => `b${Date.now().toString(36)}${(counter++ % 1296).toString(36)}${Math.random().toString(36).slice(2, 6)}`.slice(0, 22);

/** A fresh block with friendly starter content. */
export function newBlock(type: BlockType): Block {
  const st = style.parse({});
  const props: Record<BlockType, unknown> = {
    hero: { title: "Welcome to your business", subtitle: "Say in one line what you offer and who it is for.", buttonLabel: "Contact us", buttonUrl: "#contact" },
    text: { heading: "About us", body: "Tell visitors who you are, what you do and why they can trust you." },
    imageText: { heading: "Our story", body: "Write a short paragraph here and add a photo beside it.", side: "right" },
    features: { heading: "Why choose us", items: [{ icon: "⚡", title: "Fast", text: "Quick service you can count on." }, { icon: "💎", title: "Quality", text: "Careful work, every time." }, { icon: "🤝", title: "Friendly", text: "We treat you like family." }] },
    services: { heading: "Our services", items: [{ name: "Service one", text: "A short description.", price: "৳500" }, { name: "Service two", text: "A short description.", price: "৳800" }] },
    products: { heading: "Our products", count: 4 }, gallery: { heading: "Gallery", imageIds: [] },
    testimonials: { heading: "What customers say", items: [{ name: "A happy customer", quote: "Great service. I will come back." }] },
    faq: { heading: "Questions", items: [{ q: "How do I order?", a: "Message us or use the form below." }] },
    cta: { heading: "Ready to start?", text: "Get in touch today.", buttonLabel: "Contact us", buttonUrl: "#contact" },
    contact: { heading: "Contact", showHours: true }, inquiry: { heading: "Send us a message", text: "We reply quickly." }, spacer: {},
  };
  const padded = type === "spacer" ? { ...st, padTop: 24, padBottom: 24 } : type === "cta" ? { ...st, bg: undefined } : st;
  return blockSchema.parse({ id: newId(), type, props: props[type], style: padded });
}

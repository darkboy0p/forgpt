import type { Entitlements } from "../config/entitlements";
import { contrastRatio, MIN_TEXT_CONTRAST } from "../config/color";
import { builderSchema, MAX_BLOCKS, type Block, type BlockType, type BuilderData } from "./schema";

/** Which kinds of block a package may use. Look and layout controls are in every package; content blocks follow the plan. */
export function blockAllowed(type: BlockType, ent: Entitlements): boolean {
  switch (type) {
    case "products": return ent.shop.products;
    case "features": case "faq": return ent.advancedSections;
    case "gallery": return ent.gallery;
    case "testimonials": return ent.maxTestimonials > 0;
    case "inquiry": return ent.inquiries;
    default: return true;
  }
}
export type BuilderError = "invalid" | "too_many_blocks" | "not_in_package" | "too_many_items" | "low_contrast" | "duplicate_ids";

/** Checks a page sent by the editor. Nothing it says about prices, stock or limits is trusted. */
export function validateBuilder(ent: Entitlements, input: unknown, theme: { background: string; text: string }): { ok: true; data: BuilderData } | { ok: false; error: BuilderError; detail?: string } {
  const parsed = builderSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "invalid", detail: parsed.error.issues[0]?.path.join(".") };
  const blocks = parsed.data.blocks;
  if (blocks.length > MAX_BLOCKS) return { ok: false, error: "too_many_blocks" };
  if (new Set(blocks.map((b) => b.id)).size !== blocks.length) return { ok: false, error: "duplicate_ids" };
  for (const b of blocks) {
    if (!blockAllowed(b.type, ent)) return { ok: false, error: "not_in_package", detail: b.type };
    if (b.type === "services" && b.props.items.length > ent.maxServices) return { ok: false, error: "too_many_items", detail: "services" };
    if (b.type === "testimonials" && b.props.items.length > ent.maxTestimonials) return { ok: false, error: "too_many_items", detail: "testimonials" };
    // A background alone is always readable: the page picks dark or white text for it. Only a text colour the owner chose needs checking.
    if (b.style.text && contrastRatio(b.style.text, b.style.bg ?? theme.background) < MIN_TEXT_CONTRAST) return { ok: false, error: "low_contrast", detail: b.id };
  }
  return { ok: true, data: parsed.data };
}
export const countByType = (blocks: Block[], t: BlockType) => blocks.filter((b) => b.type === t).length;

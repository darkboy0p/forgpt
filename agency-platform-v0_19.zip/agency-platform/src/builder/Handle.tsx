"use client";
import { useRef } from "react";

/** A drag handle on the edge of a block. Dragging up or down changes spacing; the value is reported live. */
export function Handle({ edge, value, onChange, label }: { edge: "top" | "bottom"; value: number; onChange: (v: number) => void; label: string }) {
  const start = useRef<{ y: number; v: number } | null>(null);
  return (
    <div className={`bx-handle ${edge}`} role="slider" aria-label={label} aria-valuenow={value} aria-valuemin={0} aria-valuemax={240} tabIndex={0}
      title={`${label}: ${value}px. Drag to change.`}
      onPointerDown={(e) => { e.stopPropagation(); (e.target as HTMLElement).setPointerCapture(e.pointerId); start.current = { y: e.clientY, v: value }; }}
      onPointerMove={(e) => { if (!start.current) return; const dy = e.clientY - start.current.y; onChange(Math.max(0, Math.min(240, Math.round(start.current.v + (edge === "bottom" ? dy : -dy))))); }}
      onPointerUp={() => { start.current = null; }}
      onKeyDown={(e) => { if (e.key === "ArrowUp" || e.key === "ArrowDown") { e.preventDefault(); const d = (e.key === "ArrowDown" ? 1 : -1) * (edge === "bottom" ? 1 : -1) * 8; onChange(Math.max(0, Math.min(240, value + d))); } }}>
      <span>{value}px</span>
    </div>
  );
}

import type { CSSProperties, ReactNode } from "react";
import { DAYS, DAY_LABELS } from "../config/siteConfig";
import { onColor } from "../config/color";
import type { ShopCard, ShopView } from "../shop/types";
import { ProductCard } from "../web/templates/ShopBlocks";
import { submitInquiryAction } from "../../app/inquiry-actions";
import { Handle } from "./Handle";
import type { Block, BlockStyle } from "./schema";

export interface ViewCtx {
  businessName: string;
  contact: { phone?: string; whatsapp?: string; address?: string; email?: string; hours: Record<string, string | undefined> };
  media: (id: string) => string;
  shop: ShopView | null;
  productHref: (slug: string) => string;
  interactive: boolean;
  inquiry?: { sent?: boolean; error?: string };
  /** Present only in the editor. */
  edit?: { selectedId: string | null; onSelect: (id: string) => void; onText: (id: string, path: (string | number)[], value: string) => void; onStyle: (id: string, patch: Partial<BlockStyle>) => void };
}
const WIDTH = { narrow: 680, normal: 1040, wide: 1280, full: 0 } as const;
const SAMPLE: ShopCard[] = [1, 2, 3, 4].map((n) => ({ id: `s${n}`, slug: "#", name: `Sample product ${n}`, priceBdt: 500 * n, comparePriceBdt: null, hasOptions: false, imageId: null, soldOut: false, categoryName: null, featured: false, salePercent: null }));
const INQUIRY_ERRORS: Record<string, string> = { invalid_name: "Please enter your name.", invalid_contact: "Please enter a valid phone number or email.", invalid_message: "Please write a short message (5 to 1000 characters).", rate_limited: "You have sent several messages recently. Please try again later.", unavailable: "Messages are temporarily unavailable. Please call us instead." };

/** Text that can be typed into directly when the block is opened in the editor. */
function T({ as: Tag = "p", value, id, path, ctx, className, style }: { as?: "h1" | "h2" | "h3" | "p" | "span" | "div"; value: string; id: string; path: (string | number)[]; ctx: ViewCtx; className?: string; style?: CSSProperties }) {
  if (!ctx.edit) return value ? <Tag className={className} style={style}>{value}</Tag> : null;
  return (
    <Tag className={`${className ?? ""} bx-edit`} style={style} contentEditable suppressContentEditableWarning spellCheck={false} data-placeholder="Type here"
      onClick={(e) => e.stopPropagation()} onFocus={() => ctx.edit!.onSelect(id)}
      onBlur={(e) => { const v = e.currentTarget.innerText.replace(/\u00a0/g, " ").trim(); if (v !== value) ctx.edit!.onText(id, path, v); }}
      onPaste={(e) => { e.preventDefault(); document.execCommand("insertText", false, e.clipboardData.getData("text/plain")); }}>{value}</Tag>
  );
}
function Btn({ label, url, ctx, ghost }: { label: string; url: string; ctx: ViewCtx; ghost?: boolean }) {
  if (!label) return null;
  return <a className={ghost ? "bx-btn ghost" : "bx-btn"} href={ctx.edit ? undefined : url || "#"} onClick={ctx.edit ? (e) => e.preventDefault() : undefined} {...(url.startsWith("https://") && !ctx.edit ? { target: "_blank", rel: "noopener noreferrer" } : {})}>{label}</a>;
}
const Img = ({ id, ctx, h, radius, alt = "" }: { id?: string; ctx: ViewCtx; h: number; radius: number; alt?: string }) =>
  id ? <img className="bx-img" src={ctx.media(id)} alt={alt} loading="lazy" style={{ height: h, borderRadius: radius }} /> : <div className="bx-img empty" style={{ height: h, borderRadius: radius }}>{ctx.edit ? "Add a photo in the panel on the right" : ""}</div>;

function Inner({ b, ctx }: { b: Block; ctx: ViewCtx }): ReactNode {
  const s = b.style, id = b.id;
  const grid = { ["--cols" as string]: s.columns, ["--gap" as string]: `${s.gap}px` } as CSSProperties;
  switch (b.type) {
    case "hero": {
      const p = b.props;
      const text = (
        <div className="bx-hero-text">
          <T as="h1" value={p.title} id={id} path={["title"]} ctx={ctx} className="bx-h1" />
          <T value={p.subtitle} id={id} path={["subtitle"]} ctx={ctx} className="bx-lead" />
          <div className="bx-actions"><Btn label={p.buttonLabel} url={p.buttonUrl} ctx={ctx} /></div>
        </div>
      );
      return p.layout === "split" ? <div className="bx-split">{text}<Img id={p.imageId} ctx={ctx} h={s.imgHeight} radius={s.radius} alt={ctx.businessName} /></div> : text;
    }
    case "text": return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><T value={b.props.body} id={id} path={["body"]} ctx={ctx} className="bx-body" /></>;
    case "imageText": {
      const p = b.props;
      return (
        <div className={`bx-split ${p.side === "left" ? "rev" : ""}`}>
          <div><T as="h2" value={p.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><T value={p.body} id={id} path={["body"]} ctx={ctx} className="bx-body" /><div className="bx-actions"><Btn label={p.buttonLabel} url={p.buttonUrl} ctx={ctx} ghost /></div></div>
          <Img id={p.imageId} ctx={ctx} h={s.imgHeight} radius={s.radius} alt={p.heading} />
        </div>
      );
    }
    case "features": return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><div className="bx-grid" style={grid}>{b.props.items.map((it, i) => (
      <div className="bx-card" key={i} style={{ borderRadius: s.radius }}>{(it.icon || ctx.edit) && <T as="div" value={it.icon} id={id} path={["items", i, "icon"]} ctx={ctx} className="bx-icon" />}<T as="h3" value={it.title} id={id} path={["items", i, "title"]} ctx={ctx} className="bx-h3" /><T value={it.text} id={id} path={["items", i, "text"]} ctx={ctx} className="bx-body" /></div>))}</div></>;
    case "services": return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><div className="bx-grid" style={{ ...grid, ["--cols" as string]: Math.min(s.columns, 3) }}>{b.props.items.map((it, i) => (
      <div className="bx-card" key={i} style={{ borderRadius: s.radius }}><div className="bx-row"><T as="h3" value={it.name} id={id} path={["items", i, "name"]} ctx={ctx} className="bx-h3" /><T as="span" value={it.price} id={id} path={["items", i, "price"]} ctx={ctx} className="bx-price" /></div><T value={it.text} id={id} path={["items", i, "text"]} ctx={ctx} className="bx-body" /></div>))}</div></>;
    case "products": {
      const items = ctx.shop?.home.slice(0, b.props.count) ?? (ctx.edit ? SAMPLE.slice(0, b.props.count) : []);
      if (items.length === 0) return null;
      return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><div className="bx-grid" style={grid}>{items.map((p) => <ProductCard key={p.id} p={p} href={ctx.edit ? "#" : ctx.productHref(p.slug)} />)}</div>{!ctx.edit && <p className="bx-actions"><Btn label="See all products" url="/products" ctx={ctx} ghost /></p>}</>;
    }
    case "gallery": return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" />{b.props.imageIds.length === 0 ? <p className="bx-body">{ctx.edit ? "Choose photos in the panel on the right." : ""}</p> : <div className="bx-grid" style={grid}>{b.props.imageIds.map((m) => <img key={m} className="bx-img" src={ctx.media(m)} alt="" loading="lazy" style={{ height: Math.round(s.imgHeight * 0.6), borderRadius: s.radius }} />)}</div>}</>;
    case "testimonials": return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><div className="bx-grid" style={{ ...grid, ["--cols" as string]: Math.min(s.columns, 3) }}>{b.props.items.map((it, i) => (
      <figure className="bx-card bx-quote" key={i} style={{ borderRadius: s.radius }}><T value={it.quote} id={id} path={["items", i, "quote"]} ctx={ctx} className="bx-body" /><figcaption><T as="span" value={it.name} id={id} path={["items", i, "name"]} ctx={ctx} className="bx-price" /></figcaption></figure>))}</div></>;
    case "faq": return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><div className="bx-faq">{b.props.items.map((it, i) => ctx.edit
      ? <div className="bx-card" key={i} style={{ borderRadius: s.radius }}><T as="h3" value={it.q} id={id} path={["items", i, "q"]} ctx={ctx} className="bx-h3" /><T value={it.a} id={id} path={["items", i, "a"]} ctx={ctx} className="bx-body" /></div>
      : <details key={i} style={{ borderRadius: s.radius }}><summary>{it.q}</summary><p className="bx-body">{it.a}</p></details>)}</div></>;
    case "cta": return <div className="bx-cta"><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><T value={b.props.text} id={id} path={["text"]} ctx={ctx} className="bx-lead" /><div className="bx-actions"><Btn label={b.props.buttonLabel} url={b.props.buttonUrl} ctx={ctx} /></div></div>;
    case "contact": {
      const c = ctx.contact, tel = (c.phone ?? "").replace(/[^\d+]/g, "");
      const hours = DAYS.filter((d) => c.hours[d]);
      return <><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><div className="bx-contact">
        <div>{c.address && <p className="bx-body">{c.address}</p>}<div className="bx-actions">{c.phone && <a className="bx-btn" href={`tel:${tel}`}>Call {c.phone}</a>}{c.whatsapp && <a className="bx-btn wa" href={`https://wa.me/${c.whatsapp}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>}</div>{c.email && <p className="bx-body"><a href={`mailto:${c.email}`}>{c.email}</a></p>}{!c.phone && !c.whatsapp && !c.address && !c.email && <p className="bx-body">{ctx.edit ? "Add your phone, address and email in Settings." : ""}</p>}</div>
        {b.props.showHours && hours.length > 0 && <table className="bx-hours"><tbody>{hours.map((d) => <tr key={d}><td>{DAY_LABELS[d]}</td><td>{c.hours[d]}</td></tr>)}</tbody></table>}
      </div></>;
    }
    case "inquiry": return <div style={{ maxWidth: 560, margin: s.align === "center" ? "0 auto" : undefined }}><T as="h2" value={b.props.heading} id={id} path={["heading"]} ctx={ctx} className="bx-h2" /><T value={b.props.text} id={id} path={["text"]} ctx={ctx} className="bx-body" />
      {ctx.inquiry?.sent && <p className="bx-note">Thank you! Your message was sent. We will contact you soon.</p>}{ctx.inquiry?.error && <p className="bx-note warn">{INQUIRY_ERRORS[ctx.inquiry.error] ?? "Your message could not be sent."}</p>}
      <form action={ctx.interactive ? submitInquiryAction : undefined} className="bx-form">
        <input type="hidden" name="back" value="/" /><div style={{ position: "absolute", left: "-9999px" }} aria-hidden="true"><label>Website <input name="website" tabIndex={-1} autoComplete="off" /></label></div>
        <label>Your name<input name="name" required minLength={2} maxLength={80} disabled={!ctx.interactive} /></label><label>Phone<input name="phone" maxLength={20} disabled={!ctx.interactive} /></label>
        <label>Email<input name="email" type="email" maxLength={254} disabled={!ctx.interactive} /></label><label>Message<textarea name="message" required minLength={5} maxLength={1000} rows={4} disabled={!ctx.interactive} /></label>
        <button className="bx-btn" type="submit" disabled={!ctx.interactive}>Send message</button></form></div>;
    case "spacer": return <div style={{ height: 1 }} />;
  }
}

/** One block with its own size, spacing, alignment and colours. */
export function BlockView({ block: b, ctx }: { block: Block; ctx: ViewCtx }) {
  const s = b.style;
  const edit = ctx.edit, selected = edit?.selectedId === b.id;
  const hero = b.type === "hero" && b.props.imageId && b.props.layout !== "split";
  const ov = b.type === "hero" ? b.props.overlay / 100 : 0;
  const style = {
    paddingTop: s.padTop, paddingBottom: s.padBottom, textAlign: s.align,
    ["--bx-fs" as string]: s.fontScale, ["--bx-hs" as string]: s.headingScale, ["--bx-r" as string]: `${s.radius}px`,
    ...(s.bg ? { background: s.bg, ["--bg" as string]: s.bg, ["--soft" as string]: s.bg } : {}),
    ...(s.text ? { color: s.text, ["--text" as string]: s.text } : s.bg ? { color: onColor(s.bg), ["--text" as string]: onColor(s.bg) } : {}),
    ...(hero ? { backgroundImage: `linear-gradient(rgba(0,0,0,${ov}),rgba(0,0,0,${ov})), url(${ctx.media((b.props as { imageId: string }).imageId)})`, backgroundSize: "cover", backgroundPosition: "center", color: "#fff", ["--text" as string]: "#fff" } : {}),
  } as CSSProperties;
  if (s.hidden && !edit) return null;
  return (
    <section id={b.type === "contact" ? "contact" : b.type === "inquiry" ? "inquiry" : b.id} className={`bx-block t-${b.type} ${selected ? "selected" : ""} ${s.hidden ? "is-hidden" : ""}`} style={style} onClick={edit ? () => edit.onSelect(b.id) : undefined}>
      {edit && selected && <Handle edge="top" value={s.padTop} label="Space above" onChange={(v) => edit.onStyle(b.id, { padTop: v })} />}
      <div className={`bx-inner w-${s.width} ${b.type === "hero" && b.props.layout === "center" ? "center" : ""}`}>{Inner({ b, ctx })}</div>
      {edit && selected && <Handle edge="bottom" value={s.padBottom} label="Space below" onChange={(v) => edit.onStyle(b.id, { padBottom: v })} />}
    </section>
  );
}
export { WIDTH };

import type { SiteConfig } from "../config/siteConfig";
import { blockSchema, newId, style, type Block } from "./schema";

const PAD = { compact: 32, comfortable: 56, airy: 88 } as const;

/** Turns a site made with the old settings form into builder blocks, so nothing the owner already wrote is lost. */
export function blocksFromConfig(config: SiteConfig, businessName: string): Block[] {
  const c = config.content, L = config.layout;
  const pad = PAD[L.spacing];
  const st = (k: string, extra: Record<string, unknown> = {}) => {
    const o = (config.sectionStyles as Record<string, { background?: string; text?: string; align?: "left" | "center"; spacing?: keyof typeof PAD } | undefined>)[k] ?? {};
    return style.parse({ padTop: PAD[o.spacing ?? L.spacing], padBottom: PAD[o.spacing ?? L.spacing], align: o.align ?? (L.headingAlign === "center" ? "center" : "left"), bg: o.background, text: o.text, ...extra });
  };
  const title = (k: keyof typeof c.sectionTitles, d: string) => c.sectionTitles[k] || d;
  const out: Block[] = [];
  const add = (type: Block["type"], props: Record<string, unknown>, s = st(type)) => out.push(blockSchema.parse({ id: newId(), type, props, style: s }));

  const heroSections = config.sections.includes("hero") ? ["hero"] : [];
  if (heroSections.length || !config.sections.length) {
    add("hero", { title: c.heroTitle || businessName, subtitle: c.heroSubtitle ?? "", buttonLabel: c.cta.label ?? "", buttonUrl: c.cta.url ?? "", imageId: config.images.hero, layout: L.heroAlign === "center" ? "center" : "left", overlay: L.heroOverlay === "none" ? 0 : L.heroOverlay === "strong" ? 65 : 40 },
      style.parse({ padTop: Math.round(pad * 1.6), padBottom: Math.round(pad * 1.6), align: L.heroAlign === "center" ? "center" : "left", width: "normal" }));
  }
  for (const key of config.sections) {
    switch (key) {
      case "about": add(config.images.about ? "imageText" : "text", { heading: title("about", "About us"), body: c.about ?? "", imageId: config.images.about, side: "right" }); break;
      case "highlights": if (c.highlights.length) add("features", { heading: title("highlights", "Why choose us"), items: c.highlights.map((h) => ({ icon: "✓", title: h.title, text: h.text })) }); break;
      case "services": if (c.services.length) add("services", { heading: title("services", "Our services"), items: c.services.map((s) => ({ name: s.name, text: s.description, price: s.price })) }); break;
      case "products": add("products", { heading: title("products", "Our products"), count: 4 }); break;
      case "gallery": if (config.images.gallery.length) add("gallery", { heading: title("gallery", "Gallery"), imageIds: config.images.gallery.slice(0, 12) }); break;
      case "testimonials": if (c.testimonials.length) add("testimonials", { heading: title("testimonials", "What customers say"), items: c.testimonials.map((t) => ({ name: t.name, quote: t.quote })) }); break;
      case "faq": if (c.faqs.length) add("faq", { heading: title("faq", "Questions"), items: c.faqs.map((f) => ({ q: f.question, a: f.answer })) }); break;
      case "inquiry": add("inquiry", { heading: title("inquiry", "Send us a message"), text: "" }); break;
      case "contact": add("contact", { heading: title("contact", "Contact"), showHours: true }); break;
    }
  }
  return out;
}

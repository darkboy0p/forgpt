import type { Pool } from "pg";
import type { Entitlements } from "../config/entitlements";
import { contrastRatio, MIN_TEXT_CONTRAST } from "../config/color";
import { siteConfigV1 } from "../config/siteConfig";
import { loadEditorState, publishDraft, saveDraft } from "../store/siteEditor";
import { validateBuilder, type BuilderError } from "./rules";
import { blockSchema } from "./schema";

export type SaveResult = { ok: true; published: boolean } | { ok: false; error: BuilderError | "invalid_color" | "invalid_choice" | "invalid_media" | "publish_failed"; detail?: string };
export interface ThemeIn { primary?: string; accent?: string; background?: string; text?: string; surface?: string; font?: string }
const HEX = /^#[0-9a-fA-F]{6}$/;
const FONTS = ["sans", "serif", "rounded"];

/** Saves the page the builder sent. Everything is checked again here: block types and limits for the package, colours, readability and that every photo belongs to this website. */
export async function saveBuilder(pool: Pool, ent: Entitlements, actor: string, payload: { blocks: unknown; theme?: ThemeIn }, publish: boolean): Promise<SaveResult> {
  const state = await loadEditorState(pool);
  const base = structuredClone(state.draft ?? state.live);
  const t = payload.theme ?? {};
  const theme = { ...base.theme };
  for (const k of ["primary", "accent", "background", "text", "surface"] as const) {
    if (t[k] === undefined) continue;
    if (typeof t[k] !== "string" || !HEX.test(t[k]!)) return { ok: false, error: "invalid_color" };
    if (k !== "primary" && !ent.branding) continue; // only the main colour is changeable without the colours feature
    theme[k] = t[k]!.trim();
  }
  if (t.font !== undefined && ent.branding) {
    if (!FONTS.includes(t.font)) return { ok: false, error: "invalid_choice" };
    theme.font = t.font as typeof theme.font;
  }
  if (contrastRatio(theme.text, theme.background) < MIN_TEXT_CONTRAST) return { ok: false, error: "low_contrast", detail: "page" };

  const v = validateBuilder(ent, { blocks: payload.blocks }, theme);
  if (!v.ok) return v;
  const ids = new Set<string>();
  for (const b of v.data.blocks) {
    const p = b.props as { imageId?: string; imageIds?: string[] };
    if (p.imageId) ids.add(p.imageId);
    for (const m of p.imageIds ?? []) ids.add(m);
  }
  if (ids.size) {
    const have = new Set((await pool.query("SELECT id FROM media WHERE id = ANY($1::uuid[]) AND kind <> 'product'", [[...ids]])).rows.map((r) => r.id as string));
    if ([...ids].some((i) => !have.has(i))) return { ok: false, error: "invalid_media" };
  }
  const next = siteConfigV1.parse({ ...base, theme, builder: { blocks: v.data.blocks.map((b) => blockSchema.parse(b)) } });
  await saveDraft(pool, next, actor);
  if (publish) { const r = await publishDraft(pool, actor); if (!r.ok) return { ok: false, error: "publish_failed" }; }
  return { ok: true, published: publish };
}

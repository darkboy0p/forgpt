/** Shapes shared between the shop services and the page templates. No server code in here. */
export interface ShopCard {
  id: string; slug: string; name: string;
  priceBdt: number; comparePriceBdt: number | null; hasOptions: boolean;
  imageId: string | null; soldOut: boolean; categoryName: string | null; featured: boolean;
  /** Percent off from a running campaign (the price shown already includes it). */
  salePercent: number | null;
}
export interface ShopCategory { id: string; name: string; slug: string; count: number }
export interface ShopCatalogue { items: ShopCard[]; total: number; page: number; pages: number; q: string; category: string; sort: string }
/** Everything a page template needs to show the shop. `null` means the shop is off or empty. */
export interface ShopView {
  cart: boolean; search: boolean; categories: ShopCategory[];
  home: ShopCard[]; catalogue?: ShopCatalogue;
}
export const SORTS = ["newest", "price_asc", "price_desc", "name"] as const;

/**
 * A missing table or column means a database has not been upgraded yet (the shop tables arrived in a later version).
 * Pages that merely MENTION the shop must keep working in that case, so this turns that one kind of error into a fallback.
 * Any other error is still thrown.
 */
let warned = false;
export const isMissingSchema = (e: unknown): boolean => ["42P01", "42703"].includes((e as { code?: string } | null)?.code ?? "");

export async function orIfMissingSchema<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try { return await fn(); }
  catch (e) {
    if (!isMissingSchema(e)) throw e;
    if (!warned) { warned = true; console.warn("[database] A table or column is missing: this database has not been upgraded. Restart the app (it upgrades itself) or run: npm run db:migrate"); }
    return fallback;
  }
}

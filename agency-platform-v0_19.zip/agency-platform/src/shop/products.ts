import "../db/pgTypes";
import type { Pool } from "pg";
import type { Entitlements } from "../config/entitlements";
import { saveMedia, type MediaError } from "../store/media";
import { clean, likeEscape, toInt, uniqueSlug, UUID, type Db } from "./common";
import { SORTS, type ShopCard, type ShopCatalogue, type ShopCategory } from "./types";

export const PRODUCT_STATUSES = ["active", "sold_out", "hidden"] as const;
export const MAX_VARIANTS = 12;
export const PAGE_SIZE = 12;

export type ProductError = "invalid_name" | "invalid_description" | "invalid_price" | "invalid_compare" | "invalid_sku" | "invalid_status" | "invalid_category"
  | "invalid_stock" | "invalid_variants" | "too_many_products" | "not_in_package" | "not_found";
export interface VariantInput { label: unknown; priceBdt?: unknown; stockQty?: unknown }
export interface ProductInput {
  name: unknown; description?: unknown; priceBdt: unknown; comparePriceBdt?: unknown; sku?: unknown; status?: unknown; categoryId?: unknown;
  isFeatured?: unknown; trackStock?: unknown; stockQty?: unknown; lowStockAt?: unknown; variants?: VariantInput[];
}
interface Clean {
  name: string; description: string; price: number; compare: number | null; sku: string | null; status: string; categoryId: string | null;
  featured: boolean; track: boolean; stock: number; low: number; variants: { label: string; price: number | null; stock: number }[] | undefined;
}

/** Checks everything about a product the owner typed and limits it to what the package allows. */
function validate(ent: Entitlements, i: ProductInput): { ok: true; v: Clean } | { ok: false; error: ProductError } {
  const name = clean(i.name);
  if (name.length < 2 || name.length > 120 || /[<>]/.test(name)) return { ok: false, error: "invalid_name" };
  const description = clean(i.description);
  if (description.length > 3000) return { ok: false, error: "invalid_description" };
  const price = toInt(i.priceBdt, 10_000_000);
  if (price === null) return { ok: false, error: "invalid_price" };
  let compare: number | null = null;
  if (i.comparePriceBdt !== undefined && clean(i.comparePriceBdt) !== "") {
    compare = toInt(i.comparePriceBdt, 10_000_000);
    if (compare === null || compare <= price) return { ok: false, error: "invalid_compare" };
  }
  const sku = clean(i.sku);
  if (sku.length > 40 || /[<>]/.test(sku)) return { ok: false, error: "invalid_sku" };
  const status = clean(i.status) || "active";
  if (!(PRODUCT_STATUSES as readonly string[]).includes(status)) return { ok: false, error: "invalid_status" };
  const categoryId = clean(i.categoryId);
  if (categoryId && (!UUID.test(categoryId))) return { ok: false, error: "invalid_category" };
  if (categoryId && !ent.shop.categories) return { ok: false, error: "not_in_package" };
  const featured = i.isFeatured === true || i.isFeatured === "on";
  if (featured && !ent.shop.featured) return { ok: false, error: "not_in_package" };
  const track = i.trackStock === true || i.trackStock === "on";
  if (track && !ent.shop.stockQty) return { ok: false, error: "not_in_package" };
  const stock = i.stockQty === undefined || clean(i.stockQty) === "" ? 0 : toInt(i.stockQty, 1_000_000);
  const low = i.lowStockAt === undefined || clean(i.lowStockAt) === "" ? 3 : toInt(i.lowStockAt, 1_000_000);
  if (stock === null || low === null) return { ok: false, error: "invalid_stock" };
  let variants: Clean["variants"];
  if (i.variants !== undefined) {
    variants = [];
    const seen = new Set<string>();
    for (const row of i.variants) {
      const label = clean(row.label);
      if (!label && clean(row.priceBdt) === "" && clean(row.stockQty) === "") continue; // an empty row
      if (!label || label.length > 40 || /[<>]/.test(label) || seen.has(label.toLowerCase())) return { ok: false, error: "invalid_variants" };
      seen.add(label.toLowerCase());
      const vp = clean(row.priceBdt) === "" || row.priceBdt === undefined ? null : toInt(row.priceBdt, 10_000_000);
      const vs = clean(row.stockQty) === "" || row.stockQty === undefined ? 0 : toInt(row.stockQty, 1_000_000);
      if ((vp === null && clean(row.priceBdt) !== "" && row.priceBdt !== undefined) || vs === null) return { ok: false, error: "invalid_variants" };
      variants.push({ label, price: vp, stock: vs });
    }
    if (variants.length > MAX_VARIANTS) return { ok: false, error: "invalid_variants" };
    if (variants.length && !ent.shop.variants) return { ok: false, error: "not_in_package" };
  }
  return { ok: true, v: { name, description, price, compare, sku: sku || null, status, categoryId: categoryId || null, featured, track, stock, low, variants } };
}

async function categoryExists(db: Db, id: string): Promise<boolean> {
  return Boolean((await db.query("SELECT 1 FROM shop_categories WHERE id = $1", [id])).rowCount);
}

export async function createProduct(pool: Pool, ent: Entitlements, input: ProductInput): Promise<{ ok: true; id: string; slug: string } | { ok: false; error: ProductError }> {
  if (!ent.shop.products) return { ok: false, error: "not_in_package" };
  const r = validate(ent, input);
  if (!r.ok) return r;
  const v = r.v;
  if ((await pool.query("SELECT count(*)::int AS n FROM shop_products")).rows[0].n >= ent.shop.maxProducts) return { ok: false, error: "too_many_products" };
  if (v.categoryId && !(await categoryExists(pool, v.categoryId))) return { ok: false, error: "invalid_category" };
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const slug = await uniqueSlug(client, "products", v.name);
    const ins = await client.query(
      `INSERT INTO shop_products (name, slug, category_id, description, price_bdt, compare_price_bdt, sku, status, is_featured, track_stock, stock_qty, low_stock_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
      [v.name, slug, v.categoryId, v.description, v.price, v.compare, v.sku, v.status, v.featured, v.track, v.stock, v.low]);
    await syncVariants(client, ins.rows[0].id, v.variants ?? []);
    await client.query("COMMIT");
    return { ok: true, id: ins.rows[0].id, slug };
  } catch (e) { await client.query("ROLLBACK"); throw e; } finally { client.release(); }
}

/** Updates variants by name so their ids (and so open carts) stay valid. */
async function syncVariants(db: Db, productId: string, rows: { label: string; price: number | null; stock: number }[]): Promise<void> {
  const have = new Map((await db.query("SELECT id, label FROM shop_product_variants WHERE product_id = $1", [productId])).rows.map((r) => [r.label as string, r.id as string]));
  let order = 0;
  for (const row of rows) {
    const id = have.get(row.label);
    if (id) await db.query("UPDATE shop_product_variants SET price_bdt = $2, stock_qty = $3, sort_order = $4 WHERE id = $1", [id, row.price, row.stock, order]);
    else await db.query("INSERT INTO shop_product_variants (product_id, label, price_bdt, stock_qty, sort_order) VALUES ($1,$2,$3,$4,$5)", [productId, row.label, row.price, row.stock, order]);
    order++;
  }
  const keep = rows.map((r) => r.label);
  await db.query("DELETE FROM shop_product_variants WHERE product_id = $1 AND NOT (label = ANY($2::text[]))", [productId, keep]);
}

export async function updateProduct(pool: Pool, ent: Entitlements, id: string, input: ProductInput): Promise<{ ok: true } | { ok: false; error: ProductError }> {
  if (!UUID.test(id)) return { ok: false, error: "not_found" };
  const r = validate(ent, input);
  if (!r.ok) return r;
  const v = r.v;
  if (v.categoryId && !(await categoryExists(pool, v.categoryId))) return { ok: false, error: "invalid_category" };
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const cur = (await client.query("SELECT name FROM shop_products WHERE id = $1 FOR UPDATE", [id])).rows[0];
    if (!cur) { await client.query("ROLLBACK"); return { ok: false, error: "not_found" }; }
    // The address of a product only changes when its name does.
    const slugSql = cur.name === v.name ? "" : ", slug = $13";
    const params: unknown[] = [id, v.name, v.categoryId, v.description, v.price, v.compare, v.sku, v.status, v.featured, v.track, v.stock, v.low];
    if (slugSql) params.push(await uniqueSlug(client, "products", v.name, id));
    await client.query(
      `UPDATE shop_products SET name=$2, category_id=$3, description=$4, price_bdt=$5, compare_price_bdt=$6, sku=$7, status=$8, is_featured=$9, track_stock=$10, stock_qty=$11, low_stock_at=$12, updated_at=now()${slugSql} WHERE id=$1`, params);
    if (v.variants !== undefined) await syncVariants(client, id, v.variants);
    await client.query("COMMIT");
    return { ok: true };
  } catch (e) { await client.query("ROLLBACK"); throw e; } finally { client.release(); }
}

/** Deletes a product and its photos. Past orders keep their own copy of the name and price. */
export async function deleteProduct(pool: Pool, id: string): Promise<boolean> {
  if (!UUID.test(id)) return false;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("DELETE FROM media WHERE id IN (SELECT media_id FROM shop_product_images WHERE product_id = $1)", [id]);
    const r = await client.query("DELETE FROM shop_products WHERE id = $1", [id]);
    await client.query("COMMIT");
    return (r.rowCount ?? 0) > 0;
  } catch (e) { await client.query("ROLLBACK"); throw e; } finally { client.release(); }
}

// ---------- photos ----------
export type ImageError = MediaError | "too_many_images" | "not_found";
export async function addProductImage(pool: Pool, ent: Entitlements, productId: string, file: { filename: unknown; bytes: Uint8Array }, actor: string): Promise<{ ok: true; mediaId: string } | { ok: false; error: ImageError }> {
  if (!UUID.test(productId)) return { ok: false, error: "not_found" };
  if (!ent.shop.images) return { ok: false, error: "not_in_package" };
  const p = (await pool.query("SELECT name FROM shop_products WHERE id = $1", [productId])).rows[0];
  if (!p) return { ok: false, error: "not_found" };
  const n = (await pool.query("SELECT count(*)::int AS n FROM shop_product_images WHERE product_id = $1", [productId])).rows[0].n as number;
  if (n >= ent.shop.maxProductImages) return { ok: false, error: "too_many_images" };
  const m = await saveMedia(pool, ent, { kind: "product", filename: file.filename, alt: p.name, bytes: file.bytes }, actor);
  if (!m.ok) return m;
  try {
    await pool.query("INSERT INTO shop_product_images (product_id, media_id, position) VALUES ($1,$2,$3)", [productId, m.id, n]);
  } catch (e) { await pool.query("DELETE FROM media WHERE id = $1", [m.id]); throw e; }
  return { ok: true, mediaId: m.id };
}
export async function removeProductImage(pool: Pool, productId: string, mediaId: string): Promise<boolean> {
  if (!UUID.test(productId) || !UUID.test(mediaId)) return false;
  const r = await pool.query("DELETE FROM media WHERE id = $1 AND id IN (SELECT media_id FROM shop_product_images WHERE product_id = $2)", [mediaId, productId]);
  return (r.rowCount ?? 0) > 0;
}
/** Makes one photo the main (first) photo; the others keep their order after it. */
export async function makeMainImage(pool: Pool, productId: string, mediaId: string): Promise<boolean> {
  if (!UUID.test(productId) || !UUID.test(mediaId)) return false;
  const ids: string[] = (await pool.query("SELECT media_id FROM shop_product_images WHERE product_id = $1 ORDER BY position, id", [productId])).rows.map((r) => r.media_id);
  if (!ids.includes(mediaId)) return false;
  const next = [mediaId, ...ids.filter((x) => x !== mediaId)];
  for (let i = 0; i < next.length; i++) await pool.query("UPDATE shop_product_images SET position = $2 WHERE product_id = $1 AND media_id = $3", [productId, i, next[i]]);
  return true;
}

// ---------- categories ----------
export type CategoryError = "invalid_name" | "not_in_package" | "not_found" | "too_many";
export async function listCategories(pool: Pool, opts: { visibleOnly?: boolean } = {}): Promise<(ShopCategory & { is_visible: boolean; sort_order: number })[]> {
  const r = await pool.query(
    `SELECT c.id, c.name, c.slug, c.is_visible, c.sort_order,
            (SELECT count(*)::int FROM shop_products p WHERE p.category_id = c.id AND p.status <> 'hidden') AS count
       FROM shop_categories c ${opts.visibleOnly ? "WHERE c.is_visible" : ""} ORDER BY c.sort_order, c.name`);
  return r.rows;
}
export async function createCategory(pool: Pool, ent: Entitlements, nameRaw: unknown): Promise<{ ok: true; id: string } | { ok: false; error: CategoryError }> {
  if (!ent.shop.categories) return { ok: false, error: "not_in_package" };
  const name = clean(nameRaw);
  if (name.length < 2 || name.length > 60 || /[<>]/.test(name)) return { ok: false, error: "invalid_name" };
  if ((await pool.query("SELECT count(*)::int AS n FROM shop_categories")).rows[0].n >= 60) return { ok: false, error: "too_many" };
  const slug = await uniqueSlug(pool, "categories", name);
  const next = (await pool.query("SELECT COALESCE(max(sort_order), -1) + 1 AS n FROM shop_categories")).rows[0].n;
  const r = await pool.query("INSERT INTO shop_categories (name, slug, sort_order) VALUES ($1,$2,$3) RETURNING id", [name, slug, next]);
  return { ok: true, id: r.rows[0].id };
}
export async function updateCategory(pool: Pool, id: string, input: { name?: unknown; isVisible?: boolean; sortOrder?: unknown }): Promise<{ ok: true } | { ok: false; error: CategoryError }> {
  if (!UUID.test(id)) return { ok: false, error: "not_found" };
  const cur = (await pool.query("SELECT name FROM shop_categories WHERE id = $1", [id])).rows[0];
  if (!cur) return { ok: false, error: "not_found" };
  const name = input.name === undefined ? cur.name : clean(input.name);
  if (name.length < 2 || name.length > 60 || /[<>]/.test(name)) return { ok: false, error: "invalid_name" };
  const sort = input.sortOrder === undefined ? null : toInt(input.sortOrder, 10000);
  await pool.query("UPDATE shop_categories SET name = $2, is_visible = COALESCE($3, is_visible), sort_order = COALESCE($4, sort_order) WHERE id = $1", [id, name, input.isVisible ?? null, sort]);
  return { ok: true };
}
export async function deleteCategory(pool: Pool, id: string): Promise<boolean> {
  if (!UUID.test(id)) return false;
  return ((await pool.query("DELETE FROM shop_categories WHERE id = $1", [id])).rowCount ?? 0) > 0;
}

// ---------- reading products ----------
const CARD_SQL = `
  SELECT p.id, p.slug, p.name, p.price_bdt, p.compare_price_bdt, p.is_featured, c.name AS category_name,
         (SELECT i.media_id FROM shop_product_images i WHERE i.product_id = p.id ORDER BY i.position, i.id LIMIT 1) AS image_id,
         (SELECT max(c2.percent) FROM shop_campaigns c2 WHERE c2.is_active AND current_date BETWEEN c2.starts_on AND c2.ends_on AND (c2.applies_to = 'all' OR c2.category_id = p.category_id)) AS camp_pct,
         EXISTS (SELECT 1 FROM shop_product_variants v WHERE v.product_id = p.id) AS has_options,
         (SELECT MIN(COALESCE(v.price_bdt, p.price_bdt)) FROM shop_product_variants v WHERE v.product_id = p.id) AS min_option_price,
         (p.status = 'sold_out' OR ($1::boolean AND p.track_stock AND (
            CASE WHEN EXISTS (SELECT 1 FROM shop_product_variants v WHERE v.product_id = p.id)
                 THEN COALESCE((SELECT SUM(v.stock_qty) FROM shop_product_variants v WHERE v.product_id = p.id), 0) ELSE p.stock_qty END) <= 0)) AS sold_out
    FROM shop_products p LEFT JOIN shop_categories c ON c.id = p.category_id`;
/** Price after a running campaign. Rounds down to whole taka. */
export const campaignPrice = (price: number, pct: number | null) => (pct ? Math.floor((price * (100 - pct)) / 100) : price);
const toCard = (r: Record<string, unknown>, campaigns: boolean): ShopCard => {
  const pct = campaigns && r.camp_pct != null ? Number(r.camp_pct) : null;
  const base = Number(r.has_options && r.min_option_price != null ? Math.min(Number(r.price_bdt), Number(r.min_option_price)) : r.price_bdt);
  return {
    id: r.id as string, slug: r.slug as string, name: r.name as string,
    priceBdt: campaignPrice(base, pct), comparePriceBdt: pct ? base : r.compare_price_bdt == null ? null : Number(r.compare_price_bdt), hasOptions: Boolean(r.has_options),
    imageId: (r.image_id as string | null) ?? null, soldOut: Boolean(r.sold_out), categoryName: (r.category_name as string | null) ?? null, featured: Boolean(r.is_featured), salePercent: pct,
  };
};

export interface PublicOpts { q?: unknown; category?: unknown; sort?: unknown; page?: unknown }
export async function listPublicProducts(pool: Pool, ent: Entitlements, opts: PublicOpts = {}): Promise<ShopCatalogue> {
  // $1 is always "does this package track stock" (the card query uses it); the filters after it use $2 and up.
  const where = ["$1::boolean IS NOT NULL", "p.status <> 'hidden'", "(p.category_id IS NULL OR c.is_visible)"];
  const params: unknown[] = [ent.shop.stockQty];
  const q = ent.shop.search ? clean(opts.q).slice(0, 60) : "";
  if (q) { params.push(`%${likeEscape(q)}%`); where.push(`(p.name ILIKE $${params.length} OR p.description ILIKE $${params.length} OR p.sku ILIKE $${params.length})`); }
  const category = ent.shop.categories ? clean(opts.category).slice(0, 80) : "";
  if (category) { params.push(category); where.push(`c.slug = $${params.length}`); }
  const sort = ent.shop.search && (SORTS as readonly unknown[]).includes(opts.sort) ? String(opts.sort) : "newest";
  const order = { newest: "p.sort_order, p.created_at DESC", price_asc: "p.price_bdt ASC, p.name", price_desc: "p.price_bdt DESC, p.name", name: "p.name ASC" }[sort as "newest"];
  const countRow = await pool.query(`SELECT count(*)::int AS n FROM shop_products p LEFT JOIN shop_categories c ON c.id = p.category_id WHERE ${where.join(" AND ")}`, params);
  const count = countRow.rows[0].n as number;
  const pages = Math.max(1, Math.ceil(count / PAGE_SIZE));
  const page = Math.min(pages, Math.max(1, Number(opts.page) || 1));
  const rows = await pool.query(`${CARD_SQL} WHERE ${where.join(" AND ")} ORDER BY ${order} LIMIT ${PAGE_SIZE} OFFSET ${(page - 1) * PAGE_SIZE}`, params);
  return { items: rows.rows.map((r) => toCard(r, ent.shop.campaigns)), total: count, page, pages, q, category, sort };
}

/** Products for the home page: featured ones first when the package has featured products. */
export async function homeProducts(pool: Pool, ent: Entitlements, limit = 8): Promise<ShopCard[]> {
  const r = await pool.query(`${CARD_SQL} WHERE p.status <> 'hidden' AND (p.category_id IS NULL OR c.is_visible) ORDER BY ${ent.shop.featured ? "p.is_featured DESC, " : ""}p.sort_order, p.created_at DESC LIMIT ${Math.min(24, Math.max(1, limit))}`, [ent.shop.stockQty]);
  return r.rows.map((x) => toCard(x, ent.shop.campaigns));
}

export interface PublicProduct { card: ShopCard; description: string; sku: string | null; images: string[]; variants: { id: string; label: string; priceBdt: number; soldOut: boolean }[]; categorySlug: string | null }
export async function getPublicProduct(pool: Pool, ent: Entitlements, slug: string): Promise<PublicProduct | null> {
  const r = await pool.query(`${CARD_SQL} WHERE p.slug = $2 AND p.status <> 'hidden' AND (p.category_id IS NULL OR c.is_visible)`, [ent.shop.stockQty, slug.slice(0, 100)]);
  if (!r.rowCount) return null;
  const row = r.rows[0];
  const extra = (await pool.query("SELECT description, sku, price_bdt, track_stock, (SELECT slug FROM shop_categories WHERE id = category_id) AS category_slug FROM shop_products WHERE id = $1", [row.id])).rows[0];
  const images = (await pool.query("SELECT media_id FROM shop_product_images WHERE product_id = $1 ORDER BY position, id", [row.id])).rows.map((x) => x.media_id as string);
  const tracked = ent.shop.stockQty && extra.track_stock;
  const pct = ent.shop.campaigns && row.camp_pct != null ? Number(row.camp_pct) : null;
  const variants = (await pool.query("SELECT id, label, price_bdt, stock_qty FROM shop_product_variants WHERE product_id = $1 ORDER BY sort_order, label", [row.id])).rows
    .map((v) => ({ id: v.id as string, label: v.label as string, priceBdt: campaignPrice(Number(v.price_bdt ?? extra.price_bdt), pct), soldOut: Boolean(tracked && v.stock_qty <= 0) }));
  const card = toCard(row, ent.shop.campaigns);
  return { card, description: extra.description, sku: extra.sku, images, variants, categorySlug: extra.category_slug };
}

// ---------- owner's product list ----------
export interface AdminProductRow { id: string; name: string; slug: string; price_bdt: number; compare_price_bdt: number | null; status: string; is_featured: boolean; track_stock: boolean; stock_qty: number; low_stock_at: number; category_name: string | null; image_id: string | null; variant_count: number; variant_stock: number }
export async function listProductsAdmin(pool: Pool, opts: { q?: unknown; status?: unknown; categoryId?: unknown; page?: unknown } = {}): Promise<{ rows: AdminProductRow[]; total: number; page: number; pages: number }> {
  const where: string[] = [], params: unknown[] = [];
  const q = clean(opts.q).slice(0, 60);
  if (q) { params.push(`%${likeEscape(q)}%`); where.push(`(p.name ILIKE $${params.length} OR p.sku ILIKE $${params.length})`); }
  if ((PRODUCT_STATUSES as readonly unknown[]).includes(opts.status)) { params.push(opts.status); where.push(`p.status = $${params.length}`); }
  if (typeof opts.categoryId === "string" && UUID.test(opts.categoryId)) { params.push(opts.categoryId); where.push(`p.category_id = $${params.length}`); }
  const w = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const total = (await pool.query(`SELECT count(*)::int AS n FROM shop_products p ${w}`, params)).rows[0].n as number;
  const pages = Math.max(1, Math.ceil(total / 30)), page = Math.min(pages, Math.max(1, Number(opts.page) || 1));
  const rows = await pool.query(
    `SELECT p.id, p.name, p.slug, p.price_bdt, p.compare_price_bdt, p.status, p.is_featured, p.track_stock, p.stock_qty, p.low_stock_at, c.name AS category_name,
            (SELECT i.media_id FROM shop_product_images i WHERE i.product_id = p.id ORDER BY i.position, i.id LIMIT 1) AS image_id,
            (SELECT count(*)::int FROM shop_product_variants v WHERE v.product_id = p.id) AS variant_count,
            COALESCE((SELECT SUM(v.stock_qty)::int FROM shop_product_variants v WHERE v.product_id = p.id), 0) AS variant_stock
       FROM shop_products p LEFT JOIN shop_categories c ON c.id = p.category_id ${w} ORDER BY p.created_at DESC LIMIT 30 OFFSET ${(page - 1) * 30}`, params);
  return { rows: rows.rows, total, page, pages };
}
export async function getProductAdmin(pool: Pool, id: string) {
  if (!UUID.test(id)) return null;
  const p = (await pool.query("SELECT * FROM shop_products WHERE id = $1", [id])).rows[0];
  if (!p) return null;
  const images = (await pool.query("SELECT media_id FROM shop_product_images WHERE product_id = $1 ORDER BY position, id", [id])).rows.map((r) => r.media_id as string);
  const variants = (await pool.query("SELECT label, price_bdt, stock_qty FROM shop_product_variants WHERE product_id = $1 ORDER BY sort_order, label", [id])).rows;
  return { product: p, images, variants };
}
export async function productCount(pool: Pool): Promise<number> {
  return (await pool.query("SELECT count(*)::int AS n FROM shop_products")).rows[0].n as number;
}
export async function publicProductCount(pool: Pool): Promise<number> {
  return (await pool.query("SELECT count(*)::int AS n FROM shop_products WHERE status <> 'hidden'")).rows[0].n as number;
}

export async function listProductSlugs(pool: Pool): Promise<string[]> {
  return (await pool.query("SELECT slug FROM shop_products WHERE status <> 'hidden' ORDER BY created_at DESC LIMIT 2000")).rows.map((r) => r.slug as string);
}

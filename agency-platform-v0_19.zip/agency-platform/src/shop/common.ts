import "../db/pgTypes";
import type { Pool, PoolClient } from "pg";

export type Db = Pool | PoolClient;
export const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const clean = (v: unknown): string => String(v ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").trim();

/** A whole number from a number or a digits-only string. Anything else is null. */
export function toInt(v: unknown, max = 100_000_000): number | null {
  if (typeof v === "number") return Number.isInteger(v) && v >= 0 && v <= max ? v : null;
  if (typeof v === "string" && /^\d{1,12}$/.test(v.trim())) { const n = Number(v.trim()); return n <= max ? n : null; }
  return null;
}
export function slugify(name: string): string {
  const s = name.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60).replace(/-+$/g, "");
  return s || "item";
}
const SLUG_TABLES = { products: "shop_products", categories: "shop_categories" } as const;
export async function uniqueSlug(db: Db, table: keyof typeof SLUG_TABLES, name: string, exceptId?: string): Promise<string> {
  const base = slugify(name);
  for (let i = 1; i < 200; i++) {
    const slug = i === 1 ? base : `${base}-${i}`;
    const r = await db.query(`SELECT id FROM ${SLUG_TABLES[table]} WHERE slug = $1`, [slug]);
    if (!r.rowCount || r.rows[0].id === exceptId) return slug;
  }
  return `${base}-${Date.now().toString(36)}`;
}
/** Escapes % and _ so a visitor's search text is matched literally. */
export const likeEscape = (s: string) => s.replace(/[\\%_]/g, (m) => "\\" + m);

import "../db/pgTypes";
import type { Pool } from "pg";
import type { Entitlements } from "../config/entitlements";
import { clean, toInt, UUID } from "./common";

// ---------- shop settings ----------
export interface ShopSettings { delivery_fee_bdt: number; free_delivery_over_bdt: number | null; order_note: string }
export async function getShopSettings(pool: Pool): Promise<ShopSettings> {
  return (await pool.query("SELECT delivery_fee_bdt, free_delivery_over_bdt, order_note FROM shop_config WHERE id = 1")).rows[0] ?? { delivery_fee_bdt: 0, free_delivery_over_bdt: null, order_note: "" };
}
export async function saveShopSettings(pool: Pool, i: { deliveryFee: unknown; freeOver: unknown; orderNote: unknown }): Promise<{ ok: true } | { ok: false; error: "invalid_fee" | "invalid_free_over" | "invalid_note" }> {
  const fee = clean(i.deliveryFee) === "" ? 0 : toInt(i.deliveryFee, 100000);
  if (fee === null) return { ok: false, error: "invalid_fee" };
  const free = clean(i.freeOver) === "" ? null : toInt(i.freeOver, 10_000_000);
  if (clean(i.freeOver) !== "" && free === null) return { ok: false, error: "invalid_free_over" };
  const note = clean(i.orderNote);
  if (note.length > 300 || /[<>]/.test(note)) return { ok: false, error: "invalid_note" };
  await pool.query("UPDATE shop_config SET delivery_fee_bdt = $1, free_delivery_over_bdt = $2, order_note = $3, updated_at = now() WHERE id = 1", [fee, free, note]);
  return { ok: true };
}

// ---------- discount codes (cart and checkout packages) ----------
export type DiscountError = "not_in_package" | "invalid_code" | "invalid_kind" | "invalid_value" | "invalid_min" | "invalid_uses" | "invalid_date" | "code_exists" | "not_found" | "too_many";
export async function listDiscounts(pool: Pool) {
  return (await pool.query("SELECT id, code, kind, value, min_order_bdt, max_uses, used_count, to_char(expires_on, 'YYYY-MM-DD') AS expires_on, is_active FROM shop_discount_codes ORDER BY created_at DESC LIMIT 200")).rows;
}
export async function createDiscount(pool: Pool, ent: Entitlements, i: { code: unknown; kind: unknown; value: unknown; minOrder?: unknown; maxUses?: unknown; expiresOn?: unknown }): Promise<{ ok: true } | { ok: false; error: DiscountError }> {
  if (!ent.shop.discounts) return { ok: false, error: "not_in_package" };
  const code = clean(i.code).toUpperCase();
  if (!/^[A-Z0-9]{3,20}$/.test(code)) return { ok: false, error: "invalid_code" };
  const kind = clean(i.kind);
  if (kind !== "percent" && kind !== "fixed") return { ok: false, error: "invalid_kind" };
  const value = toInt(i.value, kind === "percent" ? 100 : 10_000_000);
  if (value === null || value < 1) return { ok: false, error: "invalid_value" };
  const min = clean(i.minOrder) === "" ? 0 : toInt(i.minOrder, 10_000_000);
  if (min === null) return { ok: false, error: "invalid_min" };
  const uses = clean(i.maxUses) === "" ? null : toInt(i.maxUses, 1_000_000);
  if (clean(i.maxUses) !== "" && (uses === null || uses < 1)) return { ok: false, error: "invalid_uses" };
  const exp = clean(i.expiresOn);
  if (exp && (!/^\d{4}-\d{2}-\d{2}$/.test(exp) || new Date(exp + "T00:00:00Z").toISOString().slice(0, 10) !== exp)) return { ok: false, error: "invalid_date" };
  if ((await pool.query("SELECT count(*)::int AS n FROM shop_discount_codes")).rows[0].n >= 100) return { ok: false, error: "too_many" };
  try { await pool.query("INSERT INTO shop_discount_codes (code, kind, value, min_order_bdt, max_uses, expires_on) VALUES ($1,$2,$3,$4,$5,$6)", [code, kind, value, min, uses, exp || null]); }
  catch (e) { if ((e as { code?: string }).code === "23505") return { ok: false, error: "code_exists" }; throw e; }
  return { ok: true };
}
export async function setDiscountActive(pool: Pool, id: string, active: boolean): Promise<boolean> {
  return UUID.test(id) && ((await pool.query("UPDATE shop_discount_codes SET is_active = $2 WHERE id = $1", [id, active])).rowCount ?? 0) > 0;
}
export async function deleteDiscount(pool: Pool, id: string): Promise<boolean> {
  return UUID.test(id) && ((await pool.query("DELETE FROM shop_discount_codes WHERE id = $1", [id])).rowCount ?? 0) > 0;
}

// ---------- customers (built from orders) ----------
export interface CustomerRow { phone: string; name: string; email: string | null; orders: number; spent: number; last_order: Date }
export async function listCustomers(pool: Pool): Promise<CustomerRow[]> {
  return (await pool.query(
    `SELECT phone, (array_agg(customer_name ORDER BY created_at DESC))[1] AS name,
            (array_agg(email ORDER BY created_at DESC) FILTER (WHERE email IS NOT NULL))[1] AS email,
            (count(*) FILTER (WHERE status <> 'cancelled'))::int AS orders,
            COALESCE(sum(total_bdt) FILTER (WHERE status <> 'cancelled'), 0)::bigint AS spent, max(created_at) AS last_order
       FROM shop_orders GROUP BY phone ORDER BY max(created_at) DESC LIMIT 300`)).rows;
}

// ---------- low stock ----------
export interface LowStockRow { id: string; name: string; variant: string | null; qty: number; low_stock_at: number }
export async function lowStock(pool: Pool, ent: Entitlements): Promise<LowStockRow[]> {
  if (!ent.shop.lowStock) return [];
  return (await pool.query(
    `SELECT p.id, p.name, NULL::text AS variant, p.stock_qty AS qty, p.low_stock_at FROM shop_products p
      WHERE p.track_stock AND p.status <> 'hidden' AND NOT EXISTS (SELECT 1 FROM shop_product_variants v WHERE v.product_id = p.id) AND p.stock_qty <= p.low_stock_at
     UNION ALL
     SELECT p.id, p.name, v.label, v.stock_qty, p.low_stock_at FROM shop_products p JOIN shop_product_variants v ON v.product_id = p.id
      WHERE p.track_stock AND p.status <> 'hidden' AND v.stock_qty <= p.low_stock_at
     ORDER BY qty, name LIMIT 100`)).rows;
}

// ---------- reports ----------
export interface SalesReport {
  days: number; orders: number; revenue: number; cancelled: number; avgOrder: number;
  byDay: { day: string; orders: number; revenue: number }[]; top: { name: string; qty: number; revenue: number }[]; byStatus: Record<string, number>;
}
export async function salesReport(pool: Pool, daysRaw: unknown): Promise<SalesReport> {
  const days = [7, 30, 90].includes(Number(daysRaw)) ? Number(daysRaw) : 30;
  const since = `now() - ($1::int * interval '1 day')`;
  const t = (await pool.query(
    `SELECT (count(*) FILTER (WHERE status <> 'cancelled'))::int AS orders, COALESCE(sum(total_bdt) FILTER (WHERE status <> 'cancelled'), 0)::bigint AS revenue,
            (count(*) FILTER (WHERE status = 'cancelled'))::int AS cancelled, COALESCE(avg(total_bdt) FILTER (WHERE status <> 'cancelled'), 0)::float AS avg
       FROM shop_orders WHERE created_at >= ${since}`, [days])).rows[0];
  const byDay = (await pool.query(
    `SELECT to_char(d::date, 'YYYY-MM-DD') AS day, (count(o.id) FILTER (WHERE o.status <> 'cancelled'))::int AS orders, COALESCE(sum(o.total_bdt) FILTER (WHERE o.status <> 'cancelled'), 0)::bigint AS revenue
       FROM generate_series(current_date - ($1::int - 1), current_date, interval '1 day') d LEFT JOIN shop_orders o ON o.created_at::date = d::date GROUP BY d ORDER BY d`, [days])).rows;
  const top = (await pool.query(
    `SELECT i.name, sum(i.qty)::int AS qty, sum(i.line_total_bdt)::bigint AS revenue FROM shop_order_items i JOIN shop_orders o ON o.id = i.order_id
      WHERE o.status <> 'cancelled' AND o.created_at >= ${since} GROUP BY i.name ORDER BY sum(i.line_total_bdt) DESC LIMIT 10`, [days])).rows;
  const byStatus: Record<string, number> = {};
  for (const r of (await pool.query(`SELECT status, count(*)::int AS n FROM shop_orders WHERE created_at >= ${since} GROUP BY status`, [days])).rows) byStatus[r.status] = r.n;
  return { days, orders: t.orders, revenue: Number(t.revenue), cancelled: t.cancelled, avgOrder: Math.round(t.avg), byDay: byDay.map((r) => ({ ...r, revenue: Number(r.revenue) })), top: top.map((r) => ({ ...r, revenue: Number(r.revenue) })), byStatus };
}
export interface AdvancedReport { byCategory: { name: string; qty: number; revenue: number }[]; customers: number; repeatCustomers: number; discountsGiven: number; ordersWithCode: number; itemsPerOrder: number }
export async function advancedReport(pool: Pool, ent: Entitlements, daysRaw: unknown): Promise<AdvancedReport | null> {
  if (!ent.shop.advancedReports) return null;
  const days = [7, 30, 90].includes(Number(daysRaw)) ? Number(daysRaw) : 30;
  const w = `o.status <> 'cancelled' AND o.created_at >= now() - ($1::int * interval '1 day')`;
  const byCategory = (await pool.query(
    `SELECT COALESCE(c.name, 'No category') AS name, sum(i.qty)::int AS qty, sum(i.line_total_bdt)::bigint AS revenue
       FROM shop_order_items i JOIN shop_orders o ON o.id = i.order_id LEFT JOIN shop_products p ON p.id = i.product_id LEFT JOIN shop_categories c ON c.id = p.category_id
      WHERE ${w} GROUP BY COALESCE(c.name, 'No category') ORDER BY sum(i.line_total_bdt) DESC LIMIT 12`, [days])).rows;
  const cust = (await pool.query(`SELECT count(*)::int AS customers, (count(*) FILTER (WHERE n > 1))::int AS repeat FROM (SELECT phone, count(*) AS n FROM shop_orders o WHERE ${w} GROUP BY phone) x`, [days])).rows[0];
  const disc = (await pool.query(`SELECT COALESCE(sum(discount_bdt), 0)::bigint AS given, (count(*) FILTER (WHERE discount_code IS NOT NULL))::int AS used FROM shop_orders o WHERE ${w}`, [days])).rows[0];
  const ipo = (await pool.query(`SELECT COALESCE(avg(q), 0)::float AS avg FROM (SELECT sum(i.qty) AS q FROM shop_order_items i JOIN shop_orders o ON o.id = i.order_id WHERE ${w} GROUP BY o.id) x`, [days])).rows[0];
  return { byCategory: byCategory.map((r) => ({ ...r, revenue: Number(r.revenue) })), customers: cust.customers, repeatCustomers: cust.repeat, discountsGiven: Number(disc.given), ordersWithCode: disc.used, itemsPerOrder: Math.round(ipo.avg * 10) / 10 };
}

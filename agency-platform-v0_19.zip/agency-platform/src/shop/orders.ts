import "../db/pgTypes";
import { randomBytes } from "node:crypto";
import type { Pool } from "pg";
import type { Entitlements } from "../config/entitlements";
import { clean, UUID, type Db } from "./common";

export const BASIC_STATUSES = ["new", "confirmed", "cancelled"] as const;
export const ALL_STATUSES = ["new", "confirmed", "processing", "shipped", "delivered", "cancelled"] as const;
export type OrderStatus = (typeof ALL_STATUSES)[number];
export const MAX_LINES = 20;
export const MAX_QTY = 50;

export type OrderError = "invalid_name" | "invalid_phone" | "invalid_email" | "invalid_address" | "invalid_area" | "invalid_note" | "invalid_items" | "not_available"
  | "sold_out" | "out_of_stock" | "choose_option" | "invalid_code" | "rate_limited" | "not_in_package" | "one_item_only";
export type LineProblem = "unavailable" | "sold_out" | "out_of_stock" | "choose_option";

export interface QuoteLine { productId: string; variantId: string | null; name: string; variantLabel: string; unitPrice: number; qty: number; lineTotal: number; imageId: string | null; stockLeft: number | null; problem?: LineProblem }
export interface Quote { lines: QuoteLine[]; subtotal: number; deliveryFee: number; discount: number; total: number; code: string | null; codeError: boolean }
export interface CartItem { productId: string; variantId?: string | null; qty: number }

interface Settings { delivery_fee_bdt: number; free_delivery_over_bdt: number | null }
async function settingsOf(db: Db): Promise<Settings> {
  return (await db.query("SELECT delivery_fee_bdt, free_delivery_over_bdt FROM shop_config WHERE id = 1")).rows[0] ?? { delivery_fee_bdt: 0, free_delivery_over_bdt: null };
}

/**
 * Works out what an order costs from what is in the database. Prices and stock sent by the browser are never used.
 * With lock = true the product rows are locked so two buyers cannot take the same last item.
 */
export async function buildQuote(db: Db, ent: Entitlements, rawItems: unknown, rawCode: unknown, lock: boolean): Promise<{ ok: true; quote: Quote; discountId: string | null } | { ok: false; error: "invalid_items" }> {
  if (!Array.isArray(rawItems) || rawItems.length === 0 || rawItems.length > MAX_LINES * 2) return { ok: false, error: "invalid_items" };
  const merged = new Map<string, { productId: string; variantId: string | null; qty: number }>();
  for (const it of rawItems as CartItem[]) {
    const productId = typeof it?.productId === "string" ? it.productId : "", variantId = typeof it?.variantId === "string" && it.variantId ? it.variantId : null;
    const qty = Number(it?.qty);
    if (!UUID.test(productId) || (variantId && !UUID.test(variantId)) || !Number.isInteger(qty) || qty < 1 || qty > MAX_QTY) return { ok: false, error: "invalid_items" };
    const key = `${productId}:${variantId ?? ""}`;
    const prev = merged.get(key);
    merged.set(key, { productId, variantId, qty: Math.min(MAX_QTY, (prev?.qty ?? 0) + qty) });
  }
  if (merged.size > MAX_LINES) return { ok: false, error: "invalid_items" };

  const lines: QuoteLine[] = [];
  for (const it of merged.values()) {
    const p = (await db.query(
      `SELECT p.id, p.name, p.price_bdt, p.status, p.track_stock, p.stock_qty,
              (SELECT max(c2.percent) FROM shop_campaigns c2 WHERE c2.is_active AND current_date BETWEEN c2.starts_on AND c2.ends_on AND (c2.applies_to = 'all' OR c2.category_id = p.category_id)) AS camp_pct,
              (SELECT i.media_id FROM shop_product_images i WHERE i.product_id = p.id ORDER BY i.position, i.id LIMIT 1) AS image_id
         FROM shop_products p WHERE p.id = $1 ${lock ? "FOR UPDATE OF p" : ""}`, [it.productId])).rows[0];
    if (!p || p.status === "hidden") { lines.push({ productId: it.productId, variantId: it.variantId, name: p?.name ?? "Unavailable product", variantLabel: "", unitPrice: 0, qty: it.qty, lineTotal: 0, imageId: null, stockLeft: null, problem: "unavailable" }); continue; }
    const variants = (await db.query("SELECT id, label, price_bdt, stock_qty FROM shop_product_variants WHERE product_id = $1", [p.id])).rows;
    const v = it.variantId ? variants.find((x) => x.id === it.variantId) : undefined;
    let problem: LineProblem | undefined;
    if (variants.length > 0 && !v) problem = it.variantId ? "unavailable" : "choose_option";
    const pct = ent.shop.campaigns && p.camp_pct != null ? Number(p.camp_pct) : null;
    const unit = pct ? Math.floor((Number(v?.price_bdt ?? p.price_bdt) * (100 - pct)) / 100) : Number(v?.price_bdt ?? p.price_bdt);
    const tracked = ent.shop.stockQty && p.track_stock;
    const available: number | null = tracked ? Number(v ? v.stock_qty : p.stock_qty) : null;
    if (!problem && p.status === "sold_out") problem = "sold_out";
    if (!problem && available !== null) { if (available <= 0) problem = "sold_out"; else if (it.qty > available) problem = "out_of_stock"; }
    lines.push({ productId: p.id, variantId: v?.id ?? null, name: p.name, variantLabel: v?.label ?? "", unitPrice: unit, qty: it.qty, lineTotal: unit * it.qty, imageId: p.image_id ?? null, stockLeft: available, problem });
  }
  const subtotal = lines.reduce((a, l) => a + (l.problem === "unavailable" ? 0 : l.lineTotal), 0);
  const st = await settingsOf(db);
  const deliveryFee = lines.length === 0 || (st.free_delivery_over_bdt != null && subtotal >= Number(st.free_delivery_over_bdt)) ? 0 : Number(st.delivery_fee_bdt);

  let discount = 0, code: string | null = null, codeError = false, discountId: string | null = null;
  const typed = clean(rawCode).toUpperCase().slice(0, 30);
  if (typed) {
    code = typed;
    const d = ent.shop.discounts ? (await db.query("SELECT * FROM shop_discount_codes WHERE code = $1", [typed])).rows[0] : undefined;
    const today = new Date().toISOString().slice(0, 10);
    const expired = d?.expires_on && new Date(d.expires_on).toISOString().slice(0, 10) < today;
    if (!d || !d.is_active || expired || subtotal < Number(d.min_order_bdt) || (d.max_uses != null && d.used_count >= d.max_uses)) codeError = true;
    else {
      discount = d.kind === "percent" ? Math.floor((subtotal * Number(d.value)) / 100) : Math.min(Number(d.value), subtotal);
      discountId = d.id;
    }
  }
  return { ok: true, discountId, quote: { lines, subtotal, deliveryFee, discount, total: Math.max(0, subtotal + deliveryFee - discount), code, codeError } };
}

export interface OrderInput {
  channel: unknown; items: unknown; name: unknown; phone: unknown; email?: unknown; address: unknown; area?: unknown; note?: unknown;
  discountCode?: unknown; ip?: unknown;
  /** Hidden trap field: real visitors leave it empty. */
  website?: unknown;
}
export type OrderResult = { ok: true; silent?: false; id: string; number: number; token: string; total: number } | { ok: true; silent: true } | { ok: false; error: OrderError; item?: string };

const PER_IP_HOUR = 8, PER_PHONE_DAY = 6, PER_SITE_DAY = 400;

export async function createOrder(pool: Pool, ent: Entitlements, input: OrderInput): Promise<OrderResult> {
  if (clean(input.website) !== "") return { ok: true, silent: true };
  if (!ent.shop.products) return { ok: false, error: "not_in_package" };
  const channel = clean(input.channel);
  if (channel !== "request" && channel !== "checkout") return { ok: false, error: "invalid_items" };
  if (channel === "checkout" && !ent.shop.cart) return { ok: false, error: "not_in_package" };
  if (channel === "request" && !ent.shop.whatsapp && !ent.shop.cart) return { ok: false, error: "not_in_package" };

  const name = clean(input.name);
  if (name.length < 2 || name.length > 80 || /[<>]/.test(name)) return { ok: false, error: "invalid_name" };
  const phone = clean(input.phone).replace(/[\s-]/g, "");
  if (!/^\+?[0-9]{7,15}$/.test(phone)) return { ok: false, error: "invalid_phone" };
  const email = clean(input.email).toLowerCase();
  if (email && (email.length > 254 || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]{2,}$/.test(email))) return { ok: false, error: "invalid_email" };
  const address = clean(input.address);
  if (address.length < 5 || address.length > 300 || /[<>]/.test(address)) return { ok: false, error: "invalid_address" };
  const area = clean(input.area);
  if (area.length > 60 || /[<>]/.test(area)) return { ok: false, error: "invalid_area" };
  const note = clean(input.note);
  if (note.length > 500 || /[<>]/.test(note)) return { ok: false, error: "invalid_note" };
  if (!ent.shop.cart && Array.isArray(input.items) && input.items.length !== 1) return { ok: false, error: "one_item_only" };

  const ip = clean(input.ip).slice(0, 64) || "unknown";
  const count = async (sql: string, v: unknown[]) => (await pool.query(sql, v)).rows[0].n as number;
  if ((await count("SELECT count(*)::int AS n FROM shop_orders WHERE ip = $1 AND created_at > now() - interval '1 hour'", [ip])) >= PER_IP_HOUR
    || (await count("SELECT count(*)::int AS n FROM shop_orders WHERE phone = $1 AND created_at > now() - interval '1 day'", [phone])) >= PER_PHONE_DAY
    || (await count("SELECT count(*)::int AS n FROM shop_orders WHERE created_at > now() - interval '1 day'", [])) >= PER_SITE_DAY) return { ok: false, error: "rate_limited" };

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const q = await buildQuote(client, ent, input.items, input.discountCode, true);
    if (!q.ok) { await client.query("ROLLBACK"); return { ok: false, error: "invalid_items" }; }
    const bad = q.quote.lines.find((l) => l.problem);
    if (bad) { await client.query("ROLLBACK"); return { ok: false, error: bad.problem === "unavailable" ? "not_available" : bad.problem!, item: bad.name }; }
    if (q.quote.codeError) { await client.query("ROLLBACK"); return { ok: false, error: "invalid_code" }; }
    if (q.discountId) {
      const u = await client.query("UPDATE shop_discount_codes SET used_count = used_count + 1 WHERE id = $1 AND is_active AND (max_uses IS NULL OR used_count < max_uses) RETURNING id", [q.discountId]);
      if (!u.rowCount) { await client.query("ROLLBACK"); return { ok: false, error: "invalid_code" }; }
    }
    const token = randomBytes(18).toString("base64url");
    const o = (await client.query(
      `INSERT INTO shop_orders (public_token, channel, customer_name, phone, email, address, area, note, subtotal_bdt, delivery_fee_bdt, discount_bdt, total_bdt, discount_code, ip)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING id, number`,
      [token, channel, name, phone, email || null, address, area, note, q.quote.subtotal, q.quote.deliveryFee, q.quote.discount, q.quote.total, q.quote.discount > 0 ? q.quote.code : null, ip])).rows[0];
    for (const l of q.quote.lines) {
      const taken = l.stockLeft !== null;
      if (taken) {
        if (l.variantId) await client.query("UPDATE shop_product_variants SET stock_qty = stock_qty - $2 WHERE id = $1", [l.variantId, l.qty]);
        else await client.query("UPDATE shop_products SET stock_qty = stock_qty - $2 WHERE id = $1", [l.productId, l.qty]);
      }
      await client.query(
        "INSERT INTO shop_order_items (order_id, product_id, variant_id, variant_label, name, unit_price_bdt, qty, line_total_bdt, stock_taken) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)",
        [o.id, l.productId, l.variantId, l.variantLabel, l.name, l.unitPrice, l.qty, l.lineTotal, taken]);
    }
    await client.query("INSERT INTO shop_order_events (order_id, status, actor) VALUES ($1,'new','customer')", [o.id]);
    await client.query("COMMIT");
    return { ok: true, id: o.id, number: o.number, token, total: q.quote.total };
  } catch (e) { await client.query("ROLLBACK"); throw e; } finally { client.release(); }
}

// ---------- owner side ----------
export interface OrderRow { id: string; number: number; public_token: string; channel: string; customer_name: string; phone: string; email: string | null; address: string; area: string; note: string; status: OrderStatus; payment_method: string; payment_status: string; subtotal_bdt: number; delivery_fee_bdt: number; discount_bdt: number; total_bdt: number; discount_code: string | null; courier: string; tracking_code: string; internal_note: string; created_at: Date; updated_at: Date }

export async function listOrders(pool: Pool, opts: { status?: unknown; q?: unknown; page?: unknown } = {}): Promise<{ rows: (OrderRow & { item_count: number })[]; total: number; page: number; pages: number }> {
  const where: string[] = [], params: unknown[] = [];
  if ((ALL_STATUSES as readonly unknown[]).includes(opts.status)) { params.push(opts.status); where.push(`o.status = $${params.length}`); }
  else if (opts.status === "open") where.push("o.status IN ('new','confirmed','processing','shipped')");
  const q = clean(opts.q).slice(0, 40);
  if (q) { params.push(`%${q.replace(/[\\%_]/g, (m) => "\\" + m)}%`); where.push(`(o.customer_name ILIKE $${params.length} OR o.phone ILIKE $${params.length} OR o.number::text LIKE $${params.length})`); }
  const w = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const total = (await pool.query(`SELECT count(*)::int AS n FROM shop_orders o ${w}`, params)).rows[0].n as number;
  const pages = Math.max(1, Math.ceil(total / 25)), page = Math.min(pages, Math.max(1, Number(opts.page) || 1));
  const rows = await pool.query(`SELECT o.*, (SELECT COALESCE(sum(qty),0)::int FROM shop_order_items i WHERE i.order_id = o.id) AS item_count FROM shop_orders o ${w} ORDER BY o.created_at DESC LIMIT 25 OFFSET ${(page - 1) * 25}`, params);
  return { rows: rows.rows, total, page, pages };
}
export interface OrderItemRow { id: string; product_id: string | null; variant_label: string; name: string; unit_price_bdt: number; qty: number; line_total_bdt: number }
export async function getOrder(pool: Pool, id: string): Promise<{ order: OrderRow; items: OrderItemRow[]; events: { status: string; actor: string; at: Date }[] } | null> {
  if (!UUID.test(id)) return null;
  const order = (await pool.query("SELECT * FROM shop_orders WHERE id = $1", [id])).rows[0];
  if (!order) return null;
  return { order, items: (await pool.query("SELECT id, product_id, variant_label, name, unit_price_bdt, qty, line_total_bdt FROM shop_order_items WHERE order_id = $1 ORDER BY name", [id])).rows,
    events: (await pool.query("SELECT status, actor, at FROM shop_order_events WHERE order_id = $1 ORDER BY at", [id])).rows };
}
/** The customer's own page. The long random token is the only thing that opens it. */
export async function getOrderByToken(pool: Pool, token: string) {
  if (!/^[A-Za-z0-9_-]{16,40}$/.test(token)) return null;
  const id = (await pool.query("SELECT id FROM shop_orders WHERE public_token = $1", [token])).rows[0]?.id;
  return id ? getOrder(pool, id) : null;
}
export async function countNewOrders(pool: Pool): Promise<number> {
  return (await pool.query("SELECT count(*)::int AS n FROM shop_orders WHERE status = 'new'")).rows[0].n as number;
}

export type OrderChangeError = "not_found" | "invalid_status" | "not_in_package" | "closed" | "invalid_value";
/** Cancelled orders are final. Cancelling puts the stock back. Simple packages only get new, confirmed and cancelled. */
export async function setOrderStatus(pool: Pool, ent: Entitlements, id: string, status: unknown, actor: string): Promise<{ ok: true } | { ok: false; error: OrderChangeError }> {
  if (!UUID.test(id)) return { ok: false, error: "not_found" };
  const allowed = ent.shop.orderManagement ? ALL_STATUSES : BASIC_STATUSES;
  if (!(allowed as readonly unknown[]).includes(status)) return { ok: false, error: (ALL_STATUSES as readonly unknown[]).includes(status) ? "not_in_package" : "invalid_status" };
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const cur = (await client.query("SELECT status FROM shop_orders WHERE id = $1 FOR UPDATE", [id])).rows[0];
    if (!cur) { await client.query("ROLLBACK"); return { ok: false, error: "not_found" }; }
    if (cur.status === "cancelled") { await client.query("ROLLBACK"); return { ok: false, error: "closed" }; }
    if (cur.status === status) { await client.query("ROLLBACK"); return { ok: true }; }
    if (status === "cancelled") {
      for (const it of (await client.query("SELECT product_id, variant_id, qty FROM shop_order_items WHERE order_id = $1 AND stock_taken", [id])).rows) {
        if (it.variant_id) await client.query("UPDATE shop_product_variants SET stock_qty = stock_qty + $2 WHERE id = $1", [it.variant_id, it.qty]);
        else if (it.product_id) await client.query("UPDATE shop_products SET stock_qty = stock_qty + $2 WHERE id = $1", [it.product_id, it.qty]);
      }
      await client.query("UPDATE shop_order_items SET stock_taken = false WHERE order_id = $1", [id]);
    }
    await client.query("UPDATE shop_orders SET status = $2, updated_at = now() WHERE id = $1", [id, status]);
    await client.query("INSERT INTO shop_order_events (order_id, status, actor) VALUES ($1,$2,$3)", [id, status, actor]);
    await client.query("COMMIT");
    return { ok: true };
  } catch (e) { await client.query("ROLLBACK"); throw e; } finally { client.release(); }
}
/** Payment, courier details and the private note need the full order management feature. */
export async function updateOrderDetails(pool: Pool, ent: Entitlements, id: string, d: { paymentStatus?: unknown; courier?: unknown; trackingCode?: unknown; internalNote?: unknown }): Promise<{ ok: true } | { ok: false; error: OrderChangeError }> {
  if (!UUID.test(id)) return { ok: false, error: "not_found" };
  if (!ent.shop.orderManagement) return { ok: false, error: "not_in_package" };
  const pay = d.paymentStatus === undefined ? null : clean(d.paymentStatus);
  if (pay !== null && pay !== "paid" && pay !== "unpaid") return { ok: false, error: "invalid_value" };
  const courier = d.courier === undefined ? null : clean(d.courier), tracking = d.trackingCode === undefined ? null : clean(d.trackingCode), note = d.internalNote === undefined ? null : clean(d.internalNote);
  if ((courier ?? "").length > 60 || (tracking ?? "").length > 60 || (note ?? "").length > 500 || [courier, tracking, note].some((x) => x !== null && /[<>]/.test(x))) return { ok: false, error: "invalid_value" };
  const r = await pool.query("UPDATE shop_orders SET payment_status = COALESCE($2, payment_status), courier = COALESCE($3, courier), tracking_code = COALESCE($4, tracking_code), internal_note = COALESCE($5, internal_note), updated_at = now() WHERE id = $1", [id, pay, courier, tracking, note]);
  return r.rowCount ? { ok: true } : { ok: false, error: "not_found" };
}

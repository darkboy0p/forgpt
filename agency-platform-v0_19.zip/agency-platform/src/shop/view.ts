import type { Pool } from "pg";
import type { Entitlements } from "../config/entitlements";
import type { PageKey } from "../web/templates/pages";
import { homeProducts, listCategories, listPublicProducts, publicProductCount, type PublicOpts } from "./products";
import type { ShopView } from "./types";
import { orIfMissingSchema } from "./safe";

/** What a page needs to show the shop. `null` when the package has no shop or there is nothing to show yet. */
export async function buildShopView(pool: Pool, ent: Entitlements, opts: { page: PageKey; sp?: PublicOpts }): Promise<ShopView | null> {
  if (!ent.shop.products) return null;
  return orIfMissingSchema(() => build(pool, ent, opts), null);
}

async function build(pool: Pool, ent: Entitlements, opts: { page: PageKey; sp?: PublicOpts }): Promise<ShopView | null> {
  if ((await publicProductCount(pool)) === 0) return null;
  const categories = ent.shop.categories ? (await listCategories(pool, { visibleOnly: true })).filter((c) => c.count > 0).map(({ id, name, slug, count }) => ({ id, name, slug, count })) : [];
  return {
    cart: ent.shop.cart, search: ent.shop.search, categories,
    home: await homeProducts(pool, ent, 8),
    catalogue: opts.page === "products" ? await listPublicProducts(pool, ent, opts.sp ?? {}) : undefined,
  };
}

import "../db/pgTypes";
import type { Pool } from "pg";
import type { Entitlements } from "../config/entitlements";
import { clean, toInt, UUID } from "./common";

export type CampaignError = "not_in_package" | "invalid_name" | "invalid_percent" | "invalid_applies" | "invalid_category" | "invalid_dates" | "too_many" | "not_found";
export interface CampaignInput { name: unknown; percent: unknown; appliesTo: unknown; categoryId?: unknown; startsOn: unknown; endsOn: unknown }
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const validDate = (d: string) => DATE.test(d) && new Date(d + "T00:00:00Z").toISOString().slice(0, 10) === d;

export async function createCampaign(pool: Pool, ent: Entitlements, i: CampaignInput): Promise<{ ok: true } | { ok: false; error: CampaignError }> {
  if (!ent.shop.campaigns) return { ok: false, error: "not_in_package" };
  const name = clean(i.name);
  if (name.length < 2 || name.length > 60 || /[<>]/.test(name)) return { ok: false, error: "invalid_name" };
  const percent = toInt(i.percent, 90);
  if (percent === null || percent < 1) return { ok: false, error: "invalid_percent" };
  const appliesTo = clean(i.appliesTo);
  if (appliesTo !== "all" && appliesTo !== "category") return { ok: false, error: "invalid_applies" };
  const categoryId = appliesTo === "category" ? clean(i.categoryId) : "";
  if (appliesTo === "category" && (!UUID.test(categoryId) || !(await pool.query("SELECT 1 FROM shop_categories WHERE id = $1", [categoryId])).rowCount)) return { ok: false, error: "invalid_category" };
  const starts = clean(i.startsOn), ends = clean(i.endsOn);
  if (!validDate(starts) || !validDate(ends) || ends < starts || (Date.parse(ends) - Date.parse(starts)) / 86_400_000 > 366) return { ok: false, error: "invalid_dates" };
  if ((await pool.query("SELECT count(*)::int AS n FROM shop_campaigns")).rows[0].n >= 100) return { ok: false, error: "too_many" };
  await pool.query("INSERT INTO shop_campaigns (name, percent, applies_to, category_id, starts_on, ends_on) VALUES ($1,$2,$3,$4,$5,$6)", [name, percent, appliesTo, categoryId || null, starts, ends]);
  return { ok: true };
}
export async function listCampaigns(pool: Pool) {
  return (await pool.query(
    `SELECT c.id, c.name, c.percent, c.applies_to, c.is_active, to_char(c.starts_on, 'YYYY-MM-DD') AS starts_on, to_char(c.ends_on, 'YYYY-MM-DD') AS ends_on, cat.name AS category_name,
            (c.is_active AND current_date BETWEEN c.starts_on AND c.ends_on) AS running
       FROM shop_campaigns c LEFT JOIN shop_categories cat ON cat.id = c.category_id ORDER BY c.starts_on DESC, c.created_at DESC LIMIT 200`)).rows as
    { id: string; name: string; percent: number; applies_to: string; is_active: boolean; starts_on: string; ends_on: string; category_name: string | null; running: boolean }[];
}
export async function setCampaignActive(pool: Pool, id: string, active: boolean): Promise<boolean> {
  return UUID.test(id) && ((await pool.query("UPDATE shop_campaigns SET is_active = $2 WHERE id = $1", [id, active])).rowCount ?? 0) > 0;
}
export async function deleteCampaign(pool: Pool, id: string): Promise<boolean> {
  return UUID.test(id) && ((await pool.query("DELETE FROM shop_campaigns WHERE id = $1", [id])).rowCount ?? 0) > 0;
}

/** Whole taka only, 0 to 100,000,000. Accepts "12,500" or 12500. Returns null if invalid. */
export function parseTaka(input: unknown): number | null {
  const s = typeof input === "number" ? String(input) : typeof input === "string" ? input.replace(/[,\s]/g, "") : "";
  if (!/^\d{1,9}$/.test(s)) return null;
  const n = Number(s);
  return n <= 100_000_000 ? n : null;
}

/** Strict YYYY-MM-DD calendar date, or null. */
export function parseDate(input: unknown): string | null {
  if (typeof input !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(input)) return null;
  const d = new Date(`${input}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === input ? input : null;
}

export function todayUtc(now = new Date()): string { return now.toISOString().slice(0, 10); }

/** Add whole months to a date whose day is 1-28 (so every month has that day). */
export function addMonths(date: string, months: number): string {
  const [y, m, d] = date.split("-").map(Number) as [number, number, number];
  const total = y * 12 + (m - 1) + months;
  return `${String(Math.floor(total / 12)).padStart(4, "0")}-${String((total % 12) + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}
export function addDays(date: string, days: number): string {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export const formatTaka = (n: number) => `৳${n.toLocaleString("en-IN")}`;

/** The monthly fee for a billing period that starts on `onDate`, after any still-valid discount. */
export function effectiveMonthlyFee(a: { monthlyFee: number; monthlyDiscount: number; discountUntil: string | null }, onDate: string): number {
  const active = a.monthlyDiscount > 0 && (a.discountUntil === null || onDate <= a.discountUntil);
  return a.monthlyFee - (active ? a.monthlyDiscount : 0);
}

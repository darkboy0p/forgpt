import type { BillingError } from "./service";

export const BILLING_ERRORS: Record<BillingError, string> = {
  not_found: "Client not found.",
  invalid_amount: "Enter whole taka amounts only (numbers, for example 12500).",
  discount_too_large: "The discount cannot be more than the monthly fee.",
  invalid_date: "Enter a valid date.",
  start_day_too_late: "The service start day must be between the 1st and the 28th, so every month has that day.",
  invalid_grace: "Grace days must be a whole number from 0 to 90.",
  no_agreement: "Save this client's agreement first.",
  setup_invoice_exists: "A setup invoice already exists. Void it first if it must be replaced.",
  period_exists: "That period already has an invoice.",
  period_not_next: "That is not the next period to bill. Reload the page and try again.",
  period_too_far: "That period starts more than 31 days from today. Generate it closer to its date.",
  invoice_not_found: "Invoice not found.",
  invoice_void: "That invoice is void.",
  invoice_paid: "That invoice is already fully paid.",
  invalid_method: "Choose a payment method.",
  overpayment: "That is more than the amount still owed on the invoice.",
  duplicate_reference: "A payment with that method and reference is already recorded for this invoice.",
  has_payments: "An invoice with payments cannot be voided.",
  reason_required: "Write a reason.",
};
export const BILLING_NOTICES: Record<string, string> = {
  agreement: "Agreement saved.", invoice: "Invoice created.", payment: "Payment recorded.", voided: "Invoice voided.",
};

import "../db/pgTypes";
import type { Pool, PoolClient } from "pg";
import { addDays, addMonths, effectiveMonthlyFee, parseDate, parseTaka, todayUtc } from "./values";

export interface Agreement {
  setupFee: number; monthlyFee: number; monthlyDiscount: number; discountUntil: string | null;
  serviceStart: string; graceDays: number; notes: string;
}
export type BillingError =
  | "not_found" | "invalid_amount" | "discount_too_large" | "invalid_date" | "start_day_too_late" | "invalid_grace" | "no_agreement"
  | "setup_invoice_exists" | "period_exists" | "period_not_next" | "period_too_far" | "invoice_not_found" | "invoice_void"
  | "invoice_paid" | "invalid_method" | "overpayment" | "duplicate_reference" | "has_payments" | "reason_required";
export type Result<T = object> = ({ ok: true } & T) | { ok: false; error: BillingError };

const METHODS = ["bkash", "nagad", "rocket", "bank", "cash", "other"] as const;
const audit = (db: Pool | PoolClient, actor: string, action: string, tenantId: string, detail: object) =>
  db.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,$2,$3,$4)", [actor, action, tenantId, JSON.stringify(detail)]);

async function tenantId(control: Pool, slug: string): Promise<string | null> {
  const r = await control.query("SELECT id FROM tenants WHERE slug = $1", [slug]);
  return r.rows[0]?.id ?? null;
}

export async function getAgreement(control: Pool, tId: string): Promise<Agreement | null> {
  const r = (await control.query("SELECT * FROM tenant_billing WHERE tenant_id = $1", [tId])).rows[0];
  if (!r) return null;
  return { setupFee: r.setup_fee_bdt, monthlyFee: r.monthly_fee_bdt, monthlyDiscount: r.monthly_discount_bdt, discountUntil: r.discount_until,
    serviceStart: r.service_start, graceDays: r.grace_days, notes: r.notes };
}

export interface AgreementInput { setupFee: unknown; monthlyFee: unknown; monthlyDiscount: unknown; discountUntil: unknown; serviceStart: unknown; graceDays: unknown; notes: unknown }

/** Sets the negotiated prices for one client. Only an administrator can call this; clients have no way to. */
export async function setAgreement(control: Pool, slug: string, input: AgreementInput, actor: string): Promise<Result> {
  const tId = await tenantId(control, slug);
  if (!tId) return { ok: false, error: "not_found" };
  const setupFee = parseTaka(input.setupFee), monthlyFee = parseTaka(input.monthlyFee);
  const monthlyDiscount = input.monthlyDiscount === "" || input.monthlyDiscount == null ? 0 : parseTaka(input.monthlyDiscount);
  if (setupFee === null || monthlyFee === null || monthlyDiscount === null) return { ok: false, error: "invalid_amount" };
  if (monthlyDiscount > monthlyFee) return { ok: false, error: "discount_too_large" };
  const serviceStart = parseDate(input.serviceStart);
  const discountUntil = input.discountUntil === "" || input.discountUntil == null ? null : parseDate(input.discountUntil);
  if (!serviceStart || (input.discountUntil !== "" && input.discountUntil != null && !discountUntil)) return { ok: false, error: "invalid_date" };
  if (Number(serviceStart.slice(8, 10)) > 28) return { ok: false, error: "start_day_too_late" };
  const graceDays = input.graceDays === "" || input.graceDays == null ? 7 : Number(input.graceDays);
  if (!Number.isInteger(graceDays) || graceDays < 0 || graceDays > 90) return { ok: false, error: "invalid_grace" };
  const notes = String(input.notes ?? "").slice(0, 2000);

  await control.query(
    `INSERT INTO tenant_billing (tenant_id, setup_fee_bdt, monthly_fee_bdt, monthly_discount_bdt, discount_until, service_start, grace_days, notes, updated_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (tenant_id) DO UPDATE SET setup_fee_bdt=$2, monthly_fee_bdt=$3, monthly_discount_bdt=$4, discount_until=$5,
       service_start=$6, grace_days=$7, notes=$8, updated_by=$9, updated_at=now()`,
    [tId, setupFee, monthlyFee, monthlyDiscount, discountUntil, serviceStart, graceDays, notes, actor]
  );
  await audit(control, actor, "billing.agreement.set", tId, { setupFee, monthlyFee, monthlyDiscount, discountUntil, serviceStart, graceDays });
  return { ok: true };
}

const NEW_NUMBER = "'INV-' || to_char(now(),'YYYY') || '-' || lpad(nextval('invoice_number_seq')::text, 5, '0')";

async function insertInvoice(control: Pool, tId: string, kind: "setup" | "monthly", periodStart: string | null, description: string, amount: number, dueDate: string, actor: string): Promise<Result<{ invoiceId: string }>> {
  try {
    const r = await control.query(
      `INSERT INTO invoices (tenant_id, number, kind, period_start, description, amount_bdt, due_date, status, paid_at, created_by)
       VALUES ($1, ${NEW_NUMBER}, $2, $3::date, $4, $5::bigint, $6::date, CASE WHEN $5::bigint = 0 THEN 'paid' ELSE 'unpaid' END, CASE WHEN $5::bigint = 0 THEN now() END, $7) RETURNING id, number`,
      [tId, kind, periodStart, description, amount, dueDate, actor]
    );
    await audit(control, actor, "invoice.created", tId, { number: r.rows[0].number, kind, amount, dueDate });
    return { ok: true, invoiceId: r.rows[0].id };
  } catch (err) {
    if ((err as { code?: string }).code === "23505") return { ok: false, error: kind === "setup" ? "setup_invoice_exists" : "period_exists" };
    throw err;
  }
}

export async function createSetupInvoice(control: Pool, slug: string, dueDate: unknown, actor: string): Promise<Result<{ invoiceId: string }>> {
  const tId = await tenantId(control, slug);
  if (!tId) return { ok: false, error: "not_found" };
  const a = await getAgreement(control, tId);
  if (!a) return { ok: false, error: "no_agreement" };
  const due = parseDate(dueDate);
  if (!due) return { ok: false, error: "invalid_date" };
  return insertInvoice(control, tId, "setup", null, "One-time website setup fee", a.setupFee, due, actor);
}

/** The next monthly period that has no invoice yet (first period starts on the agreed service start date). */
export async function nextMonthlyPeriod(control: Pool, tId: string, a: Agreement): Promise<string> {
  const last = (await control.query("SELECT max(period_start) AS p FROM invoices WHERE tenant_id=$1 AND kind='monthly' AND status<>'void'", [tId])).rows[0]?.p as string | null;
  return last ? addMonths(last, 1) : a.serviceStart;
}

/**
 * Creates the monthly invoice for ONE named period. The period must be exactly the next one, and the database refuses
 * a second invoice for the same period, so a double click or a retry cannot bill twice.
 */
export async function generateMonthlyInvoice(control: Pool, slug: string, periodStart: unknown, actor: string, now = new Date()): Promise<Result<{ invoiceId: string }>> {
  const tId = await tenantId(control, slug);
  if (!tId) return { ok: false, error: "not_found" };
  const a = await getAgreement(control, tId);
  if (!a) return { ok: false, error: "no_agreement" };
  const period = parseDate(periodStart);
  if (!period) return { ok: false, error: "invalid_date" };
  const exists = (await control.query("SELECT 1 FROM invoices WHERE tenant_id=$1 AND kind='monthly' AND period_start=$2 AND status<>'void'", [tId, period])).rowCount;
  if (exists) return { ok: false, error: "period_exists" };
  if (period !== (await nextMonthlyPeriod(control, tId, a))) return { ok: false, error: "period_not_next" };
  if (period > addDays(todayUtc(now), 31)) return { ok: false, error: "period_too_far" };
  const end = addDays(addMonths(period, 1), -1);
  return insertInvoice(control, tId, "monthly", period, `Monthly service fee ${period} to ${end}`, effectiveMonthlyFee(a, period), period, actor);
}

export interface PaymentInput { amount: unknown; method: unknown; reference: unknown; receivedOn: unknown }

/** Records money actually received. The invoice becomes paid only through recorded payments. */
export async function recordPayment(control: Pool, invoiceId: string, input: PaymentInput, actor: string): Promise<Result<{ status: string }>> {
  const amount = parseTaka(input.amount);
  if (amount === null || amount <= 0) return { ok: false, error: "invalid_amount" };
  const method = String(input.method);
  if (!(METHODS as readonly string[]).includes(method)) return { ok: false, error: "invalid_method" };
  const receivedOn = parseDate(input.receivedOn);
  if (!receivedOn) return { ok: false, error: "invalid_date" };
  const reference = String(input.reference ?? "").trim().slice(0, 100);

  const client = await control.connect();
  try {
    await client.query("BEGIN");
    const inv = (await client.query("SELECT id, tenant_id, number, amount_bdt, status FROM invoices WHERE id = $1 FOR UPDATE", [invoiceId])).rows[0];
    if (!inv) { await client.query("ROLLBACK"); return { ok: false, error: "invoice_not_found" }; }
    if (inv.status === "void") { await client.query("ROLLBACK"); return { ok: false, error: "invoice_void" }; }
    const paid = (await client.query("SELECT COALESCE(sum(amount_bdt),0) AS s FROM payments WHERE invoice_id = $1", [invoiceId])).rows[0].s as number;
    if (inv.status === "paid" || paid >= inv.amount_bdt) { await client.query("ROLLBACK"); return { ok: false, error: "invoice_paid" }; }
    if (amount > inv.amount_bdt - paid) { await client.query("ROLLBACK"); return { ok: false, error: "overpayment" }; }
    try {
      await client.query("INSERT INTO payments (invoice_id, tenant_id, amount_bdt, method, reference, received_on, recorded_by) VALUES ($1,$2,$3,$4,$5,$6,$7)",
        [invoiceId, inv.tenant_id, amount, method, reference, receivedOn, actor]);
    } catch (err) {
      await client.query("ROLLBACK");
      if ((err as { code?: string }).code === "23505") return { ok: false, error: "duplicate_reference" };
      throw err;
    }
    const status = paid + amount >= inv.amount_bdt ? "paid" : "partial";
    await client.query("UPDATE invoices SET status = $2, paid_at = CASE WHEN $2 = 'paid' THEN now() ELSE NULL END WHERE id = $1", [invoiceId, status]);
    await audit(client, actor, "payment.recorded", inv.tenant_id, { invoice: inv.number, amount, method, reference, status });
    await client.query("COMMIT");
    return { ok: true, status };
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    throw err;
  } finally { client.release(); }
}

/** Only an invoice with no payments can be voided. (Refunds are a separate, later feature.) */
export async function voidInvoice(control: Pool, invoiceId: string, reason: unknown, actor: string): Promise<Result> {
  const why = String(reason ?? "").trim().slice(0, 300);
  if (!why) return { ok: false, error: "reason_required" };
  const client = await control.connect();
  try {
    await client.query("BEGIN");
    const inv = (await client.query("SELECT id, tenant_id, number, status FROM invoices WHERE id = $1 FOR UPDATE", [invoiceId])).rows[0];
    if (!inv) { await client.query("ROLLBACK"); return { ok: false, error: "invoice_not_found" }; }
    if (inv.status === "void") { await client.query("ROLLBACK"); return { ok: false, error: "invoice_void" }; }
    if ((await client.query("SELECT 1 FROM payments WHERE invoice_id = $1", [invoiceId])).rowCount) { await client.query("ROLLBACK"); return { ok: false, error: "has_payments" }; }
    await client.query("UPDATE invoices SET status='void', voided_at=now(), void_reason=$2 WHERE id=$1", [invoiceId, why]);
    await audit(client, actor, "invoice.voided", inv.tenant_id, { invoice: inv.number, reason: why });
    await client.query("COMMIT");
    return { ok: true };
  } catch (err) { await client.query("ROLLBACK").catch(() => {}); throw err; }
  finally { client.release(); }
}

export interface Summary { monthlyRecurring: number; outstanding: number; overdueCount: number; overdueAmount: number }

/** Gross recurring revenue is counted from ACTIVE clients only, using today's effective monthly fee. */
export async function billingSummary(control: Pool, today = todayUtc()): Promise<Summary> {
  const mrr = await control.query(
    `SELECT COALESCE(sum(b.monthly_fee_bdt - CASE WHEN b.monthly_discount_bdt > 0 AND (b.discount_until IS NULL OR b.discount_until >= $1::date)
                                                  THEN b.monthly_discount_bdt ELSE 0 END), 0) AS s
       FROM tenant_billing b JOIN tenants t ON t.id = b.tenant_id WHERE t.status = 'active'`, [today]);
  const open = await control.query(
    `SELECT COALESCE(sum(i.amount_bdt - p.paid), 0) AS outstanding,
            count(*) FILTER (WHERE i.due_date + COALESCE(b.grace_days, 7) < $1::date) AS overdue_count,
            COALESCE(sum(i.amount_bdt - p.paid) FILTER (WHERE i.due_date + COALESCE(b.grace_days, 7) < $1::date), 0) AS overdue_amount
       FROM invoices i
       LEFT JOIN tenant_billing b ON b.tenant_id = i.tenant_id
       CROSS JOIN LATERAL (SELECT COALESCE(sum(amount_bdt), 0) AS paid FROM payments WHERE invoice_id = i.id) p
      WHERE i.status IN ('unpaid','partial')`, [today]);
  const o = open.rows[0];
  return { monthlyRecurring: mrr.rows[0].s, outstanding: o.outstanding, overdueCount: o.overdue_count, overdueAmount: o.overdue_amount };
}

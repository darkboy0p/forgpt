import { createHash, randomBytes } from "node:crypto";
import type { Pool } from "pg";

export const SESSION_ABSOLUTE_MS = 12 * 60 * 60 * 1000; // hard limit: 12 hours
export const SESSION_IDLE_MS = 60 * 60 * 1000;          // log out after 1 hour of inactivity
const TOKEN_RE = /^[A-Za-z0-9_-]{43}$/;

export const hashToken = (t: string) => createHash("sha256").update(t).digest("hex");

export async function createSession(control: Pool, adminId: string, meta: { ip?: string; userAgent?: string }, now = new Date()) {
  const token = randomBytes(32).toString("base64url"); // 256 bits, shown to the browser once
  const expiresAt = new Date(now.getTime() + SESSION_ABSOLUTE_MS);
  await control.query(
    "INSERT INTO admin_sessions (admin_id, token_hash, expires_at, ip, user_agent, created_at, last_seen_at) VALUES ($1,$2,$3,$4,$5,$6,$6)",
    [adminId, hashToken(token), expiresAt, meta.ip ?? null, (meta.userAgent ?? "").slice(0, 200) || null, now]
  );
  return { token, expiresAt };
}

export interface SessionAdmin { adminId: string; email: string }

export async function getSessionAdmin(control: Pool, token: string | undefined, now = new Date()): Promise<SessionAdmin | null> {
  if (!token || !TOKEN_RE.test(token)) return null;
  const idleCutoff = new Date(now.getTime() - SESSION_IDLE_MS);
  const r = await control.query(
    `SELECT s.id, a.id AS admin_id, a.email, s.last_seen_at
       FROM admin_sessions s JOIN platform_admins a ON a.id = s.admin_id
      WHERE s.token_hash = $1 AND s.expires_at > $2 AND s.last_seen_at > $3 AND a.is_active`,
    [hashToken(token), now, idleCutoff]
  );
  const row = r.rows[0];
  if (!row) return null;
  if (now.getTime() - new Date(row.last_seen_at).getTime() > 60_000)
    await control.query("UPDATE admin_sessions SET last_seen_at = $2 WHERE id = $1", [row.id, now]);
  return { adminId: row.admin_id, email: row.email };
}

export async function revokeSession(control: Pool, token: string | undefined): Promise<void> {
  if (token && TOKEN_RE.test(token)) await control.query("DELETE FROM admin_sessions WHERE token_hash = $1", [hashToken(token)]);
}
export async function revokeAllSessions(control: Pool, adminId: string): Promise<void> {
  await control.query("DELETE FROM admin_sessions WHERE admin_id = $1", [adminId]);
}

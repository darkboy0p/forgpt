import type { Pool } from "pg";
import { hashPassword, passwordPolicyError } from "./password";
import { revokeAllSessions } from "./sessions";

export const normalizeEmail = (e: string) => e.trim().toLowerCase();
const EMAIL_RE = /^[^\s@<>"']{1,64}@[^\s@<>"']{1,255}\.[^\s@<>"']{2,}$/;

export class AdminError extends Error {}

export async function createPlatformAdmin(control: Pool, emailRaw: string, password: string): Promise<{ id: string; email: string }> {
  const email = normalizeEmail(emailRaw);
  if (!EMAIL_RE.test(email) || email.length > 254) throw new AdminError("Enter a valid email address.");
  const problem = passwordPolicyError(password, email);
  if (problem) throw new AdminError(problem);
  try {
    const r = await control.query("INSERT INTO platform_admins (email, password_hash) VALUES ($1,$2) RETURNING id", [email, await hashPassword(password)]);
    await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ($1,'admin.created',$2)", ["system", JSON.stringify({ email })]);
    return { id: r.rows[0].id, email };
  } catch (err) {
    if ((err as { code?: string }).code === "23505") throw new AdminError("An administrator with that email already exists.");
    throw err;
  }
}

/** Deactivating also ends every open session immediately. */
export async function deactivateAdmin(control: Pool, emailRaw: string): Promise<boolean> {
  const r = await control.query("UPDATE platform_admins SET is_active = false WHERE email = $1 RETURNING id", [normalizeEmail(emailRaw)]);
  if (!r.rowCount) return false;
  await revokeAllSessions(control, r.rows[0].id);
  await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ('system','admin.deactivated',$1)", [JSON.stringify({ email: normalizeEmail(emailRaw) })]);
  return true;
}

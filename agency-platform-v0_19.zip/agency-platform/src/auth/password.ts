import { scrypt, randomBytes, timingSafeEqual } from "node:crypto";

// scrypt (built into Node, no native add-ons to install). Parameters are stored inside each hash,
// so they can be strengthened later without breaking existing passwords.
const N = 65536, R = 8, P = 2, KEYLEN = 32, MAXMEM = 256 * 1024 * 1024;

function derive(password: string, salt: Buffer, n: number, r: number, p: number): Promise<Buffer> {
  return new Promise((resolve, reject) =>
    scrypt(password.normalize("NFKC"), salt, KEYLEN, { N: n, r, p, maxmem: MAXMEM }, (err, key) => (err ? reject(err) : resolve(key)))
  );
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await derive(password, salt, N, R, P);
  return ["scrypt", N, R, P, salt.toString("base64url"), key.toString("base64url")].join("$");
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [alg, n, r, p, salt, hash] = stored.split("$");
  if (alg !== "scrypt" || !n || !r || !p || !salt || !hash) return false;
  try {
    const expected = Buffer.from(hash, "base64url");
    const actual = await derive(password, Buffer.from(salt, "base64url"), Number(n), Number(r), Number(p));
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch { return false; }
}

let dummy: Promise<string> | undefined;
/** Used for unknown accounts so "no such email" takes as long as "wrong password". */
export function dummyHash(): Promise<string> { return (dummy ??= hashPassword("dummy-password-for-timing")); }

/** Returns an error message, or null when the password is acceptable. */
export function passwordPolicyError(password: string, email?: string): string | null {
  if (password.length < 12) return "Password must be at least 12 characters.";
  if (password.length > 128) return "Password must be at most 128 characters.";
  if (email && password.toLowerCase().includes(email.split("@")[0]!.toLowerCase()) && email.split("@")[0]!.length >= 4)
    return "Password must not contain your email name.";
  if (/^(.)\1+$/.test(password)) return "Password is too repetitive.";
  return null;
}

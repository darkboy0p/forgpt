import type { Pool } from "pg";
import { dummyHash, verifyPassword } from "./password";
import { createSession } from "./sessions";
import { normalizeEmail } from "./admins";

export const MAX_FAILS_PER_EMAIL = 5;
export const MAX_FAILS_PER_IP = 20;
export const WINDOW_MS = 15 * 60 * 1000;

export type LoginResult =
  | { ok: true; token: string; expiresAt: Date; adminId: string; email: string }
  | { ok: false; reason: "invalid" | "rate_limited" };

/** The caller shows ONE generic message for "invalid", so attackers learn nothing about which emails exist. */
export async function attemptLogin(
  control: Pool,
  input: { email: string; password: string; ip: string; userAgent?: string },
  now = new Date()
): Promise<LoginResult> {
  const email = normalizeEmail(input.email).slice(0, 254);
  const ip = (input.ip || "unknown").slice(0, 64);
  const since = new Date(now.getTime() - WINDOW_MS);

  const fails = await control.query(
    `SELECT count(*) FILTER (WHERE email = $1) AS by_email, count(*) FILTER (WHERE ip = $2) AS by_ip
       FROM login_attempts WHERE ok = false AND created_at > $3 AND (email = $1 OR ip = $2)`,
    [email, ip, since]
  );
  if (Number(fails.rows[0].by_email) >= MAX_FAILS_PER_EMAIL || Number(fails.rows[0].by_ip) >= MAX_FAILS_PER_IP) {
    await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ($1,'admin.login.blocked',$2)", [email, JSON.stringify({ ip })]);
    return { ok: false, reason: "rate_limited" };
  }

  const found = await control.query("SELECT id, password_hash, is_active FROM platform_admins WHERE email = $1", [email]);
  const admin = found.rows[0];
  const good = await verifyPassword(input.password, admin ? admin.password_hash : await dummyHash());

  if (!admin || !admin.is_active || !good) {
    await control.query("INSERT INTO login_attempts (email, ip, ok, created_at) VALUES ($1,$2,false,$3)", [email, ip, now]);
    await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ($1,'admin.login.failed',$2)", [email, JSON.stringify({ ip })]);
    return { ok: false, reason: "invalid" };
  }

  await control.query("DELETE FROM admin_sessions WHERE admin_id = $1 AND expires_at < $2", [admin.id, now]);
  const session = await createSession(control, admin.id, { ip, userAgent: input.userAgent }, now);
  await control.query("UPDATE platform_admins SET last_login_at = $2 WHERE id = $1", [admin.id, now]);
  await control.query("INSERT INTO login_attempts (email, ip, ok, created_at) VALUES ($1,$2,true,$3)", [email, ip, now]);
  await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ($1,'admin.login.success',$2)", [email, JSON.stringify({ ip })]);
  return { ok: true, token: session.token, expiresAt: session.expiresAt, adminId: admin.id, email };
}

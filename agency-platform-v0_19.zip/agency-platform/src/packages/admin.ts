import "../db/pgTypes";
import type { Pool } from "pg";
import { parseTaka } from "../billing/values";
import { FEATURES, FEATURE_BY_KEY, LIMIT_MAX, defaultValues, effectiveValues, type PackageOverrides } from "./features";
import { clearPackageCache } from "./resolve";

export type PackageError = "invalid_tier" | "invalid_price" | "description_too_long" | "invalid_limit" | "unknown_feature";
export interface PackageInput { description: unknown; setupFee: unknown; monthlyFee: unknown; flags: Record<string, boolean>; limits: Record<string, unknown> }

export interface PackageRow { tier: number; name: string; description: string; setup: number; monthly: number }
export async function listPackages(control: Pool): Promise<PackageRow[]> {
  return (await control.query("SELECT tier, name, description, setup_bdt, monthly_bdt FROM packages ORDER BY tier")).rows
    .map((r) => ({ tier: r.tier, name: r.name, description: r.description, setup: r.setup_bdt, monthly: r.monthly_bdt }));
}

/**
 * Updates a package's DEFAULT prices, description, features and limits. Only differences from the built-in defaults are stored.
 * This never touches any client's agreement or invoice: those keep the price that was agreed with that client.
 */
export async function updatePackage(control: Pool, tier: number, input: PackageInput, actor: string): Promise<{ ok: true; changes: number } | { ok: false; error: PackageError }> {
  if (!Number.isInteger(tier) || tier < 1 || tier > 5) return { ok: false, error: "invalid_tier" };
  const setup = parseTaka(input.setupFee), monthly = parseTaka(input.monthlyFee);
  if (setup === null || monthly === null) return { ok: false, error: "invalid_price" };
  const description = String(input.description ?? "").trim();
  if (description.length > 300) return { ok: false, error: "description_too_long" };
  for (const k of [...Object.keys(input.flags), ...Object.keys(input.limits)]) if (!FEATURE_BY_KEY[k]) return { ok: false, error: "unknown_feature" };
  const limits: Record<string, number> = {};
  for (const [k, raw] of Object.entries(input.limits)) {
    if (FEATURE_BY_KEY[k]!.kind !== "limit") return { ok: false, error: "unknown_feature" };
    const n = typeof raw === "string" ? (/^\d{1,7}$/.test(raw.trim()) ? Number(raw.trim()) : NaN) : Number(raw);
    if (!Number.isInteger(n) || n < 0 || n > LIMIT_MAX) return { ok: false, error: "invalid_limit" };
    limits[k] = n;
  }

  const client = await control.connect();
  try {
    await client.query("BEGIN");
    const cur = (await client.query("SELECT name, description, setup_bdt, monthly_bdt FROM packages WHERE tier = $1 FOR UPDATE", [tier])).rows[0];
    if (!cur) { await client.query("ROLLBACK"); return { ok: false, error: "invalid_tier" }; }
    const oldOverrides: PackageOverrides = {};
    for (const r of (await client.query("SELECT feature_key, enabled, limit_value FROM package_features WHERE tier = $1", [tier])).rows) oldOverrides[r.feature_key] = { enabled: r.enabled, limit: r.limit_value };
    const before = effectiveValues(tier, oldOverrides), defaults = defaultValues(tier);
    let changes = 0;
    const audit = (action: string, detail: object) => client.query("INSERT INTO audit_log (actor, action, detail) VALUES ($1,$2,$3)", [actor, action, JSON.stringify({ tier, ...detail })]);

    if (cur.setup_bdt !== setup || cur.monthly_bdt !== monthly) {
      await client.query("UPDATE packages SET setup_bdt=$2, setup_min_bdt=$2, setup_max_bdt=$2, monthly_bdt=$3 WHERE tier=$1", [tier, setup, monthly]);
      await audit("package.price.changed", { setup: { from: cur.setup_bdt, to: setup }, monthly: { from: cur.monthly_bdt, to: monthly } });
      changes++;
    }
    if (cur.description !== description) {
      await client.query("UPDATE packages SET description=$2 WHERE tier=$1", [tier, description]);
      await audit("package.description.changed", { from: cur.description, to: description });
      changes++;
    }
    const changed: { key: string; from: boolean | number; to: boolean | number }[] = [];
    for (const f of FEATURES) {
      const submitted = f.kind === "flag" ? (f.key in input.flags ? input.flags[f.key]! : undefined) : (f.key in limits ? limits[f.key]! : undefined);
      if (submitted === undefined) continue; // not on the form: leave as is
      if (submitted === before[f.key]) continue;
      changed.push({ key: f.key, from: before[f.key]!, to: submitted });
      if (submitted === defaults[f.key]) await client.query("DELETE FROM package_features WHERE tier=$1 AND feature_key=$2", [tier, f.key]);
      else await client.query(
        `INSERT INTO package_features (tier, feature_key, enabled, limit_value, updated_by) VALUES ($1,$2,$3,$4,$5)
         ON CONFLICT (tier, feature_key) DO UPDATE SET enabled=$3, limit_value=$4, updated_by=$5, updated_at=now()`,
        [tier, f.key, f.kind === "flag" ? submitted : null, f.kind === "limit" ? submitted : null, actor]);
    }
    if (changed.length) { await audit("package.features.changed", { changed }); changes += changed.length; }
    await client.query("COMMIT");
    clearPackageCache();
    return { ok: true, changes };
  } catch (err) { await client.query("ROLLBACK").catch(() => {}); throw err; }
  finally { client.release(); }
}

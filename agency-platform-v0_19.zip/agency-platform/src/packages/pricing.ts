import type { Pool } from "pg";
import { COMPARISON_ROWS, FEATURES, FEATURE_BY_KEY, type FeatureValues } from "./features";
import { getFeatureValues } from "./resolve";
import { listPackages } from "./admin";
import { getSettings } from "./requests";

export interface PricingPackage {
  tier: number; name: string; description: string; setup: number; monthly: number; values: FeatureValues;
  summary: { label: string; value: string; planned: boolean }[];
  features: { key: string; label: string; group: string; kind: "flag" | "limit"; included: boolean; value: boolean | number; planned: boolean; unit?: string }[];
}
export interface PricingData { packages: PricingPackage[]; settings: Record<string, string> }

/** Everything the pricing page needs, read from the database so a price or feature change shows up immediately. */
export async function getPricingData(control: Pool): Promise<PricingData> {
  const pkgs = await listPackages(control);
  const packages: PricingPackage[] = [];
  for (const p of pkgs) {
    const values = await getFeatureValues(control, p.tier);
    packages.push({
      ...p, values,
      summary: COMPARISON_ROWS.map((r) => ({ label: r.label, value: r.show(values), planned: !FEATURE_BY_KEY[r.feature]!.implemented })),
      features: FEATURES.map((f) => ({ key: f.key, label: f.label, group: f.group, kind: f.kind, included: f.kind === "flag" ? Boolean(values[f.key]) : (values[f.key] as number) > 0,
        value: values[f.key]!, planned: !f.implemented, unit: f.unit })),
    });
  }
  return { packages, settings: await getSettings(control) };
}

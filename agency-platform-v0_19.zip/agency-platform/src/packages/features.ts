/**
 * The catalogue of package features. `defaults` are the built-in values for tiers 1 to 5; the Super Admin can override them
 * in the database. `implemented: false` means the feature is planned but not built yet: it is shown as "coming soon" on the
 * pricing page and must not be promised to clients.
 */
export type FeatureGroup = "Website" | "Products" | "Selling" | "Reports" | "Support" | "Limits";
export interface FeatureDef {
  key: string; label: string; group: FeatureGroup; kind: "flag" | "limit"; implemented: boolean; unit?: string;
  /** Tier 1 to 5. */ defaults: readonly [boolean | number, boolean | number, boolean | number, boolean | number, boolean | number];
}
const F = false, T = true;
const flag = (key: string, label: string, group: FeatureGroup, implemented: boolean, d: [boolean, boolean, boolean, boolean, boolean]): FeatureDef =>
  ({ key, label, group, kind: "flag", implemented, defaults: d });
const lim = (key: string, label: string, implemented: boolean, unit: string, d: [number, number, number, number, number]): FeatureDef =>
  ({ key, label, group: "Limits", kind: "limit", implemented, unit, defaults: d });

export const FEATURES: readonly FeatureDef[] = [
  flag("site_editor", "Website content editor", "Website", true, [T, T, T, T, T]),
  flag("pages_basic", "Home, About, Services and Contact pages", "Website", true, [T, T, T, T, T]),
  flag("extra_pages", "More website pages (Gallery, Reviews)", "Website", true, [F, T, T, T, T]),
  flag("branding_basic", "Basic branding (main colour, logo)", "Website", true, [T, T, T, T, T]),
  flag("branding_advanced", "Colours, fonts and buttons (accent, background, text)", "Website", true, [T, T, T, T, T]),
  flag("layout_options", "Layout, size and placement options", "Website", true, [T, T, T, T, T]),
  flag("seo_basic", "Basic SEO (title, description, sitemap)", "Website", true, [T, T, T, T, T]),
  flag("seo_expanded", "Expanded SEO (sharing image, hide from Google)", "Website", true, [F, T, T, T, T]),
  flag("gallery", "Image gallery", "Website", true, [F, T, T, T, T]),
  flag("testimonials", "Testimonials and reviews", "Website", true, [F, T, T, T, T]),
  flag("inquiry_forms", "Inquiry and quote forms", "Website", true, [F, T, T, T, T]),
  flag("promo_banners", "Promotional banners", "Website", true, [F, T, T, T, T]),
  flag("homepage_sections", "Advanced homepage sections (highlights, FAQ)", "Website", true, [F, T, T, T, T]),
  flag("analytics_integration", "Google Analytics", "Website", true, [F, T, T, T, T]),
  flag("homepage_builder", "Advanced homepage builder", "Website", true, [F, F, F, F, T]),
  flag("premium_templates", "Premium website templates", "Website", true, [F, F, F, F, T]),
  flag("premium_branding", "Premium branding customization", "Website", true, [F, F, F, F, T]),

  flag("products", "Product management", "Products", true, [T, T, T, T, T]),
  flag("product_categories", "Product categories", "Products", true, [T, T, T, T, T]),
  flag("product_images", "Product images", "Products", true, [T, T, T, T, T]),
  flag("whatsapp_ordering", "WhatsApp order button", "Products", true, [T, T, T, T, T]),
  flag("stock_basic", "Available / unavailable status", "Products", true, [T, T, T, T, T]),
  flag("product_variants", "Product variants (size, colour)", "Products", true, [F, T, T, T, T]),
  flag("product_search", "Product search, sorting and filtering", "Products", true, [F, T, T, T, T]),
  flag("featured_products", "Featured products", "Products", true, [F, T, T, T, T]),
  flag("stock_advanced", "Stock quantity management", "Products", true, [F, T, T, T, T]),

  flag("cart_checkout", "Shopping cart and checkout (cash on delivery)", "Selling", true, [F, F, T, T, T]),
  flag("customer_accounts", "Customer registration and accounts", "Selling", false, [F, F, T, T, T]),
  flag("order_management", "Order management", "Selling", true, [F, F, T, T, T]),
  flag("customer_management", "Customer management", "Selling", true, [F, F, T, T, T]),
  flag("courier_steadfast", "Steadfast courier integration", "Selling", false, [F, F, T, T, T]),
  flag("discount_codes", "Discount and coupon codes", "Selling", true, [F, F, F, T, T]),
  flag("promo_campaigns", "Promotional campaigns", "Selling", true, [F, F, F, T, T]),
  flag("low_stock_alerts", "Low-stock notifications", "Selling", true, [F, F, F, T, T]),

  flag("reports_basic", "Basic sales reports", "Reports", true, [F, F, T, T, T]),
  flag("reports_advanced", "Detailed sales and product analytics", "Reports", true, [F, F, F, T, T]),
  flag("analytics_business", "Advanced business analytics", "Reports", false, [F, F, F, F, T]),

  flag("priority_support", "Priority support (within agreed limits)", "Support", true, [F, F, F, F, T]),

  lim("max_services", "Services you can list", true, "items", [6, 12, 12, 12, 12]),
  lim("max_testimonials", "Customer reviews", true, "items", [0, 10, 10, 10, 10]),
  lim("max_media_mb", "Image storage", true, "MB", [15, 40, 80, 150, 300]),
  lim("max_products", "Products", true, "items", [50, 250, 1000, 5000, 20000]),
  lim("max_product_images", "Images per product", true, "items", [3, 6, 8, 10, 12]),
];
export const FEATURE_BY_KEY: Record<string, FeatureDef> = Object.fromEntries(FEATURES.map((f) => [f.key, f]));
export const LIMIT_MAX = 1_000_000;

export type FeatureValues = Record<string, boolean | number>;
export type PackageOverrides = Record<string, { enabled: boolean | null; limit: number | null }>;

export function defaultValues(tier: number): FeatureValues {
  const i = Math.min(5, Math.max(1, Math.trunc(tier))) - 1;
  return Object.fromEntries(FEATURES.map((f) => [f.key, f.defaults[i]!]));
}
/** Built-in defaults with the Super Admin's saved changes applied on top. */
export function effectiveValues(tier: number, overrides: PackageOverrides = {}): FeatureValues {
  const values = defaultValues(tier);
  for (const f of FEATURES) {
    const o = overrides[f.key];
    if (!o) continue;
    if (f.kind === "flag" && o.enabled !== null) values[f.key] = o.enabled;
    if (f.kind === "limit" && o.limit !== null) values[f.key] = o.limit;
  }
  return values;
}

/** The rows of the public comparison table. `feature` is the main feature behind the row (used to show "coming soon"). */
export const COMPARISON_ROWS: { label: string; feature: string; show: (v: FeatureValues) => string }[] = (() => {
  const yn = (k: string) => (v: FeatureValues) => (v[k] ? "YES" : "NO");
  return [
    { label: "Product management", feature: "products", show: yn("products") },
    { label: "Product categories", feature: "product_categories", show: yn("product_categories") },
    { label: "Product images", feature: "product_images", show: yn("product_images") },
    { label: "Product variants", feature: "product_variants", show: yn("product_variants") },
    { label: "Stock management", feature: "stock_basic", show: (v) => (!v.stock_advanced ? (v.stock_basic ? "Basic" : "NO") : v.cart_checkout && !v.low_stock_alerts ? "YES" : "Advanced") },
    { label: "WhatsApp ordering", feature: "whatsapp_ordering", show: yn("whatsapp_ordering") },
    { label: "Shopping cart", feature: "cart_checkout", show: yn("cart_checkout") },
    { label: "Integrated checkout", feature: "cart_checkout", show: yn("cart_checkout") },
    { label: "Customer accounts", feature: "customer_accounts", show: yn("customer_accounts") },
    { label: "Order management", feature: "order_management", show: (v) => (v.order_management ? (v.reports_advanced ? "Advanced" : "YES") : v.whatsapp_ordering ? "WhatsApp" : "NO") },
    { label: "Steadfast integration", feature: "courier_steadfast", show: yn("courier_steadfast") },
    { label: "Discount codes", feature: "discount_codes", show: yn("discount_codes") },
    { label: "Advanced analytics", feature: "reports_basic", show: (v) => (v.analytics_business ? "Advanced" : v.reports_advanced ? "YES" : v.reports_basic ? "Basic" : "NO") },
    { label: "Premium customization", feature: "premium_branding", show: yn("premium_branding") },
  ];
})();

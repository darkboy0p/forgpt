import "../db/pgTypes";
import type { Pool } from "pg";
import { entitlementsFromValues, type Entitlements } from "../config/entitlements";
import { effectiveValues, type FeatureValues, type PackageOverrides } from "./features";

let cache: { at: number; byTier: Map<number, PackageOverrides> } | null = null;
const TTL_MS = 10_000;
export function clearPackageCache(): void { cache = null; }

async function overridesByTier(control: Pool): Promise<Map<number, PackageOverrides>> {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.byTier;
  const rows = (await control.query("SELECT tier, feature_key, enabled, limit_value FROM package_features")).rows;
  const byTier = new Map<number, PackageOverrides>();
  for (const r of rows) {
    const o = byTier.get(r.tier) ?? {};
    o[r.feature_key] = { enabled: r.enabled, limit: r.limit_value };
    byTier.set(r.tier, o);
  }
  cache = { at: Date.now(), byTier };
  return byTier;
}

/** The feature values a package has RIGHT NOW (defaults plus the Super Admin's saved changes). */
export async function getFeatureValues(control: Pool, tier: number): Promise<FeatureValues> {
  return effectiveValues(tier, (await overridesByTier(control)).get(tier) ?? {});
}
export async function getEntitlements(control: Pool, tier: number): Promise<Entitlements> {
  return entitlementsFromValues(await getFeatureValues(control, tier));
}
/** Server-side check for any single feature, used before running a restricted action. */
export async function hasFeature(control: Pool, tier: number, key: string): Promise<boolean> {
  return Boolean((await getFeatureValues(control, tier))[key]);
}

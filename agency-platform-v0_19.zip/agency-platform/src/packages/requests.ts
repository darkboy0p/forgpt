import type { Pool } from "pg";

export const MAX_OPEN_REQUESTS = 5;
export type RequestError = "invalid_message" | "invalid_tier" | "too_many_open";

export async function createClientRequest(control: Pool, tenantId: string, kind: "upgrade" | "support", messageRaw: unknown, requestedTier: unknown, actor: string): Promise<{ ok: true } | { ok: false; error: RequestError }> {
  const message = String(messageRaw ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").trim();
  if (message.length < 5 || message.length > 1000) return { ok: false, error: "invalid_message" };
  let tier: number | null = null;
  if (kind === "upgrade") {
    tier = Number(requestedTier);
    if (!Number.isInteger(tier) || tier < 1 || tier > 5) return { ok: false, error: "invalid_tier" };
  }
  const open = (await control.query("SELECT count(*) AS n FROM client_requests WHERE tenant_id = $1 AND status = 'open'", [tenantId])).rows[0].n as number;
  if (open >= MAX_OPEN_REQUESTS) return { ok: false, error: "too_many_open" };
  await control.query("INSERT INTO client_requests (tenant_id, kind, requested_tier, message, created_by) VALUES ($1,$2,$3,$4,$5)", [tenantId, kind, tier, message, actor]);
  await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,$2,$3,$4)", [actor, `client.request.${kind}`, tenantId, JSON.stringify({ requestedTier: tier })]);
  return { ok: true };
}
export async function markRequestDone(control: Pool, id: string, actor: string): Promise<boolean> {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id)) return false;
  const r = await control.query("UPDATE client_requests SET status='done', handled_at=now() WHERE id=$1 AND status='open' RETURNING tenant_id", [id]);
  if (!r.rows[0]) return false;
  await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,'client.request.handled',$2,$3)", [actor, r.rows[0].tenant_id, JSON.stringify({ id })]);
  return true;
}

export const SETTING_KEYS = ["agency_name", "agency_whatsapp", "agency_note", "agency_payment_note"] as const;
export async function getSettings(control: Pool): Promise<Record<string, string>> {
  return Object.fromEntries((await control.query("SELECT key, value FROM platform_settings")).rows.map((r) => [r.key, r.value]));
}
export async function saveSettings(control: Pool, input: Record<string, unknown>, actor: string): Promise<{ ok: true } | { ok: false; error: "invalid_whatsapp" | "too_long" }> {
  const name = String(input.agency_name ?? "").trim(), note = String(input.agency_note ?? "").trim(), pay = String(input.agency_payment_note ?? "").trim();
  const wa = String(input.agency_whatsapp ?? "").replace(/[\s+-]/g, "");
  if (name.length > 80 || note.length > 300 || pay.length > 300) return { ok: false, error: "too_long" };
  if (wa && !/^[0-9]{6,15}$/.test(wa)) return { ok: false, error: "invalid_whatsapp" };
  for (const [k, v] of [["agency_name", name], ["agency_whatsapp", wa], ["agency_note", note], ["agency_payment_note", pay]] as const) {
    if (v) await control.query("INSERT INTO platform_settings (key, value, updated_by) VALUES ($1,$2,$3) ON CONFLICT (key) DO UPDATE SET value=$2, updated_by=$3, updated_at=now()", [k, v, actor]);
    else await control.query("DELETE FROM platform_settings WHERE key = $1", [k]);
  }
  await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ($1,'platform.settings.changed',$2)", [actor, JSON.stringify({ keys: [...SETTING_KEYS] })]);
  return { ok: true };
}

import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

/** Finds a project folder both when run from scripts/tests and inside the bundled Next.js server (where the current folder is the project root). */
function findDir(rel: string): string {
  const candidates = [join(process.cwd(), rel)];
  try { candidates.push(join(dirname(fileURLToPath(import.meta.url)), "../..", rel)); } catch { /* bundled code may not have a file address */ }
  return candidates.find((c) => existsSync(c)) ?? candidates[0]!;
}
export const TENANT_MIGRATIONS_DIR = findDir("migrations/tenant");
export const CONTROL_MIGRATIONS_DIR = findDir("migrations/control");

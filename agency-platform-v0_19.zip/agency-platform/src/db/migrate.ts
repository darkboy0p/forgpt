import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { Pool } from "pg";

/**
 * Migration files from earlier versions that were replaced. Copying a new version over an old folder leaves the old
 * files behind, and running one of these would fail, so they are always skipped (you may delete them).
 */
export const OBSOLETE_MIGRATIONS: ReadonlySet<string> = new Set(["0005_shop.sql", "0006_campaigns.sql"]);

/** The *.sql files that should run, in order. */
export function listMigrationFiles(dir: string): string[] {
  return readdirSync(dir).filter((f) => f.endsWith(".sql") && !OBSOLETE_MIGRATIONS.has(f)).sort();
}

/** Applies *.sql files in name order, once each. Safe to run repeatedly. Returns newly applied file names. */
export async function runMigrations(pool: Pool, dir: string): Promise<string[]> {
  const client = await pool.connect();
  const applied: string[] = [];
  try {
    await client.query("SELECT pg_advisory_lock(727274)"); // stop two runners racing
    await client.query(
      "CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())"
    );
    const files = listMigrationFiles(dir);
    for (const file of files) {
      const done = await client.query("SELECT 1 FROM schema_migrations WHERE name = $1", [file]);
      if (done.rowCount) continue;
      await client.query("BEGIN");
      try {
        await client.query(readFileSync(join(dir, file), "utf8"));
        await client.query("INSERT INTO schema_migrations (name) VALUES ($1)", [file]);
        await client.query("COMMIT");
        applied.push(file);
      } catch (err) {
        await client.query("ROLLBACK");
        throw new Error(`Migration ${file} failed: ${(err as Error).message}`);
      }
    }
    return applied;
  } finally {
    await client.query("SELECT pg_advisory_unlock(727274)").catch(() => {});
    client.release();
  }
}

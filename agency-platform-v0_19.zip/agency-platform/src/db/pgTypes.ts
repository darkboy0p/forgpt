import pg from "pg";
// DATE -> "YYYY-MM-DD" text (no time-zone surprises). BIGINT/NUMERIC -> JS numbers (taka amounts are far below 2^53).
pg.types.setTypeParser(1082, (v: string) => v);
const toNumber = (v: string) => {
  const n = Number(v);
  if (!Number.isSafeInteger(n)) throw new Error("number too large");
  return n;
};
pg.types.setTypeParser(20, toNumber);
pg.types.setTypeParser(1700, toNumber);

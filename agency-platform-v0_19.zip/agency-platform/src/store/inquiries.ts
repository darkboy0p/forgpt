import "../db/pgTypes";
import type { Pool } from "pg";

export const INQUIRIES_PER_IP_PER_HOUR = 5;
export const INQUIRIES_PER_SITE_PER_DAY = 200;
export type InquiryError = "invalid_name" | "invalid_contact" | "invalid_message" | "rate_limited" | "unavailable";
const EMAIL_RE = /^[^\s@<>"']{1,64}@[^\s@<>"']{1,255}\.[^\s@<>"']{2,}$/;
const stripControl = (s: string) => s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");

export interface InquiryInput { name: unknown; phone: unknown; email: unknown; message: unknown; ip: string; honeypot?: unknown }

/** Public form: validated, size-limited and rate-limited. Bots that fill the hidden field get a fake success and nothing is stored. */
export async function submitInquiry(pool: Pool, input: InquiryInput, now = new Date()): Promise<{ ok: true } | { ok: false; error: InquiryError }> {
  if (typeof input.honeypot === "string" && input.honeypot.trim() !== "") return { ok: true };
  const name = stripControl(String(input.name ?? "")).trim(), phone = String(input.phone ?? "").trim(), email = String(input.email ?? "").trim().toLowerCase();
  const message = stripControl(String(input.message ?? "")).trim();
  if (name.length < 2 || name.length > 80) return { ok: false, error: "invalid_name" };
  if (!phone && !email) return { ok: false, error: "invalid_contact" };
  if (phone && !/^[0-9+\- ]{5,20}$/.test(phone)) return { ok: false, error: "invalid_contact" };
  if (email && (!EMAIL_RE.test(email) || email.length > 254)) return { ok: false, error: "invalid_contact" };
  if (message.length < 5 || message.length > 1000) return { ok: false, error: "invalid_message" };

  const ip = (input.ip || "unknown").slice(0, 64);
  const hourAgo = new Date(now.getTime() - 3600_000), dayAgo = new Date(now.getTime() - 86_400_000);
  const c = (await pool.query(
    `SELECT count(*) FILTER (WHERE ip = $1 AND created_at > $2) AS by_ip, count(*) FILTER (WHERE created_at > $3) AS by_site
       FROM inquiries WHERE created_at > $3`, [ip, hourAgo, dayAgo])).rows[0];
  if (c.by_ip >= INQUIRIES_PER_IP_PER_HOUR) return { ok: false, error: "rate_limited" };
  if (c.by_site >= INQUIRIES_PER_SITE_PER_DAY) return { ok: false, error: "unavailable" };
  await pool.query("INSERT INTO inquiries (name, phone, email, message, ip, created_at) VALUES ($1,$2,$3,$4,$5,$6)", [name, phone || null, email || null, message, ip, now]);
  return { ok: true };
}

export async function listInquiries(pool: Pool, limit = 100) {
  return (await pool.query("SELECT id, name, phone, email, message, status, created_at FROM inquiries ORDER BY created_at DESC LIMIT $1", [Math.min(limit, 200)])).rows as
    { id: string; name: string; phone: string | null; email: string | null; message: string; status: "new" | "done"; created_at: Date }[];
}
export async function countNewInquiries(pool: Pool): Promise<number> {
  return (await pool.query("SELECT count(*) AS c FROM inquiries WHERE status = 'new'")).rows[0].c as number;
}
export async function markInquiry(pool: Pool, id: string, status: "new" | "done"): Promise<boolean> {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id) || !["new", "done"].includes(status)) return false;
  return Boolean((await pool.query("UPDATE inquiries SET status = $2 WHERE id = $1", [id, status])).rowCount);
}

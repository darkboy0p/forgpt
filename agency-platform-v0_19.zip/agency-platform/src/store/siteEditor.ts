import type { Pool } from "pg";
import { contrastRatio, MIN_TEXT_CONTRAST } from "../config/color";
import { STYLABLE_SECTIONS, SECTION_ALIGNS, SPACINGS, CTA_URL_RE, TITLE_KEYS, DEFAULT_SITE_CONFIG, BUTTON_STYLES, DAYS, FONTS, LAYOUT_CHOICES, MAX_FAQS, MAX_HIGHLIGHTS, PROMO_STYLES, SECTION_KEYS, SOCIAL_KEYS, SOCIAL_PATTERNS, UUID_RE, parseSiteConfig, siteConfigV1, type SiteConfig } from "../config/siteConfig";
import type { Entitlements } from "../config/entitlements";

export interface ServiceRow { name: string; description: string; price: string }
export interface TestimonialRow { name: string; quote: string }
export interface HighlightRow { title: string; text: string }
export interface FaqRow { question: string; answer: string }
export interface EditorInput {
  primary: unknown; heroTitle: unknown; heroSubtitle: unknown; about: unknown; phone: unknown; whatsapp: unknown; address: unknown;
  /** key -> position number as text (blank or missing = hidden) */
  sectionOrder: Record<string, unknown>;
  /** Optional fields: `undefined` means "this field was not on the form", so the stored value is kept unchanged. */
  accent?: unknown; background?: unknown; text?: unknown; surface?: unknown; font?: unknown; buttonStyle?: unknown; heroStyle?: unknown; ga4?: unknown;
  heroAlign?: unknown; servicesView?: unknown; galleryPhotos?: unknown; pageWidth?: unknown; spacing?: unknown;
  /** Any layout choice by name (see LAYOUT_CHOICES). Unknown names are ignored. */
  layout?: Record<string, unknown>;
  highlights?: HighlightRow[]; faqs?: FaqRow[];
  /** Headings by section (see TITLE_KEYS). "" = use the standard heading. Needs the layout feature. */
  sectionTitles?: Record<string, unknown>;
  /** The main button in the top banner. Both blank = no custom button. */
  cta?: { label?: unknown; url?: unknown };
  /** Per-section colours, alignment and spacing. "" = follow the site-wide choice. */
  sectionStyles?: Record<string, { background?: unknown; text?: unknown; align?: unknown; spacing?: unknown }>;
  /** Announcement banner fields; `undefined` = not on the form, keep what is stored. */
  promo?: { text?: unknown; linkLabel?: unknown; linkUrl?: unknown; until?: unknown; style?: unknown };
  services?: ServiceRow[]; testimonials?: TestimonialRow[];
  email?: unknown; seoTitle?: unknown; seoDescription?: unknown;
  /** "" clears. Needs the Expanded SEO feature. */
  seoShareImage?: unknown;
  /** true/false from a checkbox. Turning it ON needs the Expanded SEO feature. */
  seoNoindex?: boolean;
  hours?: Record<string, unknown>; social?: Record<string, unknown>;
  /** Ids of uploaded images ("" clears). Gallery is a list of ids. */
  images?: { logo?: unknown; hero?: unknown; about?: unknown; gallery?: unknown[] };
}
/** What the server already knows about the client's uploaded images, so unknown ids are rejected. */
export interface EditorContext { mediaIds?: Set<string> }
export type EditorError = "invalid_color" | "invalid_contact" | "too_long" | "no_sections" | "invalid" | "not_in_package" | "invalid_choice" | "invalid_analytics" | "incomplete_row" | "invalid_social" | "invalid_media" | "invalid_link" | "invalid_date" | "low_contrast";

const clean = (v: unknown, max: number) => { const s = typeof v === "string" ? v.trim().slice(0, max + 1) : ""; return s === "" ? undefined : s; };
const isHex = (v: unknown): v is string => typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v.trim());

/**
 * Builds a validated config from form fields. Anything unexpected is rejected, never "fixed" silently.
 * When `ent` is given, anything the client's package does not include is rejected too (server-side enforcement).
 */
export function buildConfigFromForm(input: EditorInput, base: SiteConfig = DEFAULT_SITE_CONFIG, ent?: Entitlements, ctx: EditorContext = {}): { ok: true; config: SiteConfig } | { ok: false; error: EditorError } {
  if (!isHex(input.primary)) return { ok: false, error: "invalid_color" };
  const primary = (input.primary as string).trim();
  const sections = SECTION_KEYS
    .map((key) => ({ key, pos: Number(String(input.sectionOrder[key] ?? "").trim()), shown: String(input.sectionOrder[key] ?? "").trim() !== "" }))
    .filter((s) => s.shown && Number.isFinite(s.pos))
    .sort((a, b) => a.pos - b.pos).map((s) => s.key);
  if (sections.length === 0) return { ok: false, error: "no_sections" };
  if (ent && sections.some((s) => !ent.sections.includes(s))) return { ok: false, error: "not_in_package" };

  const phone = clean(input.phone, 20), whatsapp = clean(input.whatsapp, 15)?.replace(/[\s+-]/g, "");
  if (phone && !/^[0-9+\- ]{5,20}$/.test(phone)) return { ok: false, error: "invalid_contact" };
  if (whatsapp && !/^[0-9]{6,15}$/.test(whatsapp)) return { ok: false, error: "invalid_contact" };
  const limits: [unknown, number][] = [[input.heroTitle, 120], [input.heroSubtitle, 240], [input.about, 2000], [input.address, 200]];
  if (limits.some(([v, max]) => typeof v === "string" && v.trim().length > max)) return { ok: false, error: "too_long" };

  // Optional blocks: only changed when they were actually submitted.
  let theme = { ...base.theme, primary }, layout = { ...base.layout }, analytics = { ...base.analytics };
  if (input.accent !== undefined || input.background !== undefined || input.text !== undefined || input.surface !== undefined || input.font !== undefined || input.buttonStyle !== undefined) {
    if (ent && !ent.branding) return { ok: false, error: "not_in_package" };
    if (input.accent !== undefined) { if (!isHex(input.accent)) return { ok: false, error: "invalid_color" }; theme.accent = (input.accent as string).trim(); }
    for (const k of ["background", "text", "surface"] as const) {
      if (input[k] !== undefined) { if (!isHex(input[k])) return { ok: false, error: "invalid_color" }; theme[k] = (input[k] as string).trim(); }
    }
    if (contrastRatio(theme.text, theme.background) < MIN_TEXT_CONTRAST) return { ok: false, error: "low_contrast" };
    if (input.font !== undefined) { if (!(FONTS as readonly unknown[]).includes(input.font)) return { ok: false, error: "invalid_choice" }; theme.font = input.font as SiteConfig["theme"]["font"]; }
    if (input.buttonStyle !== undefined) { if (!(BUTTON_STYLES as readonly unknown[]).includes(input.buttonStyle)) return { ok: false, error: "invalid_choice" }; theme.buttonStyle = input.buttonStyle as SiteConfig["theme"]["buttonStyle"]; }
  }
  const submitted: Record<string, unknown> = { heroStyle: input.heroStyle, heroAlign: input.heroAlign, servicesView: input.servicesView, galleryPhotos: input.galleryPhotos, pageWidth: input.pageWidth, spacing: input.spacing, ...input.layout };
  for (const [key, allowed] of Object.entries(LAYOUT_CHOICES) as [keyof SiteConfig["layout"], readonly string[]][]) {
    const value = submitted[key];
    if (value === undefined) continue;
    if (ent && !ent.layout) return { ok: false, error: "not_in_package" };
    if (typeof value !== "string" || !allowed.includes(value)) return { ok: false, error: "invalid_choice" };
    (layout as Record<string, string>)[key] = value;
  }
  if (input.ga4 !== undefined) {
    const g = typeof input.ga4 === "string" ? input.ga4.trim().toUpperCase() : "";
    if (g && ent && !ent.analytics) return { ok: false, error: "not_in_package" };
    if (g && !/^G-[A-Z0-9]{4,14}$/.test(g)) return { ok: false, error: "invalid_analytics" };
    analytics = g ? { ga4: g } : {};
  }

  const rows = <T extends object>(list: T[] | undefined, nameOf: (r: T) => string, others: (r: T) => string[]): T[] | "incomplete" | undefined => {
    if (list === undefined) return undefined;
    const kept: T[] = [];
    for (const r of list) {
      const hasName = nameOf(r).trim() !== "";
      if (!hasName && others(r).some((o) => o.trim() !== "")) return "incomplete";
      if (hasName) kept.push(r);
    }
    return kept;
  };
  const services = rows(input.services, (r) => r.name, (r) => [r.description, r.price]);
  const testimonials = rows(input.testimonials, (r) => r.name, (r) => [r.quote]);
  const highlights = rows(input.highlights, (r) => r.title, (r) => [r.text]);
  const faqs = rows(input.faqs, (r) => r.question, (r) => [r.answer]);
  if (services === "incomplete" || testimonials === "incomplete" || highlights === "incomplete" || faqs === "incomplete") return { ok: false, error: "incomplete_row" };
  if (faqs && faqs.some((r) => r.answer.trim() === "")) return { ok: false, error: "incomplete_row" };
  if (((highlights && highlights.length) || (faqs && faqs.length)) && ent && !ent.advancedSections) return { ok: false, error: "not_in_package" };
  if ((highlights && highlights.length > MAX_HIGHLIGHTS) || (faqs && faqs.length > MAX_FAQS)) return { ok: false, error: "too_long" };
  if (testimonials && testimonials.some((r) => r.quote.trim() === "")) return { ok: false, error: "incomplete_row" };
  if (ent && services && services.length > ent.maxServices) return { ok: false, error: "not_in_package" };
  if (ent && testimonials && testimonials.length > ent.maxTestimonials) return { ok: false, error: "not_in_package" };

  let sectionTitles = { ...base.content.sectionTitles };
  if (input.sectionTitles !== undefined) {
    const next: Record<string, string> = {};
    for (const k of TITLE_KEYS) {
      const raw = input.sectionTitles[k];
      const t = typeof raw === "string" ? raw.replace(/[\u0000-\u001f]/g, "").trim() : "";
      if (t.length > 40) return { ok: false, error: "too_long" };
      if (/[<>]/.test(t)) return { ok: false, error: "invalid_choice" };
      if (t) next[k] = t;
    }
    if (Object.keys(next).length && ent && !ent.layout) return { ok: false, error: "not_in_package" };
    sectionTitles = next;
  }
  let cta = { ...base.content.cta };
  if (input.cta !== undefined) {
    const str = (v: unknown) => (typeof v === "string" ? v.trim() : "");
    const label = str(input.cta.label), url = str(input.cta.url);
    if ((label || url) && ent && !ent.layout) return { ok: false, error: "not_in_package" };
    if (label.length > 30) return { ok: false, error: "too_long" };
    if (!label && !url) cta = {};
    else if (!label || !url) return { ok: false, error: "incomplete_row" };
    else if (!CTA_URL_RE.test(url)) return { ok: false, error: "invalid_link" };
    else cta = { label, url };
  }
  let sectionStyles = { ...base.sectionStyles };
  if (input.sectionStyles !== undefined) {
    const next: SiteConfig["sectionStyles"] = {};
    for (const k of STYLABLE_SECTIONS) {
      const row = input.sectionStyles[k];
      if (!row) continue;
      const str = (v: unknown) => (typeof v === "string" ? v.trim() : "");
      const background = str(row.background), text = str(row.text), align = str(row.align), spacing = str(row.spacing);
      if ((background && !isHex(background)) || (text && !isHex(text))) return { ok: false, error: "invalid_color" };
      if ((align && !(SECTION_ALIGNS as readonly string[]).includes(align)) || (spacing && !(SPACINGS as readonly string[]).includes(spacing))) return { ok: false, error: "invalid_choice" };
      if ((background || text) && ent && !ent.sectionColours) return { ok: false, error: "not_in_package" };
      if ((align || spacing) && ent && !ent.sectionLayout) return { ok: false, error: "not_in_package" };
      if ((background || text) && contrastRatio(text || theme.text, background || theme.background) < MIN_TEXT_CONTRAST) return { ok: false, error: "low_contrast" };
      const one = { ...(background ? { background } : {}), ...(text ? { text } : {}), ...(align ? { align: align as "left" | "center" } : {}), ...(spacing ? { spacing: spacing as (typeof SPACINGS)[number] } : {}) };
      if (Object.keys(one).length) (next as Record<string, unknown>)[k] = one;
    }
    sectionStyles = next;
  }
  let promo = { ...base.promo };
  if (input.promo !== undefined) {
    const p = input.promo, str = (v: unknown) => (typeof v === "string" ? v.trim() : "");
    const text = str(p.text), label = str(p.linkLabel), url = str(p.linkUrl), until = str(p.until), style = p.style === undefined ? promo.style : p.style;
    if (text && ent && !ent.promo) return { ok: false, error: "not_in_package" };
    if (text.length > 140 || label.length > 30) return { ok: false, error: "too_long" };
    if (!(PROMO_STYLES as readonly unknown[]).includes(style)) return { ok: false, error: "invalid_choice" };
    if (!text) promo = { style: style as SiteConfig["promo"]["style"] };
    else {
      if (url && !/^(https:\/\/[^\s"'<>]{4,300}|\/(?!\/)[a-zA-Z0-9\-_\/#]{0,100})$/.test(url)) return { ok: false, error: "invalid_link" };
      if (until && (!/^\d{4}-\d{2}-\d{2}$/.test(until) || new Date(until + "T00:00:00Z").toISOString().slice(0, 10) !== until)) return { ok: false, error: "invalid_date" };
      promo = { text, linkLabel: label || undefined, linkUrl: url || undefined, until: until || undefined, style: style as SiteConfig["promo"]["style"] };
    }
  }

  // Business details available to every package.
  let email = base.content.email;
  if (input.email !== undefined) {
    const e = typeof input.email === "string" ? input.email.trim().toLowerCase() : "";
    if (e && !/^[^\s@<>"']{1,64}@[^\s@<>"']{1,255}\.[^\s@<>"']{2,}$/.test(e)) return { ok: false, error: "invalid_contact" };
    email = e || undefined;
  }
  let hours = { ...base.hours };
  if (input.hours !== undefined) {
    hours = {};
    for (const d of DAYS) {
      const v = typeof input.hours[d] === "string" ? (input.hours[d] as string).trim() : "";
      if (v.length > 40) return { ok: false, error: "too_long" };
      if (v) hours[d] = v;
    }
  }
  let social = { ...base.social };
  if (input.social !== undefined) {
    social = {};
    for (const k of SOCIAL_KEYS) {
      const v = typeof input.social[k] === "string" ? (input.social[k] as string).trim() : "";
      if (!v) continue;
      if (!SOCIAL_PATTERNS[k].test(v)) return { ok: false, error: "invalid_social" };
      social[k] = v;
    }
  }
  let seo = { ...base.seo };
  if (input.seoTitle !== undefined || input.seoDescription !== undefined) {
    const t = typeof input.seoTitle === "string" ? input.seoTitle.trim() : (base.seo.title ?? ""), d = typeof input.seoDescription === "string" ? input.seoDescription.trim() : (base.seo.description ?? "");
    if (t.length > 70 || d.length > 170) return { ok: false, error: "too_long" };
    seo = { ...base.seo, title: t || undefined, description: d || undefined };
  }
  if (input.seoShareImage !== undefined) {
    const x = typeof input.seoShareImage === "string" ? input.seoShareImage.trim() : "";
    if (x && ent && !ent.seoExpanded) return { ok: false, error: "not_in_package" };
    if (x && (!UUID_RE.test(x) || (ctx.mediaIds && !ctx.mediaIds.has(x)))) return { ok: false, error: "invalid_media" };
    seo = { ...seo, shareImage: x || undefined };
  }
  if (input.seoNoindex !== undefined) {
    if (input.seoNoindex && ent && !ent.seoExpanded) return { ok: false, error: "not_in_package" };
    seo = { ...seo, noindex: input.seoNoindex ? true : undefined };
  }
  let images = { ...base.images, gallery: [...base.images.gallery] };
  if (input.images !== undefined) {
    const one = (v: unknown): string | undefined | "bad" => {
      if (v === undefined) return undefined;
      const x = typeof v === "string" ? v.trim() : "";
      if (x === "") return undefined;
      if (!UUID_RE.test(x) || (ctx.mediaIds && !ctx.mediaIds.has(x))) return "bad";
      return x;
    };
    const logo = one(input.images.logo), hero = one(input.images.hero), about = one(input.images.about);
    if (logo === "bad" || hero === "bad" || about === "bad") return { ok: false, error: "invalid_media" };
    const gal = (input.images.gallery ?? []).map(one).filter((v): v is string => v !== undefined);
    if (gal.includes("bad" as never)) return { ok: false, error: "invalid_media" };
    if (gal.length > 0 && ent && !ent.gallery) return { ok: false, error: "not_in_package" };
    images = { logo, hero, about, gallery: [...new Set(gal)] };
  }

  const parsed = siteConfigV1.safeParse({
    theme, layout, sections, analytics, hours, social, seo, images, promo, sectionStyles,
    content: {
      heroTitle: clean(input.heroTitle, 120), heroSubtitle: clean(input.heroSubtitle, 240), about: clean(input.about, 2000), phone, whatsapp, address: clean(input.address, 200), email,
      services: services ?? base.content.services, testimonials: testimonials ?? base.content.testimonials,
      highlights: highlights ?? base.content.highlights, faqs: faqs ?? base.content.faqs, sectionTitles, cta,
    },
  });
  return parsed.success ? { ok: true, config: parsed.data } : { ok: false, error: "invalid" };
}

export interface EditorState { live: SiteConfig; draft: SiteConfig | null; hasUnpublishedChanges: boolean; publishedAt: string | null; draftUpdatedAt: string | null }

export async function loadEditorState(pool: Pool): Promise<EditorState> {
  const row = (await pool.query("SELECT config, draft, published_at, draft_updated_at FROM site_config WHERE id = 1")).rows[0];
  const live = parseSiteConfig(row?.config).config;
  const draft = row?.draft ? parseSiteConfig(row.draft).config : null;
  return { live, draft, hasUnpublishedChanges: draft !== null && JSON.stringify(draft) !== JSON.stringify(live),
    publishedAt: row?.published_at ? new Date(row.published_at).toISOString() : null, draftUpdatedAt: row?.draft_updated_at ? new Date(row.draft_updated_at).toISOString() : null };
}

export async function saveDraft(pool: Pool, config: SiteConfig, actorEmail: string): Promise<void> {
  const valid = siteConfigV1.parse(config); // validated again at the point of writing
  await pool.query("UPDATE site_config SET draft = $1, draft_updated_at = now(), draft_updated_by = $2 WHERE id = 1", [JSON.stringify(valid), actorEmail]);
}

/** Makes the saved draft the live site. The previous live version is kept in history. Atomic. */
export async function publishDraft(pool: Pool, actorEmail: string): Promise<{ ok: true } | { ok: false; error: "no_draft" | "invalid_draft" }> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const row = (await client.query("SELECT config, draft FROM site_config WHERE id = 1 FOR UPDATE")).rows[0];
    if (!row?.draft) { await client.query("ROLLBACK"); return { ok: false, error: "no_draft" }; }
    const check = siteConfigV1.safeParse(row.draft);
    if (!check.success) { await client.query("ROLLBACK"); return { ok: false, error: "invalid_draft" }; }
    await client.query("INSERT INTO site_config_history (config, published_by) VALUES ($1, $2)", [JSON.stringify(row.config), actorEmail]);
    await client.query("DELETE FROM site_config_history WHERE id NOT IN (SELECT id FROM site_config_history ORDER BY id DESC LIMIT 20)");
    await client.query("UPDATE site_config SET config = $1, published_at = now(), published_by = $2 WHERE id = 1", [JSON.stringify(check.data), actorEmail]);
    await client.query("COMMIT");
    return { ok: true };
  } catch (err) { await client.query("ROLLBACK").catch(() => {}); throw err; }
  finally { client.release(); }
}

/** Drops unpublished changes and starts the draft again from the live site. */
export async function discardDraft(pool: Pool): Promise<void> {
  await pool.query("UPDATE site_config SET draft = NULL, draft_updated_at = NULL, draft_updated_by = NULL WHERE id = 1");
}

import "../db/pgTypes";
import { randomBytes, randomInt } from "node:crypto";
import type { Pool } from "pg";
import { dummyHash, hashPassword, passwordPolicyError, verifyPassword } from "../auth/password";
import { hashToken, SESSION_ABSOLUTE_MS, SESSION_IDLE_MS } from "../auth/sessions";

// Store-owner accounts live INSIDE each client's own database, so a login or session from one client
// can never be valid for another client: the other database simply does not contain it.

export const STORE_MAX_FAILS_PER_EMAIL = 5;
export const STORE_MAX_FAILS_PER_IP = 20;
export const STORE_WINDOW_MS = 15 * 60 * 1000;
const TOKEN_RE = /^[A-Za-z0-9_-]{43}$/;
const EMAIL_RE = /^[^\s@<>"']{1,64}@[^\s@<>"']{1,255}\.[^\s@<>"']{2,}$/;
const normalizeEmail = (e: string) => e.trim().toLowerCase();

export class StaffError extends Error {}

/** 16 characters from an alphabet without look-alike characters. Shown to the admin once. */
export function generateTempPassword(): string {
  const alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
  return Array.from({ length: 16 }, () => alphabet[randomInt(alphabet.length)]).join("");
}

/** Creates the owner login with a temporary password the owner must change at first sign-in. */
export async function createStaffOwner(pool: Pool, emailRaw: string): Promise<{ id: string; email: string; tempPassword: string }> {
  const email = normalizeEmail(emailRaw);
  if (!EMAIL_RE.test(email) || email.length > 254) throw new StaffError("Enter a valid email address.");
  const tempPassword = generateTempPassword();
  try {
    const r = await pool.query("INSERT INTO staff_users (email, password_hash, must_change_password) VALUES ($1,$2,true) RETURNING id", [email, await hashPassword(tempPassword)]);
    return { id: r.rows[0].id, email, tempPassword };
  } catch (err) {
    if ((err as { code?: string }).code === "23505") throw new StaffError("An owner login with that email already exists.");
    throw err;
  }
}

/** New temporary password; every open session of that person ends immediately. */
export async function resetStaffPassword(pool: Pool, emailRaw: string): Promise<{ tempPassword: string } | null> {
  const tempPassword = generateTempPassword();
  const r = await pool.query("UPDATE staff_users SET password_hash=$2, must_change_password=true, is_active=true WHERE email=$1 RETURNING id", [normalizeEmail(emailRaw), await hashPassword(tempPassword)]);
  if (!r.rows[0]) return null;
  await pool.query("DELETE FROM staff_sessions WHERE staff_id = $1", [r.rows[0].id]);
  return { tempPassword };
}

export async function setStaffActive(pool: Pool, emailRaw: string, active: boolean): Promise<boolean> {
  const r = await pool.query("UPDATE staff_users SET is_active=$2 WHERE email=$1 RETURNING id", [normalizeEmail(emailRaw), active]);
  if (!r.rows[0]) return false;
  if (!active) await pool.query("DELETE FROM staff_sessions WHERE staff_id = $1", [r.rows[0].id]);
  return true;
}

export type StoreLoginResult =
  | { ok: true; token: string; expiresAt: Date; staffId: string; email: string; mustChangePassword: boolean }
  | { ok: false; reason: "invalid" | "rate_limited" };

export async function attemptStoreLogin(pool: Pool, input: { email: string; password: string; ip: string; userAgent?: string }, now = new Date()): Promise<StoreLoginResult> {
  const email = normalizeEmail(input.email).slice(0, 254);
  const ip = (input.ip || "unknown").slice(0, 64);
  const since = new Date(now.getTime() - STORE_WINDOW_MS);
  const f = (await pool.query(
    `SELECT count(*) FILTER (WHERE email = $1) AS by_email, count(*) FILTER (WHERE ip = $2) AS by_ip
       FROM staff_login_attempts WHERE ok = false AND created_at > $3 AND (email = $1 OR ip = $2)`, [email, ip, since])).rows[0];
  if (f.by_email >= STORE_MAX_FAILS_PER_EMAIL || f.by_ip >= STORE_MAX_FAILS_PER_IP) return { ok: false, reason: "rate_limited" };

  const staff = (await pool.query("SELECT id, password_hash, is_active, must_change_password FROM staff_users WHERE email = $1", [email])).rows[0];
  const good = await verifyPassword(input.password, staff ? staff.password_hash : await dummyHash());
  if (!staff || !staff.is_active || !good) {
    await pool.query("INSERT INTO staff_login_attempts (email, ip, ok, created_at) VALUES ($1,$2,false,$3)", [email, ip, now]);
    return { ok: false, reason: "invalid" };
  }
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(now.getTime() + SESSION_ABSOLUTE_MS);
  await pool.query("DELETE FROM staff_sessions WHERE staff_id = $1 AND expires_at < $2", [staff.id, now]);
  await pool.query("INSERT INTO staff_sessions (staff_id, token_hash, expires_at, ip, user_agent, created_at, last_seen_at) VALUES ($1,$2,$3,$4,$5,$6,$6)",
    [staff.id, hashToken(token), expiresAt, ip, (input.userAgent ?? "").slice(0, 200) || null, now]);
  await pool.query("UPDATE staff_users SET last_login_at = $2 WHERE id = $1", [staff.id, now]);
  await pool.query("INSERT INTO staff_login_attempts (email, ip, ok, created_at) VALUES ($1,$2,true,$3)", [email, ip, now]);
  return { ok: true, token, expiresAt, staffId: staff.id, email, mustChangePassword: staff.must_change_password };
}

export interface StaffSession { staffId: string; email: string; mustChangePassword: boolean }

export async function getStaffSession(pool: Pool, token: string | undefined, now = new Date()): Promise<StaffSession | null> {
  if (!token || !TOKEN_RE.test(token)) return null;
  const idleCutoff = new Date(now.getTime() - SESSION_IDLE_MS);
  const r = (await pool.query(
    `SELECT s.id, u.id AS staff_id, u.email, u.must_change_password, s.last_seen_at
       FROM staff_sessions s JOIN staff_users u ON u.id = s.staff_id
      WHERE s.token_hash = $1 AND s.expires_at > $2 AND s.last_seen_at > $3 AND u.is_active`, [hashToken(token), now, idleCutoff])).rows[0];
  if (!r) return null;
  if (now.getTime() - new Date(r.last_seen_at).getTime() > 60_000) await pool.query("UPDATE staff_sessions SET last_seen_at = $2 WHERE id = $1", [r.id, now]);
  return { staffId: r.staff_id, email: r.email, mustChangePassword: r.must_change_password };
}

export async function revokeStaffSession(pool: Pool, token: string | undefined): Promise<void> {
  if (token && TOKEN_RE.test(token)) await pool.query("DELETE FROM staff_sessions WHERE token_hash = $1", [hashToken(token)]);
}

/** The owner chooses their own password; other open sessions end, the current one (if given) stays. */
export async function changeStaffPassword(pool: Pool, staffId: string, current: string, next: string, keepToken?: string): Promise<{ ok: true } | { ok: false; error: "wrong_password" | "weak_password" | "same_password"; message?: string }> {
  const u = (await pool.query("SELECT email, password_hash FROM staff_users WHERE id = $1 AND is_active", [staffId])).rows[0];
  if (!u || !(await verifyPassword(current, u.password_hash))) return { ok: false, error: "wrong_password" };
  if (current === next) return { ok: false, error: "same_password" };
  const problem = passwordPolicyError(next, u.email);
  if (problem) return { ok: false, error: "weak_password", message: problem };
  await pool.query("UPDATE staff_users SET password_hash=$2, must_change_password=false WHERE id=$1", [staffId, await hashPassword(next)]);
  await pool.query("DELETE FROM staff_sessions WHERE staff_id = $1 AND token_hash <> $2", [staffId, keepToken && TOKEN_RE.test(keepToken) ? hashToken(keepToken) : ""]);
  return { ok: true };
}

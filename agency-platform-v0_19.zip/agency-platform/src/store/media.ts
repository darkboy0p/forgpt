import "../db/pgTypes";
import { orIfMissingSchema } from "../shop/safe";
import type { Pool } from "pg";
import type { Entitlements } from "../config/entitlements";
import { UUID_RE } from "../config/siteConfig";

export const MEDIA_KINDS = ["logo", "hero", "about", "gallery", "product"] as const;
export type MediaKind = (typeof MEDIA_KINDS)[number];
/** Per-image size limits (bytes). Small on purpose: images are stored in the client's database, not in file storage. */
export const KIND_LIMITS: Record<MediaKind, number> = { logo: 300 * 1024, hero: 1024 * 1024, about: 1024 * 1024, gallery: 800 * 1024, product: 500 * 1024 };
/** Cap on logo, banner, about and gallery images together. Product photos are limited per product and by storage instead. */
export const MAX_MEDIA_COUNT = 40;

/** The file type is decided by the file's own first bytes, never by its name or what the browser claims. SVG is refused (it can carry scripts). */
export function detectImageType(b: Uint8Array): "image/png" | "image/jpeg" | "image/webp" | null {
  if (b.length > 12 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a) return "image/png";
  if (b.length > 4 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.length > 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  return null;
}
export function safeFilename(name: unknown): string {
  const base = String(name ?? "image").split(/[\\/]/).pop() ?? "image";
  return base.replace(/[^\w .()-]/g, "_").replace(/^\.+/, "").slice(0, 60) || "image";
}

export type MediaError = "invalid_kind" | "not_in_package" | "empty" | "too_large" | "bad_type" | "quota" | "too_many" | "alt_required" | "not_found" | "in_use";

export async function saveMedia(pool: Pool, ent: Entitlements, input: { kind: unknown; filename: unknown; alt: unknown; bytes: Uint8Array }, actor: string): Promise<{ ok: true; id: string } | { ok: false; error: MediaError }> {
  const kind = String(input.kind) as MediaKind;
  if (!(MEDIA_KINDS as readonly string[]).includes(kind)) return { ok: false, error: "invalid_kind" };
  if (kind === "gallery" && !ent.gallery) return { ok: false, error: "not_in_package" };
  if (kind === "product" && !ent.shop.images) return { ok: false, error: "not_in_package" };
  if (input.bytes.length === 0) return { ok: false, error: "empty" };
  if (input.bytes.length > KIND_LIMITS[kind]) return { ok: false, error: "too_large" };
  const type = detectImageType(input.bytes);
  if (!type) return { ok: false, error: "bad_type" };
  const alt = String(input.alt ?? "").trim().slice(0, 120);
  if (kind === "gallery" && alt === "") return { ok: false, error: "alt_required" }; // gallery photos need a description for accessibility
  const usage = (await pool.query("SELECT count(*) FILTER (WHERE kind <> 'product') AS n, COALESCE(sum(size_bytes), 0) AS bytes FROM media")).rows[0];
  if (kind !== "product" && usage.n >= MAX_MEDIA_COUNT) return { ok: false, error: "too_many" };
  if (usage.bytes + input.bytes.length > ent.maxMediaBytes) return { ok: false, error: "quota" };
  const r = await pool.query("INSERT INTO media (kind, filename, content_type, size_bytes, alt, data, created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id",
    [kind, safeFilename(input.filename), type, input.bytes.length, alt, Buffer.from(input.bytes), actor]);
  return { ok: true, id: r.rows[0].id };
}

export interface MediaItem { id: string; kind: MediaKind; filename: string; size_bytes: number; alt: string; created_at: Date }
export async function listMedia(pool: Pool): Promise<MediaItem[]> {
  return (await pool.query("SELECT id, kind, filename, size_bytes, alt, created_at FROM media WHERE kind <> 'product' ORDER BY created_at DESC LIMIT 100")).rows;
}
export async function mediaUsage(pool: Pool): Promise<{ count: number; bytes: number }> {
  const r = (await pool.query("SELECT count(*) FILTER (WHERE kind <> 'product') AS n, COALESCE(sum(size_bytes), 0) AS bytes FROM media")).rows[0];
  return { count: r.n, bytes: r.bytes };
}
export async function getMedia(pool: Pool, id: string): Promise<{ content_type: string; data: Buffer; size_bytes: number } | null> {
  if (!UUID_RE.test(id)) return null;
  return (await pool.query("SELECT content_type, data, size_bytes FROM media WHERE id = $1", [id])).rows[0] ?? null;
}
/** Refuses to delete an image that the live site or the saved draft still uses, so no page ever shows a broken image. */
export async function deleteMedia(pool: Pool, id: string): Promise<{ ok: true } | { ok: false; error: "not_found" | "in_use" }> {
  if (!UUID_RE.test(id)) return { ok: false, error: "not_found" };
  const onProduct = await orIfMissingSchema(async () => (await pool.query("SELECT 1 FROM shop_product_images WHERE media_id = $1", [id])).rowCount, 0);
  if (onProduct) return { ok: false, error: "in_use" };
  const used = (await pool.query("SELECT 1 FROM site_config WHERE strpos(config::text, $1) > 0 OR strpos(COALESCE(draft::text, ''), $1) > 0", [id])).rowCount;
  if (used) return { ok: false, error: "in_use" };
  const r = await pool.query("DELETE FROM media WHERE id = $1", [id]);
  return r.rowCount ? { ok: true } : { ok: false, error: "not_found" };
}

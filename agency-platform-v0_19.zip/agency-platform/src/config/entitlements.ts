import { blockAllowed } from "../builder/rules";
import { DEFAULT_SITE_CONFIG, type SectionKey, type SiteConfig } from "./siteConfig";
import { defaultValues, type FeatureValues } from "../packages/features";

/** What each package may use. Enforced on the SERVER when saving and when rendering (hiding a button is not security). */
export interface Entitlements {
  sections: readonly SectionKey[];
  maxServices: number;
  maxTestimonials: number;
  inquiries: boolean;   // public inquiry form + inbox
  branding: boolean;    // accent colour, font, button style
  layout: boolean;      // layout options
  promo: boolean;       // announcement banner
  sectionColours: boolean; // per-section colours (premium branding)
  sectionLayout: boolean;  // per-section alignment and spacing (homepage builder)
  advancedSections: boolean; // highlights and FAQ sections
  seoExpanded: boolean; // social sharing image, hide from search engines
  analytics: boolean;   // Google Analytics 4 ID
  multiPage: boolean;   // Professional template: separate Services / Reviews / Contact pages
  gallery: boolean;     // photo gallery
  maxMediaBytes: number; // total uploaded image storage
  shop: ShopEntitlements;
}

/** What a package may do in the shop. Enforced on the server in src/shop. */
export interface ShopEntitlements {
  products: boolean; maxProducts: number; maxProductImages: number;
  categories: boolean; images: boolean;
  whatsapp: boolean;      // "Order on WhatsApp" button and order requests
  variants: boolean;      // size / colour options
  search: boolean;        // search, sorting and filtering for visitors
  featured: boolean;      // featured products
  stockQty: boolean;      // stock quantities that go down with orders
  cart: boolean;          // shopping cart and checkout (cash on delivery)
  orderManagement: boolean; // full order pipeline (otherwise a simple request inbox)
  customers: boolean;     // customer list
  discounts: boolean;     // discount codes
  lowStock: boolean;      // low-stock warnings
  reports: boolean;       // sales reports
  advancedReports: boolean; // by category, repeat customers, discounts
  campaigns: boolean;     // automatic sales for a period
}

const num = (v: boolean | number | undefined) => (typeof v === "number" ? v : 0);

/** Turns a package's feature values (built-in defaults plus the Super Admin's changes) into what the website code needs. */
export function entitlementsFromValues(v: FeatureValues): Entitlements {
  const sections: SectionKey[] = ["hero", "about", "services", "contact"];
  if (v.gallery) sections.push("gallery");
  if (v.testimonials) sections.push("testimonials");
  if (v.inquiry_forms) sections.push("inquiry");
  if (v.homepage_sections) sections.push("highlights", "faq");
  if (v.products) sections.push("products");
  return {
    sections, maxServices: num(v.max_services), maxTestimonials: v.testimonials ? num(v.max_testimonials) : 0,
    inquiries: Boolean(v.inquiry_forms), branding: Boolean(v.branding_advanced), layout: Boolean(v.layout_options), promo: Boolean(v.promo_banners), sectionColours: Boolean(v.premium_branding), sectionLayout: Boolean(v.homepage_builder), seoExpanded: Boolean(v.seo_expanded), advancedSections: Boolean(v.homepage_sections),
    analytics: Boolean(v.analytics_integration), multiPage: Boolean(v.extra_pages), gallery: Boolean(v.gallery),
    maxMediaBytes: num(v.max_media_mb) * 1024 * 1024,
    shop: {
      products: Boolean(v.products), maxProducts: v.products ? num(v.max_products) : 0, maxProductImages: v.product_images ? num(v.max_product_images) : 0,
      categories: Boolean(v.products && v.product_categories), images: Boolean(v.products && v.product_images), whatsapp: Boolean(v.products && v.whatsapp_ordering),
      variants: Boolean(v.products && v.product_variants), search: Boolean(v.products && v.product_search), featured: Boolean(v.products && v.featured_products),
      stockQty: Boolean(v.products && v.stock_advanced), cart: Boolean(v.products && v.cart_checkout), orderManagement: Boolean(v.products && v.order_management),
      customers: Boolean(v.products && v.customer_management), discounts: Boolean(v.products && v.cart_checkout && v.discount_codes),
      lowStock: Boolean(v.products && v.stock_advanced && v.low_stock_alerts), reports: Boolean(v.products && v.reports_basic), advancedReports: Boolean(v.products && v.reports_basic && v.reports_advanced), campaigns: Boolean(v.products && v.promo_campaigns),
    },
  };
}

/** Built-in defaults only. The running website uses getEntitlements() (src/packages/resolve.ts), which also reads the database. */
export function entitlementsFor(tier: number): Entitlements {
  return entitlementsFromValues(defaultValues(tier));
}

/**
 * The config a visitor actually sees for the client's CURRENT package. After a downgrade, the extra data is kept in the
 * database (nothing is deleted) but is not shown until the package is upgraded again.
 */
export function applyEntitlements(config: SiteConfig, ent: Entitlements): SiteConfig {
  let sections = config.sections.filter((s) => ent.sections.includes(s));
  if (!ent.inquiries) sections = sections.filter((s) => s !== "inquiry");
  if (sections.length === 0) sections = DEFAULT_SITE_CONFIG.sections.filter((s) => ent.sections.includes(s));
  return {
    theme: {
      primary: config.theme.primary,
      accent: ent.branding ? config.theme.accent : DEFAULT_SITE_CONFIG.theme.accent,
      background: ent.branding ? config.theme.background : DEFAULT_SITE_CONFIG.theme.background,
      text: ent.branding ? config.theme.text : DEFAULT_SITE_CONFIG.theme.text,
      surface: ent.branding ? config.theme.surface : DEFAULT_SITE_CONFIG.theme.surface,
      font: ent.branding ? config.theme.font : DEFAULT_SITE_CONFIG.theme.font,
      buttonStyle: ent.branding ? config.theme.buttonStyle : DEFAULT_SITE_CONFIG.theme.buttonStyle,
    },
    layout: ent.layout ? config.layout : DEFAULT_SITE_CONFIG.layout,
    sections,
    content: { ...config.content, services: config.content.services.slice(0, ent.maxServices), testimonials: config.content.testimonials.slice(0, ent.maxTestimonials),
      sectionTitles: ent.layout ? config.content.sectionTitles : {}, cta: ent.layout ? config.content.cta : {},
      highlights: ent.advancedSections ? config.content.highlights : [], faqs: ent.advancedSections ? config.content.faqs : [] },
    promo: ent.promo ? config.promo : DEFAULT_SITE_CONFIG.promo,
    builder: config.builder ? { blocks: config.builder.blocks.filter((b) => blockAllowed(b.type, ent)).map((b) => (b.type === "services" ? { ...b, props: { ...b.props, items: b.props.items.slice(0, ent.maxServices) } } : b.type === "testimonials" ? { ...b, props: { ...b.props, items: b.props.items.slice(0, ent.maxTestimonials) } } : b)) } : undefined,
    sectionStyles: Object.fromEntries(Object.entries(config.sectionStyles).map(([k, v]) => [k, {
      ...(ent.sectionColours && v?.background ? { background: v.background } : {}), ...(ent.sectionColours && v?.text ? { text: v.text } : {}),
      ...(ent.sectionLayout && v?.align ? { align: v.align } : {}), ...(ent.sectionLayout && v?.spacing ? { spacing: v.spacing } : {}),
    }]).filter(([, v]) => Object.keys(v as object).length > 0)) as SiteConfig["sectionStyles"],
    analytics: ent.analytics ? config.analytics : {},
    hours: config.hours, social: config.social, seo: ent.seoExpanded ? config.seo : { title: config.seo.title, description: config.seo.description },
    images: { ...config.images, gallery: ent.gallery ? config.images.gallery : [] },
  };
}

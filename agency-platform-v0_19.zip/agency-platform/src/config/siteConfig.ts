import { z } from "zod";
import { builderSchema } from "../builder/schema";

/** Versioned, validated site configuration. Unknown fields are dropped; bad values fall back to defaults. */
export const SECTION_KEYS = ["hero", "highlights", "about", "services", "products", "gallery", "testimonials", "faq", "inquiry", "contact"] as const;
export type SectionKey = (typeof SECTION_KEYS)[number];
export const FONTS = ["sans", "serif", "rounded"] as const;
export const BUTTON_STYLES = ["rounded", "square", "pill"] as const;
export const HERO_STYLES = ["solid", "light"] as const;
/** Layout choices (Template 2). Every list is a closed set: values are mapped to fixed CSS by the template, never placed into CSS directly. */
export const HERO_ALIGNS = ["left", "center"] as const;
export const SERVICES_VIEWS = ["cards", "list"] as const;
export const GALLERY_SIZES = ["small", "medium", "large"] as const;
export const PAGE_WIDTHS = ["narrow", "standard", "wide"] as const;
export const SPACINGS = ["compact", "comfortable", "airy"] as const;
export const HEADER_STYLES = ["left", "centered"] as const;
export const HEADER_BEHAVIORS = ["scroll", "stay"] as const;
export const HERO_HEIGHTS = ["short", "medium", "tall"] as const;
export const CARD_STYLES = ["outlined", "shadow", "flat"] as const;
export const CARD_CORNERS = ["square", "soft", "round"] as const;
export const SECTION_BACKGROUNDS = ["alternate", "plain", "tinted"] as const;
export const HEADING_ALIGNS = ["left", "center"] as const;
export const REVIEWS_VIEWS = ["grid", "stacked"] as const;
export const ABOUT_LAYOUTS = ["stacked", "image-left", "image-right"] as const;
export const CONTACT_LAYOUTS = ["stacked", "side-by-side"] as const;
export const FOOTER_STYLES = ["simple", "detailed"] as const;
export const WHATSAPP_POSITIONS = ["right", "left", "hidden"] as const;
export const PROMO_STYLES = ["accent", "primary", "dark"] as const;
export const LOGO_SIZES = ["small", "medium", "large"] as const;
export const HERO_OVERLAYS = ["none", "soft", "strong"] as const;
export const TEXT_SIZES = ["small", "normal", "large"] as const;
export const TITLE_KEYS = ["highlights", "about", "services", "products", "gallery", "testimonials", "faq", "inquiry", "contact"] as const;
/** A button link: a full https address, a phone link, or a page of the same website. Never javascript:, data: or //host. */
export const CTA_URL_RE = /^(https:\/\/[^\s"'<>]{4,300}|tel:\+?[0-9]{5,15}|\/(?!\/)[a-zA-Z0-9\-_\/#]{0,100})$/;
export const HEADING_SIZES = ["small", "medium", "large", "xlarge"] as const;
export const BUTTON_SIZES = ["small", "medium", "large"] as const;
export const HERO_EDGES = ["straight", "slant", "curve"] as const;
export const HERO_FILLS = ["solid", "gradient"] as const;
export const HERO_ANGLES = ["right", "down-right", "down", "down-left"] as const;
export const IMAGE_SHAPES = ["square", "rounded", "circle"] as const;
export const PRODUCT_CARDS = ["small", "medium", "large"] as const;
/** Sections the designer can style one by one (the top banner has its own controls). */
export const STYLABLE_SECTIONS = SECTION_KEYS.filter((k) => k !== "hero");
export const SECTION_ALIGNS = ["left", "center"] as const;
export const MAX_HIGHLIGHTS = 6;
export const MAX_FAQS = 10;

/** Every layout choice and the values it may take. The server checks submitted values against this table. */
export const LAYOUT_CHOICES = {
  heroStyle: HERO_STYLES, heroAlign: HERO_ALIGNS, heroHeight: HERO_HEIGHTS, headerStyle: HEADER_STYLES, headerBehavior: HEADER_BEHAVIORS,
  servicesView: SERVICES_VIEWS, galleryPhotos: GALLERY_SIZES, reviewsView: REVIEWS_VIEWS, aboutLayout: ABOUT_LAYOUTS, contactLayout: CONTACT_LAYOUTS,
  cardStyle: CARD_STYLES, cardCorners: CARD_CORNERS, sectionBackground: SECTION_BACKGROUNDS, headingAlign: HEADING_ALIGNS,
  pageWidth: PAGE_WIDTHS, spacing: SPACINGS, footerStyle: FOOTER_STYLES, whatsappButton: WHATSAPP_POSITIONS,
  logoSize: LOGO_SIZES, heroOverlay: HERO_OVERLAYS, textSize: TEXT_SIZES,
  headingSize: HEADING_SIZES, buttonSize: BUTTON_SIZES, heroEdge: HERO_EDGES, heroFill: HERO_FILLS, heroAngle: HERO_ANGLES, imageShape: IMAGE_SHAPES, productCards: PRODUCT_CARDS,
} as const;

const text = (max: number) => z.string().trim().max(max);
// Strict hex colour only: these values are placed into CSS, so nothing else is allowed through.
const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/);

export const DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;
export const DAY_LABELS: Record<(typeof DAYS)[number], string> = { mon: "Monday", tue: "Tuesday", wed: "Wednesday", thu: "Thursday", fri: "Friday", sat: "Saturday", sun: "Sunday" };
const TAIL = "\\/[^\\s\"'<>]{1,200}$";
/** Only https links to the real social networks are accepted (never javascript:, data:, or look-alike hosts). */
export const SOCIAL_PATTERNS = {
  facebook: new RegExp("^https:\\/\\/(www\\.|m\\.)?(facebook\\.com|fb\\.com)" + TAIL, "i"),
  instagram: new RegExp("^https:\\/\\/(www\\.)?instagram\\.com" + TAIL, "i"),
  youtube: new RegExp("^https:\\/\\/(www\\.|m\\.)?(youtube\\.com|youtu\\.be)" + TAIL, "i"),
  tiktok: new RegExp("^https:\\/\\/(www\\.)?tiktok\\.com" + TAIL, "i"),
  x: new RegExp("^https:\\/\\/(www\\.)?(x\\.com|twitter\\.com)" + TAIL, "i"),
  linkedin: new RegExp("^https:\\/\\/(www\\.)?linkedin\\.com" + TAIL, "i"),
} as const;
export type SocialKey = keyof typeof SOCIAL_PATTERNS;
export const SOCIAL_KEYS = Object.keys(SOCIAL_PATTERNS) as SocialKey[];
export const SOCIAL_LABELS: Record<SocialKey, string> = { facebook: "Facebook", instagram: "Instagram", youtube: "YouTube", tiktok: "TikTok", x: "X (Twitter)", linkedin: "LinkedIn" };
export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const uuid = z.string().regex(UUID_RE);
const social = (k: SocialKey) => z.string().trim().regex(SOCIAL_PATTERNS[k]).optional();

export const serviceItem = z.object({ name: z.string().trim().min(1).max(80), description: text(300).default(""), price: text(40).default("") });
export const highlightItem = z.object({ title: z.string().trim().min(1).max(60), text: text(160).default("") });
export const faqItem = z.object({ question: z.string().trim().min(1).max(120), answer: z.string().trim().min(1).max(600) });
export const testimonialItem = z.object({ name: z.string().trim().min(1).max(60), quote: z.string().trim().min(1).max(400) });

export const siteConfigV1 = z.object({
  theme: z.object({
    primary: hex.default("#1f6feb"),
    accent: hex.default("#f59e0b"),
    /** Page background, normal text and the tint used for cards and alternate sections. */
    background: hex.default("#ffffff"),
    text: hex.default("#1b1f24"),
    surface: hex.default("#f3f5f7"),
    font: z.enum(FONTS).default("sans"),
    buttonStyle: z.enum(BUTTON_STYLES).default("rounded"),
  }).default({}),
  layout: z.object({
    heroStyle: z.enum(HERO_STYLES).default("solid"),
    heroAlign: z.enum(HERO_ALIGNS).default("left"),
    servicesView: z.enum(SERVICES_VIEWS).default("cards"),
    galleryPhotos: z.enum(GALLERY_SIZES).default("medium"),
    pageWidth: z.enum(PAGE_WIDTHS).default("standard"),
    spacing: z.enum(SPACINGS).default("comfortable"),
    heroHeight: z.enum(HERO_HEIGHTS).default("medium"),
    headerStyle: z.enum(HEADER_STYLES).default("left"),
    headerBehavior: z.enum(HEADER_BEHAVIORS).default("scroll"),
    reviewsView: z.enum(REVIEWS_VIEWS).default("grid"),
    aboutLayout: z.enum(ABOUT_LAYOUTS).default("stacked"),
    contactLayout: z.enum(CONTACT_LAYOUTS).default("stacked"),
    cardStyle: z.enum(CARD_STYLES).default("outlined"),
    cardCorners: z.enum(CARD_CORNERS).default("soft"),
    sectionBackground: z.enum(SECTION_BACKGROUNDS).default("alternate"),
    headingAlign: z.enum(HEADING_ALIGNS).default("left"),
    footerStyle: z.enum(FOOTER_STYLES).default("simple"),
    whatsappButton: z.enum(WHATSAPP_POSITIONS).default("right"),
    logoSize: z.enum(LOGO_SIZES).default("medium"),
    heroOverlay: z.enum(HERO_OVERLAYS).default("soft"),
    textSize: z.enum(TEXT_SIZES).default("normal"),
    headingSize: z.enum(HEADING_SIZES).default("medium"),
    buttonSize: z.enum(BUTTON_SIZES).default("medium"),
    heroEdge: z.enum(HERO_EDGES).default("straight"),
    heroFill: z.enum(HERO_FILLS).default("solid"),
    heroAngle: z.enum(HERO_ANGLES).default("down-right"),
    imageShape: z.enum(IMAGE_SHAPES).default("rounded"),
    productCards: z.enum(PRODUCT_CARDS).default("medium"),
  }).default({}),
  /** Block-based page made in the visual builder. When present, the home page is drawn from it. */
  builder: builderSchema.optional(),
  /** Per-section colours (Premium branding) and alignment/spacing (Homepage builder). Missing = follow the site-wide choice. */
  sectionStyles: z.object(Object.fromEntries(SECTION_KEYS.filter((k) => k !== "hero").map((k) => [k, z.object({ background: hex.optional(), text: hex.optional(), align: z.enum(SECTION_ALIGNS).optional(), spacing: z.enum(SPACINGS).optional() }).optional()])) as Record<Exclude<(typeof SECTION_KEYS)[number], "hero">, z.ZodOptional<z.ZodObject<{ background: z.ZodOptional<typeof hex>; text: z.ZodOptional<typeof hex>; align: z.ZodOptional<z.ZodEnum<["left", "center"]>>; spacing: z.ZodOptional<z.ZodEnum<["compact", "comfortable", "airy"]>> }>>>).default({}),
  /** Announcement bar shown above the header (Professional template). Empty text = no banner. */
  promo: z.object({
    text: text(140).optional(),
    linkLabel: text(30).optional(),
    // Only an https address or a path on this same website: never javascript:, data: or protocol-relative links.
    linkUrl: z.string().trim().regex(/^(https:\/\/[^\s"'<>]{4,300}|\/(?!\/)[a-zA-Z0-9\-_\/#]{0,100})$/).optional(),
    until: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((d) => !Number.isNaN(Date.parse(d + "T00:00:00Z")) && new Date(d + "T00:00:00Z").toISOString().startsWith(d)).optional(),
    style: z.enum(PROMO_STYLES).default("accent"),
  }).default({}),
  sections: z.array(z.enum(SECTION_KEYS)).max(10).default(["hero", "about", "contact"]),
  content: z.object({
    heroTitle: text(120).optional(),
    heroSubtitle: text(240).optional(),
    about: text(2000).optional(),
    phone: z.string().regex(/^[0-9+\- ]{5,20}$/).optional(),
    whatsapp: z.string().regex(/^[0-9]{6,15}$/).optional(),
    address: text(200).optional(),
    email: z.string().trim().regex(/^[^\s@<>"']{1,64}@[^\s@<>"']{1,255}\.[^\s@<>"']{2,}$/).max(254).optional(),
    services: z.array(serviceItem).max(12).default([]),
    testimonials: z.array(testimonialItem).max(10).default([]),
    highlights: z.array(highlightItem).max(MAX_HIGHLIGHTS).default([]),
    /** Owner-chosen headings for sections (Professional template). A missing one uses the standard heading. */
    sectionTitles: z.object(Object.fromEntries(TITLE_KEYS.map((k) => [k, text(40).optional()])) as Record<(typeof TITLE_KEYS)[number], z.ZodOptional<ReturnType<typeof text>>>).default({}),
    /** The main button in the top banner. */
    cta: z.object({ label: text(30).optional(), url: z.string().trim().regex(CTA_URL_RE).optional() }).default({}),
    faqs: z.array(faqItem).max(MAX_FAQS).default([]),
  }).default({}),
  hours: z.object(Object.fromEntries(DAYS.map((d) => [d, text(40).optional()])) as Record<(typeof DAYS)[number], z.ZodOptional<z.ZodString>>).default({}),
  social: z.object(Object.fromEntries(SOCIAL_KEYS.map((k) => [k, social(k)])) as Record<SocialKey, z.ZodOptional<z.ZodString>>).default({}),
  seo: z.object({ title: text(70).optional(), description: text(170).optional(), shareImage: uuid.optional(), noindex: z.boolean().optional() }).default({}),
  images: z.object({ logo: uuid.optional(), hero: uuid.optional(), about: uuid.optional(), gallery: z.array(uuid).max(12).default([]) }).default({}),
  analytics: z.object({ ga4: z.string().regex(/^G-[A-Z0-9]{4,14}$/).optional() }).default({}),
});
export type SiteConfig = z.infer<typeof siteConfigV1>;

export const DEFAULT_SITE_CONFIG: SiteConfig = siteConfigV1.parse({});

/** Never throws: a broken stored config must not take a client's website down. */
export function parseSiteConfig(raw: unknown): { config: SiteConfig; valid: boolean } {
  const r = siteConfigV1.safeParse(raw);
  return r.success ? { config: r.data, valid: true } : { config: DEFAULT_SITE_CONFIG, valid: false };
}

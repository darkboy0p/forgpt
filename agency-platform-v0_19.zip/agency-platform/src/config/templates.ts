/** The five templates in the master spec. Only built ones can be assigned to a client. */
export const TEMPLATES = {
  starter: { label: "Template 1: Starter Business", minTier: 1, built: true, blurb: "Home, About, Services and Contact. Simple and fast." },
  professional: { label: "Template 2: Professional Business", minTier: 2, built: true, blurb: "Adds gallery, reviews, quote form, highlights and FAQ." },
  ecommerce: { label: "Template 3: E-commerce", minTier: 3, built: true, blurb: "Shop-first home page: products, categories, cart and checkout." },
  "ecommerce-pro": { label: "Template 4: Professional E-commerce", minTier: 4, built: true, blurb: "A fuller store: products, reviews, highlights, FAQ and discounts." },
  "ecommerce-premium": { label: "Template 5: Premium E-commerce", minTier: 5, built: true, blurb: "Modern look: gradient banner, curved edge and large product cards." },
} as const;
export type TemplateKey = keyof typeof TEMPLATES;

export const PACKAGE_NAMES: Record<number, string> = {
  1: "Tier 1: Starter", 2: "Tier 2: Business", 3: "Tier 3: E-commerce", 4: "Tier 4: Professional", 5: "Tier 5: Premium",
};

export function templateMinTier(key: string): number {
  return Object.prototype.hasOwnProperty.call(TEMPLATES, key) ? TEMPLATES[key as TemplateKey].minTier : 99;
}

/** Every template except Starter uses the full renderer. They differ in the starting look and in which pages and sections they begin with. */
export const isRichTemplate = (key: string) => key !== "starter";

export function isTemplateBuilt(key: string): key is TemplateKey {
  return Object.prototype.hasOwnProperty.call(TEMPLATES, key) && TEMPLATES[key as TemplateKey].built;
}

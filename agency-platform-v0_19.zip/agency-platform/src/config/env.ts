import { z } from "zod";

/**
 * Three environments, kept strictly apart:
 *  - development : your computer. Local Postgres (Docker). Fake data allowed.
 *  - demo        : free hosting for showing the product. NOT for real customers.
 *  - production  : paid, real customers. Requires a production database provider.
 */
export const APP_ENVS = ["development", "demo", "production"] as const;
export type AppEnv = (typeof APP_ENVS)[number];

export const DB_PROVIDERS = ["local-postgres", "neon", "managed-postgres"] as const;
export type DbProviderName = (typeof DB_PROVIDERS)[number];

const schema = z.object({
  APP_ENV: z.enum(APP_ENVS),
  CONTROL_DATABASE_URL: z.string().min(1),
  TENANT_DB_PROVIDER: z.enum(DB_PROVIDERS),
  // Admin connection used ONLY by the provisioner to create new databases (local-postgres provider).
  PROVISIONER_ADMIN_URL: z.string().optional(),
  // 32 random bytes, base64. Encrypts stored tenant connection strings.
  SECRETS_MASTER_KEY: z.string().min(1),
  // Comma-separated hostnames where the platform home and admin live, e.g. "admin.myagency.com".
  // Development defaults to localhost. Demo/production have NO admin host until you set this.
  PLATFORM_HOSTS: z.string().optional(),
  // Shown to owners who connect their own domain: where to point it. Leave unset until you know your hosting address.
  DOMAIN_CNAME_TARGET: z.string().optional(),
  DOMAIN_A_RECORD: z.string().optional(),
  TENANT_POOL_MAX_TENANTS: z.coerce.number().int().min(1).default(20),
  TENANT_POOL_MAX_CONNECTIONS: z.coerce.number().int().min(1).default(3),
  TENANT_POOL_IDLE_MS: z.coerce.number().int().min(1000).default(30_000),
});

export type Env = z.infer<typeof schema>;

export class ConfigError extends Error {}

export function loadEnv(source: Record<string, string | undefined> = process.env): Env {
  const parsed = schema.safeParse(source);
  if (!parsed.success) {
    const msg = parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new ConfigError(`Invalid environment configuration: ${msg}`);
  }
  const env = parsed.data;
  assertEnvironmentRules(env);
  return env;
}

/** Safety rules that stop dev/demo shortcuts from leaking into production. */
export function assertEnvironmentRules(env: Env): void {
  if (env.APP_ENV === "production") {
    if (env.TENANT_DB_PROVIDER === "local-postgres") {
      throw new ConfigError("production must not use the local-postgres tenant provider.");
    }
    if (/localhost|127\.0\.0\.1/.test(env.CONTROL_DATABASE_URL)) {
      throw new ConfigError("production CONTROL_DATABASE_URL must not point at localhost.");
    }
  }
  if (env.APP_ENV === "demo" && env.TENANT_DB_PROVIDER === "managed-postgres") {
    throw new ConfigError("demo must not use the production provider (managed-postgres).");
  }
  const key = Buffer.from(env.SECRETS_MASTER_KEY, "base64");
  if (key.length !== 32) {
    throw new ConfigError("SECRETS_MASTER_KEY must be 32 random bytes encoded as base64.");
  }
}

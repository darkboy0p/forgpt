import { siteConfigV1, type SiteConfig } from "./siteConfig";
import type { TemplateKey } from "./templates";
import { applyTheme, themeByKey } from "./themes";

interface Look { sections: string[]; themeKey: string; layout: Partial<SiteConfig["layout"]> }

/** What a client's site starts from when a template is chosen. The owner can change everything afterwards. */
export const TEMPLATE_LOOKS: Record<TemplateKey, Look> = {
  starter: { sections: ["hero", "about", "services", "products", "contact"], themeKey: "fresh", layout: {} },
  professional: { sections: ["hero", "highlights", "about", "services", "gallery", "testimonials", "faq", "inquiry", "contact"], themeKey: "ocean", layout: {} },
  ecommerce: { sections: ["hero", "products", "highlights", "about", "contact"], themeKey: "fresh", layout: { heroAlign: "center", productCards: "medium", cardStyle: "shadow", cardCorners: "soft", headerBehavior: "stay" } },
  "ecommerce-pro": { sections: ["hero", "products", "highlights", "testimonials", "about", "faq", "contact"], themeKey: "sunset", layout: { heroAlign: "center", heroFill: "gradient", productCards: "medium", cardStyle: "shadow", cardCorners: "round", headerBehavior: "stay", footerStyle: "detailed" } },
  "ecommerce-premium": { sections: ["hero", "products", "highlights", "testimonials", "about", "faq", "contact"], themeKey: "royal", layout: { heroAlign: "center", heroFill: "gradient", heroEdge: "curve", heroHeight: "tall", headingSize: "large", productCards: "large", cardStyle: "shadow", cardCorners: "round", headerBehavior: "stay", headerStyle: "centered", footerStyle: "detailed", spacing: "airy", buttonSize: "large" } },
};

/**
 * Gives a site the starting look of a template: its sections, colours and layout. Text, images, products and prices are never touched.
 * Only what the client's package allows is applied.
 */
export function applyTemplateLook(base: SiteConfig, key: TemplateKey, allow: { sections: readonly string[]; branding: boolean; layout: boolean }): SiteConfig {
  const look = TEMPLATE_LOOKS[key];
  const themed = applyTheme(base, themeByKey(look.themeKey)!, { branding: allow.branding, layout: false });
  const next: SiteConfig = structuredClone(themed);
  const sections = look.sections.filter((s) => allow.sections.includes(s));
  if (sections.length) next.sections = sections as SiteConfig["sections"];
  if (allow.layout) next.layout = { ...next.layout, ...look.layout };
  return siteConfigV1.parse(next);
}

import { siteConfigV1, type SiteConfig } from "./siteConfig";

export interface Theme {
  key: string; name: string; blurb: string;
  primary: string; accent: string; font: SiteConfig["theme"]["font"]; buttonStyle: SiteConfig["theme"]["buttonStyle"];
  /** Layout choices this theme sets (Professional template). Anything not listed is left as the owner had it. */
  layout: Partial<SiteConfig["layout"]>;
}

/** Ready-made looks. Colours, font, buttons and a matching layout in one click. */
export const THEMES: Theme[] = [
  { key: "fresh", name: "Fresh", blurb: "Friendly green, clean and classic", primary: "#0a7d4b", accent: "#f2b01e", font: "sans", buttonStyle: "rounded",
    layout: { heroStyle: "solid", heroAlign: "left", cardStyle: "outlined", cardCorners: "soft", sectionBackground: "alternate", headingAlign: "left", spacing: "comfortable" } },
  { key: "ocean", name: "Ocean", blurb: "Calm blue, centred and airy", primary: "#0b63b6", accent: "#19c3d6", font: "sans", buttonStyle: "rounded",
    layout: { heroStyle: "solid", heroAlign: "center", cardStyle: "shadow", cardCorners: "round", sectionBackground: "tinted", headingAlign: "center", spacing: "airy" } },
  { key: "sunset", name: "Sunset", blurb: "Warm orange with pill buttons", primary: "#d9531e", accent: "#f6b93b", font: "rounded", buttonStyle: "pill",
    layout: { heroStyle: "solid", heroAlign: "left", cardStyle: "shadow", cardCorners: "soft", sectionBackground: "plain", headingAlign: "left", spacing: "comfortable" } },
  { key: "royal", name: "Royal", blurb: "Deep purple with a classic serif", primary: "#5b3cc4", accent: "#e7b24c", font: "serif", buttonStyle: "rounded",
    layout: { heroStyle: "light", heroAlign: "center", cardStyle: "outlined", cardCorners: "round", sectionBackground: "tinted", headingAlign: "center", spacing: "airy" } },
  { key: "rose", name: "Rose", blurb: "Soft and stylish, great for fashion and beauty", primary: "#c2255c", accent: "#ffd8a8", font: "serif", buttonStyle: "pill",
    layout: { heroStyle: "light", heroAlign: "center", cardStyle: "shadow", cardCorners: "round", sectionBackground: "plain", headingAlign: "center", spacing: "comfortable" } },
  { key: "slate", name: "Slate", blurb: "Sharp and professional, square corners", primary: "#1f2937", accent: "#38bdf8", font: "sans", buttonStyle: "square",
    layout: { heroStyle: "solid", heroAlign: "left", cardStyle: "flat", cardCorners: "square", sectionBackground: "plain", headingAlign: "left", spacing: "compact", headerBehavior: "stay" } },
  { key: "earth", name: "Earth", blurb: "Warm brown, natural and trustworthy", primary: "#7a4a21", accent: "#e9c46a", font: "serif", buttonStyle: "rounded",
    layout: { heroStyle: "solid", heroAlign: "left", cardStyle: "outlined", cardCorners: "soft", sectionBackground: "alternate", headingAlign: "left", spacing: "comfortable", aboutLayout: "image-left" } },
  { key: "mint", name: "Mint", blurb: "Light and minimal with roomy spacing", primary: "#0f766e", accent: "#fde68a", font: "rounded", buttonStyle: "rounded",
    layout: { heroStyle: "light", heroAlign: "center", cardStyle: "flat", cardCorners: "round", sectionBackground: "plain", headingAlign: "center", spacing: "airy", galleryPhotos: "large" } },
];

export const themeByKey = (key: unknown) => THEMES.find((t) => t.key === key);

/**
 * Applies a theme. The main colour is available to every package. Accent, font and buttons need "branding";
 * the layout part needs "layout options". The result is validated like any other save.
 */
export function applyTheme(base: SiteConfig, theme: Theme, allow: { branding: boolean; layout: boolean }): SiteConfig {
  const next: SiteConfig = structuredClone(base);
  next.theme.primary = theme.primary;
  if (allow.branding) { next.theme.accent = theme.accent; next.theme.font = theme.font; next.theme.buttonStyle = theme.buttonStyle; }
  if (allow.layout) next.layout = { ...next.layout, ...theme.layout };
  return siteConfigV1.parse(next);
}

/** Which theme the site currently matches (by its main colour), if any. */
export function currentThemeKey(config: SiteConfig): string | null {
  return THEMES.find((t) => t.primary.toLowerCase() === config.theme.primary.toLowerCase())?.key ?? null;
}

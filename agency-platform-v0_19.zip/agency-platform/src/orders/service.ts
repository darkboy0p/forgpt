import type { Pool } from "pg";
import { normalizeHostname } from "../tenancy/hostname";

export const PAYMENT_METHODS = ["bkash", "nagad", "rocket", "bank", "cash"] as const;
export const PAYMENT_LABELS: Record<(typeof PAYMENT_METHODS)[number], string> = { bkash: "bKash", nagad: "Nagad", rocket: "Rocket", bank: "Bank transfer", cash: "Cash (in person)" };
export const ORDER_STATUSES = ["new", "contacted", "paid", "client_created", "rejected"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export type OrderError = "invalid_package" | "invalid_business" | "invalid_name" | "invalid_phone" | "invalid_whatsapp" | "invalid_email" | "invalid_domain" | "invalid_message" | "invalid_payment" | "rate_limited";

const MAX_PER_CONTACT_PER_DAY = 3;
const MAX_PER_HOUR = 60;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const clean = (v: unknown) => String(v ?? "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "").trim();

export interface PurchaseInput { packageTier: unknown; businessName: unknown; contactName: unknown; phone: unknown; whatsapp?: unknown; email?: unknown; desiredHostname?: unknown; message?: unknown; paymentMethod?: unknown; /** Hidden trap field: real visitors leave it empty. */ website?: unknown }
export interface PurchaseRow { id: string; package_tier: number; business_name: string; contact_name: string; phone: string; whatsapp: string | null; email: string | null; desired_hostname: string | null; message: string; payment_method: string; status: OrderStatus; tenant_id: string | null; handled_by: string | null; handled_at: Date | null; created_at: Date }

/** Short code the customer can quote when they contact the agency. */
export const orderRef = (id: string) => id.slice(0, 8).toUpperCase();

export async function createPurchaseRequest(control: Pool, input: PurchaseInput): Promise<{ ok: true; id: string | null } | { ok: false; error: OrderError }> {
  if (clean(input.website) !== "") return { ok: true, id: null }; // a robot filled the trap field: pretend success, store nothing
  const tier = Number(input.packageTier);
  if (!Number.isInteger(tier) || tier < 1 || tier > 5) return { ok: false, error: "invalid_package" };
  const business = clean(input.businessName), name = clean(input.contactName);
  if (business.length < 2 || business.length > 80 || /[<>]/.test(business)) return { ok: false, error: "invalid_business" };
  if (name.length < 2 || name.length > 80 || /[<>]/.test(name)) return { ok: false, error: "invalid_name" };
  const phone = clean(input.phone).replace(/[\s-]/g, "");
  if (!/^\+?[0-9]{7,15}$/.test(phone)) return { ok: false, error: "invalid_phone" };
  const waRaw = clean(input.whatsapp).replace(/[\s+-]/g, "");
  if (waRaw && !/^[0-9]{6,15}$/.test(waRaw)) return { ok: false, error: "invalid_whatsapp" };
  const email = clean(input.email).toLowerCase();
  if (email && (email.length > 254 || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]{2,}$/.test(email))) return { ok: false, error: "invalid_email" };
  const hostRaw = clean(input.desiredHostname).replace(/^https?:\/\//i, "").replace(/\/.*$/, "");
  const host = hostRaw ? normalizeHostname(hostRaw) : null;
  if (hostRaw && !host) return { ok: false, error: "invalid_domain" };
  const message = clean(input.message);
  if (message.length > 1000) return { ok: false, error: "invalid_message" };
  const payment = clean(input.paymentMethod) || "bkash";
  if (!(PAYMENT_METHODS as readonly string[]).includes(payment)) return { ok: false, error: "invalid_payment" };
  if (!(await control.query("SELECT 1 FROM packages WHERE tier = $1", [tier])).rowCount) return { ok: false, error: "invalid_package" };

  const same = (await control.query(
    `SELECT count(*)::int AS n FROM purchase_requests
      WHERE created_at > now() - interval '1 day' AND (phone = $1 OR ($2::text <> '' AND lower(email) = $2))`, [phone, email])).rows[0].n as number;
  const hour = (await control.query("SELECT count(*)::int AS n FROM purchase_requests WHERE created_at > now() - interval '1 hour'")).rows[0].n as number;
  if (same >= MAX_PER_CONTACT_PER_DAY || hour >= MAX_PER_HOUR) return { ok: false, error: "rate_limited" };

  const r = await control.query(
    `INSERT INTO purchase_requests (package_tier, business_name, contact_name, phone, whatsapp, email, desired_hostname, message, payment_method)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`, [tier, business, name, phone, waRaw || null, email || null, host, message, payment]);
  await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ('public','purchase.requested',$1)", [JSON.stringify({ id: r.rows[0].id, tier })]);
  return { ok: true, id: r.rows[0].id as string };
}

export async function listPurchaseRequests(control: Pool, status?: OrderStatus | "open"): Promise<PurchaseRow[]> {
  const where = status === "open" ? "WHERE status IN ('new','contacted','paid')" : status ? "WHERE status = $1" : "";
  return (await control.query(`SELECT * FROM purchase_requests ${where} ORDER BY created_at DESC LIMIT 200`, status && status !== "open" ? [status] : [])).rows;
}
export async function countNewPurchases(control: Pool): Promise<number> {
  return (await control.query("SELECT count(*)::int AS n FROM purchase_requests WHERE status = 'new'")).rows[0].n as number;
}
export async function getPurchaseRequest(control: Pool, id: string): Promise<PurchaseRow | null> {
  if (!UUID.test(id)) return null;
  return (await control.query("SELECT * FROM purchase_requests WHERE id = $1", [id])).rows[0] ?? null;
}

/** Admin moves a request along. A request that already became a client cannot be moved again. */
export async function setPurchaseStatus(control: Pool, id: string, status: unknown, actor: string): Promise<boolean> {
  if (!UUID.test(id) || !(ORDER_STATUSES as readonly unknown[]).includes(status) || status === "client_created") return false;
  const r = await control.query("UPDATE purchase_requests SET status = $2, handled_by = $3, handled_at = now() WHERE id = $1 AND status <> 'client_created' RETURNING id", [id, status, actor]);
  if (!r.rowCount) return false;
  await control.query("INSERT INTO audit_log (actor, action, detail) VALUES ($1,'purchase.status',$2)", [actor, JSON.stringify({ id, status })]);
  return true;
}
export async function linkPurchaseToClient(control: Pool, id: string, tenantId: string, actor: string): Promise<boolean> {
  if (!UUID.test(id)) return false;
  const r = await control.query("UPDATE purchase_requests SET status = 'client_created', tenant_id = $2, handled_by = $3, handled_at = now() WHERE id = $1 AND status <> 'client_created' RETURNING id", [id, tenantId, actor]);
  if (!r.rowCount) return false;
  await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,'purchase.client_created',$2,$3)", [actor, tenantId, JSON.stringify({ id })]);
  return true;
}

/** A short internal name suggested from the business name (lowercase letters, digits, hyphens). */
export function suggestSlug(businessName: string): string {
  const s = businessName.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 38).replace(/-+$/g, "");
  return s.length >= 2 ? s : "";
}

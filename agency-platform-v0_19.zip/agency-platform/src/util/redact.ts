/** Removes anything that looks like a connection string or password before text is stored or shown. */
export function redactSecrets(text: string): string {
  return text
    .replace(/postgres(?:ql)?:\/\/[^\s"'`]+/gi, "[redacted-connection-string]")
    .replace(/(password|passwd|secret|token|apikey|api_key)\s*[=:]\s*[^\s,;"']+/gi, "$1=[redacted]")
    .slice(0, 500);
}

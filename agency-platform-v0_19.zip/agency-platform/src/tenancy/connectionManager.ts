import pg from "pg";
import type { Pool } from "pg";
import { decryptSecret } from "../crypto/secrets";

interface Entry { pool: Pool; lastUsed: number }

/**
 * Server-side only. Callers pass a tenantId that came from the verified resolver,
 * never from the browser. Keeps a capped number of small pools and closes idle ones.
 */
export class TenantConnectionManager {
  private pools = new Map<string, Entry>();
  private opening = new Map<string, Promise<Pool>>();
  private sweeper?: NodeJS.Timeout;

  constructor(
    private control: Pool,
    private masterKey: string,
    private opts = { maxTenants: 20, maxConnections: 3, idleMs: 30_000 }
  ) {
    this.sweeper = setInterval(() => void this.closeIdle(), Math.max(1000, Math.floor(opts.idleMs / 2)));
    this.sweeper.unref();
  }

  get openPoolCount(): number { return this.pools.size; }

  async getPool(tenantId: string): Promise<Pool> {
    const hit = this.pools.get(tenantId);
    if (hit) { hit.lastUsed = Date.now(); return hit.pool; }
    const pending = this.opening.get(tenantId);
    if (pending) return pending;
    const p = this.open(tenantId).finally(() => this.opening.delete(tenantId));
    this.opening.set(tenantId, p);
    return p;
  }

  private async open(tenantId: string): Promise<Pool> {
    const r = await this.control.query(
      `SELECT d.conn_encrypted FROM tenant_databases d JOIN tenants t ON t.id = d.tenant_id
        WHERE d.tenant_id = $1 AND t.status = 'active'`, [tenantId]);
    if (!r.rowCount) throw new Error("tenant has no active database");
    while (this.pools.size >= this.opts.maxTenants) await this.evictLeastRecentlyUsed();
    const pool = new pg.Pool({
      connectionString: decryptSecret(r.rows[0].conn_encrypted, this.masterKey),
      max: this.opts.maxConnections,
      idleTimeoutMillis: this.opts.idleMs,
      connectionTimeoutMillis: 5000,
    });
    pool.on("error", (e) => console.error("[tenant-pool] idle client error:", e.message)); // never log the URL
    this.pools.set(tenantId, { pool, lastUsed: Date.now() });
    return pool;
  }

  private async evictLeastRecentlyUsed(): Promise<void> {
    let oldest: [string, Entry] | undefined;
    for (const e of this.pools) if (!oldest || e[1].lastUsed < oldest[1].lastUsed) oldest = e;
    if (!oldest) return;
    this.pools.delete(oldest[0]);
    await oldest[1].pool.end();
  }

  /**
   * ADMIN ONLY (for example data export). Opens a private, one-connection pool that is never cached, so a
   * suspended client's data can be handed over without that client's website ever being able to use it.
   */
  async withAdminPool<T>(tenantId: string, fn: (pool: Pool) => Promise<T>): Promise<T> {
    const r = await this.control.query(
      `SELECT d.conn_encrypted FROM tenant_databases d JOIN tenants t ON t.id = d.tenant_id
        WHERE d.tenant_id = $1 AND t.status IN ('active','suspended')`, [tenantId]);
    if (!r.rowCount) throw new Error("tenant has no readable database");
    const pool = new pg.Pool({ connectionString: decryptSecret(r.rows[0].conn_encrypted, this.masterKey), max: 1, connectionTimeoutMillis: 5000 });
    pool.on("error", (e) => console.error("[admin-pool] idle client error:", e.message));
    try { return await fn(pool); } finally { await pool.end().catch(() => {}); }
  }

  /** Used right after a suspension so no connection to that tenant's database stays open. */
  async closePool(tenantId: string): Promise<void> {
    const e = this.pools.get(tenantId);
    if (!e) return;
    this.pools.delete(tenantId);
    await e.pool.end().catch(() => {});
  }

  async closeIdle(now = Date.now()): Promise<void> {
    for (const [id, e] of [...this.pools]) {
      if (now - e.lastUsed > this.opts.idleMs) { this.pools.delete(id); await e.pool.end().catch(() => {}); }
    }
  }

  async closeAll(): Promise<void> {
    if (this.sweeper) clearInterval(this.sweeper);
    const all = [...this.pools.values()];
    this.pools.clear();
    await Promise.all(all.map((e) => e.pool.end().catch(() => {})));
  }
}

import type { Pool } from "pg";
import { normalizeHostname } from "./hostname";

export interface ResolvedTenant {
  tenantId: string;
  slug: string;
  packageTier: number;
  templateKey: string;
}

export type HostState = { kind: "active"; tenant: ResolvedTenant } | { kind: "suspended" } | { kind: "none" };

/**
 * Host header -> state. Only VERIFIED domains of ACTIVE or SUSPENDED tenants are known.
 * The Host header is never trusted by itself: it must match the control-plane registry.
 */
export async function resolveHostState(control: Pool, hostHeader: string): Promise<HostState> {
  const host = normalizeHostname(hostHeader);
  if (!host) return { kind: "none" };
  // "www.example.com" and "example.com" are the same website. An exact match always wins over the other spelling.
  const alt = host.startsWith("www.") ? host.slice(4) : `www.${host}`;
  const r = await control.query(
    `SELECT t.id, t.slug, t.package_tier, t.template_key, t.status
       FROM domains d JOIN tenants t ON t.id = d.tenant_id
      WHERE d.hostname IN ($1, $2) AND d.status = 'verified' AND t.status IN ('active','suspended')
      ORDER BY (d.hostname = $1) DESC LIMIT 1`,
    [host, alt]
  );
  const row = r.rows[0];
  if (!row) return { kind: "none" };
  if (row.status === "suspended") return { kind: "suspended" };
  return { kind: "active", tenant: { tenantId: row.id, slug: row.slug, packageTier: row.package_tier, templateKey: row.template_key } };
}

/** Only active tenants resolve to a tenant; everything else is null. */
export async function resolveTenantByHost(control: Pool, hostHeader: string): Promise<ResolvedTenant | null> {
  const state = await resolveHostState(control, hostHeader);
  return state.kind === "active" ? state.tenant : null;
}

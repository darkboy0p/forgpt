/** Returns a clean lowercase hostname, or null if it is not a valid public hostname. */
export function normalizeHostname(raw: string): string | null {
  if (typeof raw !== "string") return null;
  let h = raw.trim().toLowerCase();
  h = h.replace(/:\d+$/, "").replace(/\.$/, ""); // strip port and trailing dot
  if (h.length < 3 || h.length > 253) return null;
  const label = /^(?!-)[a-z0-9-]{1,63}(?<!-)$/;
  const parts = h.split(".");
  if (parts.length < 2 || !parts.every((p) => label.test(p))) return null;
  if (/^\d+(\.\d+){3}$/.test(h)) return null; // bare IPs are not tenant hosts
  return h;
}

"use client";
import { usePathname } from "next/navigation";

export interface SideItem { href: string; label: string; badge?: number; exact?: boolean }
export interface SideGroup { title?: string; items: SideItem[] }

/** Dashboard menu: grouped on wide screens, a scrolling row on phones. */
export function SideNav({ groups }: { groups: SideGroup[] }) {
  const path = usePathname() ?? "";
  const here = (i: SideItem) => (i.exact ? path === i.href : path === i.href || path.startsWith(i.href + "/"));
  return (
    <nav className="dash-side" aria-label="Dashboard">
      {groups.map((g, k) => (
        <div className="grp" key={k}>
          {g.title && <h3>{g.title}</h3>}
          {g.items.map((i) => (
            <a key={i.href} href={i.href} aria-current={here(i) ? "page" : undefined}>{i.label}{i.badge ? <span className="badge">{i.badge}</span> : null}</a>
          ))}
        </div>
      ))}
    </nav>
  );
}

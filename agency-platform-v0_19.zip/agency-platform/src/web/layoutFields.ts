import type { SiteConfig } from "../config/siteConfig";

export interface LayoutField { key: keyof SiteConfig["layout"]; label: string; options: [value: string, label: string][] }
export interface LayoutGroup { title: string; hint: string; fields: LayoutField[] }

/** What the owner sees in the Layout card. The allowed values are checked on the server against LAYOUT_CHOICES. */
export const LAYOUT_GROUPS: LayoutGroup[] = [
  { title: "Top of the page", hint: "The menu bar and the big banner.", fields: [
    { key: "headerStyle", label: "Logo and menu", options: [["left", "Logo left, menu right"], ["centered", "Logo above, menu centred"]] },
    { key: "headerBehavior", label: "Menu while scrolling", options: [["scroll", "Scrolls away"], ["stay", "Stays at the top"]] },
    { key: "heroStyle", label: "Banner colour", options: [["solid", "Solid colour"], ["light", "Light"]] },
    { key: "heroAlign", label: "Banner text", options: [["left", "Left"], ["center", "Centred"]] },
    { key: "heroHeight", label: "Banner height", options: [["short", "Short"], ["medium", "Medium"], ["tall", "Tall"]] },
    { key: "heroFill", label: "Banner background", options: [["solid", "One colour"], ["gradient", "Gradient (main to accent colour)"]] },
    { key: "heroAngle", label: "Gradient direction (angle)", options: [["right", "Left to right"], ["down-right", "Diagonal, top-left to bottom-right"], ["down", "Top to bottom"], ["down-left", "Diagonal, top-right to bottom-left"]] },
    { key: "heroEdge", label: "Banner bottom edge", options: [["straight", "Straight"], ["slant", "Slanted"], ["curve", "Curved"]] },
    { key: "heroOverlay", label: "Darkness over banner photo", options: [["none", "None"], ["soft", "Soft"], ["strong", "Strong (easier to read)"]] },
    { key: "logoSize", label: "Logo size", options: [["small", "Small"], ["medium", "Medium"], ["large", "Large"]] },
  ] },
  { title: "Sections", hint: "How each part of your page is shown.", fields: [
    { key: "aboutLayout", label: "About us", options: [["stacked", "Photo above text"], ["image-left", "Photo left, text right"], ["image-right", "Text left, photo right"]] },
    { key: "servicesView", label: "Services", options: [["cards", "Cards in a grid"], ["list", "Simple list"]] },
    { key: "reviewsView", label: "Customer reviews", options: [["grid", "Cards in a grid"], ["stacked", "One under another"]] },
    { key: "galleryPhotos", label: "Gallery photos", options: [["small", "Small"], ["medium", "Medium"], ["large", "Large"]] },
    { key: "productCards", label: "Product card size", options: [["small", "Small (more per row)"], ["medium", "Medium"], ["large", "Large (fewer per row)"]] },
    { key: "contactLayout", label: "Contact", options: [["stacked", "One column"], ["side-by-side", "Details and hours side by side"]] },
  ] },
  { title: "Look and feel", hint: "Cards, corners and backgrounds.", fields: [
    { key: "cardStyle", label: "Cards", options: [["outlined", "Thin outline"], ["shadow", "Soft shadow"], ["flat", "Flat tint"]] },
    { key: "cardCorners", label: "Corners", options: [["square", "Square"], ["soft", "Slightly rounded"], ["round", "Very rounded"]] },
    { key: "sectionBackground", label: "Section backgrounds", options: [["alternate", "Alternating grey"], ["plain", "All white"], ["tinted", "Tinted with your main colour"]] },
    { key: "headingSize", label: "Heading size", options: [["small", "Small"], ["medium", "Medium"], ["large", "Large"], ["xlarge", "Extra large"]] },
    { key: "buttonSize", label: "Button size", options: [["small", "Small"], ["medium", "Medium"], ["large", "Large"]] },
    { key: "imageShape", label: "Photo shape", options: [["square", "Square corners"], ["rounded", "Rounded"], ["circle", "Circle (about photo)"]] },
    { key: "headingAlign", label: "Section headings", options: [["left", "Left"], ["center", "Centred"]] },
  ] },
  { title: "Page", hint: "Width, spacing and the bottom of the page.", fields: [
    { key: "pageWidth", label: "Page width", options: [["narrow", "Narrow (easy to read)"], ["standard", "Standard"], ["wide", "Wide"]] },
    { key: "spacing", label: "Space between sections", options: [["compact", "Compact"], ["comfortable", "Comfortable"], ["airy", "Roomy"]] },
    { key: "textSize", label: "Text size", options: [["small", "Small"], ["normal", "Normal"], ["large", "Large (easier to read)"]] },
    { key: "footerStyle", label: "Footer", options: [["simple", "Simple"], ["detailed", "Detailed (contact and pages)"]] },
    { key: "whatsappButton", label: "WhatsApp button", options: [["right", "Bottom right"], ["left", "Bottom left"], ["hidden", "Hidden"]] },
  ] },
];

/** One-click starting points. They only fill in the choices on the form; nothing is saved until the owner saves. */
export const LAYOUT_PRESETS: { name: string; blurb: string; values: Record<string, string> }[] = [
  { name: "Classic", blurb: "The standard look", values: { headerStyle: "left", headerBehavior: "scroll", heroStyle: "solid", heroAlign: "left", heroHeight: "medium", aboutLayout: "stacked", servicesView: "cards", reviewsView: "grid", galleryPhotos: "medium", contactLayout: "stacked", cardStyle: "outlined", cardCorners: "soft", sectionBackground: "alternate", headingAlign: "left", pageWidth: "standard", spacing: "comfortable", footerStyle: "simple", whatsappButton: "right", logoSize: "medium", heroOverlay: "soft", textSize: "normal", headingSize: "medium", buttonSize: "medium", heroEdge: "straight", heroFill: "solid", heroAngle: "down-right", imageShape: "rounded", productCards: "medium" } },
  { name: "Modern", blurb: "Airy, centred, soft shadows", values: { headerStyle: "centered", headerBehavior: "stay", heroStyle: "light", heroAlign: "center", heroHeight: "tall", aboutLayout: "image-left", servicesView: "cards", reviewsView: "grid", galleryPhotos: "large", contactLayout: "side-by-side", cardStyle: "shadow", cardCorners: "round", sectionBackground: "tinted", headingAlign: "center", pageWidth: "standard", spacing: "airy", footerStyle: "detailed", whatsappButton: "right", logoSize: "large", heroOverlay: "soft", textSize: "normal", headingSize: "large", buttonSize: "large", heroEdge: "curve", heroFill: "gradient", heroAngle: "down-right", imageShape: "rounded", productCards: "large" } },
  { name: "Compact", blurb: "Dense and quick to scan", values: { headerStyle: "left", headerBehavior: "stay", heroStyle: "solid", heroAlign: "left", heroHeight: "short", aboutLayout: "image-right", servicesView: "list", reviewsView: "stacked", galleryPhotos: "small", contactLayout: "side-by-side", cardStyle: "flat", cardCorners: "square", sectionBackground: "plain", headingAlign: "left", pageWidth: "narrow", spacing: "compact", footerStyle: "simple", whatsappButton: "right", logoSize: "small", heroOverlay: "strong", textSize: "small", headingSize: "small", buttonSize: "small", heroEdge: "straight", heroFill: "solid", heroAngle: "right", imageShape: "square", productCards: "small" } },
];

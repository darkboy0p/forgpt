import pg from "pg";
import type { Pool } from "pg";
import { loadEnv } from "../config/env";
import { runMigrations } from "../db/migrate";
import { CONTROL_MIGRATIONS_DIR } from "../db/paths";
import { migrateAllTenants } from "../provisioning/migrateTenants";

export interface StartupReport { control: string[]; clients: { slug: string; applied: string[]; error?: string }[] }
type Log = Pick<Console, "log" | "warn" | "error">;

/**
 * Brings the control database and every client database up to the version of this code.
 * Safe to run on every start: it applies only what is missing, under a database lock, and one client failing does not stop the rest.
 */
export async function runStartupMigrations(control: Pool, masterKey: string, log: Log = console): Promise<StartupReport> {
  const applied = await runMigrations(control, CONTROL_MIGRATIONS_DIR);
  if (applied.length) log.log(`[startup] Updated the main database: ${applied.join(", ")}`);
  const clients = await migrateAllTenants(control, masterKey);
  for (const c of clients) {
    if (c.error) log.error(`[startup] Could not update the database of client "${c.slug}": ${c.error}`);
    else if (c.applied.length) log.log(`[startup] Updated the database of client "${c.slug}": ${c.applied.join(", ")}`);
  }
  return { control: applied, clients };
}

/** Called once when the server starts (see instrumentation.ts). Never stops the server from starting. */
export async function bootstrap(): Promise<void> {
  if (process.env.AUTO_MIGRATE === "false") { console.log("[startup] AUTO_MIGRATE=false: databases are not updated automatically. Run: npm run db:migrate"); return; }
  let env;
  try { env = loadEnv(); }
  catch (e) { console.error(`[startup] The settings in .env are not valid, so the websites cannot start. ${(e as Error).message}`); return; }
  const pool = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 1, connectionTimeoutMillis: 8000 });
  pool.on("error", () => {});
  try { await runStartupMigrations(pool, env.SECRETS_MASTER_KEY); }
  catch (e) { console.error(`[startup] Could not check or update the databases: ${(e as Error).message}\n          Is PostgreSQL running, and is CONTROL_DATABASE_URL in .env correct? You can also run: npm run db:migrate`); }
  finally { await pool.end().catch(() => {}); }
}

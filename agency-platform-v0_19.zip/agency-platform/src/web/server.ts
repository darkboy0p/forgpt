import "../db/pgTypes";
import pg from "pg";
import { loadEnv, type Env } from "../config/env";
import { TenantConnectionManager } from "../tenancy/connectionManager";

interface Runtime { env: Env; control: pg.Pool; mgr: TenantConnectionManager }
const g = globalThis as unknown as { __agency?: Runtime };

/** One set of pools per server process (survives hot reloads in development). */
export function runtime(): Runtime {
  if (!g.__agency) {
    const env = loadEnv();
    const control = new pg.Pool({ connectionString: env.CONTROL_DATABASE_URL, max: 5, idleTimeoutMillis: 30_000 });
    control.on("error", (e) => console.error("[control-pool]", e.message));
    const mgr = new TenantConnectionManager(control, env.SECRETS_MASTER_KEY, {
      maxTenants: env.TENANT_POOL_MAX_TENANTS, maxConnections: env.TENANT_POOL_MAX_CONNECTIONS, idleMs: env.TENANT_POOL_IDLE_MS,
    });
    g.__agency = { env, control, mgr };
  }
  return g.__agency;
}

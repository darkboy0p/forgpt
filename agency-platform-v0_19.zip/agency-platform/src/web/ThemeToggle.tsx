"use client";
import { useEffect, useState } from "react";

/** Script that runs before the page is shown, so a saved dark choice does not flash white first. */
export const THEME_INIT = `try{if(localStorage.getItem("dash-theme")==="dark")document.documentElement.setAttribute("data-dash-theme","dark")}catch(e){}`;

export function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(document.documentElement.getAttribute("data-dash-theme") === "dark"); }, []);
  const flip = () => {
    const next = !dark;
    setDark(next);
    if (next) document.documentElement.setAttribute("data-dash-theme", "dark"); else document.documentElement.removeAttribute("data-dash-theme");
    try { localStorage.setItem("dash-theme", next ? "dark" : "light"); } catch { /* storage blocked: the choice just is not remembered */ }
  };
  return <button type="button" className="theme-switch" onClick={flip} aria-pressed={dark}>{dark ? "Light mode" : "Dark mode"}</button>;
}

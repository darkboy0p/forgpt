import type { ReactNode } from "react";
import { storeLogoutAction } from "../../app/dashboard/actions";
import { SideNav, type SideGroup } from "./SideNav";
import { ThemeToggle, THEME_INIT } from "./ThemeToggle";
import { storeContext } from "./storeSession";
import { entitlementsOf } from "./entitlements";
import { countNewOrders } from "../shop/orders";
import { orIfMissingSchema } from "../shop/safe";

/** Frame for every owner page. The menu shows only what the client's package includes. */
export async function StoreShell({ businessName, email, children }: { businessName: string; email?: string; inquiries?: boolean; children: ReactNode }) {
  let groups: SideGroup[] = [];
  if (email) {
    const { tenant, pool } = await storeContext();
    const ent = await entitlementsOf(tenant.packageTier);
    const newOrders = ent.shop.products ? await orIfMissingSchema(() => countNewOrders(pool), 0) : 0;
    groups = [
      { items: [{ href: "/dashboard", label: "Home", exact: true }] },
      { title: "Website", items: [
        { href: "/dashboard/builder", label: "Edit website" }, { href: "/dashboard/themes", label: "Themes" }, { href: "/dashboard/editor", label: "Site settings" },
        { href: "/dashboard/media", label: "Images" }, { href: "/dashboard/domain", label: "Domain" },
      ] },
      ...(ent.shop.products ? [{ title: "Shop", items: [
        { href: "/dashboard/products", label: "Products" },
        ...(ent.shop.categories ? [{ href: "/dashboard/categories", label: "Categories" }] : []),
        { href: "/dashboard/orders", label: "Orders", badge: newOrders },
        ...(ent.shop.customers ? [{ href: "/dashboard/customers", label: "Customers" }] : []),
        ...(ent.shop.discounts ? [{ href: "/dashboard/discounts", label: "Discount codes" }] : []),
        ...(ent.shop.campaigns ? [{ href: "/dashboard/campaigns", label: "Campaigns" }] : []),
        ...(ent.shop.reports ? [{ href: "/dashboard/reports", label: "Reports" }] : []),
        { href: "/dashboard/shop-settings", label: "Shop settings" },
      ] }] : []),
      { title: "Account", items: [
        ...(ent.inquiries ? [{ href: "/dashboard/inquiries", label: "Inquiries" }] : []),
        { href: "/dashboard/package", label: "My package" }, { href: "/dashboard/password", label: "Password" },
      ] },
    ];
  }
  return (
    <div className="dash">
      <script dangerouslySetInnerHTML={{ __html: THEME_INIT }} />
      <header className="dash-top">
        <div className="inner wide-inner">
          <span className="dash-brand">{businessName}<small>Website dashboard</small></span>
          {email && (
            <span className="dash-user">
              <ThemeToggle /><span>{email}</span>
              <form action={storeLogoutAction}><button type="submit">Log out</button></form>
            </span>
          )}
        </div>
      </header>
      <div className={email ? "dash-layout" : undefined}>
        {email && <SideNav groups={groups} />}
        <main className="dash-main">{children}</main>
      </div>
    </div>
  );
}

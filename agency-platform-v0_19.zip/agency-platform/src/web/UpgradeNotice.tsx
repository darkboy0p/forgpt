/** Shown instead of a restricted feature. It explains what is missing and how to ask for it. */
export function UpgradeNotice({ feature, packageName }: { feature: string; packageName?: string }) {
  return (
    <div className="card" style={{ maxWidth: 560 }}>
      <h2 style={{ marginTop: 0 }}>{feature} is not part of your current package</h2>
      <p>{packageName ? `Your ${packageName} package does not include this.` : "Your package does not include this."} You can ask your website provider to upgrade your package.</p>
      <p><a className="btn" href="/dashboard/package#upgrade">See my package and request an upgrade</a></p>
    </div>
  );
}

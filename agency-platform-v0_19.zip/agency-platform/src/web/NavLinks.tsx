"use client";
import { usePathname } from "next/navigation";

export interface NavItem { href: string; label: string; /** Path prefixes that count as "here". An entry ending in $ must match exactly. Defaults to the link itself. */ match?: string[]; badge?: number }

export function NavLinks({ links, label }: { links: NavItem[]; label: string }) {
  const path = usePathname() ?? "";
  const here = (l: NavItem) => (l.match ?? [l.href]).some((m) => (m.endsWith("$") ? path === m.slice(0, -1) : path.startsWith(m)));
  return (
    <nav className="dash-nav" aria-label={label}>
      {links.map((l) => (
        <a key={l.href} href={l.href} aria-current={here(l) ? "page" : undefined}>
          {l.label}{l.badge ? <span className="badge">{l.badge}</span> : null}
        </a>
      ))}
    </nav>
  );
}

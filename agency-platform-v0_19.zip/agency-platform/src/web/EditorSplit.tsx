"use client";
import { useEffect, useState, type ReactNode } from "react";

type Mode = "phone" | "wide";

/** Optional side-by-side preview of the owner's saved draft. It only displays; it never saves or changes anything. */
export function EditorSplit({ pages, children }: { pages: { key: string; label: string }[]; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("phone");
  const [page, setPage] = useState("home");
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    try {
      setOpen(localStorage.getItem("ed-preview") === "1");
      const m = localStorage.getItem("ed-preview-mode");
      if (m === "phone" || m === "wide") setMode(m);
    } catch { /* storage can be blocked; the preview simply starts closed */ }
  }, []);
  useEffect(() => {
    const main = document.querySelector(".dash-main");
    main?.classList.toggle("wide", open);
    return () => main?.classList.remove("wide");
  }, [open]);

  const remember = (k: string, v: string) => { try { localStorage.setItem(k, v); } catch { /* ignore */ } };
  const toggle = () => { setOpen((o) => { remember("ed-preview", o ? "0" : "1"); return !o; }); };
  const choose = (m: Mode) => { setMode(m); remember("ed-preview-mode", m); };
  const src = `/dashboard/preview?embed=1&page=${encodeURIComponent(page)}`;

  return (
    <>
      <div className="ed-split-bar">
        <button type="button" onClick={toggle} aria-pressed={open}>{open ? "Hide preview" : "Show preview beside the editor"}</button>
      </div>
      <div className={open ? `ed-split open ${mode}` : "ed-split"}>
        <div className="ed-split-main">{children}</div>
        {open && (
          <aside className="ed-preview" aria-label="Website preview">
            <div className="ed-preview-tools">
              <select value={page} onChange={(e) => setPage(e.target.value)} aria-label="Page to preview" style={{ width: "auto" }}>
                {pages.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
              </select>
              <button type="button" aria-pressed={mode === "phone"} onClick={() => choose("phone")}>Phone</button>
              <button type="button" aria-pressed={mode === "wide"} onClick={() => choose("wide")}>Wide</button>
              <button type="button" onClick={() => setNonce((n) => n + 1)}>Refresh</button>
              <a href={`/dashboard/preview?page=${encodeURIComponent(page)}`} target="_blank" rel="noopener">New tab</a>
            </div>
            <p className="hint" style={{ margin: "0 0 8px" }}>Shows your last <strong>saved</strong> draft. Press Save draft to update it.</p>
            <div className="ed-preview-view"><iframe key={nonce} title="Website preview" src={src} className={mode} /></div>
          </aside>
        )}
      </div>
    </>
  );
}

import type { Env } from "../config/env";

const DEV_DEFAULT_HOSTS = ["localhost", "127.0.0.1", "admin.localhost"];

export function hostWithoutPort(host: string): string {
  return host.trim().toLowerCase().replace(/:\d+$/, "");
}

/** Hosts where the platform home page and admin live. Never a client domain. */
export function platformHosts(env: Pick<Env, "APP_ENV" | "PLATFORM_HOSTS">): Set<string> {
  const configured = (env.PLATFORM_HOSTS ?? "").split(",").map((h) => hostWithoutPort(h)).filter(Boolean);
  if (configured.length) return new Set(configured);
  return new Set(env.APP_ENV === "development" ? DEV_DEFAULT_HOSTS : []);
}
export function isPlatformHost(env: Pick<Env, "APP_ENV" | "PLATFORM_HOSTS">, host: string): boolean {
  return platformHosts(env).has(hostWithoutPort(host));
}
/** The admin exists only on platform hosts. It also requires a login (see src/auth). */
export const isAdminAllowed = isPlatformHost;

import { notFound } from "next/navigation";
import { runtime } from "./server";
import { loadSiteForHost } from "./tenantSite";
import { applyEntitlements } from "../config/entitlements";
import { entitlementsOf } from "./entitlements";
import { StarterSite } from "./templates/StarterSite";
import { ProfessionalSite } from "./templates/ProfessionalSite";
import { PAGE_LABELS, starterPages, visiblePages, withShop, type PageKey } from "./templates/pages";
import { isRichTemplate } from "../config/templates";
import { buildShopView } from "../shop/view";
import { getShopSettings } from "../shop/extras";
import { listProductSlugs } from "../shop/products";
import { orIfMissingSchema } from "../shop/safe";
import type { ComponentProps } from "react";
import { BuilderSite } from "../builder/BuilderSite";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { cache } from "react";

export const getSite = cache(async (host: string) => {
  const { control, mgr } = runtime();
  return loadSiteForHost(control, mgr, host);
});

/** The address visitors use, built from the request (https outside development). */
export async function siteBaseUrl(): Promise<string> {
  const h = await headers();
  return `${runtime().env.APP_ENV === "development" ? "http" : "https"}://${h.get("host") ?? ""}`;
}

/** Picks the template for a client. Every template is drawn by the same engine; Starter just has fewer pages. */
export function TemplateSite({ templateKey, ...props }: { templateKey: string } & ComponentProps<typeof ProfessionalSite>) {
  if (props.config.builder) return <BuilderSite {...props} />;
  return isRichTemplate(templateKey) ? <ProfessionalSite {...props} /> : <StarterSite {...props} />;
}

type Query = { sent?: string; ie?: string; q?: string; category?: string; sort?: string; page?: string };

/** The public website for a client domain. The client's CURRENT package limits what is shown. */
export async function renderClientSite(host: string, page: PageKey, sp: Query = {}) {
  const { mgr } = runtime();
  const site = await getSite(host);
  if (site.kind === "not-found") notFound();
  if (site.kind === "suspended") {
    return (
      <div className="wrap" style={{ padding: "64px 20px" }}>
        <meta name="robots" content="noindex" />
        <h1>This website is temporarily unavailable</h1>
        <p>Please contact the website owner.</p>
      </div>
    );
  }
  if (site.kind === "error") throw new Error("Site temporarily unavailable");
  const ent = await entitlementsOf(site.tenant.packageTier);
  const config = applyEntitlements(site.config, ent);
  const siteUrl = await siteBaseUrl();
  const pool = await mgr.getPool(site.tenant.tenantId);
  const shop = await buildShopView(pool, ent, { page, sp: { q: sp.q, category: sp.category, sort: sp.sort, page: sp.page } });
  const base: PageKey[] = config.builder ? ["home"] : isRichTemplate(site.tenant.templateKey) ? visiblePages(config) : starterPages(config);
  const pages = withShop(base, Boolean(shop));
  if (page !== "home" && !pages.includes(page)) notFound();
  let galleryAlts: Record<string, string> = {};
  if (config.images.gallery.length) {
    galleryAlts = Object.fromEntries((await pool.query("SELECT id, alt FROM media WHERE id = ANY($1::uuid[])", [config.images.gallery])).rows.map((r) => [r.id, r.alt]));
  }
  const settings = shop ? await orIfMissingSchema(() => getShopSettings(pool), null) : null;
  return <TemplateSite templateKey={site.tenant.templateKey} businessName={site.tenant.businessName} config={config} page={page} inquiry={{ sent: sp.sent === "1", error: sp.ie }} galleryAlts={galleryAlts} siteUrl={siteUrl} shop={shop} shopNote={settings?.order_note || undefined} />;
}

/** Context for the product, cart and order pages: the client, its package and the site chrome inputs. Not found unless the package has a shop. */
export async function loadShopContext(host: string) {
  const { mgr } = runtime();
  const site = await getSite(host);
  if (site.kind !== "site") notFound();
  const ent = await entitlementsOf(site.tenant.packageTier);
  if (!ent.shop.products) notFound();
  const pool = await mgr.getPool(site.tenant.tenantId);
  const config = applyEntitlements(site.config, ent);
  const settings = await orIfMissingSchema(() => getShopSettings(pool), null);
  if (!settings) notFound();
  const shop = (await buildShopView(pool, ent, { page: "products" })) ?? { cart: ent.shop.cart, search: ent.shop.search, categories: [], home: [] };
  return { site, ent, pool, config, settings, shop, siteUrl: await siteBaseUrl() };
}
export type ShopContext = Awaited<ReturnType<typeof loadShopContext>>;

/** Page title, description and search-engine hints for a client site. Uses the owner's SEO settings when present. */
export async function siteMetadata(host: string, page: PageKey): Promise<Metadata> {
  const site = await getSite(host);
  if (site.kind === "suspended") return { title: "Temporarily unavailable", robots: { index: false, follow: false } };
  if (site.kind !== "site") return { title: "Site not found", robots: { index: false, follow: false } };
  const config = applyEntitlements(site.config, await entitlementsOf(site.tenant.packageTier));
  const name = site.tenant.businessName;
  const base = config.seo.title || name;
  const title = page === "home" ? base : `${PAGE_LABELS[page]} | ${base}`;
  const about = config.content.about ? config.content.about.replace(/\s+/g, " ").slice(0, 160) : undefined;
  const description = config.seo.description || about || config.content.heroSubtitle;
  const ent = await entitlementsOf(site.tenant.packageTier);
  // The sharing image: the owner's choice, otherwise the banner photo (only when the package includes Expanded SEO).
  const shareId = ent.seoExpanded ? (config.seo.shareImage ?? config.images.hero) : undefined;
  const images = shareId ? [{ url: `${await siteBaseUrl()}/media/${shareId}` }] : undefined;
  return {
    title, description,
    ...(config.seo.noindex ? { robots: { index: false, follow: false } } : {}),
    openGraph: { title, description, type: "website", siteName: name, ...(images ? { images } : {}) },
    twitter: { card: images ? "summary_large_image" : "summary", title, description, ...(images ? { images: images.map((i) => i.url) } : {}) },
  };
}

/** True when the owner asked search engines to leave their website out (Expanded SEO). */
export async function clientHidesFromSearch(host: string): Promise<boolean> {
  const site = await getSite(host);
  if (site.kind !== "site") return false;
  return Boolean(applyEntitlements(site.config, await entitlementsOf(site.tenant.packageTier)).seo.noindex);
}

/** Pages that exist for this client (used by the sitemap). */
export async function listClientPages(host: string): Promise<PageKey[] | null> {
  const site = await getSite(host);
  if (site.kind !== "site") return null;
  const config = applyEntitlements(site.config, await entitlementsOf(site.tenant.packageTier));
  const pages: PageKey[] = config.builder ? ["home"] : isRichTemplate(site.tenant.templateKey) ? visiblePages(config) : starterPages(config);
  const ent = await entitlementsOf(site.tenant.packageTier);
  const hasShop = ent.shop.products && (await buildShopView(await runtime().mgr.getPool(site.tenant.tenantId), ent, { page: "home" })) !== null;
  return withShop(pages, hasShop);
}

/** Addresses of the products visitors can see (for the sitemap). */
export async function listClientProductSlugs(host: string): Promise<string[]> {
  const site = await getSite(host);
  if (site.kind !== "site") return [];
  const ent = await entitlementsOf(site.tenant.packageTier);
  if (!ent.shop.products) return [];
  return orIfMissingSchema(async () => listProductSlugs(await runtime().mgr.getPool(site.tenant.tenantId)), []);
}

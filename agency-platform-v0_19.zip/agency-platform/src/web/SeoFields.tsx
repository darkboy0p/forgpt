"use client";
import { useState } from "react";

/** Title and description with character counts and a picture of how the result may look in Google. */
export function SeoFields({ businessName, address, initialTitle, initialDescription, fallbackDescription }: {
  businessName: string; address: string; initialTitle: string; initialDescription: string; fallbackDescription: string;
}) {
  const [title, setTitle] = useState(initialTitle);
  const [desc, setDesc] = useState(initialDescription);
  const shownTitle = (title.trim() || businessName).slice(0, 70);
  const shownDesc = (desc.trim() || fallbackDescription).slice(0, 170);
  const count = (n: number, max: number, soft: number) => <span className={n > soft ? "count over" : "count"}>{n}/{max}</span>;
  return (
    <div>
      <label>Page title
        <span className="hint">Up to 70 characters, and Google usually shows about 60. Leave blank to use your business name. {count(title.length, 70, 60)}</span>
        <input name="seoTitle" maxLength={70} value={title} onChange={(e) => setTitle(e.target.value)} />
      </label>
      <label>Short description
        <span className="hint">Up to 170 characters. Say what you offer and where. {count(desc.length, 170, 160)}</span>
        <input name="seoDescription" maxLength={170} value={desc} onChange={(e) => setDesc(e.target.value)} />
      </label>
      <div className="serp" aria-label="How your website may look in Google">
        <small>How it may look in Google</small>
        <div className="serp-url">{address}</div>
        <div className="serp-title">{shownTitle}</div>
        <div className="serp-desc">{shownDesc || "Add a short description so people know what you offer."}</div>
      </div>
    </div>
  );
}

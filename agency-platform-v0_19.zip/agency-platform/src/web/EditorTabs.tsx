"use client";
import { useEffect, useState } from "react";

export interface EditorTab { id: string; label: string }

/**
 * Tabs for the long editor form. Every field stays on the one form (hidden tabs are only hidden, not removed),
 * so Save always saves everything and nothing typed in another tab is lost.
 */
export function EditorTabs({ tabs }: { tabs: EditorTab[] }) {
  const [active, setActive] = useState(tabs[0]!.id);
  useEffect(() => {
    const fromHash = window.location.hash.replace("#tab-", "");
    if (tabs.some((t) => t.id === fromHash)) setActive(fromHash);
  }, [tabs]);
  useEffect(() => { document.getElementById("editor-form")?.setAttribute("data-active", active); }, [active]);
  const pick = (id: string) => { setActive(id); history.replaceState(null, "", `#tab-${id}`); window.scrollTo({ top: 0 }); };
  return (
    <div className="ed-tabs" role="tablist" aria-label="Parts of your website">
      {tabs.map((t) => <button key={t.id} type="button" role="tab" aria-selected={t.id === active} onClick={() => pick(t.id)}>{t.label}</button>)}
    </div>
  );
}

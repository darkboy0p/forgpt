/** Shown where the owner's package does not include a feature. It says what they would get and how to ask. */
export function LockedCard({ id, title, text, tab }: { id?: string; title: string; text: string; tab?: string }) {
  return (
    <section id={id} data-tab={tab} className="card ed-section locked">
      <header><h2>{title} <span className="chip off">Not in your package</span></h2></header>
      <p style={{ margin: "0 0 12px" }}>{text}</p>
      <a className="btn ghost" href="/dashboard/package#upgrade">See packages and ask for an upgrade</a>
    </section>
  );
}

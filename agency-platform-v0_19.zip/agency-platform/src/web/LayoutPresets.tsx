"use client";
import { useState } from "react";

/** Fills the layout dropdowns on the editor form. It never saves anything by itself. */
export function LayoutPresets({ presets }: { presets: { name: string; blurb: string; values: Record<string, string> }[] }) {
  const [last, setLast] = useState<string | null>(null);
  const apply = (name: string, values: Record<string, string>) => {
    const form = document.getElementById("editor-form") as HTMLFormElement | null;
    if (!form) return;
    for (const [k, v] of Object.entries(values)) {
      const el = form.elements.namedItem(k);
      if (el instanceof HTMLSelectElement) el.value = v;
    }
    setLast(name);
  };
  return (
    <div className="presets">
      <p className="hint" style={{ margin: "0 0 8px" }}>Start from a ready-made look, then change anything you like.</p>
      <div className="preset-row">
        {presets.map((p) => (
          <button type="button" key={p.name} onClick={() => apply(p.name, p.values)}><strong>{p.name}</strong><span>{p.blurb}</span></button>
        ))}
      </div>
      {last && <p className="hint" role="status" style={{ margin: "8px 0 0" }}>{last} look filled in below. Press <strong>Save draft</strong>, then <strong>Preview saved draft</strong> to see it.</p>}
    </div>
  );
}

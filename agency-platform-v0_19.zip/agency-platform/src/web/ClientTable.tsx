"use client";
import { useMemo, useState } from "react";

export interface ClientRow { slug: string; name: string; tier: number; packageName: string; template: string; status: string; hostname: string | null; domainStatus: string | null; siteUrl: string | null; dashUrl: string | null }

const statusClass = (s: string) => (s === "active" ? "chip" : s === "suspended" ? "chip warn" : "chip bad");

/** Search and filter the client list in the browser. All data was already prepared on the server. */
export function ClientTable({ rows }: { rows: ClientRow[] }) {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [tier, setTier] = useState("all");
  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return rows.filter((r) => (status === "all" || r.status === status) && (tier === "all" || String(r.tier) === tier)
      && (!needle || [r.name, r.slug, r.hostname ?? ""].some((v) => v.toLowerCase().includes(needle))));
  }, [rows, q, status, tier]);
  return (
    <div>
      <div className="toolbar">
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name, short name or domain" aria-label="Search clients" style={{ flex: "1 1 240px", width: "auto" }} />
        <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status" style={{ width: "auto" }}>
          <option value="all">All statuses</option><option value="active">Active</option><option value="suspended">Suspended</option><option value="failed">Setup failed</option>
        </select>
        <select value={tier} onChange={(e) => setTier(e.target.value)} aria-label="Filter by package" style={{ width: "auto" }}>
          <option value="all">All packages</option>{[1, 2, 3, 4, 5].map((t) => <option key={t} value={t}>Tier {t}</option>)}
        </select>
      </div>
      <p className="hint" role="status">Showing {shown.length} of {rows.length} clients</p>
      <div className="tbl-wrap">
        <table>
          <thead><tr><th>Client</th><th>Package</th><th>Status</th><th>Domain</th><th>Open</th></tr></thead>
          <tbody>
            {shown.map((r) => (
              <tr key={r.slug}>
                <td><a href={`/admin/clients/${r.slug}`}><strong>{r.name}</strong></a><br /><small className="hint">{r.slug} &middot; {r.template}</small></td>
                <td>{r.packageName}<br /><small className="hint">Tier {r.tier}</small></td>
                <td><span className={statusClass(r.status)}>{r.status}</span></td>
                <td>{r.hostname ? <>{r.hostname}<br /><span className={r.domainStatus === "verified" ? "chip" : "chip warn"}>{r.domainStatus}</span></> : <span className="hint">no domain yet</span>}</td>
                <td>{r.siteUrl ? <><a href={r.siteUrl}>Website</a> &middot; <a href={r.dashUrl ?? "#"}>Dashboard</a></> : <a href={`/admin/clients/${r.slug}`}>Manage</a>}</td>
              </tr>
            ))}
            {shown.length === 0 && <tr><td colSpan={5} className="hint">No client matches. Clear the search or filters.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

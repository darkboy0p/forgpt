import type { Pool } from "pg";
import { resolveHostState, type ResolvedTenant } from "../tenancy/resolver";
import type { TenantConnectionManager } from "../tenancy/connectionManager";
import { parseSiteConfig, type SiteConfig } from "../config/siteConfig";

export type SiteResult =
  | { kind: "site"; tenant: ResolvedTenant & { businessName: string }; config: SiteConfig; configValid: boolean }
  | { kind: "not-found" }
  | { kind: "suspended" }
  | { kind: "error" };

/** Host header -> verified tenant -> that tenant's own database -> its site config. */
export async function loadSiteForHost(control: Pool, mgr: TenantConnectionManager, host: string): Promise<SiteResult> {
  try {
    const state = await resolveHostState(control, host);
    if (state.kind === "suspended") return { kind: "suspended" };
    if (state.kind === "none") return { kind: "not-found" };
    const tenant = state.tenant;
    const name = await control.query("SELECT business_name FROM tenants WHERE id = $1", [tenant.tenantId]);
    const pool = await mgr.getPool(tenant.tenantId);
    const row = await pool.query("SELECT config FROM site_config WHERE id = 1");
    const { config, valid } = parseSiteConfig(row.rows[0]?.config);
    return { kind: "site", tenant: { ...tenant, businessName: name.rows[0].business_name }, config, configValid: valid };
  } catch (err) {
    console.error("[site] failed to load site:", (err as Error).message); // never log connection strings
    return { kind: "error" };
  }
}

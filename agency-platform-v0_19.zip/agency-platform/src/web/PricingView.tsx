import { COMPARISON_ROWS } from "../packages/features";
import type { PricingData, PricingPackage } from "../packages/pricing";
import { formatTaka } from "../billing/values";

const mark = (v: string) => (v === "NO" ? "✗" : v === "YES" ? "✓" : v);

function ContactButton({ pkg, settings }: { pkg: PricingPackage; settings: Record<string, string> }) {
  const wa = settings.agency_whatsapp;
  const text = encodeURIComponent(`Hello${settings.agency_name ? " " + settings.agency_name : ""}, I have a question about the ${pkg.name} package (${formatTaka(pkg.setup)} setup, ${formatTaka(pkg.monthly)} per month).`);
  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
      <a className="btn" href={`/buy?package=${pkg.tier}`}>Buy {pkg.name}</a>
      {wa && <a href={`https://wa.me/${wa}?text=${text}`} target="_blank" rel="noopener noreferrer"><small>Ask on WhatsApp</small></a>}
    </div>
  );
}

/** Five package cards plus the comparison table. Used on the public pricing page and in the admin. */
export function PricingView({ data }: { data: PricingData }) {
  const { packages, settings } = data;
  return (
    <div>
      <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", alignItems: "stretch" }}>
        {packages.map((p) => (
          <div className="card" key={p.tier} style={{ display: "flex", flexDirection: "column", margin: 0 }}>
            <span className="tag" style={{ alignSelf: "flex-start" }}>Tier {p.tier}</span>
            <h2 style={{ margin: "8px 0 4px" }}>{p.name}</h2>
            <p style={{ color: "#5b6573", marginTop: 0 }}>{p.description}</p>
            <p style={{ margin: "4px 0" }}><span style={{ fontSize: "1.8rem", fontWeight: 700 }}>{formatTaka(p.setup)}</span> <small>one-time setup</small></p>
            <p style={{ margin: "4px 0 12px" }}><strong>{formatTaka(p.monthly)}</strong> <small>per month</small></p>
            <ul style={{ listStyle: "none", padding: 0, margin: "0 0 12px", flex: 1 }}>
              {p.summary.map((r) => (
                <li key={r.label} style={{ padding: "3px 0", color: r.value === "NO" ? "#8a93a0" : undefined }}>
                  <span aria-hidden="true" style={{ display: "inline-block", width: 70, fontWeight: 600, color: r.value === "NO" ? "#c0392b" : "#1faa59" }}>{mark(r.value)}</span>
                  {r.label}{r.planned && r.value !== "NO" && <> <span className="tag">coming soon</span></>}
                </li>
              ))}
            </ul>
            <details style={{ marginBottom: 12 }}>
              <summary>All features</summary>
              {["Website", "Products", "Selling", "Reports", "Support", "Limits"].map((g) => (
                <div key={g}><p style={{ margin: "10px 0 2px" }}><strong>{g}</strong></p>
                  <ul style={{ listStyle: "none", padding: 0, margin: 0, fontSize: ".9rem" }}>
                    {p.features.filter((f) => f.group === g).map((f) => (
                      <li key={f.key} style={{ color: f.included ? undefined : "#8a93a0" }}>
                        {f.kind === "limit" ? `${f.label}: ${f.value} ${f.unit ?? ""}` : <>{f.included ? "✓" : "✗"} {f.label}</>}
                        {f.planned && f.included && <> <span className="tag">coming soon</span></>}
                      </li>
                    ))}
                  </ul></div>
              ))}
            </details>
            <ContactButton pkg={p} settings={settings} />
          </div>
        ))}
      </div>

      <h2 style={{ marginTop: 32 }}>Compare packages</h2>
      <div style={{ overflowX: "auto" }}>
        <table>
          <thead><tr><th>Feature</th>{packages.map((p) => <th key={p.tier}>{p.name}</th>)}</tr></thead>
          <tbody>
            {COMPARISON_ROWS.map((r, i) => (
              <tr key={r.label}><td>{r.label}</td>{packages.map((p) => <td key={p.tier}>{p.summary[i]!.value}</td>)}</tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{ color: "#5b6573" }}><small>
        Prices are in Bangladeshi taka (BDT). Setup is charged once; the monthly fee covers hosting, backups, security updates and support as agreed.
        Domains, domain renewals, courier fees, payment-gateway fees and major custom work are not included unless agreed in writing.
        Features marked &quot;coming soon&quot; are planned and not available yet.
      </small></p>
    </div>
  );
}

import { cookies, headers } from "next/headers";
import { cache } from "react";
import { notFound, redirect } from "next/navigation";
import { isPlatformHost } from "./adminAccess";
import { runtime } from "./server";
import { resolveHostState } from "../tenancy/resolver";
import { getStaffSession } from "../store/auth";

export const STORE_COOKIE = "store_session";

/** Which client is this request for? Only a verified, active client domain works; anything else is a 404. */
export const storeContext = cache(async () => {
  const host = (await headers()).get("host") ?? "";
  const { env, control, mgr } = runtime();
  const state = await resolveHostState(control, host);
  // Development convenience: /dashboard on localhost has no client, so send the developer to the list of client sites.
  if (state.kind !== "active" && env.APP_ENV === "development" && isPlatformHost(env, host)) redirect("/");
  if (state.kind !== "active") notFound();
  const pool = await mgr.getPool(state.tenant.tenantId);
  const name = (await control.query("SELECT business_name FROM tenants WHERE id = $1", [state.tenant.tenantId])).rows[0]?.business_name as string;
  return { env, tenant: state.tenant, businessName: name, pool };
});

/** Every dashboard page AND action calls this: the login is checked inside THIS client's own database. */
export async function requireStaff(opts: { allowMustChange?: boolean } = {}) {
  const ctx = await storeContext();
  const token = (await cookies()).get(STORE_COOKIE)?.value;
  const staff = await getStaffSession(ctx.pool, token);
  if (!staff) redirect("/dashboard/login");
  if (staff.mustChangePassword && !opts.allowMustChange) redirect("/dashboard/password");
  return { ...ctx, staff, token: token as string };
}

export async function currentStaffOrNull() {
  const ctx = await storeContext();
  const staff = await getStaffSession(ctx.pool, (await cookies()).get(STORE_COOKIE)?.value);
  return { ctx, staff };
}

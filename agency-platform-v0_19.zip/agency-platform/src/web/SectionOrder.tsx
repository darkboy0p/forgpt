"use client";
import { useState } from "react";

export interface SectionItem { key: string; label: string; shown: boolean }

/**
 * Lets the owner tick which sections show and move them up or down.
 * It submits the same `pos_<section>` fields the server already understands (1, 2, 3... or blank = hidden),
 * so the server still validates everything and enforces the package.
 */
export function SectionOrder({ initial }: { initial: SectionItem[] }) {
  const [items, setItems] = useState(initial);
  const move = (i: number, d: -1 | 1) => setItems((cur) => {
    const j = i + d;
    if (j < 0 || j >= cur.length) return cur;
    const next = [...cur];
    const a = next[i], b = next[j];
    if (!a || !b) return cur;
    next[i] = b;
    next[j] = a;
    return next;
  });
  const toggle = (i: number) => setItems((cur) => cur.map((it, k) => (k === i ? { ...it, shown: !it.shown } : it)));
  let n = 0;
  return (
    <ol className="sec-order">
      {items.map((it, i) => {
        const pos = it.shown ? ++n : 0;
        return (
          <li key={it.key} className={it.shown ? "" : "off"}>
            <input type="hidden" name={`pos_${it.key}`} value={it.shown ? String(pos) : ""} />
            <label style={{ margin: 0, flex: 1, display: "flex", alignItems: "center", fontWeight: 500 }}>
              <input type="checkbox" checked={it.shown} onChange={() => toggle(i)} />
              {it.label}
            </label>
            <span className="pos" aria-hidden="true">{it.shown ? pos : "hidden"}</span>
            <button type="button" onClick={() => move(i, -1)} disabled={i === 0} aria-label={`Move ${it.label} up`}>&uarr;</button>
            <button type="button" onClick={() => move(i, 1)} disabled={i === items.length - 1} aria-label={`Move ${it.label} down`}>&darr;</button>
          </li>
        );
      })}
    </ol>
  );
}

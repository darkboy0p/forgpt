import type { ReactNode } from "react";
import { runtime } from "./server";
import { getCurrentAdmin } from "./adminSession";
import { logoutAction } from "../../app/admin/actions";
import { NavLinks, type NavItem } from "./NavLinks";
import { ThemeToggle, THEME_INIT } from "./ThemeToggle";
import { countNewPurchases } from "../orders/service";
import { orIfMissingSchema } from "../shop/safe";

/** Common frame for every admin page: navigation, who is signed in, and the number of open client requests. */
export async function AdminShell({ children, bare = false, narrow = false }: { children: ReactNode; bare?: boolean; narrow?: boolean }) {
  let email: string | undefined, open = 0, newOrders = 0;
  if (!bare) {
    email = (await getCurrentAdmin())?.email;
    open = Number((await runtime().control.query("SELECT count(*) AS n FROM client_requests WHERE status = 'open'")).rows[0].n);
    newOrders = await orIfMissingSchema(() => countNewPurchases(runtime().control), 0);
  }
  const links: NavItem[] = [
    { href: "/admin", label: "Clients", match: ["/admin$", "/admin/clients"] },
    { href: "/admin/orders", label: "Orders", badge: newOrders },
    { href: "/admin/domains", label: "Domains" },
    { href: "/admin/templates", label: "Templates" },
    { href: "/admin/billing", label: "Billing" },
    { href: "/admin/packages", label: "Packages and pricing" },
    { href: "/admin/requests", label: "Client requests", badge: open },
  ];
  return (
    <div className="dash">
      <script dangerouslySetInnerHTML={{ __html: THEME_INIT }} />
      <header className="dash-top">
        <div className="inner">
          <span className="dash-brand">Platform admin<small>Your agency control panel</small></span>
          {!bare && (
            <>
              <NavLinks links={links} label="Admin" />
              <span className="dash-user">
                <ThemeToggle /><a href="/pricing" target="_blank" rel="noopener">Public pricing</a>
                <span>{email}</span>
                <form action={logoutAction}><button type="submit">Log out</button></form>
              </span>
            </>
          )}
        </div>
      </header>
      <main className="dash-main" style={narrow ? { maxWidth: 480 } : undefined}>{children}</main>
    </div>
  );
}

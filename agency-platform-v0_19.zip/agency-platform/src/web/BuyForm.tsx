"use client";
import { useActionState, useState } from "react";
import { submitPurchaseAction, type BuyState } from "../../app/buy/actions";
import { BUY_ERRORS } from "./buyMessages";

export interface BuyPackage { tier: number; name: string; description: string; setup: string; monthly: string; points: { label: string; value: string; planned: boolean }[] }
const PAY: [string, string][] = [["bkash", "bKash"], ["nagad", "Nagad"], ["rocket", "Rocket"], ["bank", "Bank transfer"], ["cash", "Cash (in person)"]];

export function BuyForm({ packages, initialTier }: { packages: BuyPackage[]; initialTier: number }) {
  const [state, action, pending] = useActionState<BuyState, FormData>(submitPurchaseAction, {});
  const v = state.values ?? {};
  const [tier, setTier] = useState(Number(v.packageTier) || initialTier);
  const chosen = packages.find((p) => p.tier === tier) ?? packages[0]!;
  return (
    <form action={action} className="buy-grid" noValidate={false}>
      <div>
        {state.error && <p className="buy-error" role="alert">{BUY_ERRORS[state.error] ?? "Something went wrong. Please try again."}</p>}
        <fieldset className="buy-box"><legend>1. Choose a package</legend>
          <div className="buy-packs">
            {packages.map((p) => (
              <label key={p.tier} className={p.tier === tier ? "pack on" : "pack"}>
                <input type="radio" name="packageTier" value={p.tier} checked={p.tier === tier} onChange={() => setTier(p.tier)} />
                <span><strong>{p.name}</strong><small>{p.setup} setup + {p.monthly}/month</small></span>
              </label>
            ))}
          </div>
        </fieldset>
        <fieldset className="buy-box"><legend>2. About you and your business</legend>
          <label>Business name *<input name="businessName" required minLength={2} maxLength={80} defaultValue={v.businessName ?? ""} autoComplete="organization" /></label>
          <label>Your name *<input name="contactName" required minLength={2} maxLength={80} defaultValue={v.contactName ?? ""} autoComplete="name" /></label>
          <div className="buy-two">
            <label>Phone number *<input name="phone" type="tel" inputMode="tel" required maxLength={20} placeholder="01710000000" defaultValue={v.phone ?? ""} autoComplete="tel" /></label>
            <label>WhatsApp (if different)<input name="whatsapp" inputMode="numeric" maxLength={20} placeholder="8801710000000" defaultValue={v.whatsapp ?? ""} /></label>
          </div>
          <label>Email (optional)<input name="email" type="email" maxLength={254} defaultValue={v.email ?? ""} autoComplete="email" /></label>
          <label>Web address you would like (optional)<input name="desiredHostname" maxLength={253} placeholder="www.myshop.com" defaultValue={v.desiredHostname ?? ""} autoCapitalize="none" spellCheck={false} /></label>
        </fieldset>
        <fieldset className="buy-box"><legend>3. Payment and notes</legend>
          <label>How would you like to pay?
            <select name="paymentMethod" defaultValue={v.paymentMethod || "bkash"}>{PAY.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>
          <label>Anything we should know? (optional)<textarea name="message" rows={4} maxLength={1000} defaultValue={v.message ?? ""} placeholder="What do you sell? Do you have a logo? Any colours you like?" /></label>
          <div aria-hidden="true" style={{ position: "absolute", left: "-9999px", height: 0, overflow: "hidden" }}>
            <label>Leave this empty<input name="website" tabIndex={-1} autoComplete="off" /></label>
          </div>
        </fieldset>
        <button className="btn buy-submit" type="submit" disabled={pending}>{pending ? "Sending..." : "Send my order request"}</button>
        <p className="buy-hint">You pay nothing now. We contact you to confirm the details, then you pay and we build your website.</p>
      </div>
      <aside className="buy-summary" aria-live="polite">
        <h2>{chosen.name}</h2>
        <p className="buy-desc">{chosen.description}</p>
        <p className="buy-price"><strong>{chosen.setup}</strong> <small>one-time setup</small><br /><strong>{chosen.monthly}</strong> <small>per month</small></p>
        <ul>{chosen.points.filter((x) => x.value !== "NO").map((x) => <li key={x.label}><span>{x.label}</span><b>{x.value === "YES" ? "✓" : x.value}{x.planned ? " (soon)" : ""}</b></li>)}</ul>
        <p className="buy-hint"><a href="/pricing">Compare all packages</a></p>
      </aside>
    </form>
  );
}

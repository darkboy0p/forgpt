"use client";
import { useState } from "react";
import { contrastRatio, onColor, MIN_TEXT_CONTRAST } from "../config/color";

const DEFAULTS = { primary: "#0a7d4b", accent: "#f59e0b", background: "#ffffff", text: "#1b1f24", surface: "#f3f5f7" };
type C = typeof DEFAULTS;

/** The five colours, with a live preview and a check that the text is readable on the background. */
export function ColourFields({ initial }: { initial: C }) {
  const [c, setC] = useState<C>(initial);
  const set = (k: keyof C) => (e: React.ChangeEvent<HTMLInputElement>) => setC((p) => ({ ...p, [k]: e.target.value }));
  const ratio = contrastRatio(c.text, c.background);
  const verdict = ratio < MIN_TEXT_CONTRAST ? ["bad", "Too hard to read. This cannot be saved. Pick a darker text colour or a lighter background."] : ratio < 4.5 ? ["warn", "Readable, but weak for small text. A stronger contrast is kinder to visitors."] : ["ok", "Easy to read."];
  const field = (k: keyof C, label: string, hint: string) => (
    <label key={k}>{label}<span className="hint">{hint}</span><input name={k} type="color" value={c[k]} onChange={set(k)} /></label>
  );
  return (
    <div>
      <div className="ed-colour">
        {field("primary", "Main colour", "Buttons, links, banner")}
        {field("accent", "Accent colour", "Badges and highlights")}
        {field("background", "Page background", "Behind everything")}
        {field("text", "Text colour", "Normal writing")}
        {field("surface", "Card and section tint", "Alternate sections")}
        <button type="button" onClick={() => setC(DEFAULTS)} style={{ alignSelf: "end" }}>Reset colours</button>
      </div>
      <p className={verdict[0] === "ok" ? "ok" : "warn"} role="status" style={{ marginTop: 12 }}>Text on background: <strong>{ratio.toFixed(1)} : 1</strong>. {verdict[1]}</p>
      <div className="colour-preview" style={{ background: c.background, color: c.text }} aria-label="Colour preview">
        <div style={{ background: c.primary, color: onColor(c.primary), padding: "10px 14px", fontWeight: 700 }}>Your banner</div>
        <div style={{ padding: 14 }}>
          <strong>A heading</strong>
          <p style={{ margin: "4px 0 10px" }}>This is how normal writing will look on your page.</p>
          <span style={{ background: c.primary, color: onColor(c.primary), padding: "6px 14px", borderRadius: 6, marginRight: 8, display: "inline-block" }}>Button</span>
          <span style={{ background: c.accent, color: onColor(c.accent), padding: "6px 14px", borderRadius: 6, display: "inline-block" }}>Offer</span>
          <div style={{ background: c.surface, padding: 10, marginTop: 10, borderRadius: 6 }}>A card or alternate section</div>
        </div>
      </div>
    </div>
  );
}

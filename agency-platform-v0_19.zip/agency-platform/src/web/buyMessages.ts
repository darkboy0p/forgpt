/** Messages for the public order form. Kept out of the server-action file, which may only export functions. */
export const BUY_ERRORS: Record<string, string> = {
  invalid_package: "Please choose a package.", invalid_business: "Please enter your business name (2 to 80 letters, no < or >).",
  invalid_name: "Please enter your name.", invalid_phone: "Please enter a phone number with digits only, for example 01710000000.",
  invalid_whatsapp: "The WhatsApp number should be digits with the country code, for example 8801710000000.", invalid_email: "That email address does not look right.",
  invalid_domain: "That domain name does not look right. Example: www.myshop.com, or leave it blank.", invalid_message: "Your message is too long (1000 characters at most).",
  invalid_payment: "Please choose how you would like to pay.", rate_limited: "We already received your request. Please wait, we will contact you soon.", unavailable: "Sorry, ordering is not available here.",
};

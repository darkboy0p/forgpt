"use client";
import { useMemo, useState } from "react";
import { addToCart } from "./cart";
import { OrderForm } from "./OrderForm";
import { taka } from "./messages";

export interface BuyVariant { id: string; label: string; priceBdt: number; soldOut: boolean }

/** Option and quantity choice, then either "add to cart" (cart packages) or a short order form (simple packages). */
export function ProductBuy({ productId, productName, basePrice, variants, soldOut, cart, whatsapp, orderNote, interactive }: {
  productId: string; productName: string; basePrice: number; variants: BuyVariant[]; soldOut: boolean; cart: boolean; whatsapp?: string; orderNote?: string; interactive: boolean;
}) {
  const firstFree = variants.find((v) => !v.soldOut)?.id ?? variants[0]?.id ?? "";
  const [variantId, setVariantId] = useState(firstFree);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const v = variants.find((x) => x.id === variantId);
  const unit = v ? v.priceBdt : basePrice;
  const unavailable = soldOut || (variants.length > 0 && (!v || v.soldOut));
  const itemsJson = useMemo(() => JSON.stringify([{ productId, variantId: variants.length ? variantId : null, qty }]), [productId, variantId, qty, variants.length]);
  const msg = encodeURIComponent(`Hello, I am interested in ${productName}${v ? ` (${v.label})` : ""}.`);

  if (soldOut) return <p className="formerr">This product is sold out right now.</p>;
  return (
    <div className="buybox">
      {variants.length > 0 && (
        <label className="field"><span>Choose an option</span>
          <select value={variantId} onChange={(e) => setVariantId(e.target.value)} disabled={!interactive}>
            {variants.map((x) => <option key={x.id} value={x.id} disabled={x.soldOut}>{x.label}{x.priceBdt !== basePrice ? ` - ${taka(x.priceBdt)}` : ""}{x.soldOut ? " (sold out)" : ""}</option>)}
          </select></label>
      )}
      <div className="field"><span>Quantity</span>
        <div className="qty"><button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Less">-</button>
          <input value={qty} inputMode="numeric" aria-label="Quantity" onChange={(e) => setQty(Math.min(50, Math.max(1, Number(e.target.value.replace(/\D/g, "")) || 1)))} />
          <button type="button" onClick={() => setQty((q) => Math.min(50, q + 1))} aria-label="More">+</button></div>
        <span style={{ marginLeft: 12, fontWeight: 700 }}>{taka(unit * qty)}</span></div>
      {!interactive ? <p><small>(Preview: ordering is switched off here.)</small></p> : cart ? (
        <p style={{ margin: 0 }}>
          <button className="btn pro" type="button" disabled={unavailable} style={{ border: 0, cursor: "pointer" }}
            onClick={() => { addToCart(productId, variants.length ? variantId : null, qty); setAdded(true); }}>Add to cart</button>
          <a className="btn pro ghost" href="/checkout" onClick={() => addToCart(productId, variants.length ? variantId : null, qty)}>Buy now</a>
          {added && <span className="okbox" style={{ display: "inline-block", padding: "6px 12px", margin: "0 0 0 4px" }} role="status">Added. <a href="/cart">View cart</a></span>}
        </p>
      ) : (
        <details open>
          <summary style={{ cursor: "pointer", fontWeight: 700, marginBottom: 10 }}>Order this product</summary>
          <OrderForm channel="request" itemsJson={itemsJson} submitLabel="Send my order" note={orderNote} disabled={unavailable} />
        </details>
      )}
      {whatsapp && interactive && <p style={{ marginBottom: 0 }}><a className="btn pro wa" href={`https://wa.me/${whatsapp}?text=${msg}`} target="_blank" rel="noopener noreferrer">Ask on WhatsApp</a></p>}
    </div>
  );
}

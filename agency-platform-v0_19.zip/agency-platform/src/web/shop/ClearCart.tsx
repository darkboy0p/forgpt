"use client";
import { useEffect } from "react";
import { writeCart } from "./cart";

/** The order went through, so the cart in this browser is emptied. */
export function ClearCart() { useEffect(() => { writeCart([]); }, []); return null; }

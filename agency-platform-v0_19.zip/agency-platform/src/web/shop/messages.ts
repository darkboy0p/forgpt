import type { LineProblem } from "../../shop/orders";

export const taka = (n: number) => "৳" + Math.round(n).toLocaleString("en-US");

const ORDER_ERRORS: Record<string, string> = {
  invalid_name: "Please enter your name.", invalid_phone: "Please enter a phone number, digits only, for example 01710000000.", invalid_email: "That email address does not look right.",
  invalid_address: "Please enter your full delivery address (at least 5 characters).", invalid_area: "That area name is too long.", invalid_note: "Your note is too long (500 characters at most).",
  invalid_items: "Your order could not be read. Please add the items again.", not_available: "{item} is no longer available.", sold_out: "{item} is sold out.",
  out_of_stock: "Sorry, there is not enough stock of {item}.", choose_option: "Please choose an option for {item}.", invalid_code: "That discount code is not valid for this order.",
  rate_limited: "You have sent several orders recently. Please try again later or call us.", not_in_package: "Ordering is not available on this website.", one_item_only: "Please order one product at a time.",
};
export const orderErrorText = (code: string, item?: string) => (ORDER_ERRORS[code] ?? "Your order could not be sent. Please try again.").replace("{item}", item ?? "This item");
export const PROBLEM_TEXT: Record<LineProblem, string> = { unavailable: "No longer available", sold_out: "Sold out", out_of_stock: "Not enough in stock", choose_option: "Choose an option" };
export const ORDER_STATUS_TEXT: Record<string, string> = { new: "Received", confirmed: "Confirmed", processing: "Being prepared", shipped: "On its way", delivered: "Delivered", cancelled: "Cancelled" };

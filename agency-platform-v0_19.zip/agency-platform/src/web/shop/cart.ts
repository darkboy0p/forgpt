"use client";
/** The shopping cart lives in the visitor's browser. The server never trusts it: every price is looked up again. */
export interface CartLine { p: string; v: string | null; q: number }
const KEY = "cart:v1";
export const CART_EVENT = "cart:changed";

export function readCart(): CartLine[] {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "[]");
    if (!Array.isArray(raw)) return [];
    return raw.filter((l) => l && typeof l.p === "string" && Number.isInteger(l.q) && l.q > 0).slice(0, 20).map((l) => ({ p: l.p, v: typeof l.v === "string" ? l.v : null, q: Math.min(50, l.q) }));
  } catch { return []; }
}
export function writeCart(lines: CartLine[]) {
  try { localStorage.setItem(KEY, JSON.stringify(lines.slice(0, 20))); } catch { /* storage blocked: the cart just is not kept */ }
  window.dispatchEvent(new Event(CART_EVENT));
}
export function addToCart(p: string, v: string | null, q: number) {
  const cart = readCart();
  const hit = cart.find((l) => l.p === p && l.v === v);
  if (hit) hit.q = Math.min(50, hit.q + q); else cart.push({ p, v, q: Math.min(50, q) });
  writeCart(cart);
}
export const cartCount = () => readCart().reduce((a, l) => a + l.q, 0);
export const toItems = (lines: CartLine[]) => lines.map((l) => ({ productId: l.p, variantId: l.v, qty: l.q }));

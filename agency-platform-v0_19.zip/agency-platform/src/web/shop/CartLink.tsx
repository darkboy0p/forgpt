"use client";
import { useEffect, useState } from "react";
import { CART_EVENT, cartCount } from "./cart";

export function CartLink({ href }: { href: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const update = () => setN(cartCount());
    update();
    window.addEventListener(CART_EVENT, update);
    window.addEventListener("storage", update);
    return () => { window.removeEventListener(CART_EVENT, update); window.removeEventListener("storage", update); };
  }, []);
  return <a className="cartlink" href={href}>Cart{n > 0 && <b>{n}</b>}</a>;
}

"use client";
import { useCallback, useEffect, useState } from "react";
import { quoteCartAction } from "../../../app/shop-actions";
import type { Quote } from "../../shop/orders";
import { readCart, toItems, writeCart, type CartLine } from "./cart";
import { OrderForm } from "./OrderForm";
import { PROBLEM_TEXT, taka } from "./messages";

/** Cart and checkout in one component. `checkout` adds the discount box and the customer form. */
export function CartClient({ checkout, discounts, orderNote }: { checkout: boolean; discounts: boolean; orderNote?: string }) {
  const [lines, setLines] = useState<CartLine[] | null>(null);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [code, setCode] = useState("");
  const [applied, setApplied] = useState("");
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async (cart: CartLine[], c: string) => {
    if (cart.length === 0) { setQuote(null); return; }
    setBusy(true);
    const r = await quoteCartAction(toItems(cart), c);
    setBusy(false);
    setQuote(r.ok ? r.quote : null);
  }, []);
  useEffect(() => { const c = readCart(); setLines(c); void refresh(c, ""); }, [refresh]);

  const change = (next: CartLine[]) => { setLines(next); writeCart(next); void refresh(next, applied); };
  const setQty = (i: number, q: number) => change(lines!.map((l, k) => (k === i ? { ...l, q: Math.min(50, Math.max(1, q)) } : l)));
  const remove = (i: number) => change(lines!.filter((_, k) => k !== i));

  if (lines === null) return <p>Loading your cart...</p>;
  if (lines.length === 0) return <p>Your cart is empty. <a href="/products">Continue shopping</a></p>;
  const problems = quote?.lines.some((l) => l.problem) ?? false;
  return (
    <div className={checkout ? "checkout-grid" : undefined}>
      <div>
        {quote ? quote.lines.map((l, i) => (
          <div className="cart-line" key={`${l.productId}:${l.variantId}`}>
            {l.imageId ? <img src={`/media/${l.imageId}`} alt="" /> : <div style={{ width: 64, height: 64, background: "var(--soft)", borderRadius: 8 }} />}
            <div>
              <strong>{l.name}</strong>{l.variantLabel && <div style={{ opacity: .8 }}>{l.variantLabel}</div>}
              {l.problem && <div className="issue" role="alert">{PROBLEM_TEXT[l.problem]}{l.stockLeft != null && l.problem === "out_of_stock" ? ` (only ${l.stockLeft} left)` : ""}</div>}
              <div className="qty" style={{ marginTop: 6 }}>
                <button type="button" onClick={() => setQty(i, l.qty - 1)} aria-label="Less">-</button>
                <input value={l.qty} inputMode="numeric" aria-label={`Quantity of ${l.name}`} onChange={(e) => setQty(i, Number(e.target.value.replace(/\D/g, "")) || 1)} />
                <button type="button" onClick={() => setQty(i, l.qty + 1)} aria-label="More">+</button>
              </div>{" "}
              <button type="button" className="linkbtn" onClick={() => remove(i)}>Remove</button>
            </div>
            <strong>{taka(l.lineTotal)}</strong>
          </div>
        )) : <p>{busy ? "Updating prices..." : "Your cart could not be loaded."}</p>}
        {quote && (
          <div className="totals" aria-live="polite">
            <div><span>Subtotal</span><span>{taka(quote.subtotal)}</span></div>
            <div><span>Delivery</span><span>{quote.deliveryFee ? taka(quote.deliveryFee) : "Free"}</span></div>
            {quote.discount > 0 && <div><span>Discount ({quote.code})</span><span>-{taka(quote.discount)}</span></div>}
            <div className="grand"><span>Total</span><span>{taka(quote.total)}</span></div>
            <p style={{ fontSize: ".85rem", opacity: .8, margin: "4px 0 0" }}>Pay cash on delivery.</p>
          </div>
        )}
        {checkout && discounts && (
          <div className="field" style={{ maxWidth: 360 }}><span>Discount code</span>
            <div style={{ display: "flex", gap: 8 }}><input value={code} onChange={(e) => setCode(e.target.value)} maxLength={30} placeholder="Enter code" />
              <button type="button" className="btn pro ghost" style={{ margin: 0 }} onClick={() => { setApplied(code); void refresh(lines, code); }}>Apply</button></div>
            {quote?.codeError && <small className="issue" role="alert" style={{ color: "#b3261e" }}>This code cannot be used for this order.</small>}
          </div>
        )}
        {!checkout && <p><a className="btn pro" href="/checkout" aria-disabled={problems}>Checkout</a> <a href="/products">Continue shopping</a></p>}
      </div>
      {checkout && (
        <div className="buybox" style={{ marginTop: 0 }}>
          <h2 style={{ marginTop: 0, fontSize: "1.2rem" }}>Delivery details</h2>
          <OrderForm channel="checkout" itemsJson={JSON.stringify(toItems(lines))} discountCode={quote?.codeError ? "" : applied} submitLabel="Place order" note={orderNote} disabled={problems || !quote} />
        </div>
      )}
    </div>
  );
}

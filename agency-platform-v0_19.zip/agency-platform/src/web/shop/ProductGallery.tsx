"use client";
import { useState } from "react";

export function ProductGallery({ ids, alt }: { ids: string[]; alt: string }) {
  const [i, setI] = useState(0);
  if (ids.length === 0) return <div className="main pimg none" style={{ aspectRatio: "1 / 1" }}>No photo yet</div>;
  return (
    <div className="pgallery">
      <img className="main" src={`/media/${ids[i]}`} alt={alt} />
      {ids.length > 1 && <div className="thumbs">{ids.map((id, k) => <img key={id} src={`/media/${id}`} alt={`${alt} photo ${k + 1}`} className={k === i ? "on" : ""} onClick={() => setI(k)} loading="lazy" />)}</div>}
    </div>
  );
}

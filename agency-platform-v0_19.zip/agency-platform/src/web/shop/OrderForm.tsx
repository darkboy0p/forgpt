"use client";
import { useActionState } from "react";
import { placeOrderAction, type OrderState } from "../../../app/shop-actions";
import { orderErrorText } from "./messages";

/** Customer details for an order. Used for a single product request and for the cart checkout. */
export function OrderForm({ channel, itemsJson, discountCode, submitLabel, note, disabled }: { channel: "request" | "checkout"; itemsJson: string; discountCode?: string; submitLabel: string; note?: string; disabled?: boolean }) {
  const [state, action, pending] = useActionState<OrderState, FormData>(placeOrderAction, {});
  const v = state.values ?? {};
  return (
    <form action={action}>
      {state.error && <p className="formerr" role="alert">{orderErrorText(state.error, state.item)}</p>}
      <input type="hidden" name="channel" value={channel} />
      <input type="hidden" name="items" value={itemsJson} />
      <input type="hidden" name="discountCode" value={discountCode ?? v.discountCode ?? ""} />
      <label className="field"><span>Your name *</span><input name="name" required minLength={2} maxLength={80} defaultValue={v.name ?? ""} autoComplete="name" /></label>
      <label className="field"><span>Phone number *</span><input name="phone" type="tel" inputMode="tel" required maxLength={20} placeholder="01710000000" defaultValue={v.phone ?? ""} autoComplete="tel" /></label>
      <label className="field"><span>Full delivery address *</span><textarea name="address" required minLength={5} maxLength={300} rows={3} defaultValue={v.address ?? ""} autoComplete="street-address" /></label>
      <label className="field"><span>Area / district (optional)</span><input name="area" maxLength={60} defaultValue={v.area ?? ""} /></label>
      <label className="field"><span>Email (optional)</span><input name="email" type="email" maxLength={254} defaultValue={v.email ?? ""} autoComplete="email" /></label>
      <label className="field"><span>Note (optional)</span><textarea name="note" maxLength={500} rows={2} defaultValue={v.note ?? ""} /></label>
      <div aria-hidden="true" style={{ position: "absolute", left: "-9999px", height: 0, overflow: "hidden" }}><label>Leave empty<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
      {note && <p style={{ fontSize: ".9rem", opacity: .85 }}>{note}</p>}
      <button className="btn pro" type="submit" disabled={pending || disabled} style={{ border: 0, cursor: "pointer" }}>{pending ? "Sending..." : submitLabel}</button>
    </form>
  );
}

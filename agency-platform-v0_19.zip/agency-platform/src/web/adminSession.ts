import { cookies, headers } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { runtime } from "./server";
import { isAdminAllowed } from "./adminAccess";
import { getSessionAdmin, type SessionAdmin } from "../auth/sessions";

export const SESSION_COOKIE = "admin_session";

export async function currentHost(): Promise<string> {
  return (await headers()).get("host") ?? "";
}

/** 404 unless this request is on a platform host (so the admin does not exist on client domains). */
export async function assertAdminHost(): Promise<void> {
  if (!isAdminAllowed(runtime().env, await currentHost())) notFound();
}

export async function getCurrentAdmin(): Promise<SessionAdmin | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  return getSessionAdmin(runtime().control, token);
}

/** Every admin page AND every admin action must call this: hiding a button is not security. */
export async function requireAdmin(): Promise<SessionAdmin> {
  await assertAdminHost();
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");
  return admin;
}

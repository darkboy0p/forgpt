"use client";
import { useRef, useState } from "react";

/** Shrinks photos in the browser before they are sent, so phone photos fit the storage limits. Falls back to the original file. */
async function shrink(file: File): Promise<File> {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type) || typeof createImageBitmap !== "function") return file;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, 1000 / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale); canvas.height = Math.round(bmp.height * scale);
    const c = canvas.getContext("2d");
    if (!c) return file;
    c.fillStyle = "#fff"; c.fillRect(0, 0, canvas.width, canvas.height);
    c.drawImage(bmp, 0, 0, canvas.width, canvas.height);
    const blob: Blob | null = await new Promise((res) => canvas.toBlob(res, "image/jpeg", 0.82));
    return blob && blob.size < file.size ? new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" }) : file;
  } catch { return file; }
}

export function PhotoPicker({ name, max }: { name: string; max: number }) {
  const ref = useRef<HTMLInputElement>(null);
  const [note, setNote] = useState("");
  const onChange = async () => {
    const input = ref.current; if (!input?.files?.length) return;
    const picked = Array.from(input.files).slice(0, max);
    setNote("Preparing photos...");
    const out = await Promise.all(picked.map(shrink));
    const dt = new DataTransfer(); out.forEach((f) => dt.items.add(f));
    input.files = dt.files;
    setNote(`${out.length} photo${out.length > 1 ? "s" : ""} ready (${Math.round(out.reduce((a, f) => a + f.size, 0) / 1024)} KB). Press Upload.`);
  };
  return (
    <div>
      <input ref={ref} type="file" name={name} accept="image/jpeg,image/png,image/webp" multiple required onChange={onChange} />
      {note && <p className="hint" role="status">{note}</p>}
    </div>
  );
}

"use client";
export function PrintButton() { return <button type="button" className="noprint" onClick={() => window.print()}>Print this order</button>; }

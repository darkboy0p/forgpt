import type { Entitlements } from "../../config/entitlements";
import { MAX_VARIANTS } from "../../shop/products";
import type { ShopCategory } from "../../shop/types";
import { saveProductAction, deleteProductAction, uploadProductPhotosAction, removeProductPhotoAction, makeMainPhotoAction } from "../../../app/dashboard/shop-actions";
import { PhotoPicker } from "./PhotoPicker";
import { LockedCard } from "../LockedCard";

export interface ProductFormData {
  id?: string; name: string; description: string; price: string; compare: string; sku: string; status: string; categoryId: string; featured: boolean; track: boolean; stock: string; low: string;
  variants: { label: string; price: string; stock: string }[]; images: string[];
}
export const EMPTY_PRODUCT: ProductFormData = { name: "", description: "", price: "", compare: "", sku: "", status: "active", categoryId: "", featured: false, track: false, stock: "0", low: "3", variants: [], images: [] };

export function ProductForm({ ent, data, categories }: { ent: Entitlements; data: ProductFormData; categories: (ShopCategory & { is_visible: boolean })[] }) {
  const rows = Array.from({ length: MAX_VARIANTS }, (_, i) => data.variants[i] ?? { label: "", price: "", stock: "" });
  return (
    <>
      <form action={saveProductAction} className="pform">
        {data.id && <input type="hidden" name="id" value={data.id} />}
        <section className="card">
          <h2>Basics</h2>
          <label>Product name *<input name="name" required minLength={2} maxLength={120} defaultValue={data.name} placeholder="Cotton panjabi" /></label>
          <label>Description<span className="hint">What it is, sizes, materials, delivery. Customers read this.</span><textarea name="description" rows={5} maxLength={3000} defaultValue={data.description} /></label>
          <div className="ed-cols">
            <label>Price (taka) *<input name="priceBdt" inputMode="numeric" required pattern="[0-9]+" defaultValue={data.price} placeholder="1500" /></label>
            <label>Old price (optional)<span className="hint">Shows a Sale badge and a crossed-out price. Must be higher.</span><input name="comparePriceBdt" inputMode="numeric" pattern="[0-9]*" defaultValue={data.compare} placeholder="1800" /></label>
            <label>Product code (optional)<input name="sku" maxLength={40} defaultValue={data.sku} /></label>
            {ent.shop.categories && (
              <label>Category<select name="categoryId" defaultValue={data.categoryId}><option value="">No category</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
                {categories.length === 0 && <span className="hint"><a href="/dashboard/categories">Create categories first</a></span>}</label>
            )}
            <label>Availability<select name="status" defaultValue={data.status}>
              <option value="active">Active (visible, can be ordered)</option><option value="sold_out">Sold out (visible, cannot be ordered)</option><option value="hidden">Hidden (not shown)</option></select></label>
          </div>
          {ent.shop.featured
            ? <label style={{ fontWeight: 400 }}><input type="checkbox" name="isFeatured" defaultChecked={data.featured} />Featured product<span className="hint" style={{ marginLeft: 26 }}>Featured products are shown first on your home page.</span></label>
            : <p className="hint">Featured products are available in higher packages. <a href="/dashboard/package#upgrade">See packages</a></p>}
        </section>

        {ent.shop.stockQty ? (
          <section className="card">
            <h2>Stock</h2>
            <label style={{ fontWeight: 400 }}><input type="checkbox" name="trackStock" defaultChecked={data.track} />Count stock for this product<span className="hint" style={{ marginLeft: 26 }}>Orders reduce the number automatically. At zero the product shows as sold out. Cancelling an order puts the stock back.</span></label>
            <div className="ed-cols">
              <label>In stock<input name="stockQty" inputMode="numeric" pattern="[0-9]*" defaultValue={data.stock} /></label>
              <label>Warn me at or below<input name="lowStockAt" inputMode="numeric" pattern="[0-9]*" defaultValue={data.low} /></label>
            </div>
            {data.variants.length > 0 && <p className="hint">This product has options, so stock is counted for each option below.</p>}
          </section>
        ) : <LockedCard title="Stock counting" text="Count how many you have, show Sold out automatically, and get low-stock warnings." />}

        {ent.shop.variants ? (
          <section className="card">
            <h2>Options (size, colour...)</h2>
            <p className="hint">Add options if customers must choose, for example M, L, XL. An option can have its own price and stock. Leave all rows empty if there are no options.</p>
            {rows.map((r, i) => (
              <div className="ed-row" key={i} style={{ display: i > 3 && !r.label ? "none" : undefined }}>
                <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>Option name</span><input name={`var_label_${i}`} maxLength={40} defaultValue={r.label} placeholder={i === 0 ? "M" : ""} /></label>
                <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>Price (blank = same)</span><input name={`var_price_${i}`} inputMode="numeric" pattern="[0-9]*" defaultValue={r.price} /></label>
                <label style={{ margin: 0 }}><span className="hint" style={{ margin: 0 }}>Stock</span><input name={`var_stock_${i}`} inputMode="numeric" pattern="[0-9]*" defaultValue={r.stock} /></label>
              </div>
            ))}
            <p className="hint">Four rows are shown; more appear after you save. Up to {MAX_VARIANTS} options.</p>
          </section>
        ) : <LockedCard title="Product options" text="Let customers choose a size or colour, each with its own price and stock." />}

        <div className="ed-bar"><div className="inner">
          <span className="status">{data.id ? "Changes are live as soon as you save." : "You can add photos after saving."}</span>
          <a className="btn ghost" href="/dashboard/products">Back to products</a>
          <button className="btn" type="submit">{data.id ? "Save product" : "Create product"}</button>
        </div></div>
      </form>

      {data.id && (
        <>
          <section className="card" id="photos">
            <h2>Photos</h2>
            {!ent.shop.images ? <p className="hint">Product photos are not included in your package.</p> : (
              <>
                <p className="hint">{data.images.length} of {ent.shop.maxProductImages} photos. The first photo is the main one shown in the shop.</p>
                <div className="photo-grid">
                  {data.images.map((m, k) => (
                    <figure key={m}>
                      <img src={`/media/${m}`} alt={`Photo ${k + 1}`} />
                      <figcaption>
                        {k === 0 ? <span className="chip">Main</span> : <form action={makeMainPhotoAction}><input type="hidden" name="id" value={data.id} /><input type="hidden" name="mediaId" value={m} /><button type="submit">Make main</button></form>}
                        <form action={removeProductPhotoAction}><input type="hidden" name="id" value={data.id} /><input type="hidden" name="mediaId" value={m} /><button type="submit" className="linkish">Remove</button></form>
                      </figcaption>
                    </figure>
                  ))}
                </div>
                {data.images.length < ent.shop.maxProductImages && (
                  <form action={uploadProductPhotosAction} encType="multipart/form-data">
                    <input type="hidden" name="id" value={data.id} />
                    <PhotoPicker name="photos" max={ent.shop.maxProductImages - data.images.length} />
                    <button className="btn" type="submit">Upload photos</button>
                  </form>
                )}
              </>
            )}
          </section>
          <section className="card">
            <details><summary style={{ cursor: "pointer", color: "var(--d-danger)", fontWeight: 600 }}>Delete this product</summary>
              <p className="hint">This removes the product and its photos for good. Old orders keep their own copy of the name and price. To just stop selling it, set Availability to Hidden instead.</p>
              <form action={deleteProductAction}><input type="hidden" name="id" value={data.id} /><button type="submit" style={{ color: "var(--d-danger)" }}>Yes, delete this product</button></form>
            </details>
          </section>
        </>
      )}
    </>
  );
}

export const SHOP_ERRORS: Record<string, string> = {
  invalid_name: "Please enter a name (2 or more characters, no < or >).", invalid_description: "The description is too long (3000 characters at most).",
  invalid_price: "The price must be a whole number of taka, for example 1500.", invalid_compare: "The old price must be a whole number higher than the price.",
  invalid_sku: "The product code is too long (40 characters at most).", invalid_status: "Choose Active, Sold out or Hidden.", invalid_category: "That category does not exist.",
  invalid_stock: "Stock numbers must be whole numbers.", invalid_variants: "Each option needs a different name (up to 40 characters). Prices and stock must be whole numbers.",
  too_many_products: "You have reached the number of products your package allows. Remove one or ask us for an upgrade.", not_in_package: "That is not included in your package.",
  not_found: "That item was not found.", too_many: "You have reached the limit.", too_many_images: "This product already has the most photos your package allows.",
  empty: "Choose a photo first.", too_large: "That photo is too big. Photos are shrunk automatically in most browsers; try a smaller one.", bad_type: "Only JPG, PNG or WebP photos are accepted.", quota: "Your image storage is full.",
  closed: "A cancelled order cannot be changed.", invalid_value: "That value is not allowed.",
  invalid_code: "The code must be 3 to 20 letters or numbers.", invalid_kind: "Choose percent or fixed amount.", invalid_min: "The minimum order must be a whole number.", invalid_uses: "Maximum uses must be a whole number of 1 or more.",
  invalid_date: "Choose a valid date.", invalid_percent: "The percent must be a whole number from 1 to 90.", invalid_applies: "Choose all products or one category.", invalid_dates: "Choose a start and end date (the end cannot be before the start, and a campaign can last up to one year).", code_exists: "That code already exists.", invalid_fee: "The delivery fee must be a whole number.", invalid_free_over: "The free-delivery amount must be a whole number, or blank.", invalid_note: "The note is too long (300 characters at most).",
};
export const SHOP_NOTICES: Record<string, string> = {
  created: "Product created. Now add photos below.", saved: "Saved.", deleted: "Deleted.", photo: "Photo added.", photos: "Photos added.", photo_removed: "Photo removed.", main: "Main photo changed.",
  status: "Updated.", campaign: "Campaign saved.", category: "Category saved.", discount: "Discount code saved.", home: "The Products section is now on your home page (in your draft). Preview it, then publish.",
};
export const STATUS_LABELS: Record<string, string> = { active: "Active", sold_out: "Sold out", hidden: "Hidden", new: "New", confirmed: "Confirmed", processing: "Processing", shipped: "Shipped", delivered: "Delivered", cancelled: "Cancelled" };

import type { ReactNode } from "react";
import { SHOP_ERRORS, SHOP_NOTICES } from "./shopMessages";
import { taka } from "../shop/messages";

export { taka };
export function Msg({ error, notice }: { error?: string; notice?: string }) {
  return (
    <>
      {error && <p className="warn" role="alert">{SHOP_ERRORS[error] ?? "Something went wrong."}</p>}
      {notice && SHOP_NOTICES[notice] && <p className="ok" role="status">{SHOP_NOTICES[notice]}</p>}
    </>
  );
}
export function Pager({ page, pages, href }: { page: number; pages: number; href: (p: number) => string }) {
  if (pages <= 1) return null;
  return (
    <p className="toolbar" style={{ alignItems: "center" }}>
      {page > 1 && <a className="btn ghost" href={href(page - 1)}>&larr; Previous</a>}
      <span className="hint">Page {page} of {pages}</span>
      {page < pages && <a className="btn ghost" href={href(page + 1)}>Next &rarr;</a>}
    </p>
  );
}
export function Thumb({ id }: { id: string | null }) {
  return id ? <img className="thumb" src={`/media/${id}`} alt="" loading="lazy" /> : <span className="thumb none">No photo</span>;
}
export function Stat({ label, value, sub, alert }: { label: string; value: ReactNode; sub?: ReactNode; alert?: boolean }) {
  return <div className={alert ? "kpi alert" : "kpi"}><span>{label}</span><b>{value}</b>{sub && <span>{sub}</span>}</div>;
}

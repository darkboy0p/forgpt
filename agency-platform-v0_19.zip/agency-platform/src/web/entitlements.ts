import { runtime } from "./server";
import { getEntitlements, getFeatureValues, hasFeature } from "../packages/resolve";

/** What a package may do RIGHT NOW (built-in defaults plus the Super Admin's saved changes). Always checked on the server. */
export const entitlementsOf = (tier: number) => getEntitlements(runtime().control, tier);
export const featureValuesOf = (tier: number) => getFeatureValues(runtime().control, tier);
export const tierHasFeature = (tier: number, key: string) => hasFeature(runtime().control, tier, key);

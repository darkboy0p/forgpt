import type { ShopCard, ShopView } from "../../shop/types";
import type { PublicProduct } from "../../shop/products";
import { SORTS } from "../../shop/types";
import { mediaUrl } from "./blocks";
import { ProductBuy } from "../shop/ProductBuy";
import { ProductGallery } from "../shop/ProductGallery";
import { ClearCart } from "../shop/ClearCart";
import { CartClient } from "../shop/CartClient";
import { ORDER_STATUS_TEXT, taka } from "../shop/messages";

const SORT_LABELS: Record<string, string> = { newest: "Newest", price_asc: "Price: low to high", price_desc: "Price: high to low", name: "Name A to Z" };
const withQuery = (base: string, params: Record<string, string | number>) => {
  const q = Object.entries(params).filter(([, v]) => v !== "" && v !== 1 || false).map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`).join("&");
  return q ? `${base}${base.includes("?") ? "&" : "?"}${q}` : base;
};

export function ProductCard({ p, href }: { p: ShopCard; href: string }) {
  const onSale = p.comparePriceBdt != null && p.comparePriceBdt > p.priceBdt;
  return (
    <div className="pcard">
      {p.soldOut ? <span className="badge sold">Sold out</span> : p.salePercent ? <span className="badge">-{p.salePercent}%</span> : onSale ? <span className="badge">Sale</span> : null}
      <a className="plink" href={href}>
        {p.imageId ? <img className="pimg" src={mediaUrl(p.imageId)} alt={p.name} loading="lazy" /> : <div className="pimg none">No photo</div>}
        <div className="pbody">
          {p.categoryName && <p className="pcat">{p.categoryName}</p>}
          <p className="pname">{p.name}</p>
          <p className="pprice" style={{ margin: 0 }}>{p.hasOptions && "From "}{taka(p.priceBdt)}{onSale && <span className="pold">{taka(p.comparePriceBdt!)}</span>}</p>
        </div>
      </a>
    </div>
  );
}

/** The Shop page: search and filters (where the package has them), the grid and page links. */
export function CatalogueView({ shop, baseHref, productHref, interactive, title, orderNote }: { shop: ShopView; baseHref: string; productHref: (slug: string) => string; interactive: boolean; title: string; orderNote?: string }) {
  const cat = shop.catalogue;
  if (!cat) return null;
  const keep = { q: cat.q, category: cat.category, sort: cat.sort === "newest" ? "" : cat.sort };
  const hidden = baseHref.includes("?") ? Object.fromEntries(new URL(baseHref, "http://x").searchParams.entries()) : {};
  return (
    <section className="block"><div className="wrap">
      <h2>{title}</h2>
      {orderNote && <p style={{ marginTop: -8, opacity: .85 }}>{orderNote}</p>}
      {shop.categories.length > 0 && (
        <nav className="cats" aria-label="Product categories">
          <a href={withQuery(baseHref, { q: cat.q, sort: keep.sort })} aria-current={cat.category === "" ? "true" : undefined}>All</a>
          {shop.categories.map((c) => <a key={c.id} href={withQuery(baseHref, { ...keep, category: c.slug })} aria-current={cat.category === c.slug ? "true" : undefined}>{c.name} ({c.count})</a>)}
        </nav>
      )}
      {shop.search && (
        <form className="shopbar" method="get" action={baseHref.split("?")[0]}>
          {Object.entries(hidden).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />)}
          {cat.category && <input type="hidden" name="category" value={cat.category} />}
          <label>Search<input type="search" name="q" defaultValue={cat.q} maxLength={60} placeholder="Search products" disabled={!interactive} /></label>
          <label>Sort by<select name="sort" defaultValue={cat.sort} disabled={!interactive}>{SORTS.map((s) => <option key={s} value={s}>{SORT_LABELS[s]}</option>)}</select></label>
          <button className="btn pro" type="submit" disabled={!interactive} style={{ border: 0, cursor: "pointer", margin: 0 }}>Search</button>
        </form>
      )}
      {cat.items.length === 0 ? <p>No products found. {(cat.q || cat.category) && <a href={baseHref}>Show all products</a>}</p> : (
        <div className="pgrid">{cat.items.map((p) => <ProductCard key={p.id} p={p} href={productHref(p.slug)} />)}</div>
      )}
      {cat.pages > 1 && (
        <nav className="pager" aria-label="Pages">
          {cat.page > 1 && <a href={withQuery(baseHref, { ...keep, page: cat.page - 1 })}>&larr; Previous</a>}
          <span>Page {cat.page} of {cat.pages}</span>
          {cat.page < cat.pages && <a href={withQuery(baseHref, { ...keep, page: cat.page + 1 })}>Next &rarr;</a>}
        </nav>
      )}
    </div></section>
  );
}

/** A single product: photos, price, options and the order controls. */
export function ProductPage({ product, cart, whatsapp, orderNote, shopHref, interactive = true }: { product: PublicProduct; cart: boolean; whatsapp?: string; orderNote?: string; shopHref: string; interactive?: boolean }) {
  const c = product.card;
  const onSale = c.comparePriceBdt != null && c.comparePriceBdt > c.priceBdt;
  return (
    <section className="block"><div className="wrap">
      <p><a href={shopHref}>&larr; All products</a></p>
      <div className="pdetail">
        <ProductGallery ids={product.images} alt={c.name} />
        <div>
          {c.categoryName && <p className="pcat">{c.categoryName}</p>}
          <h1>{c.name}</h1>
          <p className="pprice">{c.hasOptions && "From "}{taka(c.priceBdt)}{onSale && <span className="pold">{taka(c.comparePriceBdt!)}</span>}</p>
          {product.description && <p className="pdesc">{product.description}</p>}
          {product.sku && <p style={{ opacity: .7, fontSize: ".85rem" }}>Code: {product.sku}</p>}
          <ProductBuy productId={c.id} productName={c.name} basePrice={c.priceBdt} variants={product.variants} soldOut={c.soldOut} cart={cart} whatsapp={whatsapp} orderNote={orderNote} interactive={interactive} />
        </div>
      </div>
    </div></section>
  );
}

export function CartPage({ checkout, discounts, orderNote }: { checkout: boolean; discounts: boolean; orderNote?: string }) {
  return <section className="block"><div className="wrap" style={{ maxWidth: checkout ? undefined : 760 }}><h1 style={{ fontSize: "1.8rem", margin: "0 0 14px" }}>{checkout ? "Checkout" : "Your cart"}</h1><CartClient checkout={checkout} discounts={discounts} orderNote={orderNote} /></div></section>;
}

/** The customer's own page after ordering. */
export function OrderPage({ order, items, whatsapp, businessName }: {
  order: { number: number; status: string; channel: string; customer_name: string; phone: string; address: string; subtotal_bdt: number; delivery_fee_bdt: number; discount_bdt: number; total_bdt: number; payment_status: string; courier: string; tracking_code: string; discount_code: string | null };
  items: { name: string; variant_label: string; qty: number; line_total_bdt: number }[]; whatsapp?: string; businessName: string;
}) {
  const lines = items.map((i) => `${i.qty} x ${i.name}${i.variant_label ? ` (${i.variant_label})` : ""}`).join(", ");
  const msg = encodeURIComponent(`Hello ${businessName}, my order number is #${order.number}: ${lines}. Total ${taka(order.total_bdt)}.`);
  return (
    <section className="block"><div className="wrap" style={{ maxWidth: 720 }}>
      <ClearCart />
      <div className="okbox" role="status"><strong>Thank you, {order.customer_name}! We received your order.</strong><br />Order number <strong>#{order.number}</strong> &middot; Status: <strong>{ORDER_STATUS_TEXT[order.status] ?? order.status}</strong></div>
      <p>We will contact you on <strong>{order.phone}</strong> to confirm. Please keep this page: it is your order link.</p>
      <div className="card">
        {items.map((i, k) => <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "4px 0" }}><span>{i.qty} x {i.name}{i.variant_label ? ` (${i.variant_label})` : ""}</span><span>{taka(i.line_total_bdt)}</span></div>)}
        <div className="totals" style={{ marginRight: 0 }}>
          <div><span>Subtotal</span><span>{taka(order.subtotal_bdt)}</span></div>
          {order.channel === "checkout" && <div><span>Delivery</span><span>{order.delivery_fee_bdt ? taka(order.delivery_fee_bdt) : "Free"}</span></div>}
          {order.discount_bdt > 0 && <div><span>Discount{order.discount_code ? ` (${order.discount_code})` : ""}</span><span>-{taka(order.discount_bdt)}</span></div>}
          <div className="grand"><span>Total</span><span>{taka(order.total_bdt)}</span></div>
        </div>
        <p style={{ margin: 0 }}>Delivery to: {order.address}</p>
        {order.courier && <p style={{ marginBottom: 0 }}>Courier: <strong>{order.courier}</strong>{order.tracking_code && <> &middot; Tracking: <strong>{order.tracking_code}</strong></>}</p>}
      </div>
      {whatsapp && <p><a className="btn pro wa" href={`https://wa.me/${whatsapp}?text=${msg}`} target="_blank" rel="noopener noreferrer">Send this order on WhatsApp</a> <a href="/products">Continue shopping</a></p>}
    </div></section>
  );
}

import { DAYS, DAY_LABELS, SOCIAL_KEYS, SOCIAL_LABELS, type SiteConfig } from "../../config/siteConfig";

/** Images are served from this site's own /media route. The id was validated as a UUID before it was ever stored. */
export const mediaUrl = (id: string) => `/media/${id}`;

export function Logo({ config, businessName, height = 40 }: { config: SiteConfig; businessName: string; height?: number }) {
  const id = config.images.logo;
  return id
    ? <img src={mediaUrl(id)} alt={businessName} style={{ height, maxWidth: 220, objectFit: "contain" }} />
    : <span className="brand">{businessName}</span>;
}

export function HoursTable({ config }: { config: SiteConfig }) {
  const rows = DAYS.filter((d) => config.hours[d]);
  if (rows.length === 0) return null;
  return (
    <table style={{ maxWidth: 360 }}><tbody>
      {rows.map((d) => <tr key={d}><th>{DAY_LABELS[d]}</th><td>{config.hours[d]}</td></tr>)}
    </tbody></table>
  );
}

export function SocialLinks({ config }: { config: SiteConfig }) {
  const links = SOCIAL_KEYS.filter((k) => config.social[k]);
  if (links.length === 0) return null;
  return (
    <p style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
      {links.map((k) => <a key={k} href={config.social[k]} target="_blank" rel="noopener noreferrer">{SOCIAL_LABELS[k]}</a>)}
    </p>
  );
}

/** Floating WhatsApp button shown on every page when a WhatsApp number is set. */
export function WhatsAppFloat({ number, side = "right" }: { number?: string; side?: "right" | "left" | "hidden" }) {
  if (!number || side === "hidden") return null;
  return (
    <a href={`https://wa.me/${number}`} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp"
       style={{ position: "fixed", [side]: 16, bottom: 16, background: "#1faa59", color: "#fff", padding: "12px 18px", borderRadius: 999, textDecoration: "none", fontWeight: 700, boxShadow: "0 2px 8px rgba(0,0,0,.25)", zIndex: 50 }}>
      WhatsApp
    </a>
  );
}

/** Basic search-engine data about the business. Built from validated values; "<" is escaped so it cannot close the script tag. */
export function BusinessJsonLd({ config, businessName, url }: { config: SiteConfig; businessName: string; url: string }) {
  const c = config.content;
  const data: Record<string, unknown> = { "@context": "https://schema.org", "@type": "LocalBusiness", name: businessName, url };
  if (c.phone) data.telephone = c.phone;
  if (c.email) data.email = c.email;
  if (c.address) data.address = c.address;
  if (config.images.logo) data.image = `${url.replace(/\/$/, "")}${mediaUrl(config.images.logo)}`;
  const sameAs = SOCIAL_KEYS.filter((k) => config.social[k]).map((k) => config.social[k]);
  if (sameAs.length) data.sameAs = sameAs;
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }} />;
}

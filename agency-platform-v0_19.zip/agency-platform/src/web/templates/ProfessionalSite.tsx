import type { ReactNode } from "react";
import type { SiteConfig } from "../../config/siteConfig";
import { onColor } from "../../config/color";
import type { ShopView } from "../../shop/types";
import { PAGE_LABELS, pagePath, visiblePages, withShop, type PageKey } from "./pages";
import { CatalogueView, ProductCard } from "./ShopBlocks";
import { CartLink } from "../shop/CartLink";
import { BusinessJsonLd, HoursTable, Logo, SocialLinks, WhatsAppFloat, mediaUrl } from "./blocks";
import { submitInquiryAction } from "../../../app/inquiry-actions";

interface Props {
  businessName: string;
  /** Already limited to the client's package (see applyEntitlements). */
  config: SiteConfig;
  page: PageKey;
  /** Where menu links go (the live site, or the dashboard preview). */
  linkFor?: (p: PageKey) => string;
  /** Show a working inquiry form (live site) or a disabled sample (preview). */
  interactive?: boolean;
  inquiry?: { sent?: boolean; error?: string };
  /** Descriptions of gallery photos (stored with each image). */
  galleryAlts?: Record<string, string>;
  siteUrl?: string;
  /** Present when the client sells products (see src/shop). */
  shop?: ShopView | null;
  /** The pages in the menu. Defaults to the Professional set; the Starter template passes its own. */
  pageSet?: PageKey[];
  /** Replaces the page content (product page, cart, order page) while keeping the header, footer and design. */
  body?: ReactNode;
  productHref?: (slug: string) => string;
  /** Shown above the catalogue (delivery or payment note from the shop settings). */
  shopNote?: string;
}

const FONT = { sans: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif', serif: 'Georgia, "Times New Roman", serif', rounded: '"Trebuchet MS", "Segoe UI", system-ui, sans-serif' };
const WRAP = { narrow: "760px", standard: "960px", wide: "1160px" };
const SPACE = { compact: [28, 48], comfortable: [48, 72], airy: [72, 104] } as const;
const HERO_H = { short: 0.6, medium: 1, tall: 1.7 };
const PHOTO = { small: "150px", medium: "240px", large: "340px" };
const CORNER = { square: "0px", soft: "10px", round: "22px" };
const LOGO_H = { small: 28, medium: 40, large: 60 };
const OVERLAY = { none: 0, soft: 0.45, strong: 0.7 };
const TEXT = { small: "15px", normal: "16px", large: "18px" };
const HSIZE = { small: 0.85, medium: 1, large: 1.2, xlarge: 1.45 };
const BTN = { small: ["6px", "12px", ".85rem"], medium: ["10px", "18px", "1rem"], large: ["14px", "26px", "1.1rem"] } as const;
const PCARD = { small: "150px", medium: "210px", large: "290px" };
const SHAPE = { square: ["0px", "0px"], rounded: ["10px", "10px"], circle: ["50%", "10px"] } as const;
const ANGLE = { right: "to right", "down-right": "to bottom right", down: "to bottom", "down-left": "to bottom left" };
const RADIUS = { rounded: "8px", square: "0px", pill: "999px" };
const INQUIRY_ERRORS: Record<string, string> = {
  invalid_name: "Please enter your name.", invalid_contact: "Please enter a valid phone number or email.", invalid_message: "Please write a short message (5 to 1000 characters).",
  rate_limited: "You have sent several messages recently. Please try again later.", unavailable: "Messages are temporarily unavailable. Please call us instead.",
};

/**
 * The website renderer shared by every template. React escapes all text, so client-entered content cannot inject HTML.
 * All design choices (colours, sizes, angles, placement) come from the saved settings and are mapped to fixed CSS here.
 */
export function ProfessionalSite({ businessName, config, page, linkFor = (p) => pagePath(p), interactive = true, inquiry, galleryAlts = {}, siteUrl, shop = null, pageSet, body: bodyOverride, productHref = (slug) => `/products/${slug}`, shopNote }: Props) {
  const c = config.content;
  const L = config.layout;
  const th = config.theme;
  const vars = {
    ["--primary" as string]: th.primary, ["--accent" as string]: th.accent, ["--bg" as string]: th.background, ["--text" as string]: th.text, ["--soft" as string]: th.surface,
    ["--on-primary" as string]: onColor(th.primary), ["--on-accent" as string]: onColor(th.accent),
    ["--radius" as string]: RADIUS[th.buttonStyle], ["--wrap-max" as string]: WRAP[L.pageWidth], ["--block-pad" as string]: SPACE[L.spacing][0] + "px",
    ["--hero-pad" as string]: Math.round(SPACE[L.spacing][1] * HERO_H[L.heroHeight]) + "px", ["--card-radius" as string]: CORNER[L.cardCorners],
    ["--hs" as string]: HSIZE[L.headingSize], ["--btn-py" as string]: BTN[L.buttonSize][0], ["--btn-px" as string]: BTN[L.buttonSize][1], ["--btn-fs" as string]: BTN[L.buttonSize][2],
    ["--pmin" as string]: PCARD[L.productCards], ["--img-r" as string]: SHAPE[L.imageShape][0], ["--img-r2" as string]: SHAPE[L.imageShape][1],
    fontFamily: FONT[th.font], fontSize: TEXT[L.textSize],
  } as React.CSSProperties;
  const shopOn = Boolean(shop);
  const pages = withShop(pageSet ?? visiblePages(config), shopOn);
  const has = (k: string) => (config.sections as string[]).includes(k);
  const tel = c.phone?.replace(/[^0-9+]/g, "");
  const light = L.heroStyle === "light";
  const promo = config.promo;
  const title = (k: keyof typeof c.sectionTitles, d: string) => c.sectionTitles[k] || d;
  /** Turns a saved button link into an address. Pages of this site go through linkFor so the preview keeps working. */
  const resolveLink = (url: string): { href: string; external: boolean } => {
    if (url.startsWith("https://")) return { href: url, external: true };
    if (url.startsWith("tel:")) return { href: url, external: false };
    if (url.startsWith("/#")) return { href: url.slice(1), external: false };
    const [path, hash] = url.split("#");
    return { href: linkFor(path === "/" ? "home" : (path!.slice(1) as PageKey)) + (hash ? "#" + hash : ""), external: false };
  };
  const cta = c.cta.label && c.cta.url ? { label: c.cta.label, ...resolveLink(c.cta.url) } : null;
  const promoLive = Boolean(promo.text) && (!promo.until || new Date().toISOString().slice(0, 10) <= promo.until);
  const ga = config.analytics.ga4;

  const heroGradient = `linear-gradient(${ANGLE[L.heroAngle]}, ${th.primary}, ${th.accent})`;
  const heroStyle: React.CSSProperties | undefined = config.images.hero
    ? { backgroundImage: `${OVERLAY[L.heroOverlay] > 0 ? `linear-gradient(rgba(0,0,0,${OVERLAY[L.heroOverlay]}),rgba(0,0,0,${OVERLAY[L.heroOverlay]})), ` : ""}url(${mediaUrl(config.images.hero)})`, backgroundSize: "cover", backgroundPosition: "center", color: "#fff" }
    : light ? { background: "var(--soft)", color: "var(--text)" }
    : L.heroFill === "gradient" ? { background: heroGradient, color: onColor(th.primary) } : undefined;
  const hero = (
    <div className={L.heroAlign === "center" ? "hero center" : "hero"} style={heroStyle}>
      <div className="wrap">
        <h1>{c.heroTitle ?? `Welcome to ${businessName}`}</h1>
        <p>{c.heroSubtitle ?? "Quality service you can trust."}</p>
        {(cta || has("inquiry") || tel) && (
          <p style={{ marginTop: 20 }}>
            {cta && <a className="btn pro" style={{ background: "var(--accent)", color: "var(--on-accent)" }} href={cta.href} {...(cta.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>{cta.label}</a>}
            {!cta && has("inquiry") && <a className="btn pro" style={{ background: "var(--accent)", color: "var(--on-accent)" }} href={page === "contact" ? "#inquiry" : linkFor("contact") + "#inquiry"}>Request a quote</a>}
            {tel && <a className="btn pro" href={`tel:${tel}`}>Call {c.phone}</a>}
          </p>
        )}
      </div>
    </div>
  );
  const about = (
    <section className="block"><div className="wrap"><h2>{title("about", "About us")}</h2>
      <div className={`about ${L.aboutLayout}`}>
        {config.images.about && <img className="img-shaped" src={mediaUrl(config.images.about)} alt={businessName} loading="lazy" style={{ borderRadius: "var(--img-r, 10px)", marginBottom: 16 }} />}
        <p style={{ whiteSpace: "pre-wrap", margin: 0 }}>{c.about ?? `${businessName} is a trusted local business. Contact us to learn more.`}</p>
      </div></div></section>
  );
  const highlights = (
    <section className="block"><div className="wrap"><h2>{title("highlights", "Why choose us")}</h2>
      <div className="grid">{c.highlights.map((h, i) => (
        <div className="card" key={i}><h3 style={{ marginTop: 0 }}>{h.title}</h3>{h.text && <p style={{ margin: 0 }}>{h.text}</p>}</div>
      ))}</div></div></section>
  );
  const faq = (
    <section className="block alt"><div className="wrap" style={{ maxWidth: 760 }}><h2>{title("faq", "Frequently asked questions")}</h2>
      <div className="faq">{c.faqs.map((f, i) => (
        <details key={i}><summary>{f.question}</summary><p style={{ whiteSpace: "pre-wrap" }}>{f.answer}</p></details>
      ))}</div></div></section>
  );
  const services = (
    <section className="block alt"><div className="wrap"><h2>{title("services", "Our services")}</h2>
      {L.servicesView === "list" ? (
        <div className="list-rows">{c.services.map((s, i) => (
          <div className="card" key={i}><div style={{ flex: "1 1 260px" }}><h3 style={{ margin: 0 }}>{s.name}</h3>{s.description && <p style={{ margin: "4px 0 0" }}>{s.description}</p>}</div>{s.price && <strong>{s.price}</strong>}</div>
        ))}</div>
      ) : (
        <div className="grid">{c.services.map((s, i) => (
          <div className="card" key={i}><h3 style={{ marginTop: 0 }}>{s.name}</h3>{s.description && <p>{s.description}</p>}{s.price && <p><strong>{s.price}</strong></p>}</div>
        ))}</div>
      )}</div></section>
  );
  const productsBlock = shop && shop.home.length > 0 ? (
    <section className="block"><div className="wrap"><h2>{title("products", "Our products")}</h2>
      <div className="pgrid">{shop.home.map((p) => <ProductCard key={p.id} p={p} href={productHref(p.slug)} />)}</div>
      <p style={{ marginTop: 18 }}><a className="btn pro" href={linkFor("products")}>See all products</a></p>
    </div></section>
  ) : null;
  const gallery = (
    <section className="block"><div className="wrap"><h2>{title("gallery", "Gallery")}</h2>
      <div className="grid" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(${PHOTO[L.galleryPhotos]}, 1fr))` }}>{config.images.gallery.map((id) => (
        <img key={id} src={mediaUrl(id)} alt={galleryAlts[id] ?? ""} loading="lazy" style={{ width: "100%", borderRadius: "var(--img-r2, 10px)", objectFit: "cover", aspectRatio: "4 / 3" }} />
      ))}</div></div></section>
  );
  const testimonials = (
    <section className="block"><div className="wrap"><h2>{title("testimonials", "What customers say")}</h2>
      <div className={L.reviewsView === "stacked" ? "stack" : "grid"}>{c.testimonials.map((t, i) => (
        <blockquote className="card" key={i} style={{ margin: 0 }}><p style={{ marginTop: 0 }}>&ldquo;{t.quote}&rdquo;</p><footer><strong>{t.name}</strong></footer></blockquote>
      ))}</div></div></section>
  );
  const form = (
    <section className="block" id="inquiry"><div className="wrap" style={{ maxWidth: 640 }}>
      <h2>{title("inquiry", "Request a quote or ask a question")}</h2>
      {inquiry?.sent && <p className="card">Thank you! Your message was sent. We will contact you soon.</p>}
      {inquiry?.error && <p className="warn">{INQUIRY_ERRORS[inquiry.error] ?? "Your message could not be sent."}</p>}
      <form action={interactive ? submitInquiryAction : undefined} className="card">
        <input type="hidden" name="back" value={page === "contact" ? "/contact" : "/"} />
        <div style={{ position: "absolute", left: "-9999px" }} aria-hidden="true"><label>Website <input name="website" tabIndex={-1} autoComplete="off" /></label></div>
        <p><label>Your name<br /><input name="name" required minLength={2} maxLength={80} disabled={!interactive} style={{ width: "100%", padding: 8 }} /></label></p>
        <p><label>Phone<br /><input name="phone" maxLength={20} disabled={!interactive} style={{ width: "100%", padding: 8 }} /></label></p>
        <p><label>Email (phone or email is required)<br /><input name="email" type="email" maxLength={254} disabled={!interactive} style={{ width: "100%", padding: 8 }} /></label></p>
        <p><label>Message<br /><textarea name="message" required minLength={5} maxLength={1000} rows={5} disabled={!interactive} style={{ width: "100%", padding: 8 }} /></label></p>
        <button className="btn pro" type="submit" disabled={!interactive} style={{ border: 0, cursor: interactive ? "pointer" : "default" }}>Send message</button>
        {!interactive && <p><small>(Preview: the form is switched off here.)</small></p>}
      </form></div></section>
  );
  const contactDetails = (
    <div>
      {c.address && <p>{c.address}</p>}
      {c.phone && <a className="btn pro" href={`tel:${tel}`}>Call us</a>}
      {c.whatsapp && <a className="btn pro wa" href={`https://wa.me/${c.whatsapp}`}>WhatsApp</a>}
      {c.email && <p><a href={`mailto:${c.email}`}>{c.email}</a></p>}
      {!c.phone && !c.whatsapp && !c.address && !c.email && <p>Contact details coming soon.</p>}
      <SocialLinks config={config} />
    </div>
  );
  const hoursBlock = Object.keys(config.hours).length > 0 ? <div><h3 style={{ marginTop: 0 }}>Opening hours</h3><HoursTable config={config} /></div> : null;
  const contact = (
    <section className="block alt"><div className="wrap"><h2>{title("contact", "Contact")}</h2>
      {L.contactLayout === "side-by-side"
        ? <div className="contact-cols">{contactDetails}{hoursBlock}</div>
        : <>{contactDetails}{hoursBlock && <div style={{ marginTop: 12 }}>{hoursBlock}</div>}</>}
    </div></section>
  );
  const blocks: Record<string, React.ReactNode> = { hero, products: productsBlock, highlights: c.highlights.length ? highlights : null, faq: c.faqs.length ? faq : null, about, gallery: config.images.gallery.length ? gallery : null, services: c.services.length ? services : null, testimonials: c.testimonials.length ? testimonials : null, inquiry: form, contact };

  const body = (() => {
    if (bodyOverride !== undefined) return bodyOverride;
    if (page === "products") return shop ? <CatalogueView shop={shop} baseHref={linkFor("products")} productHref={productHref} interactive={interactive} title={title("products", "Our products")} orderNote={shopNote} /> : null;
    if (page === "home") return config.sections.map((s) => {
      const st = config.sectionStyles[s as keyof typeof config.sectionStyles];
      if (!st || !blocks[s]) return <div key={s}>{blocks[s]}</div>;
      // A wrapper changes the colour variables for just this section, so everything inside follows them.
      const style = {
        ...(st.background ? { ["--bg" as string]: st.background, ["--soft" as string]: st.background, background: st.background } : {}),
        ...(st.text ? { ["--text" as string]: st.text, color: st.text } : {}),
        ...(st.spacing ? { ["--block-pad" as string]: SPACE[st.spacing][0] + "px" } : {}),
      } as React.CSSProperties;
      return <div key={s} className={st.align === "center" ? "sec-center" : undefined} style={style} data-section={s}>{blocks[s]}</div>;
    });
    if (page === "about") return <>{about}</>;
    if (page === "gallery") return <>{gallery}</>;
    if (page === "services") return <>{services}</>;
    if (page === "testimonials") return <>{testimonials}</>;
    return <>{has("inquiry") && form}{has("contact") && contact}</>;
  })();

  const promoLink = promo.linkUrl ? resolveLink(promo.linkUrl) : null;

  return (
    <div className="pro" style={vars} data-header={L.headerStyle} data-sticky={L.headerBehavior} data-cards={L.cardStyle} data-bg={L.sectionBackground} data-headings={L.headingAlign} data-edge={L.heroEdge} data-shape={L.imageShape}>
      {promoLive && (
        <div className={`promo ${promo.style}`} role="note">
          <div className="wrap">
            <span>{promo.text}</span>
            {promoLink && <a href={promoLink.href} {...(promoLink.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}>{promo.linkLabel || "Learn more"}</a>}
          </div>
        </div>
      )}
      {siteUrl && page === "home" && <BusinessJsonLd config={config} businessName={businessName} url={siteUrl} />}
      {ga && (
        <>
          <script async src={`https://www.googletagmanager.com/gtag/js?id=${ga}`} />
          <script dangerouslySetInnerHTML={{ __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${ga}');` }} />
        </>
      )}
      <header className="site"><div className="wrap">
        <a href={linkFor("home")} style={{ textDecoration: "none" }}><Logo config={config} businessName={businessName} height={LOGO_H[L.logoSize]} /></a>
        <nav style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>{pages.map((p) => <a key={p} href={linkFor(p)} style={p === page ? { fontWeight: 700 } : undefined}>{PAGE_LABELS[p]}</a>)}{shop?.cart && interactive && <CartLink href="/cart" />}</nav>
      </div></header>
      {body}
      {L.footerStyle === "detailed" ? (
        <footer className="site detailed"><div className="wrap">
          <div className="foot-cols">
            <div><strong>{businessName}</strong>{c.address && <p style={{ margin: "6px 0 0" }}>{c.address}</p>}</div>
            <div><strong>Contact</strong>{c.phone && <p style={{ margin: "6px 0 0" }}><a href={`tel:${tel}`}>{c.phone}</a></p>}{c.email && <p style={{ margin: "6px 0 0" }}><a href={`mailto:${c.email}`}>{c.email}</a></p>}</div>
            <div><strong>Pages</strong>{pages.map((p) => <p key={p} style={{ margin: "6px 0 0" }}><a href={linkFor(p)}>{PAGE_LABELS[p]}</a></p>)}</div>
          </div>
          <SocialLinks config={config} />
          <p style={{ margin: 0 }}>&copy; {businessName}</p>
        </div></footer>
      ) : (
        <footer className="site"><div className="wrap">{page !== "contact" && <SocialLinks config={config} />}&copy; {businessName}</div></footer>
      )}
      <WhatsAppFloat number={c.whatsapp} side={L.whatsappButton} />
    </div>
  );
}

import type { SiteConfig } from "../../config/siteConfig";

export type PageKey = "home" | "about" | "services" | "products" | "gallery" | "testimonials" | "contact";
export const PAGE_KEYS: readonly PageKey[] = ["home", "about", "services", "products", "gallery", "testimonials", "contact"];
export const PAGE_LABELS: Record<PageKey, string> = { home: "Home", about: "About", services: "Services", products: "Shop", gallery: "Gallery", testimonials: "Reviews", contact: "Contact" };

const has = (c: SiteConfig, s: string) => (c.sections as string[]).includes(s);

/** Template 1 (Starter): Home, About, Services, Contact. */
export function starterPages(c: SiteConfig): PageKey[] {
  const pages: PageKey[] = ["home"];
  if (has(c, "about")) pages.push("about");
  if (has(c, "services")) pages.push("services");
  if (has(c, "contact")) pages.push("contact");
  return pages;
}
/** Template 2 (Professional): adds Gallery and Reviews pages when they have content. */
export function visiblePages(c: SiteConfig): PageKey[] {
  const pages: PageKey[] = ["home"];
  if (has(c, "about") && c.images.about) pages.push("about");
  if (has(c, "services") && c.content.services.length) pages.push("services");
  if (has(c, "gallery") && c.images.gallery.length) pages.push("gallery");
  if (has(c, "testimonials") && c.content.testimonials.length) pages.push("testimonials");
  if (has(c, "contact") || has(c, "inquiry")) pages.push("contact");
  return pages;
}
export const pagePath = (p: PageKey) => (p === "home" ? "/" : `/${p}`);
export const isPageKey = (v: string): v is PageKey => (PAGE_KEYS as readonly string[]).includes(v);

/** The Shop page is added to the menu (before Contact) when the client sells products. It is not part of the saved settings. */
export function withShop(pages: PageKey[], shopOn: boolean): PageKey[] {
  if (!shopOn || pages.includes("products")) return pages;
  const i = pages.indexOf("contact");
  return i < 0 ? [...pages, "products"] : [...pages.slice(0, i), "products", ...pages.slice(i)];
}

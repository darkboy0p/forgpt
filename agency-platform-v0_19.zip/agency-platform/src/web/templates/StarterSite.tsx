import type { ComponentProps } from "react";
import { ProfessionalSite } from "./ProfessionalSite";
import { starterPages } from "./pages";

/**
 * Template 1: Starter Business (Home, About, Services, Contact). It uses the same design engine as every template,
 * so owners on any package can change colours, sizes, placement and angles. What differs is the set of pages.
 */
export function StarterSite(props: Omit<ComponentProps<typeof ProfessionalSite>, "pageSet">) {
  return <ProfessionalSite {...props} pageSet={starterPages(props.config)} />;
}

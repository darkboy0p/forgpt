import { randomBytes } from "node:crypto";
import { promises as dns } from "node:dns";
import type { Pool } from "pg";
import type { Env } from "../config/env";
import { normalizeHostname } from "../tenancy/hostname";
import { platformHosts } from "../web/adminAccess";
import { isMissingSchema } from "../shop/safe";

export const MAX_DOMAINS_PER_TENANT = 3;
export const VERIFY_LABEL = "_agency-verify";
const MAX_ADDS_PER_DAY = 10;
const MIN_SECONDS_BETWEEN_CHECKS = 10;
const RESERVED_SUFFIXES = [".local", ".internal", ".test", ".example", ".invalid", ".onion", ".lan", ".home", ".corp", ".arpa"];
const DEV_SUFFIXES = [".localhost", ".localtest.me"];

export type DomainError = "invalid_host" | "reserved_host" | "host_taken" | "too_many_domains" | "rate_limited";
export type CheckError = "not_found" | "too_soon" | "dns_error";
export interface DomainRow { hostname: string; status: string; is_primary: boolean; verify_token: string; verified_at: Date | null; last_checked_at: Date | null; check_note: string | null }

type Env3 = Pick<Env, "APP_ENV" | "PLATFORM_HOSTS">;
const audit = (control: Pool, actor: string, action: string, tenantId: string, detail: object) =>
  control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,$2,$3,$4)", [actor, action, tenantId, JSON.stringify(detail)]);

/** The records the owner must create at their domain registrar. The text record proves they control the domain. */
export function dnsInstructions(env: Pick<Env, "DOMAIN_CNAME_TARGET" | "DOMAIN_A_RECORD">, hostname: string, token: string) {
  return { txtName: `${VERIFY_LABEL}.${hostname}`, txtValue: `agency-verify=${token}`, cnameTarget: env.DOMAIN_CNAME_TARGET || undefined, aRecord: env.DOMAIN_A_RECORD || undefined };
}

export async function listDomains(control: Pool, tenantId: string): Promise<DomainRow[]> {
  try {
    return (await control.query(
      `SELECT hostname, status, is_primary, verify_token, verified_at, last_checked_at, check_note
         FROM domains WHERE tenant_id = $1 AND status <> 'removed' ORDER BY is_primary DESC, created_at`, [tenantId])).rows;
  } catch (e) {
    if (!isMissingSchema(e)) throw e; // the main database has not been upgraded yet: show the domains without the newer columns
    return (await control.query(
      `SELECT hostname, status, is_primary, verify_token, verified_at, NULL::timestamptz AS last_checked_at, NULL::text AS check_note
         FROM domains WHERE tenant_id = $1 AND status <> 'removed' ORDER BY is_primary DESC, created_at`, [tenantId])).rows;
  }
}

/** An owner adds a domain. It stays "pending" and serves nothing until the DNS check passes. */
export async function addDomain(control: Pool, env: Env3, tenantId: string, raw: unknown, actor: string): Promise<{ ok: true; hostname: string } | { ok: false; error: DomainError }> {
  const host = normalizeHostname(typeof raw === "string" ? raw.replace(/^https?:\/\//i, "").replace(/\/.*$/, "") : "");
  if (!host) return { ok: false, error: "invalid_host" };
  const isDev = env.APP_ENV === "development";
  if (platformHosts(env).has(host) || RESERVED_SUFFIXES.some((s) => host.endsWith(s)) || (!isDev && (host === "localhost" || DEV_SUFFIXES.some((s) => host.endsWith(s))))) return { ok: false, error: "reserved_host" };
  const count = (await control.query("SELECT count(*)::int AS n FROM domains WHERE tenant_id = $1 AND status <> 'removed'", [tenantId])).rows[0].n as number;
  if (count >= MAX_DOMAINS_PER_TENANT) return { ok: false, error: "too_many_domains" };
  const recent = (await control.query("SELECT count(*)::int AS n FROM audit_log WHERE tenant_id = $1 AND action = 'domain.added' AND created_at > now() - interval '1 day'", [tenantId])).rows[0].n as number;
  if (recent >= MAX_ADDS_PER_DAY) return { ok: false, error: "rate_limited" };
  const existing = (await control.query("SELECT id, status FROM domains WHERE hostname = $1", [host])).rows[0];
  if (existing && existing.status !== "removed") return { ok: false, error: "host_taken" };
  try {
    if (existing) await control.query("DELETE FROM domains WHERE id = $1 AND status = 'removed'", [existing.id]); // a released name can be claimed again
    await control.query("INSERT INTO domains (tenant_id, hostname, status, is_primary, verify_token) VALUES ($1,$2,'pending',false,$3)", [tenantId, host, randomBytes(24).toString("hex")]);
  } catch (e) {
    if ((e as { code?: string }).code === "23505") return { ok: false, error: "host_taken" };
    throw e;
  }
  await audit(control, actor, "domain.added", tenantId, { hostname: host });
  return { ok: true, hostname: host };
}

export type Resolver = (name: string) => Promise<string[][]>;
const defaultResolver: Resolver = (name) => dns.resolveTxt(name);
const withTimeout = <T,>(p: Promise<T>, ms: number) => Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(Object.assign(new Error("timeout"), { code: "ETIMEOUT" })), ms))]);

/** Looks for the owner's proof text record. Only a match makes the domain live. Never trusts anything else. */
export async function checkDomain(control: Pool, tenantId: string, hostname: string, actor: string, resolver: Resolver = defaultResolver): Promise<{ ok: true; already?: boolean } | { ok: false; error: CheckError | "unknown_domain" }> {
  const row = (await control.query("SELECT id, status, verify_token, last_checked_at FROM domains WHERE tenant_id = $1 AND hostname = $2 AND status <> 'removed'", [tenantId, hostname])).rows[0];
  if (!row) return { ok: false, error: "unknown_domain" };
  if (row.status === "verified") return { ok: true, already: true };
  if (row.last_checked_at && Date.now() - new Date(row.last_checked_at).getTime() < MIN_SECONDS_BETWEEN_CHECKS * 1000) return { ok: false, error: "too_soon" };
  let records: string[][] = [], note: CheckError | null = null;
  try { records = await withTimeout(resolver(`${VERIFY_LABEL}.${hostname}`), 5000); }
  catch (e) { note = ["ENOTFOUND", "ENODATA"].includes((e as { code?: string }).code ?? "") ? "not_found" : "dns_error"; }
  const expected = `agency-verify=${row.verify_token}`;
  if (!records.some((parts) => parts.join("") === expected)) {
    note = note ?? "not_found";
    await control.query("UPDATE domains SET last_checked_at = now(), check_note = $2 WHERE id = $1", [row.id, note]);
    return { ok: false, error: note };
  }
  await control.query(
    `UPDATE domains SET status = 'verified', verified_at = now(), last_checked_at = now(), check_note = NULL,
            is_primary = (is_primary OR NOT EXISTS (SELECT 1 FROM domains p WHERE p.tenant_id = $2 AND p.is_primary AND p.id <> $1))
      WHERE id = $1`, [row.id, tenantId]);
  await audit(control, actor, "domain.verified.dns", tenantId, { hostname });
  return { ok: true };
}

export async function setPrimaryDomain(control: Pool, tenantId: string, hostname: string, actor: string): Promise<{ ok: true } | { ok: false; error: "unknown_domain" | "not_verified" }> {
  const client = await control.connect();
  try {
    await client.query("BEGIN");
    const row = (await client.query("SELECT id, status FROM domains WHERE tenant_id = $1 AND hostname = $2 AND status <> 'removed' FOR UPDATE", [tenantId, hostname])).rows[0];
    if (!row) { await client.query("ROLLBACK"); return { ok: false, error: "unknown_domain" }; }
    if (row.status !== "verified") { await client.query("ROLLBACK"); return { ok: false, error: "not_verified" }; }
    await client.query("UPDATE domains SET is_primary = false WHERE tenant_id = $1 AND is_primary", [tenantId]);
    await client.query("UPDATE domains SET is_primary = true WHERE id = $1", [row.id]);
    await client.query("COMMIT");
  } catch (e) { await client.query("ROLLBACK"); throw e; } finally { client.release(); }
  await audit(control, actor, "domain.primary.changed", tenantId, { hostname });
  return { ok: true };
}

/** Owners may remove any domain except the main one (pick another main domain first). The row is kept as "removed". */
export async function removeDomain(control: Pool, tenantId: string, hostname: string, actor: string): Promise<{ ok: true } | { ok: false; error: "unknown_domain" | "is_primary" }> {
  const row = (await control.query("SELECT id, is_primary FROM domains WHERE tenant_id = $1 AND hostname = $2 AND status <> 'removed'", [tenantId, hostname])).rows[0];
  if (!row) return { ok: false, error: "unknown_domain" };
  if (row.is_primary) return { ok: false, error: "is_primary" };
  await control.query("UPDATE domains SET status = 'removed', is_primary = false WHERE id = $1", [row.id]);
  await audit(control, actor, "domain.removed", tenantId, { hostname });
  return { ok: true };
}

// ---------- is the domain actually pointing at the platform? ----------
export interface RoutingResolvers { cname: (name: string) => Promise<string[]>; a: (name: string) => Promise<string[]> }
const defaultRouting: RoutingResolvers = { cname: (n) => dns.resolveCname(n), a: (n) => dns.resolve4(n) };
export interface RoutingReport { points: "yes" | "no" | "unknown"; cname: string[]; a: string[] }
const norm = (s: string) => s.toLowerCase().replace(/\.$/, "");
const settle = async <T,>(p: Promise<T[]>): Promise<T[]> => { try { return await withTimeout(p, 4000); } catch { return []; } };

/**
 * Compares where the domain points with the addresses the agency configured (DOMAIN_CNAME_TARGET and/or DOMAIN_A_RECORD).
 * "unknown" means no target was configured, so there is nothing to compare with.
 */
export async function inspectRouting(env: Pick<Env, "DOMAIN_CNAME_TARGET" | "DOMAIN_A_RECORD">, hostname: string, r: RoutingResolvers = defaultRouting): Promise<RoutingReport> {
  const cname = (await settle(r.cname(hostname))).map(norm), a = await settle(r.a(hostname));
  const target = env.DOMAIN_CNAME_TARGET ? norm(env.DOMAIN_CNAME_TARGET) : "", fixedIp = env.DOMAIN_A_RECORD?.trim() ?? "";
  if (!target && !fixedIp) return { points: "unknown", cname, a };
  const targetIps = target ? await settle(r.a(target)) : [];
  const ok = (target && cname.includes(target)) || (fixedIp && a.includes(fixedIp)) || a.some((ip) => targetIps.includes(ip));
  return { points: ok ? "yes" : "no", cname, a };
}

/** Stores the result on a verified domain so the owner and the admin can see it. */
export async function checkRouting(control: Pool, env: Pick<Env, "DOMAIN_CNAME_TARGET" | "DOMAIN_A_RECORD">, tenantId: string | null, hostname: string, actor: string, r: RoutingResolvers = defaultRouting): Promise<{ ok: true; report: RoutingReport } | { ok: false; error: "unknown_domain" | "not_verified" | "too_soon" }> {
  const row = (await control.query(`SELECT id, status, tenant_id, last_checked_at FROM domains WHERE hostname = $1 AND status <> 'removed' ${tenantId ? "AND tenant_id = $2" : ""}`, tenantId ? [hostname, tenantId] : [hostname])).rows[0];
  if (!row) return { ok: false, error: "unknown_domain" };
  if (row.status !== "verified") return { ok: false, error: "not_verified" };
  if (row.last_checked_at && Date.now() - new Date(row.last_checked_at).getTime() < MIN_SECONDS_BETWEEN_CHECKS * 1000) return { ok: false, error: "too_soon" };
  const report = await inspectRouting(env, hostname, r);
  await control.query("UPDATE domains SET last_checked_at = now(), check_note = $2 WHERE id = $1", [row.id, `points_${report.points}`]);
  await audit(control, actor, "domain.routing.checked", row.tenant_id, { hostname, points: report.points });
  return { ok: true, report };
}

/** One list for the super panel: every domain with its client. */
export async function listAllDomains(control: Pool) {
  return (await control.query(
    `SELECT d.hostname, d.status, d.is_primary, d.verify_token, d.verified_at, d.last_checked_at, d.check_note, d.tenant_id, t.slug, t.business_name
       FROM domains d JOIN tenants t ON t.id = d.tenant_id WHERE d.status <> 'removed' ORDER BY (d.status = 'verified'), t.business_name, d.hostname LIMIT 500`)).rows as
    { hostname: string; status: string; is_primary: boolean; verify_token: string; verified_at: Date | null; last_checked_at: Date | null; check_note: string | null; tenant_id: string; slug: string; business_name: string }[];
}

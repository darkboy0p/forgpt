import pg from "pg";
import type { DatabaseProvider, EnsureDatabaseInput, EnsuredDatabase } from "./types";

/** DEV ONLY: creates real, separate databases on one local Postgres (Docker). */
export class LocalPostgresProvider implements DatabaseProvider {
  readonly name = "local-postgres";
  constructor(private readonly adminUrl: string) {}

  static databaseNameFor(tenantId: string, slug: string): string {
    // Derived only from server-side values, so the name is deterministic and safe to quote.
    return `tenant_${slug.replace(/-/g, "_")}_${tenantId.replace(/-/g, "").slice(0, 8)}`;
  }

  private urlFor(databaseName: string): string {
    const u = new URL(this.adminUrl);
    u.pathname = `/${databaseName}`;
    return u.toString();
  }

  async ensureDatabase({ tenantId, slug }: EnsureDatabaseInput): Promise<EnsuredDatabase> {
    const databaseName = LocalPostgresProvider.databaseNameFor(tenantId, slug);
    if (!/^[a-z0-9_]{1,63}$/.test(databaseName)) throw new Error("unsafe database name");
    const admin = new pg.Client({ connectionString: this.adminUrl });
    await admin.connect();
    try {
      const exists = await admin.query("SELECT 1 FROM pg_database WHERE datname = $1", [databaseName]);
      if (!exists.rowCount) {
        try {
          await admin.query(`CREATE DATABASE "${databaseName}"`);
        } catch (err) {
          // 42P04 = duplicate_database: another retry created it first. That's fine.
          if ((err as { code?: string }).code !== "42P04") throw err;
        }
      }
    } finally {
      await admin.end();
    }
    return { databaseName, connectionString: this.urlFor(databaseName) };
  }

  async dropDatabase(databaseName: string): Promise<void> {
    if (!/^tenant_[a-z0-9_]{1,56}$/.test(databaseName)) throw new Error("refusing to drop non-tenant database");
    const admin = new pg.Client({ connectionString: this.adminUrl });
    await admin.connect();
    try {
      await admin.query(`DROP DATABASE IF EXISTS "${databaseName}" WITH (FORCE)`);
    } finally {
      await admin.end();
    }
  }
}

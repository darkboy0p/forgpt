import type { Env } from "../../config/env";
import { LocalPostgresProvider } from "./localPostgres";
import type { DatabaseProvider } from "./types";

export function createProvider(env: Env): DatabaseProvider {
  switch (env.TENANT_DB_PROVIDER) {
    case "local-postgres":
      if (!env.PROVISIONER_ADMIN_URL) throw new Error("PROVISIONER_ADMIN_URL is required for local-postgres");
      return new LocalPostgresProvider(env.PROVISIONER_ADMIN_URL);
    case "neon":
    case "managed-postgres":
      // Deliberately NOT implemented yet. We will not pretend it works until it is built and tested.
      throw new Error(`Provider "${env.TENANT_DB_PROVIDER}" is not implemented yet (planned for a later phase).`);
  }
}
export type { DatabaseProvider } from "./types";

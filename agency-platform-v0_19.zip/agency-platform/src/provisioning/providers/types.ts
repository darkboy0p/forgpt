/**
 * The ONLY thing the rest of the app knows about "where tenant databases live".
 * Moving from local Docker -> Neon -> your own server means swapping the provider,
 * not rewriting the application.
 */
export interface EnsureDatabaseInput {
  tenantId: string;
  slug: string;
}
export interface EnsuredDatabase {
  databaseName: string;
  /** Full connection string for the tenant's OWN database. Stored encrypted; never sent to browsers. */
  connectionString: string;
}
export interface DatabaseProvider {
  readonly name: string;
  /** MUST be idempotent: calling twice for the same tenant returns the same database. */
  ensureDatabase(input: EnsureDatabaseInput): Promise<EnsuredDatabase>;
  /** Used only in tests / explicit, confirmed deletion flows. */
  dropDatabase(databaseName: string): Promise<void>;
}

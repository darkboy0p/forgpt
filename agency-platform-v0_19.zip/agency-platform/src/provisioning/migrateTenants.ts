import pg from "pg";
import type { Pool } from "pg";
import { decryptSecret } from "../crypto/secrets";
import { runMigrations } from "../db/migrate";
import { TENANT_MIGRATIONS_DIR } from "./provisionTenant";

export interface TenantMigrationReport { slug: string; applied: string[]; error?: string }

/**
 * Brings EVERY client database up to date. Safe to repeat. One client failing does not stop the others.
 * Run this after every update that adds a tenant migration (npm run db:migrate does it for you).
 */
export async function migrateAllTenants(control: Pool, masterKey: string): Promise<TenantMigrationReport[]> {
  const rows = (await control.query(
    `SELECT t.slug, d.tenant_id, d.conn_encrypted FROM tenant_databases d JOIN tenants t ON t.id = d.tenant_id
      WHERE t.status <> 'archived' ORDER BY t.slug`)).rows;
  const reports: TenantMigrationReport[] = [];
  for (const row of rows) {
    const pool = new pg.Pool({ connectionString: decryptSecret(row.conn_encrypted, masterKey), max: 1, connectionTimeoutMillis: 8000 });
    try {
      const applied = await runMigrations(pool, TENANT_MIGRATIONS_DIR);
      reports.push({ slug: row.slug, applied });
      if (applied.length) {
        const count = (await pool.query("SELECT count(*) AS c FROM schema_migrations")).rows[0].c as number;
        await control.query("UPDATE tenant_databases SET schema_version = $2 WHERE tenant_id = $1", [row.tenant_id, count]);
      }
    } catch (err) {
      reports.push({ slug: row.slug, applied: [], error: String((err as Error).message).slice(0, 200) });
    } finally { await pool.end().catch(() => {}); }
  }
  return reports;
}

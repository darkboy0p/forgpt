import "../db/pgTypes";
import pg from "pg";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import { join, dirname } from "node:path";
import type { Pool } from "pg";
import { encryptSecret, decryptSecret } from "../crypto/secrets";
import { runMigrations } from "../db/migrate";
import type { DatabaseProvider } from "./providers/types";
import { normalizeHostname } from "../tenancy/hostname";
import { redactSecrets } from "../util/redact";

import { TENANT_MIGRATIONS_DIR } from "../db/paths";
export { TENANT_MIGRATIONS_DIR };

export interface ProvisionInput {
  slug: string;
  businessName: string;
  packageTier: 1 | 2 | 3 | 4 | 5;
  templateKey: string;
  /** Optional: registered as PENDING. Verification is a separate, explicit step. */
  hostname?: string;
}
export interface ProvisionResult {
  tenantId: string;
  databaseName: string;
  steps: string[];
  verifyToken?: string;
}

const DEFAULT_SITE_CONFIG = { theme: { primary: "#1f6feb" }, sections: ["hero", "about", "contact"] };

/** Idempotent: safe to retry after any failure. */
export async function provisionTenant(
  control: Pool,
  provider: DatabaseProvider,
  masterKey: string,
  input: ProvisionInput
): Promise<ProvisionResult> {
  const steps: string[] = [];
  const log = async (tenantId: string, step: string, status: "done" | "failed", detail?: string) => {
    await control.query("INSERT INTO provisioning_jobs (tenant_id, step, status, detail) VALUES ($1,$2,$3,$4)", [
      tenantId, step, status, detail ?? null,
    ]);
  };

  // Validate the domain first so a bad value creates nothing.
  const requestedHost = input.hostname ? normalizeHostname(input.hostname) : null;
  if (input.hostname && !requestedHost) throw new Error("invalid hostname");

  // 1. Register tenant (no duplicates on retry). The requested domain is remembered for retries.
  await control.query(
    `INSERT INTO tenants (slug, business_name, package_tier, template_key, requested_hostname)
     VALUES ($1,$2,$3,$4,$5) ON CONFLICT (slug) DO NOTHING`,
    [input.slug, input.businessName, input.packageTier, input.templateKey, requestedHost]
  );
  const t = await control.query("SELECT id, status FROM tenants WHERE slug = $1", [input.slug]);
  const tenantId: string = t.rows[0].id;
  steps.push("tenant-registered");

  let currentStep = "database";
  try {
    // 2. Create (or find) the tenant's own database
    let row = (await control.query("SELECT database_name, conn_encrypted FROM tenant_databases WHERE tenant_id = $1", [tenantId])).rows[0];
    if (!row) {
      const ensured = await provider.ensureDatabase({ tenantId, slug: input.slug });
      await control.query(
        `INSERT INTO tenant_databases (tenant_id, provider, database_name, conn_encrypted)
         VALUES ($1,$2,$3,$4) ON CONFLICT (tenant_id) DO NOTHING`,
        [tenantId, provider.name, ensured.databaseName, encryptSecret(ensured.connectionString, masterKey)]
      );
      row = (await control.query("SELECT database_name, conn_encrypted FROM tenant_databases WHERE tenant_id = $1", [tenantId])).rows[0];
    }
    steps.push("database-ready");
    await log(tenantId, "database", "done");

    // 3. Migrations + default config inside the tenant's own database
    currentStep = "migrations";
    const tenantPool = new pg.Pool({ connectionString: decryptSecret(row.conn_encrypted, masterKey), max: 1 });
    try {
      const applied = await runMigrations(tenantPool, TENANT_MIGRATIONS_DIR);
      await tenantPool.query(
        "INSERT INTO site_config (id, schema_version, config) VALUES (1, 1, $1) ON CONFLICT (id) DO NOTHING",
        [JSON.stringify(DEFAULT_SITE_CONFIG)]
      );
      const migrationCount = (await tenantPool.query("SELECT count(*) AS c FROM schema_migrations")).rows[0].c as number;
      await control.query("UPDATE tenant_databases SET schema_version = $2 WHERE tenant_id = $1", [tenantId, migrationCount]);
      steps.push(applied.length ? "migrations-applied" : "migrations-already-applied");
      await log(tenantId, "migrations", "done");
    } finally {
      await tenantPool.end();
    }

    // 4. Domain (pending only)
    currentStep = "domain";
    let verifyToken: string | undefined;
    if (input.hostname) {
      const host = normalizeHostname(input.hostname);
      if (!host) throw new Error("invalid hostname");
      const token = randomBytes(16).toString("hex");
      await control.query(
        "INSERT INTO domains (tenant_id, hostname, verify_token, is_primary) VALUES ($1,$2,$3,true) ON CONFLICT (hostname) DO NOTHING",
        [tenantId, host, token]
      );
      const d = (await control.query("SELECT tenant_id, verify_token FROM domains WHERE hostname = $1", [host])).rows[0];
      if (d.tenant_id !== tenantId) throw new Error(`hostname ${host} already belongs to another tenant`);
      verifyToken = d.verify_token;
      steps.push("domain-registered-pending");
      await log(tenantId, "domain", "done");
    }

    // 5. Activate (domain verification is a separate gate before the site is publicly resolvable)
    await control.query("UPDATE tenants SET status = 'active' WHERE id = $1 AND status IN ('provisioning','failed')", [tenantId]);
    steps.push("tenant-active");
    return { tenantId, databaseName: row.database_name, steps, verifyToken };
  } catch (err) {
    await control.query("UPDATE tenants SET status = 'failed' WHERE id = $1 AND status = 'provisioning'", [tenantId]);
    await log(tenantId, currentStep, "failed", redactSecrets((err as Error).message));
    throw err;
  }
}

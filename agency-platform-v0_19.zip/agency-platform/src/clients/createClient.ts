import type { Pool } from "pg";
import { provisionTenant } from "../provisioning/provisionTenant";
import type { DatabaseProvider } from "../provisioning/providers/types";
import { normalizeHostname } from "../tenancy/hostname";
import { isTemplateBuilt, templateMinTier } from "../config/templates";

export type CreateClientError =
  | "invalid_name" | "invalid_slug" | "slug_taken" | "invalid_tier" | "template_unavailable" | "template_tier_mismatch" | "invalid_host" | "host_taken";
export type CreateClientResult =
  | { ok: true; slug: string; tenantId: string }
  | { ok: false; error: CreateClientError }
  | { ok: false; error: "provision_failed"; slug: string };

export interface CreateClientInput { businessName: string; slug: string; packageTier: number; templateKey: string; hostname?: string }

const SLUG_RE = /^[a-z0-9][a-z0-9-]{1,40}$/; // same rule as the database CHECK

const audit = (control: Pool, actor: string, action: string, tenantId: string | null, detail: object) =>
  control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,$2,$3,$4)", [actor, action, tenantId, JSON.stringify(detail)]);

/** Validates everything BEFORE touching the database, so a bad request creates nothing. */
export async function createClient(
  control: Pool, provider: DatabaseProvider, masterKey: string, input: CreateClientInput, actor: string
): Promise<CreateClientResult> {
  const businessName = String(input.businessName ?? "").trim();
  const slug = String(input.slug ?? "").trim().toLowerCase();
  if (businessName.length < 2 || businessName.length > 80 || /[\u0000-\u001f<>]/.test(businessName)) return { ok: false, error: "invalid_name" };
  if (!SLUG_RE.test(slug) || slug.endsWith("-")) return { ok: false, error: "invalid_slug" };
  if (!Number.isInteger(input.packageTier) || input.packageTier < 1 || input.packageTier > 5) return { ok: false, error: "invalid_tier" };
  if (!isTemplateBuilt(String(input.templateKey))) return { ok: false, error: "template_unavailable" };
  if (templateMinTier(String(input.templateKey)) > input.packageTier) return { ok: false, error: "template_tier_mismatch" };

  let hostname: string | undefined;
  if (input.hostname && input.hostname.trim()) {
    const h = normalizeHostname(input.hostname);
    if (!h) return { ok: false, error: "invalid_host" };
    hostname = h;
  }
  if ((await control.query("SELECT 1 FROM tenants WHERE slug = $1", [slug])).rowCount) return { ok: false, error: "slug_taken" };
  if (hostname && (await control.query("SELECT 1 FROM domains WHERE hostname = $1", [hostname])).rowCount) return { ok: false, error: "host_taken" };

  try {
    const r = await provisionTenant(control, provider, masterKey, {
      slug, businessName, packageTier: input.packageTier as 1 | 2 | 3 | 4 | 5, templateKey: input.templateKey, hostname,
    });
    await audit(control, actor, "client.created", r.tenantId, { slug, packageTier: input.packageTier, templateKey: input.templateKey, hostname: hostname ?? null });
    return { ok: true, slug, tenantId: r.tenantId };
  } catch {
    await audit(control, actor, "client.create.failed", null, { slug });
    return { ok: false, error: "provision_failed", slug };
  }
}

export type RetryResult = { ok: true } | { ok: false; error: "not_found" | "not_retryable" | "provision_failed" };

/** Safe to repeat: provisioning is idempotent, so a retry finishes what is missing and creates nothing twice. */
export async function retryProvisioning(
  control: Pool, provider: DatabaseProvider, masterKey: string, slug: string, actor: string
): Promise<RetryResult> {
  const t = await control.query(
    `SELECT t.id, t.slug, t.business_name, t.package_tier, t.template_key, t.status,
            COALESCE((SELECT hostname FROM domains d WHERE d.tenant_id = t.id AND d.is_primary), t.requested_hostname) AS hostname
       FROM tenants t WHERE t.slug = $1`, [slug]);
  const row = t.rows[0];
  if (!row) return { ok: false, error: "not_found" };
  if (row.status !== "failed" && row.status !== "provisioning") return { ok: false, error: "not_retryable" };
  try {
    await provisionTenant(control, provider, masterKey, {
      slug: row.slug, businessName: row.business_name, packageTier: row.package_tier, templateKey: row.template_key, hostname: row.hostname ?? undefined,
    });
    await audit(control, actor, "client.provision.retried", row.id, { slug });
    return { ok: true };
  } catch {
    await audit(control, actor, "client.provision.retry.failed", row.id, { slug });
    return { ok: false, error: "provision_failed" };
  }
}

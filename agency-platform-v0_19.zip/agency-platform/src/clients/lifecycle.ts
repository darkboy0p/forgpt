import type { Pool } from "pg";

export type LifecycleError = "not_found" | "reason_required" | "not_active" | "not_suspended";
export type LifecycleResult = { ok: true; tenantId: string } | { ok: false; error: LifecycleError };

const audit = (control: Pool, actor: string, action: string, tenantId: string, detail: object) =>
  control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,$2,$3,$4)", [actor, action, tenantId, JSON.stringify(detail)]);

/**
 * Stops a client's website from being served. NOTHING is deleted: the database, domain, billing records and
 * settings all stay, and reactivating restores the site exactly as it was.
 */
export async function suspendClient(control: Pool, slug: string, reasonRaw: unknown, actor: string): Promise<LifecycleResult> {
  const reason = String(reasonRaw ?? "").trim().slice(0, 300);
  if (!reason) return { ok: false, error: "reason_required" };
  const r = await control.query(
    "UPDATE tenants SET status='suspended', suspended_reason=$2, suspended_at=now() WHERE slug=$1 AND status='active' RETURNING id", [slug, reason]);
  if (r.rows[0]) {
    await audit(control, actor, "client.suspended", r.rows[0].id, { slug, reason });
    return { ok: true, tenantId: r.rows[0].id };
  }
  const exists = await control.query("SELECT 1 FROM tenants WHERE slug = $1", [slug]);
  return { ok: false, error: exists.rowCount ? "not_active" : "not_found" };
}

export async function reactivateClient(control: Pool, slug: string, actor: string): Promise<LifecycleResult> {
  const r = await control.query(
    "UPDATE tenants SET status='active', suspended_reason=NULL, suspended_at=NULL WHERE slug=$1 AND status='suspended' RETURNING id", [slug]);
  if (r.rows[0]) {
    await audit(control, actor, "client.reactivated", r.rows[0].id, { slug });
    return { ok: true, tenantId: r.rows[0].id };
  }
  const exists = await control.query("SELECT 1 FROM tenants WHERE slug = $1", [slug]);
  return { ok: false, error: exists.rowCount ? "not_suspended" : "not_found" };
}

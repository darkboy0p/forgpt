import "../db/pgTypes";
import type { Pool } from "pg";
import type { TenantConnectionManager } from "../tenancy/connectionManager";
import { PACKAGE_NAMES } from "../config/templates";

export const MAX_EXPORT_ROWS = 100_000;
export const MAX_EXPORT_BYTES = 50 * 1024 * 1024;

export type ExportError = "not_found" | "no_database" | "too_large" | "failed";
export type ExportResult =
  | { ok: true; filename: string; json: string; tables: Record<string, number> }
  | { ok: false; error: ExportError };

// Never leave the building: credentials, sessions and reset tokens. Customer login hashes are not handed over either.
const SKIP_TABLES = /^(schema_migrations|sessions?|password_resets?|api_keys?|secrets?)$/i;
const REDACT_COLUMNS = /(password|passwd|hash|token|secret|api_?key)/i;

const quoteIdent = (n: string) => `"${n.replace(/"/g, '""')}"`;

/**
 * Builds a handover file of ONE client's own data (read from that client's separate database).
 * It deliberately excludes the agency's private records: prices, invoices, payments, notes and connection details.
 * Works for suspended clients too. For very large stores a full database dump (pg_dump) is the right tool instead.
 */
export async function exportClientData(control: Pool, mgr: TenantConnectionManager, slug: string, now = new Date()): Promise<ExportResult> {
  const t = (await control.query(
    `SELECT t.id, t.slug, t.business_name, t.template_key, t.package_tier, t.status, t.created_at FROM tenants t WHERE t.slug = $1`, [slug])).rows[0];
  if (!t) return { ok: false, error: "not_found" };
  const hasDb = (await control.query("SELECT 1 FROM tenant_databases WHERE tenant_id = $1", [t.id])).rowCount;
  if (!hasDb) return { ok: false, error: "no_database" };
  const domains = (await control.query("SELECT hostname, status, is_primary FROM domains WHERE tenant_id = $1 ORDER BY is_primary DESC, hostname", [t.id])).rows;

  try {
    const tables: Record<string, { columns: string[]; rows: unknown[] }> = {};
    const counts: Record<string, number> = {};
    await mgr.withAdminPool(t.id, async (pool) => {
      const names: string[] = (await pool.query(
        "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE' ORDER BY table_name")).rows.map((r) => r.table_name);
      const wanted = names.filter((n) => !SKIP_TABLES.test(n));
      let total = 0;
      for (const n of wanted) total += (await pool.query(`SELECT count(*) AS c FROM ${quoteIdent(n)}`)).rows[0].c as number;
      if (total > MAX_EXPORT_ROWS) throw new RangeError("too_large");
      for (const n of wanted) {
        const res = await pool.query(`SELECT * FROM ${quoteIdent(n)}`);
        const cols = res.fields.map((f) => f.name);
        const redact = new Set(cols.filter((c) => REDACT_COLUMNS.test(c)));
        tables[n] = { columns: cols, rows: res.rows.map((row) => Object.fromEntries(cols.map((c) => [c, redact.has(c) ? "[not exported]" : row[c]]))) };
        counts[n] = res.rowCount ?? 0;
      }
    });
    const json = JSON.stringify({
      format: "agency-platform-client-export", format_version: 1, exported_at: now.toISOString(),
      client: { name: t.business_name, slug: t.slug, template: t.template_key, package: PACKAGE_NAMES[t.package_tier] ?? `Tier ${t.package_tier}`, status: t.status, created_at: t.created_at,
        domains: domains.map((d) => ({ hostname: d.hostname, status: d.status, primary: d.is_primary })) },
      tables,
    }, null, 2);
    if (Buffer.byteLength(json) > MAX_EXPORT_BYTES) return { ok: false, error: "too_large" };
    return { ok: true, filename: `${t.slug}-export-${now.toISOString().slice(0, 10)}.json`, json, tables: counts };
  } catch (err) {
    if (err instanceof RangeError) return { ok: false, error: "too_large" };
    console.error("[export] failed:", (err as Error).message);
    return { ok: false, error: "failed" };
  }
}

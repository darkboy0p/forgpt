import type { Pool } from "pg";
import { getEntitlements } from "../packages/resolve";
import { TenantConnectionManager } from "../tenancy/connectionManager";
import { loadEditorState, saveDraft } from "../store/siteEditor";
import { applyTemplateLook } from "../config/templateLooks";
import { isTemplateBuilt, type TemplateKey } from "../config/templates";

/** Gives a client's DRAFT the starting look of its template (sections, colours, layout). Nothing is published and no content is changed. */
export async function applyTemplateLookToClient(control: Pool, mgr: TenantConnectionManager, slug: string, actor: string): Promise<{ ok: true } | { ok: false; error: "not_found" | "template_unavailable" }> {
  const t = (await control.query("SELECT id, package_tier, template_key FROM tenants WHERE slug = $1", [slug])).rows[0];
  if (!t) return { ok: false, error: "not_found" };
  if (!isTemplateBuilt(t.template_key)) return { ok: false, error: "template_unavailable" };
  const ent = await getEntitlements(control, t.package_tier);
  const pool = await mgr.getPool(t.id);
  const state = await loadEditorState(pool);
  const next = applyTemplateLook(state.draft ?? state.live, t.template_key as TemplateKey, { sections: ent.sections, branding: ent.branding, layout: ent.layout });
  await saveDraft(pool, next, actor);
  await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,'client.template.look_applied',$2,$3)", [actor, t.id, JSON.stringify({ slug, template: t.template_key })]);
  return { ok: true };
}

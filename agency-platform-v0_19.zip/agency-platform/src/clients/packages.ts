import type { Pool } from "pg";
import { isTemplateBuilt, templateMinTier } from "../config/templates";

export type ChangePackageError = "not_found" | "invalid_tier" | "template_unavailable" | "template_tier_mismatch" | "downgrade_needs_confirmation" | "unchanged";
export type ChangePackageResult = { ok: true; downgrade: boolean; from: { tier: number; template: string } } | { ok: false; error: ChangePackageError };

/**
 * Upgrade or downgrade a client. The client's content is NEVER deleted: features outside the new package simply stop being
 * shown until it is upgraded again. A downgrade needs an explicit confirmation. Prices are changed separately (billing).
 */
export async function changePackage(control: Pool, slug: string, tier: number, templateKey: string, confirmDowngrade: boolean, actor: string): Promise<ChangePackageResult> {
  if (!Number.isInteger(tier) || tier < 1 || tier > 5) return { ok: false, error: "invalid_tier" };
  if (!isTemplateBuilt(templateKey)) return { ok: false, error: "template_unavailable" };
  if (templateMinTier(templateKey) > tier) return { ok: false, error: "template_tier_mismatch" };
  const t = (await control.query("SELECT id, package_tier, template_key FROM tenants WHERE slug = $1", [slug])).rows[0];
  if (!t) return { ok: false, error: "not_found" };
  if (t.package_tier === tier && t.template_key === templateKey) return { ok: false, error: "unchanged" };
  const downgrade = tier < t.package_tier;
  if (downgrade && !confirmDowngrade) return { ok: false, error: "downgrade_needs_confirmation" };
  await control.query("UPDATE tenants SET package_tier = $2, template_key = $3 WHERE id = $1", [t.id, tier, templateKey]);
  await control.query("INSERT INTO audit_log (actor, action, tenant_id, detail) VALUES ($1,'client.package.changed',$2,$3)",
    [actor, t.id, JSON.stringify({ slug, from: { tier: t.package_tier, template: t.template_key }, to: { tier, template: templateKey }, downgrade })]);
  return { ok: true, downgrade, from: { tier: t.package_tier, template: t.template_key } };
}

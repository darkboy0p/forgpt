import { defineConfig } from "vitest/config";

// Password hashing and database setup are deliberately slow on small computers, so allow generous time.
export default defineConfig({ test: { testTimeout: 60_000, hookTimeout: 180_000 } });
